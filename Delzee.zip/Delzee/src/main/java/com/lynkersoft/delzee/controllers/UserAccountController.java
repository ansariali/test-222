package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/userController")
public class UserAccountController {
    Logger LOG = LoggerFactory.getLogger(UserAccountController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/v1/fetchAll/{userId}")
    public Flux<Product> fetchAllDetailById(@PathVariable String userId) {
        LOG.info("Inside fetchAllDetailById :");
        return userService.fetchAllDetails(userId);
    }

    @PostMapping("/v1/signUp")
    public Object signUp(@Valid @RequestBody UserAccount userAccount) {
        LOG.info("Inside signUp :");
        return userService.save(userAccount);
    }

    @PostMapping("/v1/blogging/save/{userId}")
    public Mono<Blogging> saveBlogging(@Valid @PathVariable String userId, @RequestBody Blogging blogging) {
        LOG.info("Inside saveBlogging :");
        return userService.saveBlogging(userId, blogging);
    }

    @PostMapping("/v1/comment/save/{userId}")
    public Object saveComment(@Valid @PathVariable String userId, @RequestBody Comment comment) {
        LOG.info("Inside saveComment :");
        return userService.saveComment(userId, comment);
    }

    @PostMapping("/v1/like/save/{userId}")
    public Mono<Like> saveLike(@Valid @PathVariable String userId, @RequestBody Like like) {
        LOG.info("Inside saveBlogging :");
        return userService.saveLike(userId, like);
    }

    @PostMapping("/v1/product/save/{userId}")
    public Object saveProduct(@Valid @PathVariable String userId, @RequestBody Product product) {
        LOG.info("Inside saveProduct :");
        return userService.saveProduct(userId, product);
    }

    @GetMapping("/v1/fetchAll")
    public Flux<UserAccount> getAll() {
        LOG.info(" Inside getAll :");
        String id = null;
        return userService.fetchAllUser(id);
    }

    @GetMapping("/v1/fetchById/{userId}")
    public Mono<UserAccount> getById(@PathVariable String userId) {
        LOG.info("Inside getUserById :");
        return userService.findId(userId);
    }

    @DeleteMapping("/v1/delete/{userId}")
    public Object delete(@PathVariable String userId) {
        LOG.info("Inside delete :");
        return userService.delete(userId);
    }

}
