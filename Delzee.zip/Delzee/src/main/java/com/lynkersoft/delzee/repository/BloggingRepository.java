package com.lynkersoft.delzee.repository;

import com.lynkersoft.delzee.entities.Blogging;
import com.lynkersoft.delzee.entities.Product;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface BloggingRepository extends ReactiveMongoRepository<Blogging, String> {
}
