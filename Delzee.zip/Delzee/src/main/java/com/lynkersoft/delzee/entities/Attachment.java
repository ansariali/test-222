package com.lynkersoft.delzee.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "attachment")
public class Attachment {
    @Id
    private String attachmentId;
    private String description;
    private Blogging bloggingId;

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Blogging getBloggingId() {
        return bloggingId;
    }

    public void setBloggingId(Blogging bloggingId) {
        this.bloggingId = bloggingId;
    }
}
