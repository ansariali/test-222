package com.lynkersoft.delzee.repository;

import com.lynkersoft.delzee.entities.Comment;
import com.lynkersoft.delzee.entities.Like;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface LikeRepository extends ReactiveMongoRepository<Like, String> {
}
