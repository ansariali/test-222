package com.lynkersoft.delzee.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "comment")
public class Comment {
    @Id
    private String commentId;
    private String title;
    private String description;

    private String bloggingId;
    private WatcherEntity watcherEntity;

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBloggingId() {
        return bloggingId;
    }

    public void setBloggingId(String bloggingId) {
        this.bloggingId = bloggingId;
    }

    public WatcherEntity getWatcherEntity() {
        return watcherEntity;
    }

    public void setWatcherEntity(WatcherEntity watcherEntity) {
        this.watcherEntity = watcherEntity;
    }
}
