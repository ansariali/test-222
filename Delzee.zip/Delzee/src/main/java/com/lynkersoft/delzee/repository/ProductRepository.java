package com.lynkersoft.delzee.repository;

import com.lynkersoft.delzee.entities.Product;
import com.lynkersoft.delzee.entities.UserAccount;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface ProductRepository extends ReactiveMongoRepository<Product, String> {
}
