package com.lynkersoft.delzee.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "like")
public class Like {
    @Id
    private String likeId;
    private String description;
    private String bloggingId;
    private Boolean isLike = Boolean.FALSE;
    private WatcherEntity watcherEntity;

    public String getLikeId() {
        return likeId;
    }

    public void setLikeId(String likeId) {
        this.likeId = likeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBloggingId() {
        return bloggingId;
    }

    public void setBloggingId(String bloggingId) {
        this.bloggingId = bloggingId;
    }

    public WatcherEntity getWatcherEntity() {
        return watcherEntity;
    }

    public Boolean getLike() {
        return isLike;
    }

    public void setLike(Boolean like) {
        isLike = like;
    }

    public void setWatcherEntity(WatcherEntity watcherEntity) {
        this.watcherEntity = watcherEntity;
    }
}
