package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface UserService {
    Mono<UserAccount> findId(String id);
    Flux<Product> fetchAllDetails(String uerId);
    Mono<UserAccount> save(UserAccount user);
    Mono<Product> saveProduct(String id , Product product);
    Mono<Blogging> saveBlogging(String id , Blogging blogging);
    Mono<Comment> saveComment(String id , Comment comment);
    Mono<Like> saveLike(String id , Like comment);
    Flux<UserAccount> fetchAllUser(String id);
    Mono<Void> delete(String id);
}
