package com.lynkersoft.delzee.repository;

import com.lynkersoft.delzee.entities.Blogging;
import com.lynkersoft.delzee.entities.Comment;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface CommentRepository extends ReactiveMongoRepository<Comment, String> {
}
