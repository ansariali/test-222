package com.lynkersoft.delzee.common;

public enum OperationStatus {
    CREATE, UPDATE, DELETE;

}
