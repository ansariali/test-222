package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.common.OperationStatus;
import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.repository.*;
import com.lynkersoft.delzee.service.UserService;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Variable;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
    ReactiveMongoTemplate reactiveMongoTemplate;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private BloggingRepository bloggingRepository;
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private LikeRepository likeRepository;

    @Override
    public Mono<Like> saveLike(String id, Like like) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount userAccount = mongoTemplate.findOne(query, UserAccount.class);
        if (userAccount == null) {
            System.out.println("User Account Not found in Like !!!");
            return null;
        }

        Query query1 = new Query();
        query1.addCriteria(Criteria.where("bloggingId").is(like.getBloggingId()));
        Blogging likes = mongoTemplate.findOne(query1, Blogging.class);
        if (likes == null) {
            System.out.println("Like Not found !!!");
            return null;
        }

        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(userAccount.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setUserId(userAccount.getUserId());
        like.setWatcherEntity(watcherEntity);
        like.setBloggingId(like.getBloggingId());
        like.setLike(Boolean.TRUE);
        return likeRepository.save(like);

    }

    @Override
    public Mono<Comment> saveComment(String id, Comment comment) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount userAccount = mongoTemplate.findOne(query, UserAccount.class);
        if (userAccount == null) {
            System.out.println("User Account Not found in Comment !!!");
            return null;
        }

        Query queryBlogging = new Query();
        queryBlogging.addCriteria(Criteria.where("bloggingId").is(comment.getBloggingId()));
        Blogging blogging = mongoTemplate.findOne(queryBlogging, Blogging.class);
        if (blogging == null) {
            System.out.println("Comment Not found !!!");
            return null;
        }

        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(userAccount.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setUserId(userAccount.getUserId());
        comment.setWatcherEntity(watcherEntity);
        comment.setBloggingId(comment.getBloggingId());
        return commentRepository.save(comment);
    }

    @Override
    public Mono<Blogging> saveBlogging(String id, Blogging blogging) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount userAccount = mongoTemplate.findOne(query, UserAccount.class);
        if (userAccount == null) {
            System.out.println("User Account Not found in Blogging !!!");
            return null;
        }

        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(userAccount.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setUserId(userAccount.getUserId());
        blogging.setWatcherEntity(watcherEntity);
        blogging.setBloggingId(blogging.getBloggingId());
        return bloggingRepository.save(blogging);
    }

    @Override
    public Flux<Product> fetchAllDetails(String uerId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(uerId));
        return reactiveMongoTemplate.find(query, Product.class);
    }

    @Override
    public Mono<Void> delete(String id) {
        return userRepository.deleteById(id);
    }

    @Override
    public Flux<UserAccount> fetchAllUser(String id) {

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("Department")
                .localField("dept_id")
                .foreignField("_id")
                .as("departments");
        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("_id").is("1")), lookupOperation);
        List<UserAccount> results = mongoTemplate.aggregate(aggregation, "Employee", UserAccount.class).getMappedResults();
//        LOGGER.info("Obj Size " +results.size());

        return userRepository.findAll();
    }

    @Override
    public Mono<Product> saveProduct(String id, Product product) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount userAccount = mongoTemplate.findOne(query, UserAccount.class);
        if (userAccount == null) {
            System.out.println("User Account Not found !!!");
            return null;
        }
        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(userAccount.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setUserId(userAccount.getUserId());
        product.setWatcherEntity(watcherEntity);
        product.setUserId(userAccount.getUserId());

        return productRepository.save(product);
    }

    @Override
    public Mono<UserAccount> save(UserAccount user) {
        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(user.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        user.setWatcherEntity(watcherEntity);
        return userRepository.save(user);
    }

    @Override
    public Mono<UserAccount> findId(String id) {
        Mono<UserAccount> userAccountMono = userRepository.findById(id).switchIfEmpty(Mono.error(new Exception("User Not Found: ")));
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        System.out.println("Id find :" + mongoTemplate.findOne(query, UserAccount.class));

    /*  System.out.println("Aggregatea"+  Aggregates.lookup("UserAccount",
                Arrays.asList(new Variable("userId", id), new Variable("userId", id)), Aggregates.match(Filters.gt("age", 42)), "outputField"));

*/
        return userAccountMono;
    }
}
