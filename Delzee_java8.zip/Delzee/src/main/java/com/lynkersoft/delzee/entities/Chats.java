package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;

@Entity
@Table(name = "chats")
public class Chats  extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatId;

    private String message;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender")
    private UserAccount sender;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver")
    private UserAccount receiver;


}
