package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "forgot_password")
public class ForgotPassword extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long forgotPasswordId;

    @Email
    @NotNull(message = "emailAddress must be required!")
    private String emailAddress;

    @NotNull(message = "otpCode must be required!")
    private String otpCode;

    @NotNull(message = "forgotToken must be required!")
    private String forgotToken;

    @NotNull(message = "forgoted must be required!")
    private Boolean forgoted;

    private Date forgotedOn;

    private Date created;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount creator;

    public UserAccount getCreator() {
        return creator;
    }

    public void setCreator(UserAccount creator) {
        this.creator = creator;
    }

    public Long getForgotPasswordId() {
        return forgotPasswordId;
    }

    public void setForgotPasswordId(Long forgotPasswordId) {
        this.forgotPasswordId = forgotPasswordId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }

    public String getForgotToken() {
        return forgotToken;
    }

    public void setForgotToken(String forgotToken) {
        this.forgotToken = forgotToken;
    }

    public Boolean getForgoted() {
        return forgoted;
    }

    public void setForgoted(Boolean forgoted) {
        this.forgoted = forgoted;
    }

    public Date getForgotedOn() {
        return forgotedOn;
    }

    public void setForgotedOn(Date forgotedOn) {
        this.forgotedOn = forgotedOn;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
