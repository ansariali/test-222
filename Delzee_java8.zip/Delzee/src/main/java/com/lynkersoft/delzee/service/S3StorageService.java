package com.lynkersoft.delzee.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;


public interface S3StorageService {
    String uploadFile(String prefix, MultipartFile multipartFile) throws IOException;

    File convertMultiPartToFile(MultipartFile file) throws IOException;

    String generateFileKey(String prefix, MultipartFile multiPart);

}
