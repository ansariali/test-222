package com.lynkersoft.delzee.utils.enums;

public enum  WebSocketType {
    NOTIFICATION, BLOG, COMMENT, LIKE
}
