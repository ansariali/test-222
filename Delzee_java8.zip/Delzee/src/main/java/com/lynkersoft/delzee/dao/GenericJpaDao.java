package com.lynkersoft.delzee.dao;

import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

//import javax.transaction.Transactional;

@SuppressWarnings({"unchecked", "hiding"})
@Service
@Transactional
public class GenericJpaDao<E extends IEntity, K extends Serializable> implements IDao<E, K> {

    protected EntityManager entityManager;

    /**
     * Get entity manager.
     *
     * @return entity manager
     */
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    /**
     * Set entity manager.
     *
     * @param entityManager
     */
    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public Long persist(E entity) {
        if (entity.getDeleted() == null) {
            entity.setVersion(1L);
            entity.setDeleted(Boolean.FALSE);
        }

        Long pKey = null;

        try {
            entityManager.persist(entity);
            pKey = (Long) entityManager.getEntityManagerFactory().getPersistenceUnitUtil().getIdentifier(entity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pKey;
    }

    @Override
    @Transactional
    public Long merge(E entity) {
        if (entity.getDeleted() == null) {
            entity.setVersion(1L);
            entity.setDeleted(Boolean.FALSE);
        }
        Long pkey = null;
        entityManager.merge(entity);
        pkey = (Long) entityManager.getEntityManagerFactory().getPersistenceUnitUtil().getIdentifier(entity);
        return pkey;
    }

    @Override
    public <E extends IEntity> E authorization(Class<E> entityClass, String userName, String password) {
        Object result;

        Query qry = entityManager.createQuery("SELECT o FROM " + entityClass.getSimpleName() + " o where (o.emailAddress = :emailAddress OR o.userName = :username) AND o.password = :password and o.userEnabled IS TRUE and o.isCustomVendor IS FALSE ");
        qry.setParameter("username", userName);
        qry.setParameter("emailAddress", userName);
        qry.setParameter("password", password);

        try {
            result = qry.getResultList();
        } catch (NoResultException e) {
            e.printStackTrace();
            return null;
        }

        if (result != null && ((List<E>) result).size() > 0) {
            return (E) (((List<E>) result).get(0));
        } else {
            return null;
        }
    }

    @Override
    @Transactional
    public <E extends IEntity> E update(E entity) {
        if (entity.getDeleted() == null) {
            entity.setDeleted(Boolean.FALSE);
        }

        entity.setVersion(entity.getVersion() + 1);

        return entityManager.merge(entity);
    }

    @Override
    @Transactional
    public int update(String query, Hashtable<String, Object> criteria, boolean deleted) {

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            return qry.executeUpdate();
        } catch (NoResultException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public <E extends IEntity> List<E> findAll(Class<E> entityClass, boolean deleted) {
        return findAll(entityClass, deleted, null);
    }

    @Override
    public <E extends IEntity> List<E> findAll(Class<E> entityClass, boolean deleted, String orderby) {
        Entity entity = entityClass.getAnnotation(Entity.class);
        String entityClsName = entityClass.getSimpleName();
        if (entity != null) {
            String eName = entity.name();
            if (eName != null && eName.length() > 0) {
                entityClsName = eName;
            }
        }

        String sQuery = "SELECT instance FROM " + entityClsName + " instance where instance.deleted";
        if (deleted) {
            sQuery = sQuery + " IS true";
        } else {
            sQuery = sQuery + " IS NOT true";
        }

        Query query = entityManager.createQuery(sQuery);
        return (List<E>) query.getResultList();
    }

    @Override
    public <E extends IEntity> E find(Class<E> entityClass, K pkey) {
        return entityManager.find(entityClass, pkey);
    }

    @Override
    public <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> elementClass, String query, Hashtable<String, Object> criteria, boolean deleted) {
        Object result;

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createQuery(query);

        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException e) {
            e.printStackTrace();
            return null;
        }

        return (List<E>) result;
    }

    @Override
    public <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> elementClass, String query, Hashtable<String, Object> criteria, boolean deleted, String orderBy) {
        Object result;

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        if (orderBy != null) {
            if (orderBy.split(" ").length == 1) {
                query = query + " ORDER BY o.created " + orderBy;
            } else {
                query = query + " ORDER BY " + orderBy;
            }
        }

        Query qry = entityManager.createQuery(query);

        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException e) {
            e.printStackTrace();
            return null;
        }

        return (List<E>) result;
    }

    @Override
    public <E extends IEntity, obj> List<E> getEntities(Class<E> entityClass, String query, Hashtable<String, Object> criteria) {
        Object result;

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException e) {
            e.printStackTrace();
            return null;
        }

        return (List<E>) result;
    }

    @Override
    public <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> elementClass, String query, boolean deleted) {
        Object result;

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createNamedQuery(query);

        try {
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }

        return (List<E>) result;
    }

    @Override
    public <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> elementClass, String query, Hashtable<String, Object> criteria, Integer pageNumber, Integer pageSize) {
        Object result;

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            qry = qry.setFirstResult(pageSize * (pageNumber - 1));
            qry.setMaxResults(pageSize);
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }

        return (List<E>) result;
    }

    @Override
    public List<Object> getData(String query, Hashtable<String, Object> criteria, boolean deleted) {
        List<Object> result = new ArrayList<>();

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }
        return (List<Object>) result;
    }

    @Override
    public <E extends IEntity, obj> E getEntity(Class<E> entityClass, String query, Hashtable<String, Object> criteria) {
        Object result;

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }

        if (result != null && ((List<E>) result).size() > 0) {
            return (E) (((List<E>) result).get(0));
        } else {
            return null;
        }
    }

    @Override
    public <E extends IEntity, obj> E getEntity(Class<E> elementClass, String query, Hashtable<String, Object> criteria, boolean deleted) {
        Object result;

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createQuery(query);
        Enumeration<String> keys = criteria.keys();

        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            qry.setParameter(key, criteria.get(key));
        }

        try {
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }

        if (result != null && ((List<E>) result).size() > 0) {
            return (E) (((List<E>) result).get(0));
        } else {
            return null;
        }
    }

    @Override
    public <E extends IEntity, obj extends Object> E getEntity(Class<E> elementClass, String query, boolean deleted) {
        Object result;

        if (deleted) {
            query = query + " AND o.deleted IS true";
        } else {
            query = query + " AND o.deleted IS NOT true";
        }

        Query qry = entityManager.createQuery(query, elementClass);

        try {
            result = qry.getResultList();
        } catch (NoResultException nre) {
            return null;
        }

        if (result != null && ((List<E>) result).size() > 0) {
            return (E) (((List<E>) result).get(0));
        } else {
            return null;
        }
    }

    @Override
    @Transactional
    public void purge(E entity) {
        entityManager.remove(entity);
    }

    @Override
    public <E extends IEntity> E delete(E entity) {
        entity.setDeleted(Boolean.TRUE);
        return entityManager.merge(entity);
    }
}