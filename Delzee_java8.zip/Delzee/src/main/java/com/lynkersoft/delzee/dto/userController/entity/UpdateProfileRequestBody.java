package com.lynkersoft.delzee.dto.userController.entity;

import java.util.Date;

public class UpdateProfileRequestBody {
    private String firstName;
    private String lastName;
    private Date birthDay;
    private String aboutMe;
    private String birthPlace;
    private String gender;
    private String occupation;
    private String status;
    private String website;
    private String religiousBeliefs;
    private String politicalIncline;

    public String getFirstName() {
        return firstName;
    }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getReligiousBeliefs() {
        return religiousBeliefs;
    }

    public void setReligiousBeliefs(String religiousBeliefs) {
        this.religiousBeliefs = religiousBeliefs;
    }

    public String getPoliticalIncline() {
        return politicalIncline;
    }

    public void setPoliticalIncline(String politicalIncline) {
        this.politicalIncline = politicalIncline;
    }
}
