package com.lynkersoft.delzee.utils.impl;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.List;

@SuppressWarnings("hiding")
public interface IDao<E extends IEntity, K extends Serializable> {

    Long persist(E entity);

    Long merge(E entity);

    <E extends IEntity> E authorization(Class<E> entityClass, String userName, String password);

    void purge(E entity);

    <E extends IEntity> E delete(E entity);

    <E extends IEntity> E update(E entity);

    int update(String query, Hashtable<String, Object> criteria, boolean deleted);

    <E extends IEntity> E find(Class<E> entityClass, K pKey);

    <E extends IEntity, obj extends Object> E getEntity(Class<E> entityClass, String query, boolean deleted);

    <E extends IEntity, obj extends Object> E getEntity(Class<E> entityClass, String query, Hashtable<String, Object> criteria);

    <E extends IEntity, obj extends Object> E getEntity(Class<E> entityClass, String query, Hashtable<String, Object> criteria, boolean deleted);

    <E extends IEntity> List<E> findAll(Class<E> entityClass, boolean deleted);

    <E extends IEntity> List<E> findAll(Class<E> entityClass, boolean deleted, String orderby);

    <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> entityClass, String query, boolean deleted);

    <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> entityClass, String query, Hashtable<String, Object> criteria, boolean deleted);

    <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> elementClass, String query, Hashtable<String, Object> criteria, boolean deleted, String orderBy);

    <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> entityClass, String query, Hashtable<String, Object> criteria);

    <E extends IEntity, obj extends Object> List<E> getEntities(Class<E> entityClass, String query, Hashtable<String, Object> criteria, Integer pageNumber, Integer pageSize);

    List<Object> getData(String query, Hashtable<String, Object> criteria, boolean deleted);
}
