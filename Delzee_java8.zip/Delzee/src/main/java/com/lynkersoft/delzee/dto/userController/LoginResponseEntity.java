package com.lynkersoft.delzee.dto.userController;

import com.lynkersoft.delzee.dto.common.UserDto;
import com.lynkersoft.delzee.dto.userController.entity.Profile;

import java.util.Date;

public class LoginResponseEntity {

    private Boolean sessionStatus;
    private Date signInOn;
    private String message;
    private String accessToken;
    private UserDto user;
    private Profile profile;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getSignInOn() {
        return signInOn;
    }

    public void setSignInOn(Date signInOn) {
        this.signInOn = signInOn;
    }

    public Boolean getSessionStatus() {
        return sessionStatus;
    }

    public void setSessionStatus(Boolean sessionStatus) {
        this.sessionStatus = sessionStatus;
    }

    public UserDto getUser() {
        return user;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
}
