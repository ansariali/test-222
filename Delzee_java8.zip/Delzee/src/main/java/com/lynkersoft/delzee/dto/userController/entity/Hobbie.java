package com.lynkersoft.delzee.dto.userController.entity;

public class Hobbie {

    private Long hobbiesId;
    private String name;
    private  String tagName;

    public Long getHobbiesId() {
        return hobbiesId;
    }

    public void setHobbiesId(Long hobbiesId) {
        this.hobbiesId = hobbiesId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }
}
