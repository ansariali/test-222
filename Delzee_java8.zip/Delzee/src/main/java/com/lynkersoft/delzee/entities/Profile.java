package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;
import com.lynkersoft.delzee.utils.enums.Privacy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "profile")
public class Profile extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long profileId;

    private Integer totalSendFriendRequest;
    private Integer totalFriendRequest;
    private Integer totalFriend;
    private Integer totalImage;
    private Integer totalVideo;
    private Integer totalShare;
    private Integer totalPost;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy addressPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy hobbyPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy friendPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy educationPrivacy;

    private String aboutMe;
    @NotNull(message = "about me privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy aboutMePrivacy;

    private Date birthDay;
    @NotNull(message = " birthDay privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy birthDayPrivacy;

    private String birthPlace;
    @NotNull(message = " birthPlace privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy birthPlacePrivacy;

    private String phoneNumber;
    @NotNull(message = " phoneNumber privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy phoneNumberPrivacy;

    private String occupation;
    private String gender;
    private String status;
    private String website;
    private String religiousBeliefs;
    private String politicalIncline;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Address> address = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Education> educations = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Hobbie> hobbies = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Friend> friends = new HashSet<>();

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }

    public Set<Address> getAddress() {
        return address;
    }

    public void setAddress(Set<Address> address) {
        this.address = address;
    }

    public Set<Education> getEducations() {
        return educations;
    }

    public void setEducations(Set<Education> educations) {
        this.educations = educations;
    }

    public Set<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(Set<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }

    public Integer getTotalSendFriendRequest() {
        return totalSendFriendRequest;
    }

    public void setTotalSendFriendRequest(Integer totalSendFriendRequest) {
        this.totalSendFriendRequest = totalSendFriendRequest;
    }

    public Integer getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Integer totalShare) {
        this.totalShare = totalShare;
    }

    public Set<Friend> getFriends() {
        return friends;
    }

    public void setFriends(Set<Friend> friends) {
        this.friends = friends;
    }

    public Integer getTotalFriendRequest() {
        return totalFriendRequest;
    }

    public void setTotalFriendRequest(Integer totalFriendRequest) {
        this.totalFriendRequest = totalFriendRequest;
    }

    public Integer getTotalFriend() {
        return totalFriend;
    }

    public void setTotalFriend(Integer totalFriend) {
        this.totalFriend = totalFriend;
    }

    public Integer getTotalImage() {
        return totalImage;
    }

    public void setTotalImage(Integer totalImage) {
        this.totalImage = totalImage;
    }

    public Integer getTotalVideo() {
        return totalVideo;
    }

    public void setTotalVideo(Integer totalVideo) {
        this.totalVideo = totalVideo;
    }

    public Privacy getAboutMePrivacy() {
        return aboutMePrivacy;
    }

    public void setAboutMePrivacy(Privacy aboutMePrivacy) {
        this.aboutMePrivacy = aboutMePrivacy;
    }

    public Integer getTotalPost() {
        return totalPost;
    }

    public void setTotalPost(Integer totalPost) {
        this.totalPost = totalPost;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public Privacy getBirthDayPrivacy() {
        return birthDayPrivacy;
    }

    public void setBirthDayPrivacy(Privacy birthDayPrivacy) {
        this.birthDayPrivacy = birthDayPrivacy;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public Privacy getBirthPlacePrivacy() {
        return birthPlacePrivacy;
    }

    public void setBirthPlacePrivacy(Privacy birthPlacePrivacy) {
        this.birthPlacePrivacy = birthPlacePrivacy;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Privacy getPhoneNumberPrivacy() {
        return phoneNumberPrivacy;
    }

    public void setPhoneNumberPrivacy(Privacy phoneNumberPrivacy) {
        this.phoneNumberPrivacy = phoneNumberPrivacy;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getReligiousBeliefs() {
        return religiousBeliefs;
    }

    public void setReligiousBeliefs(String religiousBeliefs) {
        this.religiousBeliefs = religiousBeliefs;
    }

    public String getPoliticalIncline() {
        return politicalIncline;
    }

    public void setPoliticalIncline(String politicalIncline) {
        this.politicalIncline = politicalIncline;
    }
}
