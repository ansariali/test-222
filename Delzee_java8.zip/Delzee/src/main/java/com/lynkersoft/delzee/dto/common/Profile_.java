package com.lynkersoft.delzee.dto.common;

public class Profile_ {
    private Long profileId;

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }
}
