package com.lynkersoft.dlzee.controllers;

import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.utils.GenericController;
import com.lynkersoft.dlzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/userController")
public class UserAccountController extends GenericController {

    Logger logger = LoggerFactory.getLogger(UserAccountController.class);

    @Autowired
    UserAccountService userAccountService;

    @PostMapping(value = "/v1/signUp")
    public ResponseEntity<GenericResponse> signUp(@Valid @RequestBody UserAccount signUpRequest) {
        logger.info("Inside signUp :");
        return new ResponseEntity<>(userAccountService.signUp_v1(signUpRequest, iDao), responseHeaders, HttpStatus.OK);
    }

//    @PostMapping(value = "/v1/signIn")
    @PostMapping(value = "/v1/signIn")
    public ResponseEntity<LoginResponseEntity> signIn(@RequestBody UserAccount signUpRequest) {
        logger.info("Inside signIn_v1 :");
       /* String userName = null, password = null;
        for (Map.Entry<String, Object> entry : requestHeader.e  ntrySet()) {
            String key = entry.getKey().toUpperCase();
            String value = entry.getValue().toString();

            if (key.equals("AUTHORIZATION")) {
                String[] auth = mRefactor.decodeToBase64(value).split(":");
                if (auth.length == 2) {
                    userName = auth[0];
                    password = auth[1];
                }
            }
        }*/

        return new ResponseEntity<>(userAccountService.signIn_v1(signUpRequest.getUserName(), signUpRequest.getPassword(), iDao), responseHeaders, HttpStatus.OK);
    }

}
