package com.lynkersoft.dlzee.service;

import com.lynkersoft.dlzee.entities.Blogging;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;

import java.io.Serializable;

public interface BloggingService {
    GenericResponse signUp_v1(Blogging blogging, IDao<IEntity, Serializable> iDao);
}
