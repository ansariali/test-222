package com.lynkersoft.dlzee.utils.abstracts;

import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.utils.QueryManager;
import com.lynkersoft.dlzee.utils.Refactor;
import com.lynkersoft.dlzee.utils.Util;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;

@Service
@Transactional
public abstract class GenericService {

    protected Hashtable<String, Object> mCriteria = new Hashtable<>();
    protected QueryManager queryManager = QueryManager.getInstance();
    protected static Util mUtil = Util.getInstance();
    protected static Refactor mRefactor = Refactor.getInstance();

    //Check Email
    protected void findEmailAddress(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_IS_TAKEN);
        }
    }

    //Check UserName
    protected void findUserName(String userName, IDao<IEntity, Serializable> iDao) {
        if (userName == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("userName", userName);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getUsersByUserName(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_TAKEN);
        }
    }

    //CheckUserName And Password
    protected UserAccount checkUserNameAndPassword(String userName, String password, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("userName", userName);
        mCriteria.put("password", password);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.checkUserNameAndPassword(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);
        } else {
            return  users;
        }
    }


    protected void checkNullObject(Object object, ExceptionStatus exceptionStatus) {
        if (object == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullLongId(Long id, ExceptionStatus exceptionStatus) {
        if (id == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullString(String s, ExceptionStatus exceptionStatus) {
        if (s == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullDate(Date date, ExceptionStatus exceptionStatus) {
        if (date == null) {
            throw new GenericException(exceptionStatus);
        }
    }
}
