package com.lynkersoft.dlzee.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;
import com.lynkersoft.dlzee.utils.enums.AttachmentFor;
import com.lynkersoft.dlzee.utils.enums.AttachmentType;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "attachment")
public class Attachment extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long attachmentId;

    @NotNull(message = "attachmentFor must be required!")
    @Enumerated(EnumType.STRING)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private AttachmentFor attachmentFor;

    @NotNull(message = "attachmentType must be required!")
    @Enumerated(EnumType.STRING)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private AttachmentType attachmentType;

    @NotNull(message = "contentType must be required!")
    private String contentType;

    @NotNull(message = "contentType must be required!")
    private String tag;

    @Lob
    @Size(max = 1024, message = "uploadUrl must be required!")
    private String uploadUrl;

    @Lob
    @Size(max = 1024, message = "downloadUrl must be required!")
    private String downloadUrl;

    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blogging")
    private Blogging blogging;


    public Long getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(Long attachmentId) {
        this.attachmentId = attachmentId;
    }

    public AttachmentFor getAttachmentFor() {
        return attachmentFor;
    }

    public void setAttachmentFor(AttachmentFor attachmentFor) {
        this.attachmentFor = attachmentFor;
    }

    public AttachmentType getAttachmentType() {
        return attachmentType;
    }

    public void setAttachmentType(AttachmentType attachmentType) {
        this.attachmentType = attachmentType;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getUploadUrl() {
        return uploadUrl;
    }

    public void setUploadUrl(String uploadUrl) {
        this.uploadUrl = uploadUrl;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Blogging getBlogging() {
        return blogging;
    }

    public void setBlogging(Blogging blogging) {
        this.blogging = blogging;
    }

}
