package com.lynkersoft.dlzee.utils;

import com.lynkersoft.dlzee.controllers.UserAccountController;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Refactor {

    Logger mLogger = LoggerFactory.getLogger(UserAccountController.class);

    public static Refactor getInstance() {
        return new Refactor();
    }

    public Date getTimeBySpecificZone(final String timeZone, final Date date) {
        try {
            SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");

            TimeZone aTimeZone = TimeZone.getTimeZone(timeZone);
            aSimpleDateFormat.setTimeZone(aTimeZone);

            return aSimpleDateFormat.parse(aSimpleDateFormat.format(date));
        } catch (Exception e) {
            mLogger.error(e.getMessage());
            return null;
        }
    }

    public String decodeToBase64(final String data) {
        try {
            return new String(Base64.decodeBase64(data));
        } catch (Exception e) {
            mLogger.error(e.getMessage());
            return null;
        }
    }

}
