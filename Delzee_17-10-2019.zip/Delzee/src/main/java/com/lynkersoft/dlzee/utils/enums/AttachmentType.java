package com.lynkersoft.dlzee.utils.enums;

public enum AttachmentType {
    IMAGE, VIDEO
}
