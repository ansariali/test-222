package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "user_account")
public class UserAccount extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long userId;

    @NotNull(message = "firstName must be required!")
    @Size(min = 3, max = 30, message = "firstName length must be between 3 to 30 char")
    private String firstName;

    @NotNull(message = "userName must be required!")
    @Size(min = 3, max = 30, message = "lastName length must be between 3 to 30 char")
    private String lastName;

    @Column(unique = true)
    @NotNull(message = "userName must be required!")
    @Size(min = 3, max = 30, message = "userName length must be between 3 to 30 char")
    private String userName;

    private String gender;

    @Email
    @Column(unique = true)
    @NotNull(message = "email address must be required!")
    @Size(max = 255, message = "emailAddress length must be maximum 255 char")
    private String emailAddress;

    private String password;

    @Size(max = 10, message = "mobile number is invalid")
    private String mobileNo;

    private Boolean userEnabled;

    private Boolean userBlocked;


    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "address")
    private Address address;


  /*  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "watcher")
    private Watcher watcher;*/

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Boolean getUserEnabled() {
        return userEnabled;
    }

    public void setUserEnabled(Boolean userEnabled) {
        this.userEnabled = userEnabled;
    }

    public Boolean getUserBlocked() {
        return userBlocked;
    }

    public void setUserBlocked(Boolean userBlocked) {
        this.userBlocked = userBlocked;
    }
}


