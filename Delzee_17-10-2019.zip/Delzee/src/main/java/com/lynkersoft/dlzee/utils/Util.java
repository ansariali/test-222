package com.lynkersoft.dlzee.utils;

import java.util.Date;
import java.util.UUID;

public class Util {

    public static Util getInstance() {
        return new Util();
    }

    public String getDefaultTimeZone() {
        return TimeZone.DEFAULT.getTimeZone();
    }

    public Date getCurrentTime() {
        return new Date();
    }


    public String getTokenNumber() {
        try {
            return UUID.randomUUID().toString();
        } catch (Exception e) {
            return null;
        }
    }
}
