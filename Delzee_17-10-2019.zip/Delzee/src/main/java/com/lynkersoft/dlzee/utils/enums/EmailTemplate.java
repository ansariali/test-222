package com.lynkersoft.dlzee.utils.enums;

public enum EmailTemplate {
    WELCOME("Welcome to Dlzee", "templates/emailTemplate/welcome.vm");

    private final String emailSubject;
    private final String emailTemplate;

    EmailTemplate(String emailSubject, String emailTemplate) {
        this.emailSubject = emailSubject;
        this.emailTemplate = emailTemplate;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public String getTemplateUrl() {
        return emailTemplate;
    }
}
