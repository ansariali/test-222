-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2018 at 03:17 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `1talkhives_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `blog_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `blog_tag` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `image_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`blog_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `blog_tag`, `info`, `message`, `title`, `organization_id`, `user_id`, `deleted_at`, `image_id`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 11:54:18', NULL, b'0', NULL, 1, NULL, NULL, 'hello!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', 'Testing', 1, 1, NULL, NULL, NULL, NULL),
(2, '2018-02-26 08:51:32', NULL, b'0', NULL, 1, NULL, NULL, 'Udi jaje pavagadh re!', 'pakhidao', 1, 1, NULL, NULL, NULL, NULL),
(3, '2018-02-26 08:51:45', NULL, b'0', '2018-03-16 06:41:54', 2, NULL, NULL, 'Testing Blocg', 'Testing With Image Blog', 1, 3, NULL, 34, NULL, NULL),
(4, '2018-02-26 08:54:41', NULL, b'1', NULL, 1, NULL, NULL, 'Have a great Day', 'Good Morning', 1, 3, '2018-03-23 12:01:59', NULL, NULL, NULL),
(5, '2018-02-26 09:05:58', NULL, b'0', NULL, 1, NULL, NULL, 'Ola Bon Diva', 'Testing', 1, 3, NULL, NULL, NULL, NULL),
(6, '2018-02-26 09:10:10', NULL, b'0', '2018-03-26 12:54:31', 2, NULL, NULL, 'Oiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii', 'Testing For Image', 1, 3, NULL, NULL, NULL, NULL),
(7, '2018-02-26 09:10:58', NULL, b'1', NULL, 1, NULL, NULL, 'fdfdf', 'sdhsf', 1, 3, '2018-02-28 07:00:14', NULL, NULL, NULL),
(8, '2018-02-26 09:19:05', NULL, b'0', NULL, 1, NULL, NULL, 'qweqwe', 'qweqwe', 1, 2, NULL, NULL, NULL, NULL),
(9, '2018-02-26 09:26:29', NULL, b'0', NULL, 1, NULL, NULL, '22222222222222', '222222222222222222222', 1, 1, NULL, NULL, NULL, NULL),
(10, '2018-02-26 09:40:42', NULL, b'0', NULL, 1, NULL, NULL, '111', '1111', 1, 2, NULL, NULL, NULL, NULL),
(11, '2018-02-26 09:42:10', NULL, b'0', NULL, 1, NULL, NULL, 'https://www.jdoodle.com/online-java-compiler', 'Java compiler', 1, 2, NULL, NULL, NULL, NULL),
(12, '2018-02-26 09:44:11', NULL, b'0', NULL, 1, NULL, NULL, '3333333', '333333333', 1, 2, NULL, NULL, NULL, NULL),
(13, '2018-02-26 10:45:13', NULL, b'1', NULL, 1, NULL, NULL, 'oiiii', 'good evening with image', 1, 3, '2018-03-23 12:02:08', NULL, NULL, NULL),
(14, '2018-02-26 10:46:33', NULL, b'0', NULL, 1, NULL, NULL, 'oii  Himalya mall', 'Game Zone', 1, 3, NULL, NULL, NULL, NULL),
(15, '2018-02-26 10:52:56', NULL, b'0', '2018-02-28 11:48:09', 2, NULL, NULL, 'qweqweqwe', '1111', 1, 1, NULL, 5, NULL, NULL),
(16, '2018-02-26 10:55:10', NULL, b'1', NULL, 1, NULL, NULL, 'awsome movie .....must watch at least one time ', 'What a Movie!!!!!!!!!!', 1, 3, '2018-03-26 12:54:42', 6, NULL, NULL),
(17, '2018-02-26 12:38:48', NULL, b'0', NULL, 1, NULL, NULL, 'Tmap: { ''@ng-bootstrap/ng-bootstrap'': ''node_modules/@ng-bootstrap/ng-bootstrap/bundles/ng-bootstrap.js'', }', 'Tooltip', 1, 3, NULL, NULL, NULL, NULL),
(18, '2018-02-28 04:57:12', NULL, b'0', NULL, 1, NULL, NULL, '123123123123', '28', 1, 3, NULL, 7, NULL, NULL),
(19, '2018-02-28 04:59:27', NULL, b'0', NULL, 1, NULL, NULL, 'aaaaaaaaaaaaaaaaaaaa', 'qweqweqweqweqwe', 1, 3, NULL, 8, NULL, NULL),
(20, '2018-02-28 05:02:59', NULL, b'0', NULL, 1, NULL, NULL, 'asdasdasd', '23q41', 1, 3, NULL, 9, NULL, NULL),
(21, '2018-02-28 05:06:23', NULL, b'0', NULL, 1, NULL, NULL, '34534534534534534', '35345345', 1, 3, NULL, 10, NULL, NULL),
(22, '2018-02-28 05:29:15', NULL, b'0', NULL, 1, NULL, NULL, 'asdasd', 'ads', 1, 3, NULL, 11, NULL, NULL),
(23, '2018-02-28 05:30:33', NULL, b'0', NULL, 1, NULL, NULL, 'asd', 'sad', 1, 3, NULL, 12, NULL, NULL),
(24, '2018-02-28 05:33:13', NULL, b'0', '2018-02-28 06:38:40', 3, NULL, NULL, '111111111122222222233333333', 'ewrwer', 1, 3, NULL, 17, NULL, NULL),
(25, '2018-02-28 06:00:57', NULL, b'1', '2018-02-28 06:35:08', 2, NULL, NULL, 'asdasd', 'dsa', 1, 3, '2018-02-28 06:44:53', NULL, NULL, NULL),
(26, '2018-02-28 06:01:42', NULL, b'1', NULL, 1, NULL, NULL, 'qwe', 'qwe', 1, 3, '2018-02-28 06:44:51', NULL, NULL, NULL),
(27, '2018-02-28 06:02:09', NULL, b'1', '2018-02-28 06:33:56', 3, NULL, NULL, '123123123', '123123', 1, 3, '2018-02-28 06:44:50', NULL, NULL, NULL),
(28, '2018-02-28 07:01:02', NULL, b'0', '2018-02-28 12:16:40', 6, NULL, NULL, 'bon diva', 'Testing lion', 1, 2, NULL, 22, NULL, NULL),
(29, '2018-02-28 07:14:24', NULL, b'0', '2018-02-28 07:14:45', 2, NULL, NULL, 'Bon Diva', 'ttt', 1, 2, NULL, 19, NULL, NULL),
(30, '2018-02-28 10:40:50', NULL, b'1', '2018-02-28 10:43:43', 2, NULL, NULL, 'Hello Testing for Update', 'Testing for Blog with image', 1, 3, '2018-03-01 06:23:09', 20, NULL, NULL),
(31, '2018-02-28 10:44:20', NULL, b'1', NULL, 1, NULL, NULL, 'Oiiiiiiii', 'Testing for Delete Blog', 1, 1, '2018-02-28 10:45:46', NULL, NULL, NULL),
(32, '2018-02-28 11:03:16', NULL, b'1', '2018-02-28 11:05:27', 3, NULL, NULL, 'Hii I am Owner............', 'Owner', 1, 1, '2018-02-28 11:05:47', NULL, NULL, NULL),
(33, '2018-02-28 11:07:03', NULL, b'0', NULL, 1, NULL, NULL, 'Hii I am Owner............', 'Owner Blog', 1, 1, NULL, NULL, NULL, NULL),
(34, '2018-02-28 11:48:22', NULL, b'0', NULL, 1, NULL, NULL, 'dsds', 'Testing', 1, 3, NULL, 21, NULL, NULL),
(35, '2018-02-28 11:53:21', NULL, b'1', NULL, 1, NULL, NULL, 'sdsdsd', 'Testing', 1, 3, '2018-02-28 11:53:23', NULL, NULL, NULL),
(36, '2018-02-28 12:31:08', NULL, b'1', NULL, 1, NULL, NULL, 'sdfsdfsdfsdf', 'sdfsdf', 1, 2, '2018-02-28 12:34:45', 23, NULL, NULL),
(37, '2018-02-28 12:31:30', NULL, b'1', NULL, 1, NULL, NULL, 'asas', 'asas', 1, 3, '2018-02-28 12:34:37', NULL, NULL, NULL),
(38, '2018-02-28 12:32:28', NULL, b'1', NULL, 1, NULL, NULL, 'ASAS', 'aSSAS', 1, 3, '2018-02-28 12:34:40', 24, NULL, NULL),
(39, '2018-02-28 12:32:53', NULL, b'1', NULL, 1, NULL, NULL, 'SAS', 'SAS', 1, 3, '2018-03-26 12:54:59', 25, NULL, NULL),
(40, '2018-02-28 12:33:27', NULL, b'0', NULL, 1, NULL, NULL, 'DSDSDS', 'HELLO', 1, 3, NULL, 26, NULL, NULL),
(41, '2018-02-28 12:35:08', NULL, b'0', '2018-03-16 06:40:28', 3, NULL, NULL, 'owner''s Picture', 'Vivek ', 1, 3, NULL, 33, NULL, NULL),
(42, '2018-02-28 12:51:01', NULL, b'0', NULL, 1, NULL, NULL, 'asdasdasdasdasd', 'asdasd', 1, 2, NULL, 29, NULL, NULL),
(43, '2018-02-28 12:57:01', NULL, b'1', NULL, 1, NULL, NULL, 'vivek', 'hello', 1, 3, '2018-02-28 12:57:29', 30, NULL, NULL),
(44, '2018-02-28 12:57:59', NULL, b'1', NULL, 1, NULL, NULL, 'image vivek', 'It will be normal', 1, 3, '2018-02-28 13:01:05', 31, NULL, NULL),
(45, '2018-02-28 13:01:46', NULL, b'0', NULL, 1, NULL, NULL, 'Hello every one', 'I am owner', 1, 1, NULL, 32, NULL, NULL),
(46, '2018-03-01 11:40:10', NULL, b'0', NULL, 1, NULL, NULL, 'Testing For top position after page has been refresh', 'Testing For Top', 1, 3, NULL, NULL, NULL, NULL),
(47, '2018-03-23 12:01:10', NULL, b'0', NULL, 1, NULL, NULL, 'Once again Testing', 'Top', 1, 3, NULL, 35, NULL, NULL),
(48, '2018-03-28 10:05:09', NULL, b'0', NULL, 1, NULL, NULL, 'asdasdasd', 'Testing Notification', 1, 3, NULL, NULL, NULL, NULL),
(49, '2018-03-28 10:05:30', NULL, b'0', NULL, 1, NULL, NULL, 'sdfsdfsdf', 'asdasdssaf', 1, 3, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chat_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `chat_room_id` bigint(20) DEFAULT NULL,
  `sender` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`chat_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `content`, `chat_room_id`, `sender`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-19 11:25:25', NULL, b'0', NULL, 1, 'v v  fvc', 1, 1, NULL, NULL, NULL),
(2, '2018-02-19 11:25:33', NULL, b'0', NULL, 1, 'asdasd', 1, 2, NULL, NULL, NULL),
(3, '2018-02-19 11:25:36', NULL, b'0', NULL, 1, 'vdfvfcd', 1, 1, NULL, NULL, NULL),
(4, '2018-02-19 11:26:53', NULL, b'0', NULL, 1, 'fvdvdgvdrg', 1, 1, NULL, NULL, NULL),
(5, '2018-02-19 07:17:02', NULL, b'0', NULL, 1, 'asdasd', 5, 1, NULL, NULL, NULL),
(6, '2018-02-19 07:17:11', NULL, b'0', NULL, 1, 'asdasdasd', 5, 2, NULL, NULL, NULL),
(7, '2018-02-19 07:21:22', NULL, b'0', NULL, 1, 'gfrghed', 5, 1, NULL, NULL, NULL),
(8, '2018-02-19 07:21:29', NULL, b'0', NULL, 1, 'hghjg', 5, 1, NULL, NULL, NULL),
(9, '2018-02-19 07:24:24', NULL, b'0', NULL, 1, 'hello..pagalo', 8, 1, NULL, NULL, NULL),
(10, '2018-02-19 07:24:28', NULL, b'0', NULL, 1, 'hi ', 8, 2, NULL, NULL, NULL),
(11, '2018-02-19 07:24:33', NULL, b'0', NULL, 1, 'pagalo', 8, 6, NULL, NULL, NULL),
(12, '2018-02-19 07:24:38', NULL, b'0', NULL, 1, 'tu pagal', 8, 2, NULL, NULL, NULL),
(13, '2018-02-19 07:24:46', NULL, b'0', NULL, 1, 'kya kar rahe ho', 8, 1, NULL, NULL, NULL),
(14, '2018-02-19 07:24:52', NULL, b'0', NULL, 1, 'tu pagal.....................', 8, 6, NULL, NULL, NULL),
(15, '2018-02-19 07:24:57', NULL, b'0', NULL, 1, 'kam karo kam', 8, 2, NULL, NULL, NULL),
(16, '2018-02-19 07:24:57', NULL, b'0', NULL, 1, 'sir ko call karu', 8, 1, NULL, NULL, NULL),
(17, '2018-02-19 07:24:59', NULL, b'0', NULL, 1, 'time pass', 8, 6, NULL, NULL, NULL),
(18, '2018-02-19 07:25:06', NULL, b'0', NULL, 1, 'karo..call', 8, 6, NULL, NULL, NULL),
(19, '2018-02-19 07:25:18', NULL, b'0', NULL, 1, 'hjghg', 8, 1, NULL, NULL, NULL),
(20, '2018-02-19 07:25:19', NULL, b'0', NULL, 1, 'jhghjg', 8, 1, NULL, NULL, NULL),
(21, '2018-02-19 07:25:20', NULL, b'0', NULL, 1, 'hgjhg', 8, 1, NULL, NULL, NULL),
(22, '2018-02-19 07:25:20', NULL, b'0', NULL, 1, '', 8, 1, NULL, NULL, NULL),
(23, '2018-02-19 07:25:20', NULL, b'0', NULL, 1, 'calling nu feature var 6 haji', 8, 2, NULL, NULL, NULL),
(24, '2018-02-19 07:25:21', NULL, b'0', NULL, 1, 'nngvgbn', 8, 1, NULL, NULL, NULL),
(25, '2018-02-19 07:25:22', NULL, b'0', NULL, 1, 'nbnbvnb', 8, 1, NULL, NULL, NULL),
(26, '2018-02-19 07:26:10', NULL, b'0', NULL, 1, 'jor banayu.....', 8, 6, NULL, NULL, NULL),
(27, '2018-02-19 07:26:18', NULL, b'0', NULL, 1, 'mane shikhvado', 8, 6, NULL, NULL, NULL),
(28, '2018-02-19 07:27:27', NULL, b'0', NULL, 1, 'jarur jarur', 8, 2, NULL, NULL, NULL),
(29, '2018-02-19 09:17:35', NULL, b'0', NULL, 1, 'vdfv', 7, 1, NULL, NULL, NULL),
(30, '2018-02-19 09:44:29', NULL, b'0', NULL, 1, 'bnv', 1, 1, NULL, NULL, NULL),
(31, '2018-02-19 09:50:50', NULL, b'0', NULL, 1, 'vdcfdcv', 4, 1, NULL, NULL, NULL),
(32, '2018-02-19 10:01:09', NULL, b'0', NULL, 1, 'hmjn', 5, 1, NULL, NULL, NULL),
(33, '2018-02-19 10:02:28', NULL, b'0', NULL, 1, '', 5, 1, NULL, NULL, NULL),
(34, '2018-02-19 10:19:05', NULL, b'0', NULL, 1, 'vvv', 7, 1, NULL, NULL, NULL),
(35, '2018-02-19 10:24:20', NULL, b'0', NULL, 1, '', 1, 1, NULL, NULL, NULL),
(36, '2018-02-19 10:24:35', NULL, b'0', NULL, 1, 'fff', 1, 1, NULL, NULL, NULL),
(37, '2018-02-19 10:37:44', NULL, b'0', NULL, 1, '/tunnel/v1/refresh/tender/cb0faaa4-eab9-4bed-ade5-35e7ec66931c', 1, 2, NULL, NULL, NULL),
(38, '2018-02-19 11:00:28', NULL, b'0', NULL, 1, 'ddddddd', 1, 1, NULL, NULL, NULL),
(40, '2018-02-19 11:21:28', NULL, b'0', NULL, 1, 'vxdvcdvgcdgb', 1, 1, NULL, NULL, NULL),
(41, '2018-02-19 11:34:21', NULL, b'0', NULL, 1, 'asdasd', 1, 1, NULL, NULL, NULL),
(42, '2018-02-19 11:35:46', NULL, b'0', NULL, 1, 'fdvdff', 1, 1, NULL, NULL, NULL),
(43, '2018-02-19 11:36:36', NULL, b'0', NULL, 1, 'asdasd', 1, 2, NULL, NULL, NULL),
(44, '2018-02-19 11:36:52', NULL, b'0', NULL, 1, '111', 1, 2, NULL, NULL, NULL),
(45, '2018-02-19 11:37:00', NULL, b'0', NULL, 1, '2222', 1, 1, NULL, NULL, NULL),
(46, '2018-02-19 11:37:19', NULL, b'0', NULL, 1, '3333', 1, 2, NULL, NULL, NULL),
(47, '2018-02-22 12:27:45', NULL, b'0', NULL, 1, 'hgggh', 1, 2, NULL, NULL, NULL),
(48, '2018-02-22 12:29:06', NULL, b'0', NULL, 1, 'asdasdasd', 1, 1, NULL, NULL, NULL),
(49, '2018-02-22 12:31:52', NULL, b'0', NULL, 1, 'qweqwe', 1, 2, NULL, NULL, NULL),
(50, '2018-02-22 12:32:01', NULL, b'0', NULL, 1, 'vgrfgvtgrf', 1, 1, NULL, NULL, NULL),
(51, '2018-02-22 12:32:01', NULL, b'0', NULL, 1, '', 1, 1, NULL, NULL, NULL),
(52, '2018-02-22 12:32:10', NULL, b'0', NULL, 1, 'bfvhgfhfhgf', 1, 1, NULL, NULL, NULL),
(53, '2018-02-22 12:32:10', NULL, b'0', NULL, 1, '', 1, 1, NULL, NULL, NULL),
(54, '2018-02-22 12:33:21', NULL, b'0', NULL, 1, '11111111', 1, 1, NULL, NULL, NULL),
(55, '2018-02-23 07:11:43', NULL, b'0', NULL, 1, 'hi', 35, 3, NULL, NULL, NULL),
(56, '2018-02-23 07:11:49', NULL, b'0', NULL, 1, 'hi', 35, 3, NULL, NULL, NULL),
(57, '2018-02-23 07:18:34', NULL, b'0', NULL, 1, 'hiiii', 35, 2, NULL, NULL, NULL),
(58, '2018-02-23 07:19:47', NULL, b'0', NULL, 1, 'asdasdasd', 1, 1, NULL, NULL, NULL),
(59, '2018-02-23 07:19:55', NULL, b'0', NULL, 1, 'jljlj', 34, 3, NULL, NULL, NULL),
(60, '2018-02-23 07:20:03', NULL, b'0', NULL, 1, '1111111111111', 1, 1, NULL, NULL, NULL),
(61, '2018-02-23 07:21:13', NULL, b'0', NULL, 1, 'ffff', 35, 3, NULL, NULL, NULL),
(62, '2018-02-23 07:21:39', NULL, b'0', NULL, 1, 'fffffdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 35, 3, NULL, NULL, NULL),
(63, '2018-02-23 07:24:41', NULL, b'0', NULL, 1, '22222', 1, 2, NULL, NULL, NULL),
(64, '2018-02-23 07:25:18', NULL, b'0', NULL, 1, 'jhgjkhgjgjgkjg', 11, 3, NULL, NULL, NULL),
(65, '2018-02-23 07:25:23', NULL, b'0', NULL, 1, 'asdasdasd', 1, 2, NULL, NULL, NULL),
(66, '2018-02-23 07:25:24', NULL, b'0', NULL, 1, 'hiiii', 11, 3, NULL, NULL, NULL),
(67, '2018-02-23 07:25:30', NULL, b'0', NULL, 1, '444444444', 1, 2, NULL, NULL, NULL),
(68, '2018-02-23 07:27:20', NULL, b'0', NULL, 1, 'qweqweqwe', 1, 2, NULL, NULL, NULL),
(69, '2018-02-23 09:47:40', NULL, b'0', NULL, 1, 'asdasd', 1, 2, NULL, NULL, NULL),
(70, '2018-02-23 09:47:50', NULL, b'0', NULL, 1, 'cffefcer', 1, 1, NULL, NULL, NULL),
(71, '2018-02-23 09:48:04', NULL, b'0', NULL, 1, 'dfgddgf', 1, 2, NULL, NULL, NULL),
(72, '2018-02-23 09:48:18', NULL, b'0', NULL, 1, 'hgfghfh', 1, 2, NULL, NULL, NULL),
(73, '2018-02-23 09:48:30', NULL, b'0', NULL, 1, 'hghjg', 1, 2, NULL, NULL, NULL),
(74, '2018-02-23 09:48:42', NULL, b'0', NULL, 1, 'hfhh', 1, 2, NULL, NULL, NULL),
(75, '2018-02-23 11:04:01', NULL, b'0', NULL, 1, 'asdasdasd', 1, 2, NULL, NULL, NULL),
(76, '2018-02-23 11:04:15', NULL, b'0', NULL, 1, 'asdsdasds', 1, 2, NULL, NULL, NULL),
(77, '2018-02-23 11:04:26', NULL, b'0', NULL, 1, 'asdasdasd', 1, 2, NULL, NULL, NULL),
(78, '2018-02-23 11:04:35', NULL, b'0', NULL, 1, 'asdasdasd', 1, 2, NULL, NULL, NULL),
(79, '2018-02-23 11:06:42', NULL, b'0', NULL, 1, 'sdfsdf', 1, 2, NULL, NULL, NULL),
(80, '2018-02-23 11:06:49', NULL, b'0', NULL, 1, 'dfgdfgdcfgd', 1, 2, NULL, NULL, NULL),
(81, '2018-02-23 11:06:56', NULL, b'0', NULL, 1, 'dfgdfgdfg', 1, 2, NULL, NULL, NULL),
(82, '2018-02-23 11:06:57', NULL, b'0', NULL, 1, '', 1, 2, NULL, NULL, NULL),
(83, '2018-02-23 11:07:08', NULL, b'0', NULL, 1, 'dfgdfgdfg', 1, 2, NULL, NULL, NULL),
(84, '2018-02-23 11:07:14', NULL, b'0', NULL, 1, '', 1, 2, NULL, NULL, NULL),
(85, '2018-02-23 11:11:15', NULL, b'0', NULL, 1, '', 5, 2, NULL, NULL, NULL),
(86, '2018-02-23 11:12:15', NULL, b'0', NULL, 1, '', 5, 2, NULL, NULL, NULL),
(87, '2018-02-23 11:12:54', NULL, b'0', NULL, 1, '', 7, 2, NULL, NULL, NULL),
(88, '2018-02-23 11:13:49', NULL, b'0', NULL, 1, 'asdasdasdasdasd', 5, 2, NULL, NULL, NULL),
(89, '2018-02-23 11:33:45', NULL, b'0', NULL, 1, 'saasd', 5, 2, NULL, NULL, NULL),
(90, '2018-02-23 11:35:51', NULL, b'0', NULL, 1, 'de', 6, 1, NULL, NULL, NULL),
(91, '2018-02-23 11:41:09', NULL, b'0', NULL, 1, 'asdasd', 4, 1, NULL, NULL, NULL),
(92, '2018-02-23 11:41:11', NULL, b'0', NULL, 1, 'asd', 4, 1, NULL, NULL, NULL),
(93, '2018-02-23 11:41:12', NULL, b'0', NULL, 1, 'a', 4, 1, NULL, NULL, NULL),
(94, '2018-02-26 05:23:20', NULL, b'0', NULL, 1, 'hello', 11, 3, NULL, NULL, NULL),
(95, '2018-02-26 06:36:34', NULL, b'0', NULL, 1, 'kljhjkhkjh', 1, 2, NULL, NULL, NULL),
(96, '2018-02-26 06:36:40', NULL, b'0', NULL, 1, 'hjkhkjh', 1, 2, NULL, NULL, NULL),
(97, '2018-02-26 10:39:16', NULL, b'0', NULL, 1, 'hello', 5, 3, NULL, NULL, NULL),
(98, '2018-02-26 12:10:37', NULL, b'0', NULL, 1, 'ljn', 19, 1, NULL, NULL, NULL),
(99, '2018-02-26 12:10:39', NULL, b'0', NULL, 1, ',nk,nlkn', 19, 1, NULL, NULL, NULL),
(100, '2018-02-26 12:10:41', NULL, b'0', NULL, 1, ',n mkl knlknlknkn', 19, 1, NULL, NULL, NULL),
(101, '2018-02-26 12:10:42', NULL, b'0', NULL, 1, 'lkJ', 19, 1, NULL, NULL, NULL),
(102, '2018-02-26 12:10:44', NULL, b'0', NULL, 1, 'KFDLKFLSKNGlksdngklnsdg', 19, 1, NULL, NULL, NULL),
(103, '2018-02-26 12:10:45', NULL, b'0', NULL, 1, 'ksdlgnknsdglknsdlg', 19, 1, NULL, NULL, NULL),
(104, '2018-02-26 12:10:47', NULL, b'0', NULL, 1, 'lsdnglknsdglknsdlkgnlsdkgn', 19, 1, NULL, NULL, NULL),
(105, '2018-02-26 12:10:48', NULL, b'0', NULL, 1, 'lsdknglsdngksdnglksndglks', 19, 1, NULL, NULL, NULL),
(106, '2018-02-26 12:10:48', NULL, b'0', NULL, 1, 'd', 19, 1, NULL, NULL, NULL),
(107, '2018-02-26 12:10:50', NULL, b'0', NULL, 1, 'dslgnlsdgnlksdnglksdngsdkgn', 19, 1, NULL, NULL, NULL),
(108, '2018-02-26 12:10:53', NULL, b'0', NULL, 1, 'sdkgnsldkgnlskdgnlsdkgnlksdgnlsdkgndlksgndsklgndklgndsglkndglkndglknsdlkgn', 19, 1, NULL, NULL, NULL),
(109, '2018-02-26 12:10:53', NULL, b'0', NULL, 1, 'sdgn', 19, 1, NULL, NULL, NULL),
(110, '2018-02-26 12:10:54', NULL, b'0', NULL, 1, 'lsdkgnsdlkgnsdlkg', 19, 1, NULL, NULL, NULL),
(111, '2018-02-26 12:10:55', NULL, b'0', NULL, 1, 'ndskgnsdl', 19, 1, NULL, NULL, NULL),
(112, '2018-02-26 12:10:55', NULL, b'0', NULL, 1, 'gnsdg', 19, 1, NULL, NULL, NULL),
(113, '2018-02-26 12:10:56', NULL, b'0', NULL, 1, 'sdgkndslgknsdglknsdlgkns', 19, 1, NULL, NULL, NULL),
(114, '2018-02-26 12:10:57', NULL, b'0', NULL, 1, 'dgjnsdl', 19, 1, NULL, NULL, NULL),
(115, '2018-02-26 12:10:57', NULL, b'0', NULL, 1, 'gkknsg', 19, 1, NULL, NULL, NULL),
(116, '2018-02-26 12:10:58', NULL, b'0', NULL, 1, 'lsngdsl', 19, 1, NULL, NULL, NULL),
(117, '2018-02-26 12:10:58', NULL, b'0', NULL, 1, 'gknlskdg', 19, 1, NULL, NULL, NULL),
(118, '2018-02-26 12:10:59', NULL, b'0', NULL, 1, 'sdg', 19, 1, NULL, NULL, NULL),
(119, '2018-02-26 12:55:22', NULL, b'0', NULL, 1, '.fmgmsfgl', 16, 1, NULL, NULL, NULL),
(120, '2018-02-26 12:55:22', NULL, b'0', NULL, 1, '', 16, 1, NULL, NULL, NULL),
(121, '2018-02-26 12:55:23', NULL, b'0', NULL, 1, 'skfgnsfgknsf', 16, 1, NULL, NULL, NULL),
(122, '2018-02-26 12:55:23', NULL, b'0', NULL, 1, 'gknsdg', 16, 1, NULL, NULL, NULL),
(123, '2018-02-26 12:55:23', NULL, b'0', NULL, 1, 'nsdglknsdg', 16, 1, NULL, NULL, NULL),
(124, '2018-02-26 12:55:24', NULL, b'0', NULL, 1, 'lskdng', 16, 1, NULL, NULL, NULL),
(125, '2018-02-26 12:55:24', NULL, b'0', NULL, 1, 'lsdkng', 16, 1, NULL, NULL, NULL),
(126, '2018-02-26 12:55:24', NULL, b'0', NULL, 1, 'lsdkgns', 16, 1, NULL, NULL, NULL),
(127, '2018-02-26 12:55:24', NULL, b'0', NULL, 1, 'dlkgnsdl', 16, 1, NULL, NULL, NULL),
(128, '2018-02-26 12:55:25', NULL, b'0', NULL, 1, 'gknsdg', 16, 1, NULL, NULL, NULL),
(129, '2018-02-26 12:55:25', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(130, '2018-02-26 12:55:25', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(131, '2018-02-26 12:55:25', NULL, b'0', NULL, 1, 'lknl', 16, 1, NULL, NULL, NULL),
(132, '2018-02-26 12:55:26', NULL, b'0', NULL, 1, 'knlk', 16, 1, NULL, NULL, NULL),
(133, '2018-02-26 12:55:26', NULL, b'0', NULL, 1, 'nkl', 16, 1, NULL, NULL, NULL),
(134, '2018-02-26 12:55:26', NULL, b'0', NULL, 1, 'nlk', 16, 1, NULL, NULL, NULL),
(135, '2018-02-26 12:55:26', NULL, b'0', NULL, 1, 'nl', 16, 1, NULL, NULL, NULL),
(136, '2018-02-26 12:55:26', NULL, b'0', NULL, 1, 'kn', 16, 1, NULL, NULL, NULL),
(137, '2018-02-26 12:55:27', NULL, b'0', NULL, 1, 'lknl', 16, 1, NULL, NULL, NULL),
(138, '2018-02-26 12:55:27', NULL, b'0', NULL, 1, 'kn', 16, 1, NULL, NULL, NULL),
(139, '2018-02-26 12:55:27', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(140, '2018-02-26 12:55:27', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(141, '2018-02-26 12:55:28', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(142, '2018-02-26 12:55:28', NULL, b'0', NULL, 1, 'lknl', 16, 1, NULL, NULL, NULL),
(143, '2018-02-26 12:55:28', NULL, b'0', NULL, 1, 'kn', 16, 1, NULL, NULL, NULL),
(144, '2018-02-26 12:55:29', NULL, b'0', NULL, 1, 'lknkn', 16, 1, NULL, NULL, NULL),
(145, '2018-02-26 12:55:29', NULL, b'0', NULL, 1, 'lknk', 16, 1, NULL, NULL, NULL),
(146, '2018-02-26 12:55:29', NULL, b'0', NULL, 1, 'n', 16, 1, NULL, NULL, NULL),
(147, '2018-02-26 12:55:29', NULL, b'0', NULL, 1, 'lknk', 16, 1, NULL, NULL, NULL),
(148, '2018-02-26 12:55:30', NULL, b'0', NULL, 1, 'nlkn', 16, 1, NULL, NULL, NULL),
(149, '2018-02-26 12:55:30', NULL, b'0', NULL, 1, 'ln', 16, 1, NULL, NULL, NULL),
(150, '2018-02-26 12:55:30', NULL, b'0', NULL, 1, 'nkl', 16, 1, NULL, NULL, NULL),
(151, '2018-02-26 12:55:30', NULL, b'0', NULL, 1, 'nknn', 16, 1, NULL, NULL, NULL),
(152, '2018-02-26 12:55:31', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(153, '2018-02-26 12:55:31', NULL, b'0', NULL, 1, 'lknk', 16, 1, NULL, NULL, NULL),
(154, '2018-02-26 12:55:32', NULL, b'0', NULL, 1, 'lnlknlkn', 16, 1, NULL, NULL, NULL),
(155, '2018-02-26 12:55:32', NULL, b'0', NULL, 1, 'lkn', 16, 1, NULL, NULL, NULL),
(156, '2018-02-26 12:55:32', NULL, b'0', NULL, 1, 'kln', 16, 1, NULL, NULL, NULL),
(157, '2018-02-26 12:55:33', NULL, b'0', NULL, 1, 'lkkln', 16, 1, NULL, NULL, NULL),
(158, '2018-02-26 12:55:33', NULL, b'0', NULL, 1, 'lnkl', 16, 1, NULL, NULL, NULL),
(159, '2018-02-26 12:55:33', NULL, b'0', NULL, 1, 'n', 16, 1, NULL, NULL, NULL),
(160, '2018-02-26 12:55:33', NULL, b'0', NULL, 1, 'lknkl', 16, 1, NULL, NULL, NULL),
(161, '2018-02-26 12:55:34', NULL, b'0', NULL, 1, 'nklnlknklnl', 16, 1, NULL, NULL, NULL),
(162, '2018-02-26 12:55:35', NULL, b'0', NULL, 1, 'knlkn', 16, 1, NULL, NULL, NULL),
(163, '2018-02-28 11:20:13', NULL, b'0', NULL, 1, 'hello', 4, 3, NULL, NULL, NULL),
(164, '2018-02-28 11:20:24', NULL, b'0', NULL, 1, 'bvvnnnnnnnnnnnnnn', 35, 2, NULL, NULL, NULL),
(165, '2018-02-28 11:20:26', NULL, b'0', NULL, 1, 'nbhjgh', 35, 2, NULL, NULL, NULL),
(166, '2018-02-28 11:20:27', NULL, b'0', NULL, 1, 'hjg', 35, 2, NULL, NULL, NULL),
(167, '2018-02-28 11:20:44', NULL, b'0', NULL, 1, 'hiii...kevi 6e tabiyt?????????', 35, 3, NULL, NULL, NULL),
(168, '2018-02-28 11:26:51', NULL, b'0', NULL, 1, 'hello', 4, 3, NULL, NULL, NULL),
(169, '2018-02-28 11:26:53', NULL, b'0', NULL, 1, 'asdasd', 7, 1, NULL, NULL, NULL),
(170, '2018-02-28 11:26:53', NULL, b'0', NULL, 1, 'asd', 7, 1, NULL, NULL, NULL),
(171, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'as', 7, 1, NULL, NULL, NULL),
(172, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'sd', 7, 1, NULL, NULL, NULL),
(173, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'as', 7, 1, NULL, NULL, NULL),
(174, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'd', 7, 1, NULL, NULL, NULL),
(175, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'as', 7, 1, NULL, NULL, NULL),
(176, '2018-02-28 11:26:54', NULL, b'0', NULL, 1, 'd', 7, 1, NULL, NULL, NULL),
(177, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'as', 7, 1, NULL, NULL, NULL),
(178, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'd', 7, 1, NULL, NULL, NULL),
(179, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'a', 7, 1, NULL, NULL, NULL),
(180, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'sd', 7, 1, NULL, NULL, NULL),
(181, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'a', 7, 1, NULL, NULL, NULL),
(182, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'sd', 7, 1, NULL, NULL, NULL),
(183, '2018-02-28 11:26:55', NULL, b'0', NULL, 1, 'a', 7, 1, NULL, NULL, NULL),
(184, '2018-02-28 11:26:56', NULL, b'0', NULL, 1, 'a', 7, 1, NULL, NULL, NULL),
(185, '2018-02-28 11:26:56', NULL, b'0', NULL, 1, 'sd', 7, 1, NULL, NULL, NULL),
(186, '2018-02-28 11:26:56', NULL, b'0', NULL, 1, 'sd', 7, 1, NULL, NULL, NULL),
(187, '2018-02-28 11:31:50', NULL, b'0', NULL, 1, 'Abe oyyy ama testing karo bija group delete kar database mathi', 37, 3, NULL, NULL, NULL),
(188, '2018-02-28 11:32:36', NULL, b'0', NULL, 1, 'oiii', 7, 3, NULL, NULL, NULL),
(189, '2018-02-28 11:39:07', NULL, b'0', NULL, 1, 'hello', 7, 3, NULL, NULL, NULL),
(190, '2018-02-28 11:39:18', NULL, b'0', NULL, 1, 'hiii', 7, 3, NULL, NULL, NULL),
(191, '2018-02-28 11:39:34', NULL, b'0', NULL, 1, 'hiii', 35, 3, NULL, NULL, NULL),
(192, '2018-02-28 11:45:39', NULL, b'0', NULL, 1, 'http://192.168.0.101:3000//#/676457/guest/viewTender/%7Btoken%7D', 35, 3, NULL, NULL, NULL),
(193, '2018-03-01 07:27:17', NULL, b'0', NULL, 1, 'dasdasd', 4, 1, NULL, NULL, NULL),
(194, '2018-03-01 07:27:17', NULL, b'0', NULL, 1, 'asd', 4, 1, NULL, NULL, NULL),
(195, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'asd', 4, 1, NULL, NULL, NULL),
(196, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'as', 4, 1, NULL, NULL, NULL),
(197, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'd', 4, 1, NULL, NULL, NULL),
(198, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'a', 4, 1, NULL, NULL, NULL),
(199, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'sd', 4, 1, NULL, NULL, NULL),
(200, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, '', 4, 1, NULL, NULL, NULL),
(201, '2018-03-01 07:27:18', NULL, b'0', NULL, 1, 'as', 4, 1, NULL, NULL, NULL),
(202, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'd', 4, 1, NULL, NULL, NULL),
(203, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'as', 4, 1, NULL, NULL, NULL),
(204, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'sda', 4, 1, NULL, NULL, NULL),
(205, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'sd', 4, 1, NULL, NULL, NULL),
(206, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'ass', 4, 1, NULL, NULL, NULL),
(207, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'd', 4, 1, NULL, NULL, NULL),
(208, '2018-03-01 07:27:19', NULL, b'0', NULL, 1, 'as', 4, 1, NULL, NULL, NULL),
(209, '2018-03-01 07:27:24', NULL, b'0', NULL, 1, 'asdasd', 10, 1, NULL, NULL, NULL),
(210, '2018-03-01 07:27:24', NULL, b'0', NULL, 1, 'as', 10, 1, NULL, NULL, NULL),
(211, '2018-03-01 07:27:24', NULL, b'0', NULL, 1, 'd', 10, 1, NULL, NULL, NULL),
(212, '2018-03-01 07:27:24', NULL, b'0', NULL, 1, 'a', 10, 1, NULL, NULL, NULL),
(213, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'sd', 10, 1, NULL, NULL, NULL),
(214, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'as', 10, 1, NULL, NULL, NULL),
(215, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'da', 10, 1, NULL, NULL, NULL),
(216, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'ssd', 10, 1, NULL, NULL, NULL),
(217, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'ass', 10, 1, NULL, NULL, NULL),
(218, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'd', 10, 1, NULL, NULL, NULL),
(219, '2018-03-01 07:27:25', NULL, b'0', NULL, 1, 'asd', 10, 1, NULL, NULL, NULL),
(220, '2018-03-01 07:27:26', NULL, b'0', NULL, 1, 'a', 10, 1, NULL, NULL, NULL),
(221, '2018-03-01 07:27:27', NULL, b'0', NULL, 1, 'xxsa', 1, 2, NULL, NULL, NULL),
(222, '2018-03-01 07:27:34', NULL, b'0', NULL, 1, 'hello', 1, 2, NULL, NULL, NULL),
(223, '2018-03-01 07:27:39', NULL, b'0', NULL, 1, 'asdasd', 1, 1, NULL, NULL, NULL),
(224, '2018-03-01 07:27:43', NULL, b'0', NULL, 1, 'hello', 1, 2, NULL, NULL, NULL),
(225, '2018-03-01 07:27:48', NULL, b'0', NULL, 1, 'cffcerer', 1, 2, NULL, NULL, NULL),
(226, '2018-03-01 07:27:52', NULL, b'0', NULL, 1, 'ljkl', 1, 2, NULL, NULL, NULL),
(227, '2018-03-01 07:28:17', NULL, b'0', NULL, 1, 'jjjjjjjjjj', 37, 2, NULL, NULL, NULL),
(228, '2018-03-01 07:29:41', NULL, b'0', NULL, 1, 'hello', 4, 1, NULL, NULL, NULL),
(229, '2018-03-01 07:29:43', NULL, b'0', NULL, 1, 'fr', 37, 2, NULL, NULL, NULL),
(230, '2018-03-01 07:29:50', NULL, b'0', NULL, 1, 'vfdvdfv', 37, 2, NULL, NULL, NULL),
(231, '2018-03-01 07:29:51', NULL, b'0', NULL, 1, 'hello', 8, 1, NULL, NULL, NULL),
(232, '2018-03-01 07:30:04', NULL, b'0', NULL, 1, 'is this kajal?', 8, 1, NULL, NULL, NULL),
(233, '2018-03-01 07:30:07', NULL, b'0', NULL, 1, 'cdvdvfdfv', 8, 2, NULL, NULL, NULL),
(234, '2018-03-01 07:30:19', NULL, b'0', NULL, 1, 'you received my message?', 8, 1, NULL, NULL, NULL),
(235, '2018-03-01 07:30:21', NULL, b'0', NULL, 1, 'hello', 8, 2, NULL, NULL, NULL),
(236, '2018-03-01 07:30:53', NULL, b'0', NULL, 1, 'hi.............', 1, 2, NULL, NULL, NULL),
(237, '2018-03-01 07:31:21', NULL, b'0', NULL, 1, 'kem??????????????', 1, 2, NULL, NULL, NULL),
(238, '2018-03-01 07:31:26', NULL, b'0', NULL, 1, 'hello', 1, 1, NULL, NULL, NULL),
(239, '2018-03-01 07:31:36', NULL, b'0', NULL, 1, 'hello', 1, 1, NULL, NULL, NULL),
(240, '2018-03-01 07:31:43', NULL, b'0', NULL, 1, 'hi', 1, 1, NULL, NULL, NULL),
(241, '2018-03-01 09:27:15', NULL, b'0', NULL, 1, 'spring.datasource.url = jdbc:mysql://testdb.cllenzkegaw0.us-west-2.rds.amazonaws.com:3306/test_eazeprocure_ebdb?createDatabaseIfNotExist=true #spring.datasource.username = lynkertest #spring.datasource.password = lynkertest123', 1, 2, NULL, NULL, NULL),
(242, '2018-03-12 11:15:57', NULL, b'0', NULL, 1, 'aadsasd', 11, 1, NULL, NULL, NULL),
(243, '2018-03-12 11:15:57', NULL, b'0', NULL, 1, 'a', 11, 1, NULL, NULL, NULL),
(244, '2018-03-12 11:15:57', NULL, b'0', NULL, 1, 'sd', 11, 1, NULL, NULL, NULL),
(245, '2018-03-12 11:15:57', NULL, b'0', NULL, 1, 'as', 11, 1, NULL, NULL, NULL),
(246, '2018-03-12 11:15:57', NULL, b'0', NULL, 1, 'da', 11, 1, NULL, NULL, NULL),
(247, '2018-03-12 11:15:58', NULL, b'0', NULL, 1, 'sd', 11, 1, NULL, NULL, NULL),
(248, '2018-03-12 11:15:58', NULL, b'0', NULL, 1, '', 11, 1, NULL, NULL, NULL),
(249, '2018-03-12 11:15:58', NULL, b'0', NULL, 1, 'as', 11, 1, NULL, NULL, NULL),
(250, '2018-03-12 11:15:58', NULL, b'0', NULL, 1, 'da', 11, 1, NULL, NULL, NULL),
(251, '2018-03-16 06:42:36', NULL, b'0', NULL, 1, 'hello', 11, 3, NULL, NULL, NULL),
(252, '2018-03-16 06:48:41', NULL, b'0', NULL, 1, 'gcgchgdjhgd', 1, 2, NULL, NULL, NULL),
(253, '2018-03-23 12:00:09', NULL, b'0', NULL, 1, 'hello', 15, 3, NULL, NULL, NULL),
(254, '2018-03-26 07:42:18', NULL, b'0', NULL, 1, 'hello', 4, 3, NULL, NULL, NULL),
(255, '2018-03-28 06:58:35', NULL, b'0', NULL, 1, 'fyfyfyfyfyff', 1, 1, NULL, NULL, NULL),
(256, '2018-03-28 06:59:06', NULL, b'0', NULL, 1, 'hello', 1, 2, NULL, NULL, NULL),
(257, '2018-03-28 06:59:14', NULL, b'0', NULL, 1, 'testing', 1, 2, NULL, NULL, NULL),
(258, '2018-03-28 06:59:18', NULL, b'0', NULL, 1, 'jhgsxhjgaschj', 1, 2, NULL, NULL, NULL),
(259, '2018-03-28 06:59:21', NULL, b'0', NULL, 1, 'sdfdsdf', 1, 2, NULL, NULL, NULL),
(260, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'sdf', 1, 2, NULL, NULL, NULL),
(261, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'gdf', 1, 2, NULL, NULL, NULL),
(262, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'g', 1, 2, NULL, NULL, NULL),
(263, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'df', 1, 2, NULL, NULL, NULL),
(264, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'g', 1, 2, NULL, NULL, NULL),
(265, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'df', 1, 2, NULL, NULL, NULL),
(266, '2018-03-28 06:59:22', NULL, b'0', NULL, 1, 'g', 1, 2, NULL, NULL, NULL),
(267, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'd', 1, 2, NULL, NULL, NULL),
(268, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'fg', 1, 2, NULL, NULL, NULL),
(269, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'df', 1, 2, NULL, NULL, NULL),
(270, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'g', 1, 2, NULL, NULL, NULL),
(271, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, '', 1, 2, NULL, NULL, NULL),
(272, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'df', 1, 2, NULL, NULL, NULL),
(273, '2018-03-28 06:59:23', NULL, b'0', NULL, 1, 'g', 1, 2, NULL, NULL, NULL),
(274, '2018-04-05 06:26:16', NULL, b'0', NULL, 1, 'ghfgffgfhg', 1, 2, NULL, NULL, NULL),
(275, '2018-04-05 06:26:21', NULL, b'0', NULL, 1, 'Hello', 1, 2, NULL, NULL, NULL),
(276, '2018-04-05 06:26:31', NULL, b'0', NULL, 1, 'Are you at office!', 1, 2, NULL, NULL, NULL),
(277, '2018-04-05 06:28:01', NULL, b'0', NULL, 1, 'hello', 1, 1, NULL, NULL, NULL),
(278, '2018-04-05 06:28:14', NULL, b'0', NULL, 1, 'who r u..?', 1, 2, NULL, NULL, NULL),
(279, '2018-04-05 06:28:19', NULL, b'0', NULL, 1, 'i m vivekj', 1, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_rooms`
--

CREATE TABLE `chat_rooms` (
  `chat_room_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `chat_room_tag` varchar(255) DEFAULT NULL,
  `user_one` bigint(20) DEFAULT NULL,
  `user_two` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `group_chat` bit(1) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_rooms`
--

INSERT INTO `chat_rooms` (`chat_room_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `chat_room_tag`, `user_one`, `user_two`, `deleted_at`, `group_chat`, `info`, `name`, `status`, `created_by`, `updated_by`, `deleted_by`) VALUES
(1, NULL, NULL, b'0', NULL, 1, 'b1a74fc5-bf3d-4fff-be1b-e2cde1ed51f2', 1, 2, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, b'0', NULL, 1, '76f9106e-78fa-410f-8f6c-77a31ab06938', NULL, NULL, NULL, b'1', NULL, 'jkcdhgjvgj', NULL, NULL, NULL, NULL),
(3, NULL, NULL, b'0', NULL, 1, '2e69b918-2c26-4828-8c0b-77206a487012', NULL, NULL, NULL, b'1', NULL, 'jkcdhgjvgj', NULL, NULL, NULL, NULL),
(4, NULL, NULL, b'0', NULL, 1, 'beaa260d-9a3e-417d-a389-3ff2bd08c2a9', NULL, NULL, NULL, b'1', NULL, 'g1', NULL, NULL, NULL, NULL),
(5, NULL, NULL, b'0', NULL, 1, '080a5cc2-30d5-471e-989e-5c5fad4465e2', NULL, NULL, NULL, b'1', NULL, 'g3', NULL, NULL, NULL, NULL),
(6, NULL, NULL, b'0', NULL, 1, '04b11bf2-7111-42c2-b550-21a7f6f4fcc0', NULL, NULL, NULL, b'1', NULL, 'g5', NULL, NULL, NULL, NULL),
(7, NULL, NULL, b'0', NULL, 1, 'c592fcdc-b544-4bb7-bc8d-6d28d6c88d84', NULL, NULL, NULL, b'1', NULL, 'done', NULL, NULL, NULL, NULL),
(8, NULL, NULL, b'0', NULL, 1, '7760a0a0-df26-4ee3-82bb-ed309a9a9170', NULL, NULL, NULL, b'1', NULL, 'for testing', NULL, NULL, NULL, NULL),
(9, NULL, NULL, b'0', NULL, 1, '37b7f1c4-a55f-4140-b4f0-06bd1029c2c1', 1, 7, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(10, NULL, NULL, b'0', NULL, 1, 'da4b1577-52a9-4f5e-a46d-f3fa2a3c2fd8', 1, 6, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(11, NULL, NULL, b'0', NULL, 1, '704024f5-a5d4-4ee8-8d64-4aafcd09a93e', 1, 3, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(12, NULL, NULL, b'0', NULL, 1, 'f7e9c9cc-0811-4b2b-bdc7-2130da5722c8', 6, 2, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(13, NULL, NULL, b'0', NULL, 1, 'e1d0dbf0-5cd4-4674-9619-602b1759de34', 6, 7, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(14, NULL, NULL, b'0', NULL, 1, 'dbc8a499-3562-421b-be0b-5665364e364a', 6, 5, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(15, NULL, NULL, b'0', NULL, 1, 'aba451eb-d0a7-49b4-9c64-26de3fffda85', 6, 3, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(16, NULL, NULL, b'0', NULL, 1, 'edf5641f-490c-41d0-a0be-be2db736466e', 1, 5, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(17, NULL, NULL, b'0', NULL, 1, 'f56ce785-521c-40b2-a163-d0c0d6f42eb5', 1, 5, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(18, NULL, NULL, b'0', NULL, 1, 'a31625b0-dc56-493e-b79f-c330f8a98fbd', NULL, NULL, NULL, b'1', NULL, 'TEST NEW', NULL, NULL, NULL, NULL),
(19, NULL, NULL, b'0', NULL, 1, 'dca14fba-590b-4535-8391-87c291b340d7', NULL, NULL, NULL, b'1', NULL, 'oyyyyy', NULL, NULL, NULL, NULL),
(20, NULL, NULL, b'0', NULL, 1, '1c0f59b1-3f82-48a3-afa7-0c2fb48b3466', NULL, NULL, NULL, b'1', NULL, 'oyyyyy22222', NULL, NULL, NULL, NULL),
(21, NULL, NULL, b'0', NULL, 1, 'ca27a5cf-8ec6-487a-87e6-1a4b102f2bf3', NULL, NULL, NULL, b'1', NULL, '2222', NULL, NULL, NULL, NULL),
(22, NULL, NULL, b'0', NULL, 1, '199a89b0-29d0-408a-bf67-a7f6fcd42972', NULL, NULL, NULL, b'1', NULL, '2222', NULL, NULL, NULL, NULL),
(23, NULL, NULL, b'0', NULL, 1, '123c1a5b-eb7e-4c15-871e-4b3454a3e2c3', NULL, NULL, NULL, b'1', NULL, '2222', NULL, NULL, NULL, NULL),
(24, NULL, NULL, b'0', NULL, 1, 'b0ecfaa7-2e33-416f-8015-13d1a647d239', NULL, NULL, NULL, b'1', NULL, '333333', NULL, NULL, NULL, NULL),
(25, NULL, NULL, b'0', NULL, 1, '6a8283b9-ddce-4332-95af-eff4785ae2ba', NULL, NULL, NULL, b'1', NULL, '44444', NULL, NULL, NULL, NULL),
(26, NULL, NULL, b'0', NULL, 1, '35cd5060-b2ad-4af4-8b9d-3d6113d8435e', NULL, NULL, NULL, b'1', NULL, '555555', NULL, NULL, NULL, NULL),
(27, NULL, NULL, b'0', NULL, 1, 'a2d04a19-d96b-41a5-a94c-ed0f334023c0', NULL, NULL, NULL, b'1', NULL, '666', NULL, NULL, NULL, NULL),
(28, NULL, NULL, b'0', NULL, 1, '6daab4ec-8bc4-4207-871d-4526f359c2d7', NULL, NULL, NULL, b'1', NULL, '777', NULL, NULL, NULL, NULL),
(29, NULL, NULL, b'0', NULL, 1, '1a11b996-94dc-4264-b071-5e9ca1f52ce2', NULL, NULL, NULL, b'1', NULL, '88888', NULL, NULL, NULL, NULL),
(30, NULL, NULL, b'0', NULL, 1, '93788797-8f44-4870-a8cf-92508024fb79', NULL, NULL, NULL, b'1', NULL, '99999', NULL, NULL, NULL, NULL),
(31, NULL, NULL, b'0', NULL, 1, 'a7b207fe-fd29-42c9-99cf-770fc30404a7', NULL, NULL, NULL, b'1', NULL, '99999', NULL, NULL, NULL, NULL),
(32, NULL, NULL, b'0', NULL, 1, '18f46033-2c1c-4d68-a2f6-f91d6294b147', NULL, NULL, NULL, b'1', NULL, '99999', NULL, NULL, NULL, NULL),
(33, NULL, NULL, b'0', NULL, 1, 'b43b64f4-6d0e-4b50-947e-7c8141aaed3d', NULL, NULL, NULL, b'1', NULL, '99999', NULL, NULL, NULL, NULL),
(34, NULL, NULL, b'0', NULL, 1, '21f78b9f-24cb-41b4-92a0-5024b5dda2a7', NULL, NULL, NULL, b'1', NULL, 'kajal vivek testing', NULL, NULL, NULL, NULL),
(35, NULL, NULL, b'0', NULL, 1, '82272b15-2714-4b78-b59a-7f16542e3de4', 3, 2, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(36, NULL, NULL, b'0', NULL, 1, '4d9bafc5-ca32-452c-b906-72a0631ea3b5', 3, 5, NULL, b'0', NULL, NULL, NULL, NULL, NULL, NULL),
(37, NULL, NULL, b'0', NULL, 1, 'c59c3cfa-e0c2-4a6f-81bd-8be536a0790b', NULL, NULL, NULL, b'1', NULL, 'Testing ', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_room_members`
--

CREATE TABLE `chat_room_members` (
  `chat_room_member_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `admin` bit(1) DEFAULT NULL,
  `chat_room_member_tag` varchar(255) DEFAULT NULL,
  `chat_room_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_room_members`
--

INSERT INTO `chat_room_members` (`chat_room_member_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `admin`, `chat_room_member_tag`, `chat_room_id`, `user_id`, `updated_by`, `deleted_by`) VALUES
(10, NULL, b'0', NULL, NULL, 1, b'0', NULL, 4, 1, NULL, NULL),
(11, NULL, b'0', NULL, NULL, 1, b'0', NULL, 4, 3, NULL, NULL),
(12, '2018-02-19 06:21:58', b'0', NULL, NULL, 1, b'0', NULL, 5, 1, NULL, NULL),
(13, '2018-02-19 06:21:58', b'0', NULL, NULL, 1, b'0', NULL, 5, 3, NULL, NULL),
(14, '2018-02-19 06:21:58', b'0', NULL, NULL, 1, b'1', NULL, 5, 2, NULL, NULL),
(15, '2018-02-19 06:23:53', b'0', NULL, NULL, 1, b'0', NULL, 6, 3, NULL, NULL),
(16, '2018-02-19 06:23:53', b'0', NULL, NULL, 1, b'0', NULL, 6, 1, NULL, NULL),
(17, '2018-02-19 06:23:53', b'0', NULL, NULL, 1, b'1', NULL, 6, 2, NULL, NULL),
(18, '2018-02-19 06:28:12', b'0', NULL, NULL, 1, b'0', NULL, 7, 3, NULL, NULL),
(19, '2018-02-19 06:28:12', b'0', NULL, NULL, 1, b'0', NULL, 7, 1, NULL, NULL),
(20, '2018-02-19 06:28:12', b'0', NULL, NULL, 1, b'1', NULL, 7, 2, NULL, NULL),
(21, '2018-02-19 07:23:58', b'0', NULL, NULL, 1, b'0', NULL, 8, 3, NULL, NULL),
(22, '2018-02-19 07:23:58', b'0', NULL, NULL, 1, b'0', NULL, 8, 5, NULL, NULL),
(23, '2018-02-19 07:23:58', b'0', NULL, NULL, 1, b'1', NULL, 8, 1, NULL, NULL),
(24, '2018-02-19 07:23:58', b'0', NULL, NULL, 1, b'0', NULL, 8, 6, NULL, NULL),
(25, '2018-02-19 07:23:58', b'0', NULL, NULL, 1, b'0', NULL, 8, 2, NULL, NULL),
(26, '2018-02-22 11:02:50', b'0', NULL, NULL, 1, b'0', NULL, 18, 1, NULL, NULL),
(27, '2018-02-22 11:02:50', b'0', NULL, NULL, 1, b'1', NULL, 18, 2, NULL, NULL),
(28, '2018-02-22 12:06:52', b'0', NULL, NULL, 1, b'0', NULL, 19, 1, NULL, NULL),
(29, '2018-02-22 12:06:52', b'0', NULL, NULL, 1, b'1', NULL, 19, 2, NULL, NULL),
(30, '2018-02-22 12:07:41', b'0', NULL, NULL, 1, b'1', NULL, 20, 2, NULL, NULL),
(31, '2018-02-22 12:07:41', b'0', NULL, NULL, 1, b'0', NULL, 20, 1, NULL, NULL),
(32, '2018-02-22 12:08:33', b'0', NULL, NULL, 1, b'0', NULL, 21, 3, NULL, NULL),
(33, '2018-02-22 12:08:33', b'0', NULL, NULL, 1, b'1', NULL, 21, 2, NULL, NULL),
(34, '2018-02-22 12:08:33', b'0', NULL, NULL, 1, b'0', NULL, 21, 1, NULL, NULL),
(35, '2018-02-22 12:08:45', b'0', NULL, NULL, 1, b'0', NULL, 22, 3, NULL, NULL),
(36, '2018-02-22 12:08:45', b'0', NULL, NULL, 1, b'1', NULL, 22, 2, NULL, NULL),
(37, '2018-02-22 12:08:45', b'0', NULL, NULL, 1, b'0', NULL, 22, 1, NULL, NULL),
(38, '2018-02-22 12:09:05', b'0', NULL, NULL, 1, b'0', NULL, 23, 3, NULL, NULL),
(39, '2018-02-22 12:09:05', b'0', NULL, NULL, 1, b'1', NULL, 23, 2, NULL, NULL),
(40, '2018-02-22 12:09:05', b'0', NULL, NULL, 1, b'0', NULL, 23, 1, NULL, NULL),
(41, '2018-02-22 12:09:23', b'0', NULL, NULL, 1, b'0', NULL, 24, 3, NULL, NULL),
(42, '2018-02-22 12:09:23', b'0', NULL, NULL, 1, b'0', NULL, 24, 1, NULL, NULL),
(43, '2018-02-22 12:09:23', b'0', NULL, NULL, 1, b'1', NULL, 24, 2, NULL, NULL),
(44, '2018-02-22 12:09:37', b'0', NULL, NULL, 1, b'1', NULL, 25, 2, NULL, NULL),
(45, '2018-02-22 12:09:37', b'0', NULL, NULL, 1, b'0', NULL, 25, 1, NULL, NULL),
(46, '2018-02-22 12:09:37', b'0', NULL, NULL, 1, b'0', NULL, 25, 3, NULL, NULL),
(47, '2018-02-22 12:09:46', b'0', NULL, NULL, 1, b'1', NULL, 26, 2, NULL, NULL),
(48, '2018-02-22 12:09:46', b'0', NULL, NULL, 1, b'0', NULL, 26, 1, NULL, NULL),
(49, '2018-02-22 12:09:46', b'0', NULL, NULL, 1, b'0', NULL, 26, 3, NULL, NULL),
(50, '2018-02-22 12:10:02', b'0', NULL, NULL, 1, b'0', NULL, 27, 1, NULL, NULL),
(51, '2018-02-22 12:10:02', b'0', NULL, NULL, 1, b'1', NULL, 27, 2, NULL, NULL),
(52, '2018-02-22 12:10:02', b'0', NULL, NULL, 1, b'0', NULL, 27, 3, NULL, NULL),
(53, '2018-02-22 12:10:19', b'0', NULL, NULL, 1, b'0', NULL, 28, 3, NULL, NULL),
(54, '2018-02-22 12:10:19', b'0', NULL, NULL, 1, b'0', NULL, 28, 1, NULL, NULL),
(55, '2018-02-22 12:10:19', b'0', NULL, NULL, 1, b'1', NULL, 28, 2, NULL, NULL),
(56, '2018-02-22 12:10:30', b'0', NULL, NULL, 1, b'0', NULL, 29, 3, NULL, NULL),
(57, '2018-02-22 12:10:30', b'0', NULL, NULL, 1, b'1', NULL, 29, 2, NULL, NULL),
(58, '2018-02-22 12:10:30', b'0', NULL, NULL, 1, b'0', NULL, 29, 1, NULL, NULL),
(59, '2018-02-22 12:10:41', b'0', NULL, NULL, 1, b'0', NULL, 30, 1, NULL, NULL),
(60, '2018-02-22 12:10:41', b'0', NULL, NULL, 1, b'1', NULL, 30, 2, NULL, NULL),
(61, '2018-02-22 12:10:41', b'0', NULL, NULL, 1, b'0', NULL, 30, 3, NULL, NULL),
(62, '2018-02-22 12:11:03', b'0', NULL, NULL, 1, b'0', NULL, 31, 1, NULL, NULL),
(63, '2018-02-22 12:11:03', b'0', NULL, NULL, 1, b'0', NULL, 31, 3, NULL, NULL),
(64, '2018-02-22 12:11:03', b'0', NULL, NULL, 1, b'1', NULL, 31, 2, NULL, NULL),
(65, '2018-02-22 12:11:10', b'0', NULL, NULL, 1, b'1', NULL, 32, 2, NULL, NULL),
(66, '2018-02-22 12:11:10', b'0', NULL, NULL, 1, b'0', NULL, 32, 3, NULL, NULL),
(67, '2018-02-22 12:11:10', b'0', NULL, NULL, 1, b'0', NULL, 32, 1, NULL, NULL),
(68, '2018-02-22 12:11:22', b'0', NULL, NULL, 1, b'0', NULL, 33, 1, NULL, NULL),
(69, '2018-02-22 12:11:22', b'0', NULL, NULL, 1, b'1', NULL, 33, 2, NULL, NULL),
(70, '2018-02-22 12:11:22', b'0', NULL, NULL, 1, b'0', NULL, 33, 3, NULL, NULL),
(71, '2018-02-23 07:08:28', b'0', NULL, NULL, 1, b'0', NULL, 34, 3, NULL, NULL),
(72, '2018-02-23 07:08:28', b'0', NULL, NULL, 1, b'0', NULL, 34, 2, NULL, NULL),
(73, '2018-02-23 07:08:28', b'0', NULL, NULL, 1, b'1', NULL, 34, 1, NULL, NULL),
(74, '2018-02-28 11:31:19', b'0', NULL, NULL, 1, b'1', NULL, 37, 3, NULL, NULL),
(75, '2018-02-28 11:31:19', b'0', NULL, NULL, 1, b'0', NULL, 37, 1, NULL, NULL),
(76, '2018-02-28 11:31:19', b'0', NULL, NULL, 1, b'0', NULL, 37, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `client_tag` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `name` varchar(30) NOT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `client_tag`, `country_code`, `email_id`, `info`, `mobile_no`, `name`, `organization_id`, `user_id`) VALUES
(1, '2018-04-12 06:52:01', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'xdsafsf@gmail.com', 'xasxadxsaeds', '2345665433', 'cc1', 1, 2),
(2, '2018-04-12 06:52:13', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'xdsafsf@gmail.com', 'xasxadxsaeds', '2345665433', 'cc2', 1, 2),
(3, '2018-04-12 06:52:20', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'xdsafsf@gmail.com', 'xasxadxsaeds', '2345665433', 'cc3', 1, 2),
(4, '2018-04-12 06:52:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'xdsafsf@gmail.com', 'xasxadxsaeds', '2345665433', 'cc4', 1, 2),
(5, '2018-04-12 09:12:02', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'jkjskkhas@gamil.com', 'fsfcvsdfgvdeg', '2345678900', 'cc5', 1, 2),
(6, '2018-04-12 09:13:34', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'jkhghjg@gmail.com', 'fvdfvdfgvdf', '345667890', 'cc6', 1, 2),
(7, '2018-04-12 09:14:52', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'jkdshjkhj@ha.com', 'dcsdcse', '2345678987', 'cc7', 1, 2),
(8, '2018-04-12 09:19:17', b'0', NULL, NULL, NULL, NULL, 1, NULL, '91', 'cvfdsfvcsmnb@ha.co', 'edcwscferf', '2345678987', 'cc8', 1, 2),
(9, '2018-04-12 10:40:53', b'0', NULL, NULL, NULL, NULL, 1, NULL, '1246', 'asasas@mail.com', 'aaaaaaaaa', '1231123123', 'c10', 1, 1),
(10, '2018-04-12 10:41:27', b'0', NULL, NULL, NULL, NULL, 1, NULL, '1246', 'asasas@mail.com', 'aaaaaaaaa', '1231123123', 'c11', 1, 1),
(11, '2018-04-12 10:41:46', b'0', NULL, NULL, NULL, NULL, 1, NULL, '1246', 'asasas@mail.com', 'aaaaaaaaa', '1231123123', 'c12', 1, 1),
(12, '2018-04-12 12:31:22', b'0', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'c13', 1, 2),
(13, '2018-04-12 12:33:20', b'0', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'c14', 1, 2),
(14, '2018-04-12 12:34:28', b'0', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'c15', 1, 2),
(15, '2018-04-12 12:36:13', b'0', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'c16', 1, 2),
(16, '2018-04-12 12:36:45', b'0', NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'c16', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `forgot_passwords`
--

CREATE TABLE `forgot_passwords` (
  `forgot_password_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `forgot_password_tag` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `visited_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `content` longblob,
  `file_name` varchar(255) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `image_tag` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`image_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `content`, `file_name`, `file_url`, `image_tag`, `info`, `type`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, NULL, 'userDefault.png', 'https://s3-us-west-2.amazonaws.com/lynkersoft-s3-filestorage-bucket/TalkHives/Public/Images/1518587202385-userDefault.png', '483607', 'Default Profile Pic for any User', 'image/png', NULL, NULL, NULL),
(2, '2018-02-14 06:34:12', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Users/1-images.png', '483721', NULL, 'image/png', NULL, NULL, NULL),
(3, '2018-02-22 09:34:04', NULL, b'0', NULL, 1, NULL, 'Koala.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Users/9', '483721', NULL, 'image/jpeg', NULL, NULL, NULL),
(4, '2018-02-22 09:52:37', NULL, b'0', NULL, 1, NULL, 'Koala.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Users/10', '483721', NULL, 'image/jpeg', NULL, NULL, NULL),
(5, '2018-02-26 10:52:56', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/15/images.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(6, '2018-02-26 10:55:10', NULL, b'0', NULL, 1, NULL, 'p03crg65.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/16/p03crg65.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(7, '2018-02-28 04:57:12', NULL, b'0', NULL, 1, NULL, 'userDefault.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/18/userDefault.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(8, '2018-02-28 04:59:27', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/19/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(9, '2018-02-28 05:02:59', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/20/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(10, '2018-02-28 05:06:23', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/21/images.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(11, '2018-02-28 05:29:15', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/22/images.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(12, '2018-02-28 05:30:33', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/23/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(13, '2018-02-28 05:33:13', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/24/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(14, '2018-02-28 06:00:57', NULL, b'0', NULL, 1, NULL, 'userDefault.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/25/userDefault.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(15, '2018-02-28 06:02:09', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/27/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(16, '2018-02-28 06:37:11', NULL, b'0', NULL, 1, NULL, 'userDefault.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/24/userDefault.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(17, '2018-02-28 06:38:35', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/24/images.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(18, '2018-02-28 07:01:02', NULL, b'0', NULL, 1, NULL, 'p03crg65.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/28/p03crg65.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(19, '2018-02-28 07:14:24', NULL, b'0', NULL, 1, NULL, 'download.jfif', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/29/download.jfif', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(20, '2018-02-28 10:40:50', NULL, b'0', NULL, 1, NULL, 'about-img.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/30/about-img.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(21, '2018-02-28 11:48:22', NULL, b'0', NULL, 1, NULL, 'home-bg.jpeg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/34/home-bg.jpeg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(22, '2018-02-28 12:15:29', NULL, b'0', NULL, 1, NULL, 'images.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/28/images.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(23, '2018-02-28 12:31:08', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/36/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(24, '2018-02-28 12:32:28', NULL, b'0', NULL, 1, NULL, 'bar-chart.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/38/bar-chart.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(25, '2018-02-28 12:32:53', NULL, b'0', NULL, 1, NULL, 'home-bg.jpeg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/39/home-bg.jpeg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(26, '2018-02-28 12:33:27', NULL, b'0', NULL, 1, NULL, 'portfolio-img8.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/40/portfolio-img8.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(27, '2018-02-28 12:35:08', NULL, b'0', NULL, 1, NULL, 'team1.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/41/team1.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(28, '2018-02-28 12:41:15', NULL, b'0', NULL, 1, NULL, 'team4.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/41/team4.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(29, '2018-02-28 12:51:01', NULL, b'0', NULL, 1, NULL, 'ep.png', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/42/ep.png', '483388', NULL, 'image/png', NULL, NULL, NULL),
(30, '2018-02-28 12:57:01', NULL, b'0', NULL, 1, NULL, '4.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/43/4.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(31, '2018-02-28 12:57:59', NULL, b'0', NULL, 1, NULL, '1.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/44/1.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(32, '2018-02-28 13:01:47', NULL, b'0', NULL, 1, NULL, '1.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/45/1.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(33, '2018-03-16 06:40:25', NULL, b'0', NULL, 1, NULL, 'p03crg65.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/41/p03crg65.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(34, '2018-03-16 06:41:51', NULL, b'0', NULL, 1, NULL, 'download.jfif', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/3/download.jfif', '483388', NULL, 'image/jpeg', NULL, NULL, NULL),
(35, '2018-03-23 12:01:10', NULL, b'0', NULL, 1, NULL, 'images.jpg', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Blog/47/images.jpg', '483388', NULL, 'image/jpeg', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE `invitations` (
  `invitation_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `invite_token` varchar(255) DEFAULT NULL,
  `person_name` varchar(255) DEFAULT NULL,
  `registered` bit(1) NOT NULL,
  `invited_as` bigint(20) DEFAULT NULL,
  `invited_by` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invitations`
--

INSERT INTO `invitations` (`invitation_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `email_id`, `invite_token`, `person_name`, `registered`, `invited_as`, `invited_by`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 06:36:04', NULL, b'0', NULL, 1, 'maulik.2304@rediffmail.com', '1365a44c-5c2a-4616-8668-1700f3bcc460', 'maulik', b'1', 3, 1, NULL, NULL, NULL),
(2, '2018-02-14 06:36:18', NULL, b'0', NULL, 1, 'ervicpatel@rediffmail.com', 'c7eb8d79-cbcb-4301-a009-2a593f8c9138', 'Vicky', b'1', 2, 1, NULL, NULL, NULL),
(3, '2018-02-14 06:46:17', NULL, b'0', NULL, 1, 'shelatmaulik16@gmail.com', '9c7fb411-a39c-4c05-b3e8-eb525fcb5adb', 'Lynkersoft', b'1', 5, 3, NULL, NULL, NULL),
(4, '2018-02-14 06:47:18', NULL, b'0', NULL, 1, 'prince.shelat007@gmail.com', '88e8d5a3-412f-46ca-b609-de9d3694d336', 'Maulik', b'1', 5, 3, NULL, NULL, NULL),
(5, '2018-02-15 05:27:27', NULL, b'0', NULL, 1, 'patelvivekb.00@gmail.com', '4beca361-9f2a-4cd8-a15e-aaa55803f336', 'Nana', b'1', 4, 3, NULL, NULL, NULL),
(6, '2018-03-01 12:19:10', NULL, b'0', NULL, 1, 'kajaltrivedi910@rediffmail.com', 'eb59ee18-1673-4d52-86bc-9ffe4107735f', 'Shridevi', b'0', 6, 1, NULL, NULL, NULL),
(7, '2018-03-01 12:19:57', NULL, b'0', NULL, 1, 'kajaltrivedi910@rediffmail.com', '363ed985-02b5-4f09-aed7-eabe4d43930e', 'aliya Bhatt', b'0', 6, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `login_users`
--

CREATE TABLE `login_users` (
  `login_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `logged_out` bit(1) DEFAULT NULL,
  `login_token` varchar(255) DEFAULT NULL,
  `th_tag` varchar(255) DEFAULT NULL,
  `ws_connection` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_users`
--

INSERT INTO `login_users` (`login_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `logged_out`, `login_token`, `th_tag`, `ws_connection`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 06:34:22', NULL, b'0', NULL, 1, b'0', '8e1919c4-72ac-4c5b-8fbf-897677fd54ef', '00017001g', b'1', NULL, NULL, NULL),
(2, '2018-02-14 06:45:28', NULL, b'0', NULL, 1, b'0', '387ad807-f108-4a3a-943c-74f976899612', '00037001s', b'1', NULL, NULL, NULL),
(3, '2018-02-14 06:52:41', NULL, b'0', NULL, 1, b'0', 'cbe223a6-67d2-4906-92b9-0739b81b377d', '00037001s', b'1', NULL, NULL, NULL),
(4, '2018-02-14 07:13:08', NULL, b'0', NULL, 1, b'0', '3d7b9505-67b6-4320-a617-fd517e23bd09', '00037001s', b'1', NULL, NULL, NULL),
(5, '2018-02-14 07:22:32', NULL, b'0', NULL, 1, b'0', '1c12cdcd-6a21-4a06-ad98-9066b6291c94', '00037001s', b'1', NULL, NULL, NULL),
(6, '2018-02-14 11:27:16', NULL, b'0', NULL, 1, b'0', 'ae1c0aa1-ca00-401c-8fc7-e973ae80fb74', '00037001s', b'1', NULL, NULL, NULL),
(7, '2018-02-14 11:28:03', NULL, b'0', NULL, 1, b'0', '28a341b3-e44c-477b-a621-faada9d443e2', '00037001s', b'1', NULL, NULL, NULL),
(8, '2018-02-14 11:31:05', NULL, b'0', NULL, 1, b'0', '6e2a85ea-2321-4d16-9282-7c42536f9b3c', '00017001g', b'1', NULL, NULL, NULL),
(9, '2018-02-14 12:35:08', NULL, b'0', NULL, 1, b'0', '58d1d993-74fb-4134-98f5-3e247fad4a23', '00037001s', b'1', NULL, NULL, NULL),
(10, '2018-02-15 05:31:47', NULL, b'0', NULL, 1, b'0', '8234fa44-02e7-4489-a159-9b7a0abf52d7', 'l00170007', b'1', NULL, NULL, NULL),
(11, '2018-02-15 05:32:23', NULL, b'0', NULL, 1, b'0', '636a0f86-2b31-4361-a7ab-1206c6a584f5', '00037001s', b'1', NULL, NULL, NULL),
(12, '2018-02-15 06:08:23', NULL, b'0', NULL, 1, b'0', 'dc38532f-bb90-4d99-beb1-ee45ac7262f9', '00017001g', b'1', NULL, NULL, NULL),
(13, '2018-02-15 06:09:03', NULL, b'0', NULL, 1, b'0', '95426b8f-2178-4d6a-a14c-62ec41d50876', '00017001g', b'1', NULL, NULL, NULL),
(14, '2018-02-16 05:29:44', NULL, b'0', NULL, 1, b'0', 'e86657e4-d65a-4d89-9e26-bfce331d885b', '00037001s', b'1', NULL, NULL, NULL),
(15, '2018-02-16 05:31:03', NULL, b'0', NULL, 1, b'0', '1ae8566c-5592-46dd-90c8-10a555d73277', '00017001g', b'1', NULL, NULL, NULL),
(16, '2018-02-16 10:46:16', NULL, b'0', NULL, 1, b'0', 'b129cb5a-bf5a-4305-bc82-be4e4b8b2eb3', '00017001g', b'1', NULL, NULL, NULL),
(17, '2018-02-16 11:03:41', NULL, b'0', NULL, 1, b'0', '9df8ec8e-5db3-4471-8374-895f082875d8', '00017001g', b'1', NULL, NULL, NULL),
(18, '2018-02-16 11:10:14', NULL, b'0', NULL, 1, b'0', 'a62c24b9-0a0f-418b-8fd0-42901cb8b6c6', '00017001g', b'1', NULL, NULL, NULL),
(19, '2018-02-16 11:11:19', NULL, b'0', NULL, 1, b'0', 'adf1d0f1-a905-463c-9c1b-96d88e047d4b', '00017001g', b'1', NULL, NULL, NULL),
(20, '2018-02-16 11:12:31', NULL, b'0', NULL, 1, b'0', 'dcdc9258-2e69-451a-ac42-ca7a8f85b8b1', '00017001g', b'1', NULL, NULL, NULL),
(21, '2018-02-16 11:49:26', NULL, b'0', NULL, 1, b'0', 'cc1a0efb-9b23-438c-bc3d-8f1069c96bbe', '00017001g', b'1', NULL, NULL, NULL),
(22, '2018-02-16 12:59:28', NULL, b'0', NULL, 1, b'0', 'ed07e220-fd31-4bff-a29a-44ba2b667680', '00027001s', b'1', NULL, NULL, NULL),
(23, '2018-02-19 05:24:52', NULL, b'0', NULL, 1, b'0', '4fcaba5f-e343-47bb-8b5d-45218695e734', '00017001g', b'1', NULL, NULL, NULL),
(24, '2018-02-19 05:55:20', NULL, b'0', NULL, 1, b'0', '97cfef5f-a213-475b-a88f-2c68dcbd40ce', '00027001s', b'1', NULL, NULL, NULL),
(25, '2018-02-19 07:22:42', NULL, b'0', NULL, 1, b'0', '13a551df-aefa-42fd-a626-27b210ce91f1', 'g00170006', b'1', NULL, NULL, NULL),
(26, '2018-02-19 07:35:49', NULL, b'0', NULL, 1, b'0', 'c3f772a3-3ec8-4f24-976c-afd7b9889d00', '00017001g', b'1', NULL, NULL, NULL),
(27, '2018-02-20 04:45:50', NULL, b'0', NULL, 1, b'0', '2c305279-b930-4292-ae74-c00e07eb58a9', '00017001g', b'1', NULL, NULL, NULL),
(28, '2018-02-20 08:33:21', NULL, b'0', NULL, 1, b'0', 'd202866d-1aeb-4369-9ad8-e179cc89c9d1', '00017001g', b'1', NULL, NULL, NULL),
(29, '2018-02-20 11:46:19', NULL, b'0', NULL, 1, b'0', 'f70e50e4-fcce-4cd7-8a81-43fbe2517546', '00037001s', b'1', NULL, NULL, NULL),
(30, '2018-02-20 11:49:41', NULL, b'0', NULL, 1, b'0', '93050fe4-2e84-45e9-9fbb-dc3a7cf030c6', '00037001s', b'1', NULL, NULL, NULL),
(31, '2018-02-21 05:23:27', NULL, b'0', NULL, 1, b'0', 'e7276da9-e02b-437a-9269-7fddf9d7773f', '00017001g', b'1', NULL, NULL, NULL),
(32, '2018-02-21 06:09:04', NULL, b'0', NULL, 1, b'0', '6d25ee1d-60ee-489d-8f83-cf238694f766', '00017001g', b'1', NULL, NULL, NULL),
(33, '2018-02-21 11:31:34', NULL, b'0', NULL, 1, b'0', 'b7c07575-e47c-4938-8761-58dda5935785', '00017001g', b'1', NULL, NULL, NULL),
(34, '2018-02-22 05:12:14', NULL, b'0', NULL, 1, b'0', '71d9aba3-e69d-4ada-ad1e-4065453b3c16', '00017001g', b'1', NULL, NULL, NULL),
(35, '2018-02-22 06:43:04', NULL, b'0', NULL, 1, b'0', '81c0dbc6-9e90-4656-a88b-d231f2691f2f', '00027001s', b'1', NULL, NULL, NULL),
(36, '2018-02-22 06:43:17', NULL, b'0', NULL, 1, b'0', 'd8266877-d864-4e74-b662-9d52058a29bd', '00017001g', b'1', NULL, NULL, NULL),
(37, '2018-02-22 09:57:41', NULL, b'0', NULL, 1, b'0', 'e444b7cd-9a7f-4979-893b-095ebbc83635', '00017001g', b'1', NULL, NULL, NULL),
(38, '2018-02-23 06:07:42', NULL, b'0', NULL, 1, b'0', '3707b3d6-4ba4-4041-9213-c3df9f7b32e2', '00017001g', b'1', NULL, NULL, NULL),
(39, '2018-02-23 07:11:24', NULL, b'0', NULL, 1, b'0', '96d7567a-be37-4438-b3f3-5231cd27f637', '00037001s', b'1', NULL, NULL, NULL),
(40, '2018-02-26 05:21:03', NULL, b'0', NULL, 1, b'0', '6704a241-b8b6-4f12-a394-11955cafb4e9', '00037001s', b'1', NULL, NULL, NULL),
(41, '2018-02-26 05:41:32', NULL, b'0', NULL, 1, b'0', '65f565ff-bc8f-465a-b560-eaf9e3c5c0a7', '00017001g', b'1', NULL, NULL, NULL),
(42, '2018-02-26 05:44:39', NULL, b'0', NULL, 1, b'0', '5e1b0766-0678-4e60-a5b3-45ec61db6492', '00017001g', b'1', NULL, NULL, NULL),
(43, '2018-02-26 12:50:07', NULL, b'0', NULL, 1, b'0', '322b03c3-fdb6-4e1f-aa81-ede61fb93cf8', '00027001s', b'1', NULL, NULL, NULL),
(44, '2018-02-26 12:51:01', NULL, b'0', NULL, 1, b'0', '99651f7c-66b4-4ca7-8d37-93b36f1d0711', '00027001s', b'1', NULL, NULL, NULL),
(45, '2018-02-26 12:55:52', NULL, b'0', NULL, 1, b'0', '58e13499-794b-47cd-9015-0aed95313189', '00037001s', b'1', NULL, NULL, NULL),
(46, '2018-02-28 08:33:32', NULL, b'0', NULL, 1, b'0', 'c974ef2d-2a6d-4088-9987-693163f9a2e6', '00017001g', b'1', NULL, NULL, NULL),
(47, '2018-02-28 08:40:07', NULL, b'0', NULL, 1, b'0', '1edc00b6-99d2-457b-a994-b9a7f6d440af', '00037001s', b'1', NULL, NULL, NULL),
(48, '2018-02-28 09:42:34', NULL, b'0', NULL, 1, b'0', 'ac64e63f-c574-4acf-80f7-61a7a7885d2c', '00017001g', b'1', NULL, NULL, NULL),
(49, '2018-02-28 09:43:24', NULL, b'0', NULL, 1, b'0', 'dac11326-2726-49f7-b5c1-1d5a2bae7a89', '00017001g', b'1', NULL, NULL, NULL),
(50, '2018-02-28 09:44:54', NULL, b'0', NULL, 1, b'0', 'e3a5d183-e0d1-418a-bdbe-e2524f704688', '00027001s', b'1', NULL, NULL, NULL),
(51, '2018-02-28 09:46:47', NULL, b'0', NULL, 1, b'0', '279aae6a-56a2-4c62-b3a1-1ae51f2ce921', '00017001g', b'1', NULL, NULL, NULL),
(52, '2018-02-28 09:54:16', NULL, b'0', NULL, 1, b'0', 'a9f91214-941e-4093-944c-d3908fcfe897', '00027001s', b'1', NULL, NULL, NULL),
(53, '2018-02-28 09:54:26', NULL, b'0', NULL, 1, b'0', 'c0057ace-9187-4c1c-96e9-c7c02310153d', '00037001s', b'1', NULL, NULL, NULL),
(54, '2018-02-28 09:55:54', NULL, b'0', NULL, 1, b'0', 'ceb4401e-c1da-42df-a732-48c8036d7b0a', '00017001g', b'1', NULL, NULL, NULL),
(55, '2018-02-28 11:06:07', NULL, b'0', NULL, 1, b'0', '2b502f75-e8c7-4455-a408-05de6683392f', '00017001g', b'1', NULL, NULL, NULL),
(56, '2018-02-28 11:06:15', NULL, b'0', NULL, 1, b'0', 'e2591a35-718e-41c0-b490-ccc8583c002d', '00037001s', b'1', NULL, NULL, NULL),
(57, '2018-02-28 11:18:43', NULL, b'0', NULL, 1, b'0', '71999388-7ee4-4a59-a35a-380af4cc12af', '00037001s', b'1', NULL, NULL, NULL),
(58, '2018-02-28 11:19:07', NULL, b'0', NULL, 1, b'0', '1d97f788-f152-4719-a509-b27ccb6aa466', '00027001s', b'1', NULL, NULL, NULL),
(59, '2018-02-28 11:19:25', NULL, b'0', NULL, 1, b'0', '9d2918dc-73b1-4438-9566-27755ba70ca5', '00027001s', b'1', NULL, NULL, NULL),
(60, '2018-02-28 11:19:37', NULL, b'0', NULL, 1, b'0', '4096fb71-1550-4ce9-a08b-b36043782480', '00017001g', b'1', NULL, NULL, NULL),
(61, '2018-02-28 13:01:18', NULL, b'0', NULL, 1, b'0', '97d9e020-1cdf-4262-8660-e664c143cbd6', '00017001g', b'1', NULL, NULL, NULL),
(62, '2018-02-28 13:02:03', NULL, b'0', NULL, 1, b'0', '218ee2af-c233-4e0f-a138-10194e1f11b8', '00037001s', b'1', NULL, NULL, NULL),
(63, '2018-02-28 13:10:23', NULL, b'0', NULL, 1, b'0', 'b79f73e2-319e-41a9-864c-e357d942c13a', 'g00170006', b'1', NULL, NULL, NULL),
(64, '2018-02-28 13:12:23', NULL, b'0', NULL, 1, b'0', 'c59f2cce-7fde-45ec-9b90-8cd35f7c4cbf', '00037001s', b'1', NULL, NULL, NULL),
(65, '2018-02-28 13:14:05', NULL, b'0', NULL, 1, b'0', '03ce3303-ec71-41b2-841e-75b1aebfdb01', '00027001s', b'1', NULL, NULL, NULL),
(66, '2018-02-28 13:14:36', NULL, b'0', NULL, 1, b'0', '58cf4ed8-f687-4f98-9f44-1114041aa944', 'l00170007', b'1', NULL, NULL, NULL),
(67, '2018-02-28 13:15:02', NULL, b'0', NULL, 1, b'0', '30b2e5e1-67aa-498e-bfdf-2be09f3e863b', '00037001s', b'1', NULL, NULL, NULL),
(68, '2018-03-01 05:42:09', NULL, b'0', NULL, 1, b'0', 'a1af73ab-3780-4640-b109-6d64a08a233a', '00037001s', b'1', NULL, NULL, NULL),
(69, '2018-03-01 06:13:56', NULL, b'0', NULL, 1, b'0', '4b12dbbe-cd6b-4396-8da1-ba162a33a281', '00017001g', b'1', NULL, NULL, NULL),
(70, '2018-03-01 06:17:36', NULL, b'0', NULL, 1, b'0', '3da7bf25-c45b-452a-ad28-4b81a3c49afa', '00027001s', b'1', NULL, NULL, NULL),
(71, '2018-03-01 07:24:58', NULL, b'0', NULL, 1, b'0', '86861282-d03f-4dd4-bb70-412373965e8e', '00017001g', b'1', NULL, NULL, NULL),
(72, '2018-03-01 07:26:20', NULL, b'0', NULL, 1, b'0', '89697002-116a-4c3e-96d9-6335bcf15f34', '00017001g', b'1', NULL, NULL, NULL),
(73, '2018-03-01 07:26:37', NULL, b'0', NULL, 1, b'0', '0f8c36da-91c5-4118-8bcf-e3f1b3845bb1', '00027001s', b'1', NULL, NULL, NULL),
(74, '2018-03-01 07:29:13', NULL, b'0', NULL, 1, b'0', '78ee3761-415e-4b9a-b05e-7148a7e22248', '00017001g', b'1', NULL, NULL, NULL),
(75, '2018-03-01 08:27:08', NULL, b'0', NULL, 1, b'0', '4347fe06-946a-4763-b76d-6f2f2b4d40cd', '00017001g', b'1', NULL, NULL, NULL),
(76, '2018-03-01 11:19:00', NULL, b'0', NULL, 1, b'0', 'ca9990a4-1102-471d-94b1-c416cc504ff5', '00017001g', b'1', NULL, NULL, NULL),
(77, '2018-03-01 11:19:51', NULL, b'0', NULL, 1, b'0', '7381f8c3-8c13-43cb-b574-f10ccd177fe6', '00027001s', b'1', NULL, NULL, NULL),
(78, '2018-03-01 11:27:07', NULL, b'0', NULL, 1, b'0', '31ebd141-89ea-4fe5-b962-67b23ae2a82d', '00037001s', b'1', NULL, NULL, NULL),
(79, '2018-03-01 12:57:36', NULL, b'0', NULL, 1, b'0', 'ee5aa825-d8aa-42ed-9b9c-a27bb7542cd4', '00037001s', b'1', NULL, NULL, NULL),
(80, '2018-03-05 05:34:19', NULL, b'0', NULL, 1, b'0', '893127ef-af54-4027-a51c-256ee6a687b3', '00027001s', b'1', NULL, NULL, NULL),
(81, '2018-03-05 08:49:31', NULL, b'0', NULL, 1, b'0', 'd660aae3-ea6e-4744-a458-1e530dd8355b', '00017001g', b'1', NULL, NULL, NULL),
(82, '2018-03-05 09:39:56', NULL, b'0', NULL, 1, b'0', '39f5d949-c1ea-4ce4-a81f-fb478b43a628', '00027001s', b'1', NULL, NULL, NULL),
(83, '2018-03-05 09:45:13', NULL, b'0', NULL, 1, b'0', '02e5f35c-855f-48ee-bdc1-4f27ca7f7bdb', '00037001s', b'1', NULL, NULL, NULL),
(84, '2018-03-09 05:46:46', NULL, b'0', NULL, 1, b'0', '62a94139-2c42-46f4-b9a4-e29bcae5e3d5', '00017001g', b'1', NULL, NULL, NULL),
(85, '2018-03-09 09:05:43', NULL, b'0', NULL, 1, b'0', '8b931e9a-ad06-4bbe-9fc5-248e9a811e20', '00037001s', b'1', NULL, NULL, NULL),
(86, '2018-03-09 09:08:24', NULL, b'0', NULL, 1, b'0', '9c2d03d8-5834-4f99-bdc5-8a11825a55f3', '00017001g', b'1', NULL, NULL, NULL),
(87, '2018-03-09 09:09:05', NULL, b'0', NULL, 1, b'0', '3ba9b02b-9e1d-4df4-b11f-9cba6bda39a5', '00017001g', b'1', NULL, NULL, NULL),
(88, '2018-03-12 12:09:42', NULL, b'0', NULL, 1, b'0', 'bf60a6e3-056d-4481-8538-d81d926db58f', '00027001s', b'1', NULL, NULL, NULL),
(89, '2018-03-13 09:18:38', NULL, b'0', NULL, 1, b'0', '5675b7ed-e5bc-4729-862a-831246a9f7a4', '00037001s', b'1', NULL, NULL, NULL),
(90, '2018-03-14 06:20:24', NULL, b'0', NULL, 1, b'0', 'dfd083df-ce78-438f-b02e-dbedd665afe5', '00017001g', b'1', NULL, NULL, NULL),
(91, '2018-03-16 06:10:31', NULL, b'0', NULL, 1, b'0', '5041e35d-2b53-4fdd-b271-b513a2146bef', '00037001s', b'1', NULL, NULL, NULL),
(92, '2018-03-19 05:32:54', NULL, b'0', NULL, 1, b'0', '5a02c62c-9ece-4f67-8a2a-e9cf5a87c31f', '00037001s', b'1', NULL, NULL, NULL),
(93, '2018-03-19 05:51:10', NULL, b'0', NULL, 1, b'0', '9f54d23b-60b2-4b44-a26c-d2ffa8283a6e', '00037001s', b'1', NULL, NULL, NULL),
(94, '2018-03-21 10:32:31', NULL, b'0', NULL, 1, b'0', '3123454c-14d1-47cc-a01e-038299b2424b', '00037001s', b'1', NULL, NULL, NULL),
(95, '2018-03-26 07:52:31', NULL, b'0', NULL, 1, b'0', '6600bb35-a73d-41c1-98ea-f60594661858', '00017001g', b'1', NULL, NULL, NULL),
(96, '2018-03-26 07:57:12', NULL, b'0', NULL, 1, b'0', '4c0bc8eb-de37-43bc-aa27-632a173a18ee', '00037001s', b'1', NULL, NULL, NULL),
(97, '2018-03-28 06:58:45', NULL, b'0', NULL, 1, b'0', 'f5be4849-70d3-4813-a7c1-df5831958044', '00027001s', b'1', NULL, NULL, NULL),
(98, '2018-03-28 07:55:10', NULL, b'0', NULL, 1, b'0', 'a296961a-999d-4a51-8a53-df2525621ed9', '00037001s', b'1', NULL, NULL, NULL),
(99, '2018-03-30 09:32:38', NULL, b'0', NULL, 1, b'0', '0bbeeeb9-e3fb-42e0-9925-23baa3b3b1cf', '00027001s', b'1', NULL, NULL, NULL),
(100, '2018-04-03 06:15:51', NULL, b'0', NULL, 1, b'0', '2a47f92e-0ffd-4be3-b1ae-2682eca3fc92', '00027001s', b'1', NULL, NULL, NULL),
(101, '2018-04-03 06:17:06', NULL, b'0', NULL, 1, b'0', '6c61b99e-22ed-4a4e-aadf-00f5abb166b5', '00037001s', b'1', NULL, NULL, NULL),
(102, '2018-04-03 09:37:31', NULL, b'0', NULL, 1, b'0', '2d7f5dfa-378d-4e25-a052-1a6770d47d2e', '00017001g', b'1', NULL, NULL, NULL),
(103, '2018-04-05 12:47:37', NULL, b'0', NULL, 1, b'0', '3f672156-090a-4a62-8b67-9d59ab53d871', '00027001s', b'1', NULL, NULL, NULL),
(104, '2018-04-06 06:36:55', NULL, b'0', NULL, 1, b'0', '5e6cc6ad-4b79-41a5-a785-71ef99207b54', '00027001s', b'1', NULL, NULL, NULL),
(105, '2018-04-06 06:37:31', NULL, b'0', NULL, 1, b'0', 'd5c8b574-3da0-4793-822e-cdac4a156bd0', '00017001g', b'1', NULL, NULL, NULL),
(106, '2018-04-06 07:13:22', NULL, b'0', NULL, 1, b'0', '8b5c4ef9-ef95-4be4-862c-12b191d4e2f8', '00017001g', b'1', NULL, NULL, NULL),
(107, '2018-04-06 07:32:46', NULL, b'0', NULL, 1, b'0', 'd4deeed7-fcff-4834-8ee3-2c6c1d0bfa6e', '00017001g', b'1', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `new_entity`
--

CREATE TABLE `new_entity` (
  `id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `tag` varchar(255) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `notification_tag` varchar(255) DEFAULT NULL,
  `seen` bit(1) DEFAULT NULL,
  `self` bit(1) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `blog_id` bigint(20) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `privacy_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `receiver` bigint(20) DEFAULT NULL,
  `sender` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `vote_id` bigint(20) DEFAULT NULL,
  `who` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `task_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `info`, `message`, `notification_tag`, `seen`, `self`, `token`, `type`, `blog_id`, `organization_id`, `post_id`, `privacy_id`, `project_id`, `receiver`, `sender`, `team_id`, `vote_id`, `who`, `updated_by`, `deleted_by`, `task_id`) VALUES
(1, '2018-03-26 09:24:05', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat added a new post', '422', NULL, b'0', 'dc77cafa-8161-4d27-adcf-4d4d3d29c2af', '1269', NULL, 1, 236, 8, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(2, '2018-03-26 09:24:31', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has shared Maulik Shelat''s post', '422', NULL, b'0', '6c11d7e6-dcc8-49e4-8d2c-6ed699d3008f', '1269', NULL, 1, 237, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(3, '2018-03-26 09:24:31', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has shared your post', '422', NULL, b'1', '5d4dd54b-d9cd-4c8c-addc-a88aa4514e50', '415', NULL, 1, 237, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(4, '2018-03-26 11:36:00', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat added a new post', '422', NULL, b'0', 'a163d2bb-5c8e-49a5-9a90-e47c5c1a6c1b', '1269', NULL, 1, 238, 8, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(5, '2018-03-28 07:04:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new post', '422', NULL, b'0', 'f2525dbf-3c08-44ef-b8cc-a09191840220', '1269', NULL, 1, 240, 8, NULL, NULL, 2, NULL, NULL, 2, NULL, NULL, NULL),
(6, '2018-03-28 07:54:39', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'0', 'aa56b21e-58f3-47b7-a88b-73ef309fff53', '415', NULL, 1, 240, 8, NULL, 2, 2, NULL, NULL, 2, NULL, NULL, NULL),
(7, '2018-03-28 07:54:39', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked his post', '422', NULL, b'0', 'c1ab1059-3ebe-44e1-80c8-59d1d7628d77', '1269', NULL, 1, 240, 8, NULL, NULL, 2, NULL, NULL, 2, NULL, NULL, NULL),
(8, '2018-03-28 07:59:47', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked your post', '422', NULL, b'0', 'f1d1db3d-60bf-47d1-b9fb-e6040a629770', '415', NULL, 1, 240, 8, NULL, 2, 1, NULL, NULL, 2, NULL, NULL, NULL),
(9, '2018-03-28 07:59:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked his post', '422', NULL, b'0', '934ec8e1-9462-4fdf-a10e-a7369b67b3fe', '1269', NULL, 1, 240, 8, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, NULL),
(10, '2018-03-28 08:19:48', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked your post', '422', NULL, b'0', 'dd9d5bfe-4b46-4d55-89ee-9ec223e08f1d', '415', NULL, 1, 240, 8, NULL, 2, 1, NULL, NULL, 2, NULL, NULL, NULL),
(11, '2018-03-28 08:19:48', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked his post', '422', NULL, b'0', '3ecfb5b4-6e2c-4740-8179-e78c638af63e', '1269', NULL, 1, 240, 8, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, NULL),
(12, '2018-03-28 08:19:50', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked your post', '422', NULL, b'0', '1ca72c80-ba71-4626-ac04-9c85eec1ae5c', '415', NULL, 1, 240, 8, NULL, 2, 1, NULL, NULL, 2, NULL, NULL, NULL),
(13, '2018-03-28 08:19:50', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked his post', '422', NULL, b'0', '4ce7823c-bf03-4530-8d15-25f695c2f553', '1269', NULL, 1, 240, 8, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, NULL),
(14, '2018-03-28 08:27:46', b'0', NULL, NULL, 1, NULL, 'Vivek Patel added a new post', '422', NULL, b'0', '88f931f1-95bf-4ff1-b66b-35bfad6bce40', '1269', NULL, 1, 241, 8, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL),
(15, '2018-03-28 08:28:06', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'0', '60f09652-be75-417e-aa85-0f1c991003b7', '415', NULL, 1, 241, 8, NULL, 1, 2, NULL, NULL, 1, NULL, NULL, NULL),
(16, '2018-03-28 08:28:06', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked his post', '422', NULL, b'0', '93aaa7e3-3541-4108-8fc0-708f6f5fa34e', '1269', NULL, 1, 241, 8, NULL, NULL, 2, NULL, NULL, 1, NULL, NULL, NULL),
(17, '2018-03-28 08:33:07', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'0', '1db6b9ed-0792-41f6-8fe5-61bb029d28b6', '415', NULL, 1, 241, 8, NULL, 1, 1, NULL, NULL, 1, NULL, NULL, NULL),
(18, '2018-03-28 08:33:07', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked his post', '422', NULL, b'0', '72264caf-69ce-4ad5-a47b-01d822b3ab6c', '1269', NULL, 1, 241, 8, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL),
(19, '2018-03-28 08:34:05', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'0', 'd71c9710-d6f2-495c-a1ba-9edab1547d8f', '415', NULL, 1, 210, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(20, '2018-03-28 08:34:05', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', '40aa54b5-849b-4fa9-b4c7-25c39c044dc1', '1269', NULL, 1, 210, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(21, '2018-03-28 08:34:52', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'0', '5238ba70-3e1c-4114-b531-42ec3350a444', '415', NULL, 1, 194, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(22, '2018-03-28 08:34:52', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', 'ab1a405f-c5b0-4a2a-9481-c0e61fd43aea', '1269', NULL, 1, 194, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(23, '2018-03-28 08:40:19', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked your post', '422', NULL, b'0', '7402e557-923e-49fd-a109-2198bf35d12b', '415', NULL, 1, 210, 8, NULL, 3, 1, NULL, NULL, 3, NULL, NULL, NULL),
(24, '2018-03-28 08:40:19', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked Maulik Shelat''s post', '422', NULL, b'0', 'd0c54979-4783-41c8-853f-5451dd9d1edd', '1269', NULL, 1, 210, 8, NULL, NULL, 1, NULL, NULL, 3, NULL, NULL, NULL),
(25, '2018-03-28 08:46:03', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked your post', '422', NULL, b'1', 'a87c7bf1-442f-4520-859f-6f025543d79d', '415', NULL, 1, 206, 8, NULL, 3, 1, NULL, NULL, 3, NULL, NULL, NULL),
(26, '2018-03-28 08:46:03', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has liked Maulik Shelat''s post', '422', NULL, b'0', '7720bb70-f724-463c-a42e-82c0881af0bd', '1269', NULL, 1, 206, 8, NULL, NULL, 1, NULL, NULL, 3, NULL, NULL, NULL),
(27, '2018-03-28 09:11:07', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', 'b8bc80ec-bf7b-4e20-9876-62507c0c3de7', '415', NULL, 1, 191, 8, NULL, 1, 2, NULL, NULL, 1, NULL, NULL, NULL),
(28, '2018-03-28 09:11:08', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Vivek Patel''s post', '422', NULL, b'0', '834f89de-fd1d-44cb-b117-21856257ed08', '1269', NULL, 1, 191, 8, NULL, NULL, 2, NULL, NULL, 1, NULL, NULL, NULL),
(29, '2018-03-28 09:45:28', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'1', 'da42b33f-8d33-4163-a8a9-acc714c59264', '415', NULL, 1, 237, 8, NULL, 3, 3, NULL, NULL, 3, NULL, NULL, NULL),
(30, '2018-03-28 09:45:28', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has liked own post', '422', NULL, b'0', 'ef60a7b0-b816-4cad-a2b0-05b833d69306', '1269', NULL, 1, 237, 8, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(31, '2018-03-28 09:46:53', b'0', NULL, NULL, 1, NULL, 'You have commented on your post', '422', NULL, b'1', '77f2cb93-c026-48b0-bbba-262fd3ce1013', '415', NULL, 1, 241, 8, NULL, 1, 1, NULL, NULL, 1, NULL, NULL, NULL),
(32, '2018-03-28 09:46:53', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has commented on own post', '422', NULL, b'0', 'dc0349c5-5d18-496d-9974-ca3c37a5570f', '1269', NULL, 1, 241, 8, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL),
(33, '2018-03-28 09:49:58', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'1', '463fb4ef-7af2-42bb-9067-f47a290afd19', '415', NULL, 1, 237, 8, NULL, 3, 3, NULL, NULL, 3, NULL, NULL, NULL),
(34, '2018-03-28 09:49:58', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has liked own post', '422', NULL, b'0', '66e90b58-234b-4bb8-8cc1-de514ac79790', '1269', NULL, 1, 237, 8, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(35, '2018-03-28 09:51:35', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'1', 'dbcba217-bc4c-4a3d-88c5-0214231d9410', '415', NULL, 1, 230, 8, NULL, 3, 3, NULL, NULL, 3, NULL, NULL, NULL),
(36, '2018-03-28 09:51:35', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has liked own post', '422', NULL, b'0', 'ea8b6980-04ff-4741-9414-7dbc9ab03d6c', '1269', NULL, 1, 230, 8, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(37, '2018-03-28 10:05:09', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat added a new blog', '388', NULL, b'0', '205cdebd-059d-4fb5-942e-3bd3d30bf01f', '1269', 48, 1, NULL, NULL, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(38, '2018-03-28 10:05:30', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat added a new blog', '388', NULL, b'0', '9c24977c-32d4-4db0-bf71-70d95d4aee20', '1269', 49, 1, NULL, NULL, NULL, NULL, 3, NULL, NULL, 3, NULL, NULL, NULL),
(39, '2018-03-30 06:36:36', b'0', NULL, NULL, 1, NULL, 'You have liked your post', '422', NULL, b'1', '5f9c7d25-d17a-4cb9-b8b0-ccb78da0f30c', '415', NULL, 1, 243, 1, NULL, 1, 1, NULL, NULL, 1, NULL, NULL, NULL),
(45, '2018-03-30 09:33:20', b'0', NULL, NULL, 1, NULL, 'Vivek Patel added a new vote', '410', NULL, b'0', 'e3f3ec80-d8c0-4198-8b60-59bdfc4aa610', '1269', NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, 13, 1, NULL, NULL, NULL),
(50, '2018-03-30 10:28:36', b'0', NULL, NULL, 1, NULL, 'You have voted your vote', '410', NULL, b'1', 'a99f4727-3521-4dfb-a8ee-64d2f8934059', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, 13, 1, NULL, NULL, NULL),
(51, '2018-03-30 10:28:36', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has voted own vote', '410', NULL, b'0', '30f31695-3279-4799-b015-17add22cdab7', '1269', NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, 13, 1, NULL, NULL, NULL),
(52, '2018-03-30 11:24:13', b'0', NULL, NULL, 1, NULL, 'You have voted your vote', '410', NULL, b'1', 'e8a2788e-52f4-4fa6-bf20-fe82836ad07b', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, 5, 1, NULL, NULL, NULL),
(53, '2018-03-30 11:24:13', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has voted own vote', '410', NULL, b'0', 'e0080c05-01a1-4651-99b9-0e5439de0e54', '1269', NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, 5, 1, NULL, NULL, NULL),
(54, '2018-03-30 11:24:23', b'0', NULL, NULL, 1, NULL, 'You have voted your vote', '410', NULL, b'1', '4a90b55b-367d-452c-bc6b-a6882ee5dc04', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, 5, 1, NULL, NULL, NULL),
(55, '2018-03-30 11:24:24', b'0', NULL, NULL, 1, NULL, 'Vivek Patel has voted own vote', '410', NULL, b'0', 'ec62dfa9-4f4e-48c9-8d60-c3a9c80e8523', '1269', NULL, 1, NULL, NULL, NULL, NULL, 1, NULL, 5, 1, NULL, NULL, NULL),
(56, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new team called testing', '410', NULL, b'0', 'd501dc58-1819-4eda-9c1e-cf82c3bdd517', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 10, NULL, 2, NULL, NULL, NULL),
(57, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called testing as Team leader', '410', NULL, b'1', 'c21e3c6c-2cd4-45de-b9e7-8d3b50f59e6b', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 10, NULL, 2, NULL, NULL, NULL),
(58, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing', '410', NULL, b'0', 'ce44f8f8-8204-4a06-9c4c-4b7b0012ae32', '415', NULL, 1, NULL, NULL, NULL, 3, 2, 10, NULL, 2, NULL, NULL, NULL),
(59, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing', '410', NULL, b'0', '091a0a9e-5d79-4bdb-8d68-6a20963f02b2', '415', NULL, 1, NULL, NULL, NULL, 5, 2, 10, NULL, 2, NULL, NULL, NULL),
(60, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing', '410', NULL, b'0', '4b32a1e0-c7b0-45ee-9f77-3f0a6177f167', '415', NULL, 1, NULL, NULL, NULL, 7, 2, 10, NULL, 2, NULL, NULL, NULL),
(61, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing', '410', NULL, b'0', '267452a1-5d91-4c71-8e94-0fc0bceab9b0', '415', NULL, 1, NULL, NULL, NULL, 6, 2, 10, NULL, 2, NULL, NULL, NULL),
(62, '2018-04-05 05:07:19', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing', '410', NULL, b'0', 'f919b52a-6d76-4f57-94d0-bd0d8b0ed270', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 10, NULL, 2, NULL, NULL, NULL),
(63, '2018-04-05 06:17:06', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called testing as Team leader', '410', NULL, b'0', '840c7341-6fda-4755-b2e7-499693a8a165', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 10, NULL, 2, NULL, NULL, NULL),
(64, '2018-04-05 06:17:06', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called testing', '410', NULL, b'0', 'afd229e0-2b1c-411d-8060-071a1e46c08c', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 10, NULL, 2, NULL, NULL, NULL),
(65, '2018-04-05 06:21:49', b'0', NULL, NULL, 1, NULL, 'Vivek Patel added a new post', '422', NULL, b'0', 'f647ab18-9082-4678-953d-fd72203d0aa2', '1269', NULL, 1, 244, 8, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL),
(66, '2018-04-05 12:40:26', b'0', NULL, NULL, 1, NULL, 'Vivek Patel added a new post', '422', NULL, b'0', 'e1078aeb-8f48-438d-b80b-4c4a1e26cf7e', '1269', NULL, 1, 245, 8, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL),
(67, '2018-04-05 12:42:46', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has liked your post', '422', NULL, b'1', 'cb248a46-92f5-4018-bb4e-3c0373e41555', '415', NULL, 1, 245, 8, NULL, 1, 3, NULL, NULL, 1, NULL, NULL, NULL),
(68, '2018-04-05 12:42:46', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has liked Vivek Patel''s post', '422', NULL, b'0', '388474c8-e0df-4c68-bf14-cc638381bfe5', '1269', NULL, 1, 245, 8, NULL, NULL, 3, NULL, NULL, 1, NULL, NULL, NULL),
(69, '2018-04-05 12:42:58', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has shared Vivek Patel''s post', '422', NULL, b'0', 'ff2df852-1867-422c-8775-080a4afdba7e', '1269', NULL, 1, 246, 8, NULL, NULL, 3, NULL, NULL, 1, NULL, NULL, NULL),
(70, '2018-04-05 12:42:58', b'0', NULL, NULL, 1, NULL, 'Maulik Shelat has shared your post', '422', NULL, b'1', '0e5cfe88-ed5c-4d06-a1d4-2edc83cb711e', '415', NULL, 1, 246, 8, NULL, 1, 3, NULL, NULL, 1, NULL, NULL, NULL),
(71, '2018-04-05 12:53:48', b'0', NULL, NULL, 1, NULL, 'Vivek Patel updated team called t8', '410', NULL, b'0', 'af0e9d64-c78a-420b-af03-072100bbd919', '415', NULL, 1, NULL, NULL, NULL, 2, 1, 10, NULL, 2, NULL, NULL, NULL),
(72, '2018-04-05 12:53:48', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called t8', '410', NULL, b'0', '39cfa8c9-5148-4fae-a2a6-1776223f32a8', '415', NULL, 1, NULL, NULL, NULL, 1, 1, 10, NULL, 2, NULL, NULL, NULL),
(73, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new team called bhim', '410', NULL, b'0', 'a88f45a0-a39e-4327-afb4-238b937671a0', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 11, NULL, 2, NULL, NULL, NULL),
(74, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called bhim as Team leader', '410', NULL, b'0', '94cf135f-e6a4-4039-a489-54e6dc492ade', '415', NULL, 1, NULL, NULL, NULL, 3, 2, 11, NULL, 2, NULL, NULL, NULL),
(75, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called bhim', '410', NULL, b'0', 'af29af00-a0ef-4c2c-b24c-6b6b283764f8', '415', NULL, 1, NULL, NULL, NULL, 6, 2, 11, NULL, 2, NULL, NULL, NULL),
(76, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called bhim', '410', NULL, b'0', 'c42a0d13-97c2-4876-9b65-8c7dcef27c23', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 11, NULL, 2, NULL, NULL, NULL),
(77, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called bhim', '410', NULL, b'0', 'f20dfbed-be7a-4e84-ab3f-67d947b86f55', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 11, NULL, 2, NULL, NULL, NULL),
(78, '2018-04-06 07:31:45', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called bhim', '410', NULL, b'0', '11c9c4f2-0bdc-4fa7-9f87-ba7f38b4f4d8', '415', NULL, 1, NULL, NULL, NULL, 7, 2, 11, NULL, 2, NULL, NULL, NULL),
(79, '2018-04-06 07:33:34', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi updated team called bhim', '410', NULL, b'0', 'dfcaa41d-c34a-4f92-942d-ebbfa741696e', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 11, NULL, 2, NULL, NULL, NULL),
(80, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new team called angular ', '410', NULL, b'0', 'cd640afb-7d91-456e-8acf-8c50836382d4', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 12, NULL, 2, NULL, NULL, NULL),
(81, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called angular  as Team leader', '410', NULL, b'0', '63405ea0-34b8-41a2-9806-a62b7d893203', '415', NULL, 1, NULL, NULL, NULL, 3, 2, 12, NULL, 2, NULL, NULL, NULL),
(82, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called angular ', '410', NULL, b'0', '3b8b51aa-8ffe-4102-afe8-cd87c5491444', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 12, NULL, 2, NULL, NULL, NULL),
(83, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called angular ', '410', NULL, b'0', 'ae58f96e-f1c3-4d8b-9fc4-516eb0c4a7b0', '415', NULL, 1, NULL, NULL, NULL, 5, 2, 12, NULL, 2, NULL, NULL, NULL),
(84, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called angular ', '410', NULL, b'0', 'e7f8a872-1fab-4df9-8e89-0ed19b5b82e4', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 12, NULL, 2, NULL, NULL, NULL),
(85, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called angular ', '410', NULL, b'0', '0efb77af-836a-4fe8-b961-85bfd6d076a6', '415', NULL, 1, NULL, NULL, NULL, 6, 2, 12, NULL, 2, NULL, NULL, NULL),
(86, '2018-04-06 08:50:29', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called angular ', '410', NULL, b'0', 'a10d8669-55a0-4b07-bf8e-4961996f7e31', '415', NULL, 1, NULL, NULL, NULL, 7, 2, 12, NULL, 2, NULL, NULL, NULL),
(87, '2018-04-06 08:51:12', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called spring as Team leader', '410', NULL, b'0', 'b6d97383-0231-476c-9661-d61bcbace55b', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 13, NULL, 2, NULL, NULL, NULL),
(88, '2018-04-06 08:51:12', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called spring', '410', NULL, b'0', '29b7e395-bff2-45c1-9fb8-39b60e808f56', '415', NULL, 1, NULL, NULL, NULL, 7, 2, 13, NULL, 2, NULL, NULL, NULL),
(89, '2018-04-06 08:51:12', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called spring', '410', NULL, b'0', '6e0b8cee-3fbc-4897-91d8-0587a7ae3373', '415', NULL, 1, NULL, NULL, NULL, 3, 2, 13, NULL, 2, NULL, NULL, NULL),
(90, '2018-04-06 08:51:13', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called spring', '410', NULL, b'0', 'f24aaef4-8627-4f08-a8b5-89ca18853b80', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 13, NULL, 2, NULL, NULL, NULL),
(91, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new team called devloper', '410', NULL, b'0', 'ca118681-8759-4d6f-ad85-13f4c71889f7', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 14, NULL, 2, NULL, NULL, NULL),
(92, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called devloper as Team leader', '410', NULL, b'0', 'f6e49089-12f3-4a36-aba1-59c71991bcdf', '415', NULL, 1, NULL, NULL, NULL, 6, 2, 14, NULL, 2, NULL, NULL, NULL),
(93, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called devloper', '410', NULL, b'0', '97d9e6a3-733f-444f-adbe-61b03bde76d9', '415', NULL, 1, NULL, NULL, NULL, 3, 2, 14, NULL, 2, NULL, NULL, NULL),
(94, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called devloper', '410', NULL, b'0', '3d60fe88-db82-44fd-a75b-fbc22d59726c', '415', NULL, 1, NULL, NULL, NULL, 5, 2, 14, NULL, 2, NULL, NULL, NULL),
(95, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'You added yourself in team called devloper', '410', NULL, b'0', 'dcb84c46-3c6f-4e37-a86a-275aa92b8133', '415', NULL, 1, NULL, NULL, NULL, 2, 2, 14, NULL, 2, NULL, NULL, NULL),
(96, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called devloper', '410', NULL, b'0', 'bd16679c-f0dc-4aa6-b65d-d03496e0c202', '415', NULL, 1, NULL, NULL, NULL, 7, 2, 14, NULL, 2, NULL, NULL, NULL),
(97, '2018-04-06 08:53:47', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added you in team called devloper', '410', NULL, b'0', '17a6bf62-9db2-4c6f-b49f-65211786e600', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 14, NULL, 2, NULL, NULL, NULL),
(98, '2018-04-06 08:54:26', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi updated team called developer', '410', NULL, b'0', '38b424cf-85d5-43d2-ba9a-6e380122631a', '415', NULL, 1, NULL, NULL, NULL, 1, 2, 14, NULL, 2, NULL, NULL, NULL),
(99, '2018-04-06 12:32:24', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', 'e575c6a4-e3fd-471e-902f-93f31cc0012c', '415', NULL, 1, 237, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(100, '2018-04-06 12:32:25', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', '85e63579-d17c-49f5-9e6f-03506ef5abc5', '1269', NULL, 1, 237, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(101, '2018-04-06 12:32:44', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', '64f48019-d184-42e6-9c49-45d1cb2763a1', '415', NULL, 1, 230, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(102, '2018-04-06 12:32:44', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', '495f6c0e-539a-41b3-8c00-38719680aadd', '1269', NULL, 1, 230, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(103, '2018-04-06 12:32:48', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', '9a0ff137-1c8d-4e25-8ff2-63972299f783', '415', NULL, 1, 230, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(104, '2018-04-06 12:32:48', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', '5b6da165-94ef-4689-93b1-41498d17c8f6', '1269', NULL, 1, 230, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(105, '2018-04-06 12:32:49', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', '26c127ab-f5e4-4534-919e-b0fdc98351cb', '415', NULL, 1, 230, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(106, '2018-04-06 12:32:50', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', 'c2a1bd67-95eb-4ee0-931c-e27b595b922f', '1269', NULL, 1, 230, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(107, '2018-04-06 12:32:56', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', '2bd3662b-45f3-40b6-9891-2c923a17342d', '415', NULL, 1, 230, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(108, '2018-04-06 12:32:56', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', 'c2ad9335-30e2-4e3a-b5ce-a986357fe73f', '1269', NULL, 1, 230, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(109, '2018-04-06 12:33:04', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked your post', '422', NULL, b'1', '14e1c9b4-ffa1-4530-a6d8-a3a24b5a0156', '415', NULL, 1, 218, 8, NULL, 3, 2, NULL, NULL, 3, NULL, NULL, NULL),
(110, '2018-04-06 12:33:04', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi has liked Maulik Shelat''s post', '422', NULL, b'0', 'a26956f1-28c0-4434-adde-ce41b0acb46d', '1269', NULL, 1, 218, 8, NULL, NULL, 2, NULL, NULL, 3, NULL, NULL, NULL),
(111, '2018-04-09 10:24:52', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new Low task to you', NULL, NULL, b'1', 'ac8d7285-2e91-4b34-8889-81b761f0231f', '415', NULL, 1, NULL, NULL, NULL, 2, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(112, '2018-04-09 10:24:54', b'0', NULL, NULL, 1, NULL, 'You assigned a new Low task to you', NULL, NULL, b'1', '1530aeba-8a9d-4b5a-850b-096da70ee0a3', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(113, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new High task to you', NULL, NULL, b'1', '7853f931-eec5-4966-86e5-ef3651e76468', '415', NULL, 1, NULL, NULL, NULL, 6, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(114, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new High task to you', NULL, NULL, b'1', 'c1f664c4-1130-4206-b266-6005e2eebaa8', '415', NULL, 1, NULL, NULL, NULL, 7, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(115, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new High task to you', NULL, NULL, b'1', '1042d416-c131-406f-b842-aec397d764f0', '415', NULL, 1, NULL, NULL, NULL, 2, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(116, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'You assigned a new High task to you', NULL, NULL, b'1', 'fb714d30-9011-4d55-8af5-955dcb1495d8', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(117, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new High task to you', NULL, NULL, b'1', '71e1828c-b900-4fe5-864b-7ce7f3d838b4', '415', NULL, 1, NULL, NULL, NULL, 5, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(118, '2018-04-09 11:14:38', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new High task to you', NULL, NULL, b'1', 'f0d037b1-e80a-4d06-88a0-e6c17817dcf8', '415', NULL, 1, NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(119, '2018-04-09 12:45:47', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new Urgent task to you', '403', NULL, b'1', 'b5debde4-56e4-46d2-9bc8-21009e396af2', '415', NULL, 1, NULL, NULL, NULL, 3, 1, NULL, NULL, 1, NULL, NULL, 4),
(120, '2018-04-09 12:45:47', b'0', NULL, NULL, 1, NULL, 'Vivek Patel assigned a new Urgent task to you', '403', NULL, b'1', '11ac6121-b8c3-492e-8ecc-f0d00880f794', '415', NULL, 1, NULL, NULL, NULL, 2, 1, NULL, NULL, 1, NULL, NULL, 4),
(121, '2018-04-09 12:45:47', b'0', NULL, NULL, 1, NULL, 'You assigned a new Urgent task to you', '403', NULL, b'1', '77ecf645-378a-4935-bfb9-5b17232991d4', '415', NULL, 1, NULL, NULL, NULL, 1, 1, NULL, NULL, 1, NULL, NULL, 4),
(122, '2018-04-10 11:16:08', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi assigned a new High task to you', '403', NULL, b'1', '7214203a-73f9-4156-96dc-d9e4ef59863b', '415', NULL, 1, NULL, NULL, NULL, 5, 2, NULL, NULL, 2, NULL, NULL, 5),
(123, '2018-04-10 11:16:11', b'0', NULL, NULL, 1, NULL, 'You assigned a new High task to you', '403', NULL, b'1', 'f9406863-58b6-4390-b11a-7b263e4da2fa', '415', NULL, 1, NULL, NULL, NULL, 2, 2, NULL, NULL, 2, NULL, NULL, 5),
(124, '2018-04-10 11:16:11', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi assigned a new High task to you', '403', NULL, b'1', '0270832f-aa1f-40bf-8325-7620f91e2fc1', '415', NULL, 1, NULL, NULL, NULL, 3, 2, NULL, NULL, 2, NULL, NULL, 5),
(125, '2018-04-10 11:16:11', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi assigned a new High task to you', '403', NULL, b'1', 'b2667eee-941d-44b9-8c67-5ef6717504cb', '415', NULL, 1, NULL, NULL, NULL, 1, 2, NULL, NULL, 2, NULL, NULL, 5),
(126, '2018-04-12 13:11:35', b'0', NULL, NULL, 1, NULL, 'Kajal Trivedi added a new post', '422', NULL, b'0', 'e24bcdaa-0686-40ad-9990-e5eb595f4630', '1269', NULL, 1, 247, 8, NULL, NULL, 2, NULL, NULL, 2, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `organization_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `hash_tag` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `specific_type` varchar(255) DEFAULT NULL,
  `total_employee` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`organization_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `hash_tag`, `info`, `name`, `specific_type`, `total_employee`, `type`, `created_by`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 06:34:08', NULL, b'0', NULL, 1, NULL, NULL, 'LynkerSoft', 'IT !!!', 6, 'Other', 1, NULL, NULL, NULL),
(3, '2018-02-22 09:33:58', NULL, b'0', NULL, 1, NULL, NULL, 'cydila', NULL, 1, 'Healthcare', 9, NULL, NULL, NULL),
(4, '2018-02-22 09:52:31', NULL, b'0', NULL, 1, NULL, NULL, 'LynkerSoft', 'IT !!!', 1, 'Other', 10, NULL, NULL, NULL),
(5, '2018-02-22 09:53:22', NULL, b'0', NULL, 1, NULL, NULL, 'LynkerSoft', 'IT !!!', 1, 'Other', 11, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `paid_amount` double DEFAULT NULL,
  `payment_days` int(11) DEFAULT NULL,
  `payment_info` int(11) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `plan_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pins`
--

CREATE TABLE `pins` (
  `pin_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `pin_tag` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pins`
--

INSERT INTO `pins` (`pin_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `message`, `pin_tag`, `title`, `user_id`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 07:23:14', NULL, b'0', '2018-03-16 06:39:37', 2, '1st Testing..............', NULL, 'testing', 3, NULL, NULL, NULL),
(2, '2018-02-19 05:57:17', NULL, b'0', NULL, 1, 'vf fgbdf', NULL, 'testing', 1, NULL, NULL, NULL),
(3, '2018-02-26 09:48:34', NULL, b'1', NULL, 1, 'oioioio\n', NULL, 'oiii', 2, NULL, NULL, NULL),
(4, '2018-02-26 09:48:45', NULL, b'0', '2018-02-26 09:48:49', 2, '1111', NULL, '22222222', 2, NULL, NULL, NULL),
(5, '2018-02-26 10:38:42', NULL, b'1', '2018-02-26 10:38:47', 2, 'dsds dsds', NULL, 'testing for delete', 3, NULL, NULL, NULL),
(6, '2018-02-26 11:02:44', NULL, b'1', NULL, 1, 'http://www.eazeprocure.com/1125/#/guest/welcome/tender/quoteToTender/530072c7-8176-4775-bf58-b0c66d6d51ac', NULL, 'Send to Umar Sir', 3, NULL, NULL, NULL),
(7, '2018-02-26 12:10:09', NULL, b'0', NULL, 1, 'Pin msg test for notes.', NULL, 'The pin shouldn''t prick', 1, NULL, NULL, NULL),
(8, '2018-02-28 07:04:44', NULL, b'1', NULL, 1, 'asdasdasdasddasd', NULL, 'asdasdasdasdas', 3, '2018-02-28 11:29:54', NULL, NULL),
(9, '2018-02-28 11:27:49', NULL, b'0', '2018-02-28 11:28:12', 2, 'Pins are work or not??????????????\nIt will be Update to', NULL, 'Testing ', 3, NULL, NULL, NULL),
(10, '2018-03-12 11:15:45', NULL, b'0', NULL, 1, 'asdad', NULL, 'asdasdasdasdas', 1, NULL, NULL, NULL),
(11, '2018-03-16 06:39:49', NULL, b'1', NULL, 1, '2nd ', NULL, 'Create', 3, '2018-03-23 12:00:29', NULL, NULL),
(12, '2018-03-20 13:52:04', NULL, b'0', NULL, 1, 'Sound sense', NULL, 'products', 1, NULL, NULL, NULL),
(13, '2018-03-26 09:00:29', NULL, b'1', '2018-03-26 09:01:15', 3, 'Small Charatcter', NULL, 'TESTING', 3, '2018-03-26 09:01:18', NULL, NULL),
(14, '2018-03-28 06:57:49', NULL, b'0', NULL, 1, 'need to meet clent', NULL, 'urgent', 1, NULL, NULL, NULL),
(15, '2018-04-05 06:27:35', NULL, b'0', NULL, 1, 'Description', NULL, 'title', 1, NULL, NULL, NULL),
(16, '2018-04-05 11:30:41', NULL, b'0', NULL, 1, 'gfgfgfgf', NULL, '123', 1, NULL, NULL, NULL),
(17, '2018-04-10 10:31:51', NULL, b'0', NULL, 1, NULL, NULL, 'Pin1', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `plan_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `blogs` bigint(20) DEFAULT NULL,
  `days` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `invited_users` bigint(20) DEFAULT NULL,
  `issues` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `payment_days` int(11) DEFAULT NULL,
  `payment_info` varchar(255) DEFAULT NULL,
  `payment_term` int(11) DEFAULT NULL,
  `plan_tag` varchar(255) DEFAULT NULL,
  `posts` bigint(20) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `projects` bigint(20) DEFAULT NULL,
  `teams` bigint(20) DEFAULT NULL,
  `time_span` int(11) DEFAULT NULL,
  `votes` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plan_manager`
--

CREATE TABLE `plan_manager` (
  `plan_manager_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `comments` int(11) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `post_tag` varchar(255) DEFAULT NULL,
  `share` int(11) DEFAULT NULL,
  `shared` bit(1) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `privacy_id` bigint(20) DEFAULT NULL,
  `shared_by` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `comments`, `info`, `likes`, `message`, `post_tag`, `share`, `shared`, `title`, `organization_id`, `privacy_id`, `shared_by`, `user_id`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(102, '2018-02-28 10:03:15', NULL, b'0', NULL, 1, 4, NULL, 3, 'All User Post', NULL, 2, b'1', 'Public ', 1, 8, 1, 2, NULL, NULL, NULL),
(103, '2018-02-28 10:08:29', NULL, b'0', NULL, 1, 1, NULL, 1, 'When user can refresh page it will be hide ', NULL, 1, b'1', 'Public Post for Share', 1, 8, 1, 2, NULL, NULL, NULL),
(104, '2018-02-28 10:14:40', NULL, b'0', NULL, 1, 0, NULL, 1, 'Checking ', NULL, 0, b'0', 'Public Post for Share Second', 1, 8, NULL, 3, NULL, NULL, NULL),
(105, '2018-02-28 10:15:54', NULL, b'0', NULL, 1, 0, NULL, 1, 'Checking', NULL, 0, b'0', 'Public Post for Share Third', 1, 8, NULL, 3, NULL, NULL, NULL),
(106, '2018-02-28 10:19:38', NULL, b'0', NULL, 1, 0, NULL, 2, 'Hello', NULL, 0, b'0', 'Public Post for Share four', 1, 8, NULL, 3, NULL, NULL, NULL),
(107, '2018-02-28 10:28:18', NULL, b'0', NULL, 1, 1, NULL, 0, 'h', NULL, 0, b'0', 'fifth', 1, 8, NULL, 3, NULL, NULL, NULL),
(108, '2018-02-28 10:29:13', NULL, b'0', NULL, 1, 0, NULL, 0, 'Oiiiiiiiii', NULL, 0, b'0', 'six', 1, 8, NULL, 2, NULL, NULL, NULL),
(109, '2018-02-28 10:47:06', NULL, b'0', NULL, 1, 0, NULL, 0, 'oiii', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(110, '2018-02-28 13:12:01', NULL, b'0', NULL, 1, 4, NULL, 4, 'Su lage tamne hu pagal 6u????????????/\n\nPlease Comment....', NULL, 0, b'0', 'I need help....', 1, 8, NULL, 6, NULL, NULL, NULL),
(111, '2018-03-01 06:18:29', NULL, b'0', NULL, 1, 2, NULL, 2, 'On this Day Lynkersoft has complete 2 years', NULL, 0, b'0', '2 Years Complete', 1, 8, NULL, 1, NULL, NULL, NULL),
(112, '2018-03-01 06:26:28', NULL, b'0', NULL, 1, 3, NULL, 1, 'testing for new post without old comment and like', NULL, 1, b'1', 'Testing for new post', 1, 8, 1, 2, NULL, NULL, NULL),
(113, '2018-03-01 06:44:28', NULL, b'0', NULL, 1, 0, NULL, 1, 'No one see this post ', NULL, 0, b'0', 'Only Me  Post', 1, 1, NULL, 1, NULL, NULL, NULL),
(114, '2018-03-01 08:27:33', NULL, b'0', NULL, 1, 0, NULL, 1, 'Hello', NULL, 1, b'1', 'Public Post', 1, 8, 2, 1, NULL, NULL, NULL),
(115, '2018-03-01 11:25:30', NULL, b'0', NULL, 1, 0, NULL, 1, 'https://css-tricks.com/snippets/css/ribbon/', NULL, 0, b'1', 'Ribbon Link ', 1, 8, 2, 1, NULL, NULL, NULL),
(116, '2018-03-01 11:26:14', NULL, b'1', NULL, 1, 2, NULL, 1, 'Testing', NULL, 0, b'0', 'Create For Share', 1, 8, NULL, 2, '2018-03-05 13:09:05', NULL, NULL),
(117, '2018-03-01 12:10:22', NULL, b'0', NULL, 1, 0, NULL, 1, 'ngvhfhf', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(118, '2018-03-01 12:11:44', NULL, b'1', NULL, 1, 0, NULL, 1, 'nmbnmbnmbnmb', NULL, 0, b'0', NULL, 1, 8, NULL, 2, '2018-03-05 13:08:56', NULL, NULL),
(119, '2018-03-01 12:11:59', NULL, b'0', NULL, 1, 1, NULL, 2, 'Public', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(122, '2018-03-05 08:03:51', NULL, b'0', NULL, 1, 0, NULL, 0, 'Public', NULL, 0, b'1', NULL, NULL, 8, 2, NULL, NULL, NULL, NULL),
(123, '2018-03-05 08:46:56', NULL, b'0', NULL, 1, 0, NULL, 0, 'public 2', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(124, '2018-03-05 08:47:11', NULL, b'0', NULL, 1, 0, NULL, 0, 'public 2', NULL, 0, b'1', NULL, NULL, 8, 2, NULL, NULL, NULL, NULL),
(125, '2018-03-05 08:52:54', NULL, b'0', NULL, 1, 0, NULL, 0, 'sadasdasdasd', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(126, '2018-03-05 08:53:01', NULL, b'0', NULL, 1, 0, NULL, 0, 'sadasdasdasd', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(127, '2018-03-05 08:57:01', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(128, '2018-03-05 08:57:06', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasd', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(129, '2018-03-05 09:00:43', NULL, b'0', '2018-03-06 09:32:25', 5, 1, NULL, 1, 'Write Something P1', NULL, 3, b'0', 'Caption P1', 1, 8, NULL, 1, NULL, NULL, NULL),
(130, '2018-03-05 09:13:34', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasd', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(131, '2018-03-05 09:45:30', NULL, b'0', NULL, 1, 0, NULL, 0, 'Public', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(132, '2018-03-05 09:46:16', NULL, b'0', NULL, 1, 0, NULL, 0, 'Write Something P1', NULL, 0, b'1', 'Caption P1', 1, 8, 3, 1, NULL, NULL, NULL),
(133, '2018-03-05 09:46:48', NULL, b'0', NULL, 1, 0, NULL, 0, 'Write Something P1', NULL, 0, b'1', 'Caption P1', 1, 8, 3, 1, NULL, NULL, NULL),
(134, '2018-03-05 09:47:20', NULL, b'0', NULL, 1, 0, NULL, 1, 'Write Something P1', NULL, 0, b'1', 'Caption P1', 1, 8, 3, 1, NULL, NULL, NULL),
(135, '2018-03-06 05:30:14', NULL, b'0', '2018-03-06 05:36:41', 5, 0, NULL, 0, 'hello....good morning....', NULL, 0, b'0', '', 1, 8, NULL, 2, NULL, NULL, NULL),
(136, '2018-03-12 11:14:37', NULL, b'0', NULL, 1, 0, NULL, 0, 'sdfsdf', NULL, 0, b'0', NULL, 1, 1, NULL, 1, NULL, NULL, NULL),
(137, '2018-03-12 12:10:00', NULL, b'0', NULL, 1, 0, NULL, 0, 'heynbnv jbdhgvcjhfdgvhjfgv', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(138, '2018-03-12 12:30:16', NULL, b'0', NULL, 1, 0, NULL, 0, 'jhkjghjfhgdfhgdhgd', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(139, '2018-03-12 12:31:20', NULL, b'0', NULL, 1, 0, NULL, 0, 'eeeeeeeeeeeeeeee', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(140, '2018-03-12 12:35:15', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdasd', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(141, '2018-03-12 12:41:35', NULL, b'0', NULL, 1, 0, NULL, 0, 'aaaaaaaaaaaaaa', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(142, '2018-03-12 12:47:01', NULL, b'0', NULL, 1, 0, NULL, 0, 'eeee pagal...vivek...', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(143, '2018-03-12 12:58:54', NULL, b'0', NULL, 1, 0, NULL, 0, 'hgjghjghjg', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(144, '2018-03-12 12:59:14', NULL, b'0', NULL, 1, 0, NULL, 0, 'aaaaaaaaaaaaaaa', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(145, '2018-03-12 12:59:27', NULL, b'0', NULL, 1, 0, NULL, 0, 'csdcfsdfcsdfc', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(146, '2018-03-12 13:00:39', NULL, b'0', NULL, 1, 0, NULL, 0, 'dxcfffffffffffffff', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(147, '2018-03-12 13:02:39', NULL, b'0', NULL, 1, 0, NULL, 0, 'dedcsfcsf', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(148, '2018-03-12 13:03:06', NULL, b'0', NULL, 1, 0, NULL, 0, 'wwwwwwwwwwwwwwwwwwww', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(149, '2018-03-12 13:03:59', NULL, b'0', NULL, 1, 0, NULL, 0, 'tttttttttttttttttttttttttt', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(150, '2018-03-13 09:17:35', NULL, b'0', NULL, 1, 0, NULL, 0, 'TESTING', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(151, '2018-03-13 09:18:53', NULL, b'0', NULL, 1, 0, NULL, 0, 'Testimg', NULL, 0, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(152, '2018-03-14 07:05:15', NULL, b'0', NULL, 1, 0, NULL, 0, 'vm jhdfjhvdjkfhkjdfhg', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(153, '2018-03-14 09:22:12', NULL, b'0', NULL, 1, 0, NULL, 0, 'dsfsdfsdf', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(154, '2018-03-14 10:34:36', NULL, b'0', NULL, 1, 0, NULL, 0, 'kkkkkkkkkkkkkkkkk', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(155, '2018-03-14 10:34:50', NULL, b'0', NULL, 1, 0, NULL, 0, 'aaaaaaaaaaaaaaa', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(156, '2018-03-14 10:35:04', NULL, b'0', NULL, 1, 0, NULL, 0, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaa', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(157, '2018-03-14 10:35:20', NULL, b'0', NULL, 1, 0, NULL, 0, 'ttttttttttttttttt', NULL, 0, b'0', NULL, 1, 4, NULL, 2, NULL, NULL, NULL),
(158, '2018-03-14 10:35:45', NULL, b'0', NULL, 1, 0, NULL, 0, 'a\nppppppppppppppppppppppppppppp', NULL, 0, b'0', NULL, 1, 4, NULL, 2, NULL, NULL, NULL),
(159, '2018-03-16 06:08:25', NULL, b'0', NULL, 1, 0, NULL, 0, 'kjchkjdhckjdh', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(160, '2018-03-16 06:09:25', NULL, b'0', NULL, 1, 0, NULL, 0, 'jkgjghjghjhjg', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(161, '2018-03-16 06:11:38', NULL, b'0', NULL, 1, 0, NULL, 0, 'zxczxczxczxczxc', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(162, '2018-03-16 06:11:47', NULL, b'0', NULL, 1, 0, NULL, 0, 'zxcczxcxcvvxcv', NULL, 1, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(163, '2018-03-16 06:12:12', NULL, b'1', '2018-03-16 06:12:27', 2, 0, NULL, 0, 'Testing', NULL, 0, b'0', 'Hello', 1, 8, NULL, 3, '2018-03-16 06:12:43', NULL, NULL),
(164, '2018-03-16 06:12:49', NULL, b'0', NULL, 1, 0, NULL, 0, 'zxcczxcxcvvxcv', NULL, 0, b'1', NULL, 1, 8, 3, 2, NULL, NULL, NULL),
(165, '2018-03-16 06:20:08', NULL, b'0', NULL, 1, 0, NULL, 0, 'Hello', NULL, 0, b'0', 'Good Morning', 1, 8, NULL, 3, NULL, NULL, NULL),
(166, '2018-03-16 06:20:53', NULL, b'1', NULL, 1, 0, NULL, 0, 'CS', NULL, 0, b'0', 'CSV File Testing', 1, 8, NULL, 3, '2018-03-16 06:21:04', NULL, NULL),
(167, '2018-03-16 06:21:33', NULL, b'0', NULL, 1, 0, NULL, 0, 'hey...', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(168, '2018-03-16 06:22:01', NULL, b'0', '2018-03-16 06:22:57', 2, 0, NULL, 0, 'Smile in the mirror. Do that every morning and you''ll start to see a big difference in your life.\n', NULL, 0, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(169, '2018-03-16 06:28:17', NULL, b'0', '2018-03-16 06:29:31', 2, 0, NULL, 0, 'The forthcoming movie Avengers movie, the summer’s big kick-off superhero blockbuster, is the culmination of five superhero films released over the past four years, all of them set within the same universe. But if you’re not familiar with....\n', NULL, 0, b'0', 'Avengers movie', 1, 8, NULL, 3, NULL, NULL, NULL),
(170, '2018-03-16 06:46:57', NULL, b'0', NULL, 1, 0, NULL, 0, 'hello', NULL, 0, b'0', NULL, 1, 1, NULL, 2, NULL, NULL, NULL),
(171, '2018-03-21 09:16:46', NULL, b'0', NULL, 1, 0, NULL, 0, 'wqeqweqweqweqweqwe', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(172, '2018-03-21 09:20:25', NULL, b'0', NULL, 1, 0, NULL, 0, 'vjfghfhgfghfhf', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(173, '2018-03-21 09:22:26', NULL, b'0', NULL, 1, 0, NULL, 0, 'hellovkfjlkjv jvvkdjvlkjgb', NULL, 0, b'0', NULL, 1, 9, NULL, 2, NULL, NULL, NULL),
(174, '2018-03-21 09:23:42', NULL, b'0', '2018-03-21 09:25:36', 2, 0, NULL, 0, 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', NULL, 1, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(175, '2018-03-21 09:26:32', NULL, b'0', NULL, 1, 0, NULL, 0, 'wqeqweqweqweqweqwe', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(176, '2018-03-21 09:39:39', NULL, b'0', NULL, 1, 0, NULL, 0, 'dvfdgdfgdfg', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(177, '2018-03-21 09:40:46', NULL, b'0', NULL, 1, 0, NULL, 0, 'dvfdgdfgdfg', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(178, '2018-03-21 09:41:04', NULL, b'0', NULL, 1, 0, NULL, 0, 'sdfsfsdf', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(179, '2018-03-21 09:41:10', NULL, b'0', NULL, 1, 0, NULL, 0, 'sdfsfsdf', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(180, '2018-03-21 09:59:30', NULL, b'0', NULL, 1, 0, NULL, 0, 'aasdasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(181, '2018-03-21 09:59:44', NULL, b'0', NULL, 1, 0, NULL, 0, 'aasdasdasd', NULL, 0, b'1', NULL, 1, 8, 1, 2, NULL, NULL, NULL),
(182, '2018-03-21 10:06:04', NULL, b'0', NULL, 1, 0, NULL, 0, 'me only', NULL, 0, b'0', NULL, 1, 1, NULL, 1, NULL, NULL, NULL),
(183, '2018-03-21 10:06:16', NULL, b'0', NULL, 1, 0, NULL, 0, 'public', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(184, '2018-03-21 10:06:44', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasd', NULL, 0, b'0', NULL, 1, 3, NULL, 1, NULL, NULL, NULL),
(185, '2018-03-21 10:07:10', NULL, b'0', NULL, 1, 0, NULL, 0, 'sadasdasdasd', NULL, 0, b'0', NULL, 1, 4, NULL, 1, NULL, NULL, NULL),
(186, '2018-03-21 10:07:28', NULL, b'0', NULL, 1, 0, NULL, 0, 'sadasdasdasdas', NULL, 0, b'0', NULL, 1, 2, NULL, 1, NULL, NULL, NULL),
(187, '2018-03-21 10:07:53', NULL, b'0', NULL, 1, 0, NULL, 0, 'specific ppl', NULL, 0, b'0', NULL, 1, 9, NULL, 1, NULL, NULL, NULL),
(188, '2018-03-21 10:08:56', NULL, b'0', NULL, 1, 0, NULL, 0, 'public', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(189, '2018-03-21 10:09:17', NULL, b'0', NULL, 1, 0, NULL, 0, 'public', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(190, '2018-03-21 10:15:58', NULL, b'0', NULL, 1, 0, NULL, 0, 'qweqwe', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(191, '2018-03-21 10:32:00', NULL, b'0', NULL, 1, 0, NULL, 1, 'asdassd', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(192, '2018-03-21 10:32:37', NULL, b'0', NULL, 1, 0, NULL, 0, 'saddasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(193, '2018-03-21 10:32:42', NULL, b'0', NULL, 1, 0, NULL, 0, 'saddasdasd', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(194, '2018-03-21 10:33:25', NULL, b'0', NULL, 1, 0, NULL, 1, 'asdasdasdasdasdasdasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(195, '2018-03-21 10:33:30', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdasdasdasdasdasd', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(196, '2018-03-21 10:38:23', NULL, b'0', NULL, 1, 0, NULL, 0, 'Hobu salu', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(197, '2018-03-21 10:38:54', NULL, b'0', NULL, 1, 0, NULL, 0, 'Hobu salu', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(198, '2018-03-21 12:10:36', NULL, b'0', NULL, 1, 0, NULL, 0, 'Hello ', NULL, 0, b'0', 'Testing', 1, 8, NULL, 3, NULL, NULL, NULL),
(199, '2018-03-21 12:12:48', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdas', NULL, 2, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(200, '2018-03-21 12:20:45', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdas', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(201, '2018-03-21 13:05:55', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(202, '2018-03-23 10:04:00', NULL, b'0', NULL, 1, 0, NULL, 0, 'zxczxcasdasd', NULL, 2, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(203, '2018-03-23 10:04:48', NULL, b'0', NULL, 1, 0, NULL, 0, 'testing', NULL, 1, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(204, '2018-03-23 10:10:53', NULL, b'0', NULL, 1, 0, NULL, 0, 'testing', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(205, '2018-03-23 10:11:28', NULL, b'0', NULL, 1, 0, NULL, 0, 'testing', NULL, 0, b'0', NULL, 1, 1, NULL, 3, NULL, NULL, NULL),
(206, '2018-03-23 10:11:44', NULL, b'0', NULL, 1, 0, NULL, 1, 'testing', NULL, 1, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(207, '2018-03-23 10:12:00', NULL, b'0', NULL, 1, 0, NULL, 0, 'hoba', NULL, 2, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(208, '2018-03-23 10:12:13', NULL, b'0', NULL, 1, 0, NULL, 0, 'hoba', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(209, '2018-03-23 10:14:38', NULL, b'0', NULL, 1, 0, NULL, 0, 'zxczxcasdasd', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(210, '2018-03-23 10:15:04', NULL, b'0', '2018-03-23 11:38:39', 2, 0, NULL, 2, 'hoba2!!!!!!!!!!!!!', NULL, 5, b'0', NULL, 1, 8, NULL, 3, NULL, NULL, NULL),
(211, '2018-03-23 10:15:14', NULL, b'0', NULL, 1, 0, NULL, 0, 'hoba2', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(212, '2018-03-23 10:42:27', NULL, b'0', NULL, 1, 0, NULL, 0, 'testing', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(213, '2018-03-23 12:02:49', NULL, b'0', NULL, 1, 0, NULL, 0, 'Employeeeeeeeeeeeeeeeeeeeeeeeeeee', NULL, 0, b'0', NULL, 1, 5, NULL, 1, NULL, NULL, NULL),
(214, '2018-03-23 12:03:39', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdasd', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(215, '2018-03-23 12:18:45', NULL, b'0', NULL, 1, 0, NULL, 1, 'zxczxcasdasd', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(216, '2018-03-23 12:26:58', NULL, b'0', NULL, 1, 0, NULL, 0, 'hoba2!!!!!!!!!!!!!', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(217, '2018-03-23 12:33:15', NULL, b'0', NULL, 1, 0, NULL, 0, 'hoba', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(218, '2018-03-23 12:37:51', NULL, b'0', NULL, 1, 0, NULL, 1, 'hoba2!!!!!!!!!!!!!', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(219, '2018-03-23 12:38:36', NULL, b'0', NULL, 1, 0, NULL, 1, 'hoba2!!!!!!!!!!!!!', NULL, 0, b'1', NULL, 1, 8, 1, 3, NULL, NULL, NULL),
(230, '2018-03-26 07:23:56', NULL, b'0', NULL, 1, 0, NULL, 1, 'hoba2!!!!!!!!!!!!!', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(231, '2018-03-26 07:25:08', NULL, b'0', NULL, 1, 0, NULL, 0, 'asdasdasdas', NULL, 0, b'1', NULL, 1, 8, 2, 1, NULL, NULL, NULL),
(232, '2018-03-26 07:35:01', NULL, b'1', NULL, 1, 0, NULL, 0, 'Testing', NULL, 0, b'0', NULL, 1, 9, NULL, 3, '2018-03-26 07:40:36', NULL, NULL),
(233, '2018-03-26 07:37:41', NULL, b'1', NULL, 1, 0, NULL, 1, 'hello', NULL, 0, b'0', NULL, 1, 9, NULL, 3, '2018-03-26 07:40:55', NULL, NULL),
(234, '2018-03-26 07:41:03', NULL, b'0', NULL, 1, 0, NULL, 0, 'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', NULL, 0, b'1', NULL, 1, 8, 3, 2, NULL, NULL, NULL),
(235, '2018-03-26 07:57:32', NULL, b'1', NULL, 1, 0, NULL, 0, 'bhai jamava jaisu', NULL, 0, b'0', NULL, 1, 9, NULL, 3, '2018-03-26 07:58:09', NULL, NULL),
(236, '2018-03-26 09:24:05', NULL, b'1', NULL, 1, 0, NULL, 0, 'testing', NULL, 1, b'0', NULL, 1, 8, NULL, 3, '2018-03-26 09:34:51', NULL, NULL),
(237, '2018-03-26 09:24:31', NULL, b'0', NULL, 1, 0, NULL, 1, 'testing', NULL, 0, b'1', NULL, 1, 8, 2, 3, NULL, NULL, NULL),
(238, '2018-03-26 11:35:59', NULL, b'1', NULL, 1, 0, NULL, 0, 'testing', NULL, 0, b'0', NULL, 1, 8, NULL, 3, '2018-03-26 12:53:34', NULL, NULL),
(239, '2018-03-26 12:57:55', NULL, b'1', NULL, 1, 0, NULL, 0, 'testing for .exe file upload', NULL, 0, b'0', NULL, 1, 1, NULL, 3, '2018-03-26 12:57:59', NULL, NULL),
(240, '2018-03-28 07:04:19', NULL, b'0', NULL, 1, 0, NULL, 2, 'Good Afternoon', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL),
(241, '2018-03-28 08:27:46', NULL, b'0', NULL, 1, 1, NULL, 2, 'Likes only', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(242, '2018-03-28 12:06:18', NULL, b'0', NULL, 1, 0, NULL, 0, 'fdgdfg', NULL, 0, b'0', NULL, 1, 1, NULL, 1, NULL, NULL, NULL),
(243, '2018-03-30 06:35:33', NULL, b'0', NULL, 1, 0, NULL, 1, 'fgdf', NULL, 0, b'0', NULL, 1, 1, NULL, 1, NULL, NULL, NULL),
(244, '2018-04-05 06:21:49', NULL, b'0', NULL, 1, 0, NULL, 0, 'Good Morning', NULL, 0, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(245, '2018-04-05 12:40:26', NULL, b'0', NULL, 1, 0, NULL, 1, 'assdasdasdasd', NULL, 1, b'0', NULL, 1, 8, NULL, 1, NULL, NULL, NULL),
(246, '2018-04-05 12:42:58', NULL, b'0', NULL, 1, 0, NULL, 0, 'oi', NULL, 0, b'1', NULL, 1, 8, 3, 1, NULL, NULL, NULL),
(247, '2018-04-12 13:11:35', NULL, b'0', NULL, 1, 0, NULL, 0, 'hello..', NULL, 0, b'0', NULL, 1, 8, NULL, 2, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `post_comment_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `post_comment_tag` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`post_comment_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `info`, `message`, `post_comment_tag`, `post_id`, `user_id`, `updated_by`, `deleted_by`) VALUES
(30, '2018-02-28 09:57:19', b'0', NULL, NULL, 1, NULL, '1st Comment', NULL, 102, 2, NULL, NULL),
(31, '2018-02-28 09:57:38', b'0', NULL, NULL, 1, NULL, '2nd Comment', NULL, 102, 3, NULL, NULL),
(32, '2018-02-28 09:57:50', b'0', NULL, NULL, 1, NULL, '3rd Comment', NULL, 102, 1, NULL, NULL),
(33, '2018-02-28 10:10:47', b'0', NULL, NULL, 1, NULL, 'Bhai Orignial Post gayab thai jay 6e jyare koi share kari ne refresh page kare tyre badha user ni wall mathi original post gayab?????How it''s posible', NULL, 103, 3, NULL, NULL),
(34, '2018-02-28 13:12:52', b'0', NULL, NULL, 1, NULL, 'Bun pagal thay gay', NULL, 110, 1, NULL, NULL),
(35, '2018-02-28 13:13:11', b'0', NULL, NULL, 1, NULL, 'Sachi vat', NULL, 110, 3, NULL, NULL),
(36, '2018-02-28 13:14:22', b'0', NULL, NULL, 1, NULL, 'Bahu Pagal ', NULL, 110, 2, NULL, NULL),
(37, '2018-02-28 13:14:49', b'0', NULL, NULL, 1, NULL, '100% right', NULL, 110, 7, NULL, NULL),
(38, '2018-03-01 06:18:53', b'0', NULL, NULL, 1, NULL, 'Hello', NULL, 111, 2, NULL, NULL),
(39, '2018-03-01 06:19:01', b'0', NULL, NULL, 1, NULL, 'Hello', NULL, 111, 1, NULL, NULL),
(40, '2018-03-01 06:20:12', b'0', NULL, NULL, 1, NULL, 'Done', NULL, 112, 2, NULL, NULL),
(41, '2018-03-01 06:20:23', b'0', NULL, NULL, 1, NULL, 'Ok It will proper work?', NULL, 112, 1, NULL, NULL),
(42, '2018-03-01 06:20:27', b'0', NULL, NULL, 1, NULL, 'Yes ', NULL, 112, 2, NULL, NULL),
(43, '2018-03-05 07:44:16', b'0', NULL, NULL, 1, NULL, 'wedrfgthyjuk', NULL, 116, 2, NULL, NULL),
(44, '2018-03-05 07:44:33', b'0', NULL, NULL, 1, NULL, 'aaaaaaaaaaaaaaaaaaaaa', NULL, 116, 2, NULL, NULL),
(45, '2018-03-05 07:44:48', b'0', NULL, NULL, 1, NULL, 'asssssssssssssssssssss', NULL, 119, 2, NULL, NULL),
(46, '2018-03-05 09:46:13', b'0', NULL, NULL, 1, NULL, 'nice', NULL, 129, 3, NULL, NULL),
(47, '2018-03-09 09:07:09', b'0', NULL, NULL, 1, NULL, 'hello', NULL, 107, 3, NULL, NULL),
(48, '2018-03-26 12:04:04', b'0', NULL, NULL, 1, NULL, '4th Comment', NULL, 102, 3, NULL, NULL),
(49, '2018-03-28 09:46:53', b'0', NULL, NULL, 1, NULL, 'asdasdasdasdasd', NULL, 241, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_files`
--

CREATE TABLE `post_files` (
  `post_files_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_tag` varchar(255) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_files`
--

INSERT INTO `post_files` (`post_files_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `file_name`, `file_tag`, `file_url`, `info`, `type`, `post_id`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(2, '2018-03-06 05:30:14', NULL, b'1', NULL, 1, 'imCool.png', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/135/imCool.png', NULL, 'image/png', 135, '2018-03-06 05:31:37', NULL, NULL),
(3, '2018-03-05 09:00:43', NULL, b'0', NULL, 1, '42795.jpg', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/129/42795.jpg', NULL, 'image/jpeg', 129, NULL, NULL, NULL),
(4, '2018-03-16 06:20:08', NULL, b'0', NULL, 1, 'download.jfif', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/165/download.jfif', NULL, 'image/jpeg', 165, NULL, NULL, NULL),
(5, '2018-03-16 06:20:53', NULL, b'0', NULL, 1, 'SampleCSVFile_2kb.csv', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/166/SampleCSVFile_2kb.csv', NULL, 'application/vnd.ms-excel', 166, NULL, NULL, NULL),
(6, '2018-03-16 06:21:33', NULL, b'0', NULL, 1, 'Jellyfish.jpg', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/167/Jellyfish.jpg', NULL, 'image/jpeg', 167, NULL, NULL, NULL),
(7, '2018-03-16 06:22:01', NULL, b'0', NULL, 1, 'images.jpg', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/168/images.jpg', NULL, 'image/jpeg', 168, NULL, NULL, NULL),
(8, '2018-03-16 06:28:17', NULL, b'0', NULL, 1, 'p03crg65.jpg', '384422', 'https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/TalkHives/Post/169/p03crg65.jpg', NULL, 'image/jpeg', 169, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `post_like_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `liked` bit(1) DEFAULT NULL,
  `post_like_tag` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`post_like_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `info`, `liked`, `post_like_tag`, `post_id`, `user_id`, `updated_by`, `deleted_by`) VALUES
(27, '2018-02-28 09:58:07', b'0', NULL, '2018-03-05 13:13:32', 1, NULL, b'1', NULL, 102, 2, NULL, NULL),
(28, '2018-02-28 09:58:10', b'0', NULL, NULL, 1, NULL, b'1', NULL, 102, 3, NULL, NULL),
(29, '2018-02-28 09:58:12', b'0', NULL, NULL, 1, NULL, b'1', NULL, 102, 1, NULL, NULL),
(30, '2018-02-28 10:09:48', b'0', NULL, NULL, 1, NULL, b'1', NULL, 103, 2, NULL, NULL),
(31, '2018-02-28 13:12:44', b'0', NULL, NULL, 1, NULL, b'1', NULL, 110, 1, NULL, NULL),
(32, '2018-02-28 13:12:55', b'0', NULL, NULL, 1, NULL, b'1', NULL, 110, 3, NULL, NULL),
(33, '2018-02-28 13:14:08', b'0', NULL, NULL, 1, NULL, b'1', NULL, 110, 2, NULL, NULL),
(34, '2018-02-28 13:14:38', b'0', NULL, NULL, 1, NULL, b'1', NULL, 110, 7, NULL, NULL),
(35, '2018-03-01 06:18:34', b'0', NULL, NULL, 1, NULL, b'1', NULL, 111, 1, NULL, NULL),
(36, '2018-03-01 06:19:57', b'0', NULL, '2018-03-05 13:13:01', 1, NULL, b'1', NULL, 111, 2, NULL, NULL),
(37, '2018-03-01 06:20:07', b'0', NULL, '2018-03-05 13:12:27', 1, NULL, b'1', NULL, 112, 2, NULL, NULL),
(38, '2018-03-01 08:27:33', b'0', NULL, '2018-03-01 14:31:25', 1, NULL, b'1', NULL, 114, 1, NULL, NULL),
(39, '2018-03-01 09:01:19', b'0', NULL, '2018-03-09 14:38:47', 1, NULL, b'1', NULL, 113, 1, NULL, NULL),
(40, '2018-03-01 11:27:22', b'0', NULL, NULL, 1, NULL, b'1', NULL, 116, 3, NULL, NULL),
(41, '2018-03-01 12:10:43', b'1', '2018-03-01 17:40:52', NULL, 1, NULL, b'1', NULL, 117, 1, NULL, NULL),
(42, '2018-03-01 12:10:44', b'1', '2018-03-01 17:40:53', NULL, 1, NULL, b'1', NULL, 117, 3, NULL, NULL),
(43, '2018-03-05 07:43:11', b'0', NULL, NULL, 1, NULL, b'1', NULL, 114, 2, NULL, NULL),
(44, '2018-03-05 07:43:20', b'0', NULL, NULL, 1, NULL, b'1', NULL, 106, 2, NULL, NULL),
(45, '2018-03-05 07:43:24', b'0', NULL, NULL, 1, NULL, b'1', NULL, 105, 2, NULL, NULL),
(46, '2018-03-05 07:43:26', b'0', NULL, NULL, 1, NULL, b'1', NULL, 104, 2, NULL, NULL),
(47, '2018-03-05 07:43:43', b'0', NULL, NULL, 1, NULL, b'1', NULL, 119, 2, NULL, NULL),
(48, '2018-03-05 07:43:44', b'0', NULL, NULL, 1, NULL, b'1', NULL, 118, 2, NULL, NULL),
(49, '2018-03-05 07:43:47', b'0', NULL, NULL, 1, NULL, b'1', NULL, 117, 2, NULL, NULL),
(50, '2018-03-05 09:46:00', b'0', NULL, NULL, 1, NULL, b'1', NULL, 119, 3, NULL, NULL),
(51, '2018-03-05 09:46:08', b'0', NULL, NULL, 1, NULL, b'1', NULL, 129, 3, NULL, NULL),
(52, '2018-03-09 09:06:35', b'1', '2018-03-09 14:36:48', '2018-03-09 14:36:44', 1, NULL, b'1', NULL, 107, 3, NULL, NULL),
(53, '2018-03-09 09:06:46', b'0', NULL, NULL, 1, NULL, b'1', NULL, 106, 3, NULL, NULL),
(54, '2018-03-09 09:08:36', b'0', NULL, NULL, 1, NULL, b'1', NULL, 134, 1, NULL, NULL),
(55, '2018-03-09 09:08:52', b'0', NULL, NULL, 1, NULL, b'1', NULL, 115, 1, NULL, NULL),
(56, '2018-03-23 11:46:38', b'1', '2018-03-23 17:16:56', NULL, 1, NULL, b'1', NULL, 199, 3, NULL, NULL),
(57, '2018-03-23 12:59:37', b'0', NULL, '2018-03-26 13:10:11', 1, NULL, b'1', NULL, 219, 3, NULL, NULL),
(58, '2018-03-26 07:39:28', b'0', NULL, NULL, 1, NULL, b'1', NULL, 233, 3, NULL, NULL),
(59, '2018-03-26 07:40:23', b'0', NULL, NULL, 1, NULL, b'1', NULL, 215, 3, NULL, NULL),
(60, '2018-03-26 07:48:38', b'1', '2018-03-26 13:18:40', NULL, 1, NULL, b'1', NULL, 104, 3, NULL, NULL),
(61, '2018-03-28 07:54:39', b'0', NULL, NULL, 1, NULL, b'1', NULL, 240, 2, NULL, NULL),
(62, '2018-03-28 07:59:47', b'0', NULL, '2018-03-28 13:49:50', 1, NULL, b'1', NULL, 240, 1, NULL, NULL),
(63, '2018-03-28 08:28:06', b'0', NULL, NULL, 1, NULL, b'1', NULL, 241, 2, NULL, NULL),
(64, '2018-03-28 08:33:07', b'0', NULL, NULL, 1, NULL, b'1', NULL, 241, 1, NULL, NULL),
(65, '2018-03-28 08:34:05', b'0', NULL, NULL, 1, NULL, b'1', NULL, 210, 2, NULL, NULL),
(66, '2018-03-28 08:34:52', b'0', NULL, NULL, 1, NULL, b'1', NULL, 194, 2, NULL, NULL),
(67, '2018-03-28 08:40:19', b'0', NULL, NULL, 1, NULL, b'1', NULL, 210, 1, NULL, NULL),
(68, '2018-03-28 08:46:03', b'0', NULL, NULL, 1, NULL, b'1', NULL, 206, 1, NULL, NULL),
(69, '2018-03-28 09:11:07', b'0', NULL, NULL, 1, NULL, b'1', NULL, 191, 2, NULL, NULL),
(70, '2018-03-28 09:45:28', b'1', '2018-03-28 15:19:58', NULL, 1, NULL, b'1', NULL, 237, 3, NULL, NULL),
(71, '2018-03-28 09:51:35', b'0', NULL, NULL, 1, NULL, b'1', NULL, 230, 3, NULL, NULL),
(72, '2018-03-30 06:36:36', b'0', NULL, NULL, 1, NULL, b'1', NULL, 243, 1, NULL, NULL),
(73, '2018-04-05 12:42:46', b'0', NULL, NULL, 1, NULL, b'1', NULL, 245, 3, NULL, NULL),
(74, '2018-04-06 12:32:24', b'0', NULL, NULL, 1, NULL, b'1', NULL, 237, 2, NULL, NULL),
(75, '2018-04-06 12:32:44', b'1', '2018-04-06 18:02:56', '2018-04-06 18:02:49', 1, NULL, b'1', NULL, 230, 2, NULL, NULL),
(76, '2018-04-06 12:33:04', b'0', NULL, NULL, 1, NULL, b'1', NULL, 218, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_sharing`
--

CREATE TABLE `post_sharing` (
  `post_sharing_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_sharing`
--

INSERT INTO `post_sharing` (`post_sharing_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `post_id`, `user_id`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-03-21 09:23:42', NULL, b'0', NULL, 1, 174, 1, NULL, NULL, NULL),
(2, '2018-03-21 09:23:42', NULL, b'0', NULL, 1, 174, 3, NULL, NULL, NULL),
(3, '2018-03-21 09:23:42', NULL, b'0', NULL, 1, 174, 6, NULL, NULL, NULL),
(4, '2018-03-21 10:07:53', NULL, b'0', NULL, 1, 187, 2, NULL, NULL, NULL),
(5, '2018-03-26 07:35:01', NULL, b'0', NULL, 1, 232, 2, NULL, NULL, NULL),
(6, '2018-03-26 07:37:41', NULL, b'0', NULL, 1, 233, 1, NULL, NULL, NULL),
(7, '2018-03-26 07:57:32', NULL, b'0', NULL, 1, 235, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `priority`
--

CREATE TABLE `priority` (
  `priority_tag` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `priority`
--

INSERT INTO `priority` (`priority_tag`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `info`, `title`, `organization_id`, `user_id`) VALUES
(306, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Low', NULL, NULL),
(384, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'High', NULL, NULL),
(617, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Normal', NULL, NULL),
(629, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Urgent', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `privacy_level`
--

CREATE TABLE `privacy_level` (
  `privacy_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `privacy_tag` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privacy_level`
--

INSERT INTO `privacy_level` (`privacy_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `info`, `privacy_tag`, `title`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Only you can see', '0', 'Only Me', NULL, NULL, NULL),
(2, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Only owners can see', '1', 'Owners Only', NULL, NULL, NULL),
(3, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Admin & above', '2', 'Admin & above', NULL, NULL, NULL),
(4, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Manager & above', '3', 'Manager & above', NULL, NULL, NULL),
(5, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Employee & above', '4', 'Employee & above', NULL, NULL, NULL),
(6, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'User & above', '5', 'User & above', NULL, NULL, NULL),
(7, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Watcher & above', '6', 'Watcher & above', NULL, NULL, NULL),
(8, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Everyone can see', '9', 'Public', NULL, NULL, NULL),
(9, '2018-02-14 12:03:49', NULL, b'0', NULL, 1, 'Selected People can see', '10', 'Specific People', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `completion` double DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `milestone_percentage` double DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `project_tag` varchar(255) DEFAULT NULL,
  `total_member` int(11) DEFAULT NULL,
  `total_milestone` int(11) DEFAULT NULL,
  `client` bigint(20) DEFAULT NULL,
  `manager` bigint(20) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `initial_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `completion`, `deadline`, `info`, `milestone_percentage`, `name`, `project_tag`, `total_member`, `total_milestone`, `client`, `manager`, `organization_id`, `team_id`, `user_id`, `status`, `initial_date`) VALUES
(1, '2018-04-13 11:01:17', b'0', NULL, NULL, NULL, NULL, 1, 0, NULL, 'azZS', NULL, 'angular', NULL, 5, 0, 1, 6, 1, 12, 2, NULL, NULL),
(2, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, 1, '2018-05-13 13:30:00', 'xasxa', 33, 'testing', NULL, 3, 3, 12, 1, 1, 13, 2, 298, '2018-05-13 13:30:00'),
(3, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, 1, '2018-05-13 13:30:00', 'xasxa', 33, 'testing', NULL, 3, 3, 12, 1, 1, 13, 2, 298, '2018-05-13 13:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `project_comments`
--

CREATE TABLE `project_comments` (
  `project_comment_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `project_comment_tag` varchar(255) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project_milestones`
--

CREATE TABLE `project_milestones` (
  `project_milestone_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `completion` double DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `initial_date` datetime DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `project_milestone_tag` varchar(255) DEFAULT NULL,
  `task_percentage` double DEFAULT NULL,
  `total_task` int(11) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project_milestones`
--

INSERT INTO `project_milestones` (`project_milestone_id`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `completion`, `deadline`, `info`, `initial_date`, `level`, `name`, `project_milestone_tag`, `task_percentage`, `total_task`, `organization_id`, `project_id`, `user_id`, `status`) VALUES
(1, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-09 12:30:00', 'hgghfh', '2018-05-09 12:30:00', 1, 'm2', NULL, 100, 1, 1, 2, 2, 298),
(2, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-01 12:30:00', 'cdacds', '2018-05-01 12:30:00', 0, 'm1', NULL, 50, 2, 1, 2, 2, 298),
(3, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-18 12:30:00', 'fhfhgfhgfhg', '2018-05-18 12:30:00', 2, 'm3', NULL, 50, 2, 1, 2, 2, 298),
(4, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-01 12:30:00', 'cdacds', '2018-05-01 12:30:00', 0, 'm1', NULL, 50, 2, 1, 3, 2, 298),
(5, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-09 12:30:00', 'hgghfh', '2018-05-09 12:30:00', 1, 'm2', NULL, 100, 1, 1, 3, 2, 298),
(6, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, 0, '2018-05-18 12:30:00', 'fhfhgfhgfhg', '2018-05-18 12:30:00', 2, 'm3', NULL, 50, 2, 1, 3, 2, 298);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `status_tag` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_tag`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `info`, `title`, `organization_id`, `user_id`) VALUES
(298, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'New', NULL, NULL),
(604, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Active', NULL, NULL),
(695, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Deleted', NULL, NULL),
(709, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Pending', NULL, NULL),
(730, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Overdue', NULL, NULL),
(773, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Need Help', NULL, NULL),
(806, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Rejected', NULL, NULL),
(813, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Not Found', NULL, NULL),
(914, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Undefined', NULL, NULL),
(925, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Completed', NULL, NULL),
(956, '2018-04-11 11:46:23', b'0', NULL, NULL, NULL, NULL, 1, NULL, 'Postponed', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `talk_hives`
--

CREATE TABLE `talk_hives` (
  `talk_hives_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `disabled` bit(1) DEFAULT NULL,
  `th_tag` varchar(255) DEFAULT NULL,
  `th_team` bit(1) NOT NULL,
  `verified` bit(1) DEFAULT NULL,
  `invited_by` bigint(20) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `payment_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `talk_hives`
--

INSERT INTO `talk_hives` (`talk_hives_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `disabled`, `th_tag`, `th_team`, `verified`, `invited_by`, `organization_id`, `payment_id`, `user_id`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 06:34:13', NULL, b'0', NULL, 1, b'0', '00017001g', b'0', b'0', NULL, 1, NULL, 1, NULL, NULL, NULL),
(2, '2018-02-14 06:38:08', NULL, b'0', NULL, 1, b'0', '00027001s', b'0', b'0', 1, 1, NULL, 2, NULL, NULL, NULL),
(3, '2018-02-14 06:43:09', NULL, b'0', NULL, 1, b'0', '00037001s', b'0', b'0', 1, 1, NULL, 3, NULL, NULL, NULL),
(4, '2018-02-14 06:50:59', NULL, b'0', NULL, 1, b'0', '00057001l', b'0', b'0', 3, 1, NULL, 5, NULL, NULL, NULL),
(5, '2018-02-14 06:54:46', NULL, b'0', NULL, 1, b'0', 'g00170006', b'0', b'0', 3, 1, NULL, 6, NULL, NULL, NULL),
(6, '2018-02-15 05:30:00', NULL, b'0', NULL, 1, b'0', 'l00170007', b'0', b'0', 3, 1, NULL, 7, NULL, NULL, NULL),
(7, '2018-02-22 09:34:04', NULL, b'0', NULL, 1, b'0', '00097003l', b'0', b'0', NULL, 3, NULL, 9, NULL, NULL, NULL),
(9, '2018-02-22 09:52:37', NULL, b'0', NULL, 1, b'0', 's00470010', b'0', b'0', NULL, 4, NULL, 10, NULL, NULL, NULL),
(10, '2018-02-22 09:53:22', NULL, b'0', NULL, 1, b'0', '00117005o', b'0', b'0', NULL, 5, NULL, 11, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `initial_date` datetime DEFAULT NULL,
  `overdue_date` datetime DEFAULT NULL,
  `task_tag` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `total_member` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `priority` bigint(20) DEFAULT NULL,
  `project_milestone_id` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `deadline`, `info`, `initial_date`, `overdue_date`, `task_tag`, `title`, `total_member`, `type`, `organization_id`, `priority`, `project_milestone_id`, `status`, `user_id`) VALUES
(1, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-09 07:00:00', NULL, '2018-05-09 07:00:00', NULL, NULL, 't1 m2', 1, '727', 1, 384, 1, 298, 2),
(2, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-01 07:00:00', NULL, '2018-05-01 07:00:00', NULL, NULL, 'task1 m1', 1, '727', 1, 384, 2, 298, 2),
(3, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-01 07:00:00', NULL, '2018-05-01 07:00:00', NULL, NULL, 'task2 m2', 2, '727', 1, 384, 2, 298, 2),
(4, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-18 07:00:00', NULL, '2018-05-18 07:00:00', NULL, NULL, 't2 m3', 1, '727', 1, 629, 3, 298, 2),
(5, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-18 07:00:00', NULL, '2018-05-18 07:00:00', NULL, NULL, 't1 m3', 1, '727', 1, 384, 3, 298, 2),
(6, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-01 07:00:00', NULL, '2018-05-01 07:00:00', NULL, NULL, 'task2 m2', 2, '727', 1, 384, 4, 298, 2),
(7, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-01 07:00:00', NULL, '2018-05-01 07:00:00', NULL, NULL, 'task1 m1', 1, '727', 1, 384, 4, 298, 2),
(8, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-09 07:00:00', NULL, '2018-05-09 07:00:00', NULL, NULL, 't1 m2', 1, '727', 1, 384, 5, 298, 2),
(9, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-18 07:00:00', NULL, '2018-05-18 07:00:00', NULL, NULL, 't2 m3', 1, '727', 1, 629, 6, 298, 2),
(10, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, '2018-05-18 07:00:00', NULL, '2018-05-18 07:00:00', NULL, NULL, 't1 m3', 1, '727', 1, 384, 6, 298, 2);

-- --------------------------------------------------------

--
-- Table structure for table `task_members`
--

CREATE TABLE `task_members` (
  `task_member_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` tinyblob,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` tinyblob,
  `version` bigint(20) DEFAULT NULL,
  `task_member_tag` varchar(255) DEFAULT NULL,
  `assigned_by` bigint(20) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_members`
--

INSERT INTO `task_members` (`task_member_id`, `created_at`, `deleted`, `deleted_at`, `deleted_by`, `updated_at`, `updated_by`, `version`, `task_member_tag`, `assigned_by`, `task_id`, `user_id`) VALUES
(1, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 1, 7),
(2, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 2, 2),
(3, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 3, 3),
(4, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 3, 7),
(5, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 4, 2),
(6, '2018-04-16 12:43:57', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 5, 3),
(7, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 6, 3),
(8, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 6, 7),
(9, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 7, 2),
(10, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 8, 7),
(11, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 9, 2),
(12, '2018-04-16 13:15:25', b'0', NULL, NULL, NULL, NULL, 1, NULL, 2, 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `team_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `budget` decimal(19,2) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ranking` int(11) DEFAULT NULL,
  `team_tag` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `total_member` int(11) DEFAULT NULL,
  `total_projects` int(11) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `live_projects` int(11) DEFAULT NULL,
  `success_projects` int(11) DEFAULT NULL,
  `team_leader` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `budget`, `info`, `name`, `ranking`, `team_tag`, `title`, `total_member`, `total_projects`, `organization_id`, `user_id`, `deleted_at`, `live_projects`, `success_projects`, `team_leader`, `updated_by`, `deleted_by`) VALUES
(3, '2018-02-14 11:51:09', NULL, b'0', NULL, 1, '100000.00', 'testing ', 'TalkHives', 0, NULL, NULL, 3, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(4, '2018-02-15 11:44:47', NULL, b'1', '2018-03-01 05:47:50', 2, '400000.00', 'asdasdasd', 't2', 0, NULL, NULL, 0, 0, 1, 1, '2018-04-06 08:46:58', NULL, NULL, NULL, NULL, NULL),
(5, '2018-02-26 08:34:17', NULL, b'0', NULL, 1, '800000.00', 'wqeqweqweqweqwe\n\nqwe\nqwe\nqwe', 'Team 3', 0, NULL, NULL, 2, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(6, '2018-02-26 08:35:55', NULL, b'0', NULL, 1, '400000000.00', 'asdasdasdasd', 'Team 4', 0, NULL, NULL, 2, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '2018-02-26 08:39:54', NULL, b'0', '2018-03-01 05:48:24', 2, '12123123.00', '7 no', 't5', 0, NULL, NULL, 0, 0, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(8, '2018-02-26 08:44:26', NULL, b'1', '2018-03-26 07:54:55', 4, '12121212.00', 'asdasd', 't6', 0, NULL, NULL, 2, 0, 3, 1, '2018-04-05 06:58:06', NULL, NULL, NULL, NULL, NULL),
(9, '2018-03-26 07:55:34', NULL, b'0', NULL, 1, '100000.00', 'Testing', 't7', 0, NULL, NULL, 2, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(10, '2018-04-05 05:07:18', NULL, b'0', '2018-04-05 12:53:48', 3, '12000.00', 'csdc', 't8', 0, NULL, NULL, 5, 0, 1, 2, NULL, 0, 0, 1, NULL, NULL),
(11, '2018-04-06 07:31:44', NULL, b'1', '2018-04-06 07:33:34', 2, '120394.00', 'mare marji...', 'bhim', 0, NULL, NULL, 4, 0, 1, 2, '2018-04-06 07:50:25', 0, 0, 3, NULL, NULL),
(12, '2018-04-06 08:50:28', NULL, b'0', NULL, 1, '192000.00', 'angular team', 'angular ', 0, NULL, NULL, 5, 0, 1, 2, NULL, 0, 0, 3, NULL, NULL),
(13, '2018-04-06 08:51:12', NULL, b'0', NULL, 1, '12356666.00', 'spring teams', 'spring', 0, NULL, NULL, 3, 0, 1, 2, NULL, 0, 0, 1, NULL, NULL),
(14, '2018-04-06 08:53:46', NULL, b'0', '2018-04-06 08:54:26', 2, '1245000.00', 'devloper ream', 'developer', 0, NULL, NULL, 5, 0, 1, 2, NULL, 0, 0, 6, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `team_member_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `team_member_tag` varchar(255) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `team_leader` bit(1) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`team_member_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `team_member_tag`, `team_id`, `user_id`, `deleted_at`, `team_leader`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 11:51:09', NULL, b'0', NULL, 1, NULL, 3, 1, NULL, NULL, NULL, NULL),
(2, '2018-02-14 11:51:09', NULL, b'0', NULL, 1, NULL, 3, 2, NULL, NULL, NULL, NULL),
(3, '2018-02-14 11:51:09', NULL, b'0', NULL, 1, NULL, 3, 6, NULL, NULL, NULL, NULL),
(4, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 6, '2018-03-01 05:47:50', NULL, NULL, NULL),
(5, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 7, '2018-03-01 05:47:50', NULL, NULL, NULL),
(6, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 5, '2018-03-01 05:47:50', NULL, NULL, NULL),
(7, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 3, '2018-03-01 05:47:50', NULL, NULL, NULL),
(8, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 2, '2018-03-01 05:47:50', NULL, NULL, NULL),
(9, '2018-02-15 11:44:47', NULL, b'1', NULL, 1, NULL, 4, 1, '2018-03-01 05:47:50', NULL, NULL, NULL),
(10, '2018-02-26 08:34:17', NULL, b'0', NULL, 1, NULL, 5, 7, NULL, NULL, NULL, NULL),
(11, '2018-02-26 08:34:17', NULL, b'0', NULL, 1, NULL, 5, 1, NULL, NULL, NULL, NULL),
(12, '2018-02-26 08:35:55', NULL, b'0', NULL, 1, NULL, 6, 7, NULL, NULL, NULL, NULL),
(13, '2018-02-26 08:35:55', NULL, b'0', NULL, 1, NULL, 6, 5, NULL, NULL, NULL, NULL),
(14, '2018-02-26 08:39:54', NULL, b'1', NULL, 1, NULL, 7, 7, '2018-03-01 05:48:24', NULL, NULL, NULL),
(15, '2018-02-26 08:39:54', NULL, b'1', NULL, 1, NULL, 7, 6, '2018-03-01 05:48:24', NULL, NULL, NULL),
(16, '2018-02-26 08:44:26', NULL, b'1', NULL, 1, NULL, 8, 6, '2018-03-01 05:58:32', NULL, NULL, NULL),
(17, '2018-03-01 05:58:32', NULL, b'1', NULL, 1, NULL, 8, 1, '2018-03-26 07:54:12', NULL, NULL, NULL),
(18, '2018-03-01 05:58:32', NULL, b'1', NULL, 1, NULL, 8, 2, '2018-03-26 07:54:12', NULL, NULL, NULL),
(19, '2018-03-26 07:54:12', NULL, b'1', NULL, 1, NULL, 8, 6, '2018-03-26 07:54:55', NULL, NULL, NULL),
(20, '2018-03-26 07:54:12', NULL, b'1', NULL, 1, NULL, 8, 3, '2018-03-26 07:54:55', NULL, NULL, NULL),
(21, '2018-03-26 07:54:54', NULL, b'0', NULL, 1, NULL, 8, 1, NULL, NULL, NULL, NULL),
(22, '2018-03-26 07:54:55', NULL, b'0', NULL, 1, NULL, 8, 2, NULL, NULL, NULL, NULL),
(23, '2018-03-26 07:55:35', NULL, b'0', NULL, 1, NULL, 9, 1, NULL, NULL, NULL, NULL),
(24, '2018-03-26 07:55:35', NULL, b'0', NULL, 1, NULL, 9, 3, NULL, NULL, NULL, NULL),
(25, '2018-04-05 05:07:19', NULL, b'1', NULL, 1, NULL, 10, 1, '2018-04-05 06:17:06', b'0', NULL, NULL),
(26, '2018-04-05 05:07:19', NULL, b'0', NULL, 1, NULL, 10, 5, NULL, b'0', NULL, NULL),
(27, '2018-04-05 05:07:19', NULL, b'0', NULL, 1, NULL, 10, 3, NULL, b'0', NULL, NULL),
(28, '2018-04-05 05:07:19', NULL, b'0', NULL, 1, NULL, 10, 6, NULL, b'0', NULL, NULL),
(30, '2018-04-05 06:17:06', NULL, b'0', NULL, 1, NULL, 10, 2, NULL, b'0', NULL, NULL),
(31, '2018-04-05 12:53:48', NULL, b'0', NULL, 1, NULL, 10, 1, NULL, b'0', NULL, NULL),
(32, '2018-04-06 07:31:45', NULL, b'0', NULL, 1, NULL, 11, 2, NULL, b'0', NULL, NULL),
(33, '2018-04-06 07:31:45', NULL, b'0', NULL, 1, NULL, 11, 1, NULL, b'0', NULL, NULL),
(34, '2018-04-06 07:31:45', NULL, b'0', NULL, 1, NULL, 11, 6, NULL, b'0', NULL, NULL),
(35, '2018-04-06 07:31:45', NULL, b'0', NULL, 1, NULL, 11, 7, NULL, b'0', NULL, NULL),
(36, '2018-04-06 08:50:28', NULL, b'0', NULL, 1, NULL, 12, 1, NULL, b'0', NULL, NULL),
(37, '2018-04-06 08:50:28', NULL, b'0', NULL, 1, NULL, 12, 6, NULL, b'0', NULL, NULL),
(38, '2018-04-06 08:50:28', NULL, b'0', NULL, 1, NULL, 12, 7, NULL, b'0', NULL, NULL),
(39, '2018-04-06 08:50:29', NULL, b'0', NULL, 1, NULL, 12, 2, NULL, b'0', NULL, NULL),
(40, '2018-04-06 08:50:29', NULL, b'0', NULL, 1, NULL, 12, 5, NULL, b'0', NULL, NULL),
(41, '2018-04-06 08:51:12', NULL, b'0', NULL, 1, NULL, 13, 2, NULL, b'0', NULL, NULL),
(42, '2018-04-06 08:51:12', NULL, b'0', NULL, 1, NULL, 13, 7, NULL, b'0', NULL, NULL),
(43, '2018-04-06 08:51:12', NULL, b'0', NULL, 1, NULL, 13, 3, NULL, b'0', NULL, NULL),
(44, '2018-04-06 08:53:46', NULL, b'0', NULL, 1, NULL, 14, 1, NULL, b'0', NULL, NULL),
(45, '2018-04-06 08:53:47', NULL, b'0', NULL, 1, NULL, 14, 2, NULL, b'0', NULL, NULL),
(46, '2018-04-06 08:53:47', NULL, b'0', NULL, 1, NULL, 14, 3, NULL, b'0', NULL, NULL),
(47, '2018-04-06 08:53:47', NULL, b'0', NULL, 1, NULL, 14, 5, NULL, b'0', NULL, NULL),
(48, '2018-04-06 08:53:47', NULL, b'0', NULL, 1, NULL, 14, 7, NULL, b'0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `age` datetime DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `hash_tag` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pin_code` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `image_id` bigint(20) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_role` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `birth_day` datetime DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `address`, `age`, `bio`, `birth_date`, `city`, `country`, `country_code`, `designation`, `email_id`, `first_name`, `hash_tag`, `last_name`, `latitude`, `longitude`, `mobile_no`, `password`, `pin_code`, `state`, `user_name`, `image_id`, `organization_id`, `user_role`, `deleted_at`, `birth_day`, `gender`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 06:34:08', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'CEO', 'ervicpatel@gmail.com', 'Vivek', NULL, 'Patel', NULL, NULL, '9426645992', '123321', NULL, NULL, 'vicky', 2, 1, 1, NULL, NULL, 'Male', NULL, NULL),
(2, '2018-02-14 06:38:08', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Developer', 'ervicpatel@rediffmail.com', 'Kajal', NULL, 'Trivedi', NULL, NULL, '9426612345', '123321', NULL, NULL, 'kajal', 1, 1, 2, NULL, NULL, 'Female', NULL, NULL),
(3, '2018-02-14 06:43:08', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Designer', 'maulik.2304@rediffmail.com', 'Maulik', NULL, 'Shelat', NULL, NULL, '9426645992', '123321', NULL, NULL, 'maulik', 1, 1, 3, NULL, NULL, 'Male', NULL, NULL),
(5, '2018-02-14 06:50:59', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'FrontEnd Developer', 'prince.shelat007@gmail.com', 'Rajkumar', NULL, 'Yadav', NULL, NULL, '9426645992', '123321', NULL, NULL, 'maulik1', 1, 1, 5, NULL, NULL, 'Male', NULL, NULL),
(6, '2018-02-14 06:54:46', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Web Developer', 'shelatmaulik16@gmail.com', 'Twinkle', NULL, 'Bhati', NULL, NULL, '9426645992', '123321', NULL, NULL, 'twinkle', 1, 1, 5, NULL, NULL, 'Female', NULL, NULL),
(7, '2018-02-15 05:30:00', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Software Engineer', 'patelvivekb.00@gmail.com', 'Nana', NULL, 'Patekar', NULL, NULL, '9426645992', '123321', NULL, NULL, 'nana', 1, 1, 4, NULL, NULL, 'Male', NULL, NULL),
(9, '2018-02-22 09:33:59', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Manager', 'dhrvutripathi@gmail.com', 'Dhruv', NULL, 'Tripathi', NULL, NULL, '3345434566', '123321', NULL, NULL, 'dhruv', 3, 3, 1, NULL, NULL, 'Male', NULL, NULL),
(10, '2018-02-22 09:52:31', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Software Engineer', 'poojapatel@gmail.com', 'Pooja', NULL, 'Patel', NULL, NULL, '9426645992', '123321', NULL, NULL, 'pooja', 4, 4, 1, NULL, NULL, 'Female', NULL, NULL),
(11, '2018-02-22 09:53:22', NULL, b'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, '91', 'Gamer', 'ravipatel@gmail.com', 'Ravi', NULL, 'Patel', NULL, NULL, '9426645992', '123321', NULL, NULL, 'ravi', 1, 5, 1, NULL, NULL, 'Male', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_activity`
--

CREATE TABLE `user_activity` (
  `user_activity_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `blogs` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `invited_users` bigint(20) DEFAULT NULL,
  `issues` bigint(20) DEFAULT NULL,
  `posts` bigint(20) DEFAULT NULL,
  `projects` bigint(20) DEFAULT NULL,
  `teams` bigint(20) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_activity_tag` varchar(255) DEFAULT NULL,
  `votes` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `role_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `role_tag` varchar(255) DEFAULT NULL,
  `role_title` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `created_at`, `delete_at`, `deleted`, `updated_at`, `version`, `role_tag`, `role_title`, `deleted_at`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '1', 'Owner', NULL, NULL, NULL),
(2, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '2', 'Admin', NULL, NULL, NULL),
(3, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '3', 'Manager', NULL, NULL, NULL),
(4, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '4', 'Employee', NULL, NULL, NULL),
(5, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '5', 'User', NULL, NULL, NULL),
(6, '2018-02-14 12:03:48', NULL, b'0', NULL, 1, '6', 'Watcher', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `vote_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `comments` int(11) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `vote_tag` varchar(255) DEFAULT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`vote_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `comments`, `info`, `likes`, `message`, `vote_tag`, `organization_id`, `user_id`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-19 07:31:47', b'0', NULL, NULL, 1, 14, NULL, 1, 'Hu aiya su karu 6u?', NULL, 1, 2, NULL, NULL),
(2, '2018-02-20 04:45:11', b'0', NULL, '2018-03-01 11:29:00', 2, 3, NULL, 2, 'What is vote??', NULL, 1, 1, NULL, NULL),
(3, '2018-02-20 04:45:34', b'0', NULL, NULL, 1, 0, NULL, 1, 'What is this?', NULL, 1, 1, NULL, NULL),
(4, '2018-02-20 04:46:09', b'0', NULL, NULL, 1, 3, NULL, 1, 'What is IT?', NULL, 1, 1, NULL, NULL),
(5, '2018-02-20 05:09:44', b'0', NULL, NULL, 1, 1, NULL, 0, 'Hello', NULL, 1, 1, NULL, NULL),
(6, '2018-03-01 11:30:01', b'0', NULL, NULL, 1, 0, NULL, 1, 'I need a help in angular 5..........', NULL, 1, 1, NULL, NULL),
(7, '2018-03-01 11:33:01', b'0', NULL, NULL, 1, 7, NULL, 2, 'Comment counter', NULL, 1, 3, NULL, NULL),
(8, '2018-03-01 11:37:04', b'1', '2018-03-01 11:41:58', NULL, 1, 1, NULL, 0, 'For Top', NULL, 1, 3, NULL, NULL),
(9, '2018-03-01 11:41:16', b'1', '2018-03-01 11:41:49', NULL, 1, 0, NULL, 0, 'Top Position', NULL, 1, 3, NULL, NULL),
(10, '2018-03-01 12:06:29', b'1', '2018-03-01 12:07:08', NULL, 1, 0, NULL, 0, 'top', NULL, 1, 1, NULL, NULL),
(11, '2018-03-01 12:09:31', b'1', '2018-03-01 12:10:07', NULL, 1, 0, NULL, 0, 'top', NULL, 1, 1, NULL, NULL),
(12, '2018-03-01 12:21:24', b'1', '2018-03-26 12:55:57', NULL, 1, 1, NULL, 2, 'top', NULL, 1, 3, NULL, NULL),
(13, '2018-03-30 09:33:20', b'0', NULL, NULL, 1, 0, NULL, 1, 'Test Like', NULL, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vote_comments`
--

CREATE TABLE `vote_comments` (
  `vote_comment_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `vote_comment_tag` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `vote_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vote_comments`
--

INSERT INTO `vote_comments` (`vote_comment_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `info`, `message`, `vote_comment_tag`, `user_id`, `vote_id`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-19 07:32:34', b'0', NULL, NULL, 1, NULL, 'heyy..', NULL, 6, 1, NULL, NULL),
(2, '2018-02-19 07:32:55', b'0', NULL, NULL, 1, NULL, 'hiii\n', NULL, 2, 1, NULL, NULL),
(3, '2018-02-19 07:33:10', b'0', NULL, NULL, 1, NULL, 'cdc', NULL, 1, 1, NULL, NULL),
(4, '2018-02-19 07:33:13', b'0', NULL, NULL, 1, NULL, 'hu vivek', NULL, 2, 1, NULL, NULL),
(5, '2018-02-19 07:33:27', b'0', NULL, NULL, 1, NULL, 'ads', NULL, 6, 1, NULL, NULL),
(6, '2018-02-19 07:33:33', b'0', NULL, NULL, 1, NULL, 'twinkle', NULL, 2, 1, NULL, NULL),
(7, '2018-02-19 07:33:55', b'0', NULL, NULL, 1, NULL, 'kajal', NULL, 2, 1, NULL, NULL),
(8, '2018-02-19 07:34:10', b'0', NULL, NULL, 1, NULL, 'opiii\n', NULL, 2, 1, NULL, NULL),
(9, '2018-02-20 12:41:49', b'0', NULL, NULL, 1, NULL, 'Ae tane kabar', NULL, 3, 1, NULL, NULL),
(10, '2018-02-26 05:46:25', b'0', NULL, NULL, 1, NULL, 'ala aatlu nai khabar ?', NULL, 2, 4, NULL, NULL),
(11, '2018-02-26 08:51:05', b'0', NULL, NULL, 1, NULL, 'asdasdasd', NULL, 1, 1, NULL, NULL),
(12, '2018-02-28 07:34:53', b'0', NULL, NULL, 1, NULL, 'hello', NULL, 2, 1, NULL, NULL),
(13, '2018-02-28 11:30:31', b'0', NULL, NULL, 1, NULL, 'hahahahahahahaha', NULL, 3, 4, NULL, NULL),
(14, '2018-02-28 11:30:43', b'0', NULL, NULL, 1, NULL, 'hahahaha@vivek', NULL, 3, 4, NULL, NULL),
(15, '2018-03-01 11:31:15', b'0', NULL, NULL, 1, NULL, 'Mane si kabar', NULL, 3, 1, NULL, NULL),
(16, '2018-03-01 11:33:16', b'0', NULL, NULL, 1, NULL, 'Su?????', NULL, 1, 7, NULL, NULL),
(17, '2018-03-01 11:34:19', b'0', NULL, NULL, 1, NULL, 'Counter not proper display number...After page refresh it will be displayed.....Check It', NULL, 3, 7, NULL, NULL),
(18, '2018-03-01 11:37:24', b'0', NULL, NULL, 1, NULL, 'Comment counter testing\n', NULL, 3, 8, NULL, NULL),
(19, '2018-03-01 11:50:48', b'0', NULL, NULL, 1, NULL, 'hello', NULL, 3, 1, NULL, NULL),
(20, '2018-03-01 11:52:00', b'0', NULL, NULL, 1, NULL, '14', NULL, 3, 1, NULL, NULL),
(21, '2018-03-01 12:06:05', b'0', NULL, NULL, 1, NULL, 'hello', NULL, 3, 2, NULL, NULL),
(22, '2018-03-12 11:15:25', b'0', NULL, NULL, 1, NULL, 'dssdfsf', NULL, 1, 12, NULL, NULL),
(23, '2018-03-16 06:43:06', b'0', NULL, NULL, 1, NULL, 'Testing', NULL, 3, 2, NULL, NULL),
(24, '2018-03-16 06:43:20', b'0', NULL, NULL, 1, NULL, '3rd Comment', NULL, 3, 2, NULL, NULL),
(25, '2018-03-16 06:43:37', b'0', NULL, NULL, 1, NULL, 'Hello', NULL, 3, 5, NULL, NULL),
(26, '2018-03-26 07:50:18', b'0', NULL, NULL, 1, NULL, 'Hello', NULL, 3, 7, NULL, NULL),
(27, '2018-03-26 07:50:46', b'0', NULL, NULL, 1, NULL, 'Can we delete previous Comment???....', NULL, 3, 7, NULL, NULL),
(28, '2018-03-26 07:51:34', b'0', NULL, NULL, 1, NULL, 'Previous Comment are not delete and update...Put this Functionality....If it will be possible\n', NULL, 3, 7, NULL, NULL),
(29, '2018-03-26 07:52:46', b'0', NULL, NULL, 1, NULL, 'wait', NULL, 1, 7, NULL, NULL),
(30, '2018-03-26 07:53:05', b'0', NULL, NULL, 1, NULL, 'Let me check............', NULL, 1, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vote_likes`
--

CREATE TABLE `vote_likes` (
  `vote_like_id` bigint(20) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `liked` bit(1) DEFAULT NULL,
  `vote_like_tag` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `vote_id` bigint(20) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `deleted_by` tinyblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vote_likes`
--

INSERT INTO `vote_likes` (`vote_like_id`, `created_at`, `deleted`, `deleted_at`, `updated_at`, `version`, `info`, `liked`, `vote_like_tag`, `user_id`, `vote_id`, `updated_by`, `deleted_by`) VALUES
(1, '2018-02-19 07:32:15', b'0', NULL, '2018-02-28 13:04:32', 1, NULL, b'1', NULL, 2, 1, NULL, NULL),
(2, '2018-02-19 07:32:49', b'1', '2018-02-26 17:38:10', '2018-02-26 17:38:09', 1, NULL, b'1', NULL, 1, 1, NULL, NULL),
(3, '2018-02-20 12:42:08', b'1', '2018-03-23 17:32:45', '2018-03-23 17:32:44', 1, NULL, b'0', NULL, 3, 1, NULL, NULL),
(4, '2018-02-28 07:06:24', b'1', '2018-03-23 17:32:49', '2018-03-23 17:32:47', 1, NULL, b'0', NULL, 3, 2, NULL, NULL),
(5, '2018-02-28 07:06:26', b'0', NULL, NULL, 1, NULL, b'1', NULL, 3, 3, NULL, NULL),
(6, '2018-02-28 07:06:27', b'0', NULL, '2018-03-23 17:32:40', 1, NULL, b'1', NULL, 3, 4, NULL, NULL),
(7, '2018-02-28 07:06:30', b'0', NULL, '2018-02-28 12:36:31', 1, NULL, b'0', NULL, 3, 5, NULL, NULL),
(8, '2018-03-01 11:34:56', b'0', NULL, NULL, 1, NULL, b'1', NULL, 1, 7, NULL, NULL),
(9, '2018-03-01 11:34:59', b'0', NULL, NULL, 1, NULL, b'1', NULL, 3, 7, NULL, NULL),
(10, '2018-03-01 12:07:24', b'0', NULL, NULL, 1, NULL, b'1', NULL, 1, 2, NULL, NULL),
(11, '2018-03-12 11:15:21', b'0', NULL, '2018-03-20 19:21:22', 1, NULL, b'1', NULL, 1, 12, NULL, NULL),
(12, '2018-03-23 12:02:31', b'1', '2018-03-23 17:32:33', '2018-03-23 17:32:32', 1, NULL, b'0', NULL, 3, 12, NULL, NULL),
(13, '2018-03-26 12:55:48', b'0', NULL, '2018-03-26 18:25:49', 1, NULL, b'0', NULL, 3, 6, NULL, NULL),
(14, '2018-03-28 06:57:05', b'0', NULL, NULL, 1, NULL, b'1', NULL, 1, 6, NULL, NULL),
(21, '2018-03-30 10:28:35', b'0', NULL, NULL, 1, NULL, b'1', NULL, 1, 13, NULL, NULL),
(22, '2018-03-30 11:24:13', b'1', '2018-03-30 16:54:23', NULL, 1, NULL, b'0', NULL, 1, 5, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`blog_id`),
  ADD KEY `FKnfnxii05mcn97yorongcp40w7` (`organization_id`),
  ADD KEY `FKpg4damav6db6a6fh5peylcni5` (`user_id`),
  ADD KEY `FKd3hupdqimepujqpq15cu9g6j8` (`image_id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chat_id`),
  ADD KEY `FK23gnfyyutie4dxee1pbby5nfi` (`chat_room_id`),
  ADD KEY `FKnily3yln8u34fc4vp2ckniesv` (`sender`);

--
-- Indexes for table `chat_rooms`
--
ALTER TABLE `chat_rooms`
  ADD PRIMARY KEY (`chat_room_id`),
  ADD KEY `FKs9o1q56sfhb29ao5qwl2dh9xe` (`user_one`),
  ADD KEY `FK134cnqavvpcuc5l1x5vg3pc8f` (`user_two`),
  ADD KEY `FKin9277aywbjursj2b4e3bmw3s` (`created_by`);

--
-- Indexes for table `chat_room_members`
--
ALTER TABLE `chat_room_members`
  ADD PRIMARY KEY (`chat_room_member_id`),
  ADD KEY `FK6x7kwk21yt5odfxv5ubbrmo0h` (`chat_room_id`),
  ADD KEY `FKbemsjj4g0iny4xpkvj5rwj6ab` (`user_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`),
  ADD KEY `FKqtabsk1bran5vu6akf0t5im81` (`organization_id`),
  ADD KEY `FKtiuqdledq2lybrds2k3rfqrv4` (`user_id`);

--
-- Indexes for table `forgot_passwords`
--
ALTER TABLE `forgot_passwords`
  ADD PRIMARY KEY (`forgot_password_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `invitations`
--
ALTER TABLE `invitations`
  ADD PRIMARY KEY (`invitation_id`),
  ADD KEY `FKex4qyxxsvv0imcv78b36qg2ng` (`invited_as`),
  ADD KEY `FKh67axu8o0vump4ii8d89e2244` (`invited_by`);

--
-- Indexes for table `login_users`
--
ALTER TABLE `login_users`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `new_entity`
--
ALTER TABLE `new_entity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `FKoabmk0oi6lx0x9gtbk43q1whq` (`blog_id`),
  ADD KEY `FK5ke2wwe92aixvisnkqvfrxb1c` (`organization_id`),
  ADD KEY `FK599539lym3mnkbqks0u806eac` (`post_id`),
  ADD KEY `FKiipbedgxt4856we8fgcaf5rvg` (`privacy_id`),
  ADD KEY `FK6fpt82588ru8v0imso3v8nan7` (`project_id`),
  ADD KEY `FKb24vbsa4ex6lv6bflt27mdbwo` (`receiver`),
  ADD KEY `FK3ir6n13njkrg669t3igyk4s7j` (`sender`),
  ADD KEY `FK3ylay2wp5j90aoi1j7jtc9vxc` (`team_id`),
  ADD KEY `FKbcf20g9dpb11baeys7v4x337q` (`vote_id`),
  ADD KEY `FKamgipnxddhwtkhlp3pl4vwy9v` (`who`),
  ADD KEY `FK2ktjq1slw0ldkuy5rx8fbte2p` (`task_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`organization_id`),
  ADD KEY `FK3x7xa8km09wmd5mgdhquhm8xq` (`created_by`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `FKef0yupohx30lw61gr8n57jlr0` (`organization_id`),
  ADD KEY `FK70f50cqfiyp9w8qi5fgikvsxd` (`plan_id`);

--
-- Indexes for table `pins`
--
ALTER TABLE `pins`
  ADD PRIMARY KEY (`pin_id`),
  ADD KEY `FKjtdqg04rdo7uq71d7kwrwgoxl` (`user_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`plan_id`),
  ADD KEY `FKtek3yglvdpqcwm3nf8570k8rv` (`created_by`);

--
-- Indexes for table `plan_manager`
--
ALTER TABLE `plan_manager`
  ADD PRIMARY KEY (`plan_manager_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `FKdor22mv7c8vs14e9cwmgxmn7o` (`organization_id`),
  ADD KEY `FKomb4kyhve4sfj149qo0xu8a03` (`privacy_id`),
  ADD KEY `FKdq6juqo0pj8om309r82rpthig` (`shared_by`),
  ADD KEY `FK5lidm6cqbc7u4xhqpxm898qme` (`user_id`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`post_comment_id`),
  ADD KEY `FKaawaqxjs3br8dw5v90w7uu514` (`post_id`),
  ADD KEY `FKsnxoecngu89u3fh4wdrgf0f2g` (`user_id`);

--
-- Indexes for table `post_files`
--
ALTER TABLE `post_files`
  ADD PRIMARY KEY (`post_files_id`),
  ADD KEY `FK8xc9ew2bxk7axrmc9epq40v2h` (`post_id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`post_like_id`),
  ADD KEY `FKa5wxsgl4doibhbed9gm7ikie2` (`post_id`),
  ADD KEY `FKkgau5n0nlewg6o9lr4yibqgxj` (`user_id`);

--
-- Indexes for table `post_sharing`
--
ALTER TABLE `post_sharing`
  ADD PRIMARY KEY (`post_sharing_id`),
  ADD KEY `FKpflkmsu7k1o4vfpvdxphmfbj3` (`post_id`),
  ADD KEY `FK64hdyipj7n00vv46pos2yagbv` (`user_id`);

--
-- Indexes for table `priority`
--
ALTER TABLE `priority`
  ADD PRIMARY KEY (`priority_tag`),
  ADD KEY `FKgbnak2anvilhy4vg4ji6t6n4k` (`organization_id`),
  ADD KEY `FKdi4eibr7r4w8pe7oissahgt2f` (`user_id`);

--
-- Indexes for table `privacy_level`
--
ALTER TABLE `privacy_level`
  ADD PRIMARY KEY (`privacy_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`),
  ADD KEY `FKfg1kfdnypbpllnpvlqbao6nen` (`client`),
  ADD KEY `FKpe4hrjaqqbcydvs54el28uq93` (`manager`),
  ADD KEY `FK3gwrleyyq6prcnqekmkobbimd` (`organization_id`),
  ADD KEY `FKmqih0928bq6r3gbuh47giq8w` (`team_id`),
  ADD KEY `FKhswfwa3ga88vxv1pmboss6jhm` (`user_id`),
  ADD KEY `FKnlyte1pyv1mh64xi0cnekidhy` (`status`);

--
-- Indexes for table `project_comments`
--
ALTER TABLE `project_comments`
  ADD PRIMARY KEY (`project_comment_id`),
  ADD KEY `FKfsk4ll3g13rwc631iwek1vmj5` (`project_id`),
  ADD KEY `FKhfovv2g0k4e98sp5g8mqwg9pg` (`user_id`);

--
-- Indexes for table `project_milestones`
--
ALTER TABLE `project_milestones`
  ADD PRIMARY KEY (`project_milestone_id`),
  ADD KEY `FKqsyt4knrqbiyv6cmo45vgaao9` (`organization_id`),
  ADD KEY `FKf89i5mou2qk96lrjgb8of4mdq` (`project_id`),
  ADD KEY `FKob71jvbh29ddq6yo6cowy7mdo` (`user_id`),
  ADD KEY `FKrgfn9lp5wx8utu1uole5ngjf` (`status`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_tag`),
  ADD KEY `FKj9suwfa0uf392mb37dg1qi1ja` (`organization_id`),
  ADD KEY `FK41pnbjmhlw8pvggq86inm7le` (`user_id`);

--
-- Indexes for table `talk_hives`
--
ALTER TABLE `talk_hives`
  ADD PRIMARY KEY (`talk_hives_id`),
  ADD KEY `FKoxp9c1m1dh7eofbmslou7luih` (`invited_by`),
  ADD KEY `FKry2dtsv7n76c6jdr73l9db9yp` (`organization_id`),
  ADD KEY `FKee79s8s2rjytr254sor1h3x69` (`payment_id`),
  ADD KEY `FKkyfw45xnpmg7psa5m91g9pi2v` (`user_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `FKgr44qo7c9sk5xqirvqwkdnd25` (`organization_id`),
  ADD KEY `FK636bkwxctg5ga3ttchmqgcqth` (`priority`),
  ADD KEY `FK6032xboy0vhwuey4n7sx5ec8q` (`project_milestone_id`),
  ADD KEY `FK75spb8vjkba9g75smsk95lbsx` (`status`),
  ADD KEY `FK6s1ob9k4ihi75xbxe2w0ylsdh` (`user_id`);

--
-- Indexes for table `task_members`
--
ALTER TABLE `task_members`
  ADD PRIMARY KEY (`task_member_id`),
  ADD KEY `FK4doycdgws5rexgg71afo0pixa` (`assigned_by`),
  ADD KEY `FKdt52vbqd7of6qsw8rcjtliihk` (`task_id`),
  ADD KEY `FKrl3dwc1wr947g91sbvnk7i053` (`user_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`team_id`),
  ADD KEY `FK5i52bhmm0nbq6lrbur63anlmc` (`organization_id`),
  ADD KEY `FKlm88j38y90erf2rum00e85gw8` (`user_id`),
  ADD KEY `FKab9ipjw80vbpjketttof4lnq1` (`team_leader`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`team_member_id`),
  ADD KEY `FKtgca08el3ofisywcf11f0f76t` (`team_id`),
  ADD KEY `FKee8x7x5026imwmma9kndkxs36` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `FK17herqt2to4hyl5q5r5ogbxk9` (`image_id`),
  ADD KEY `FKqpugllwvyv37klq7ft9m8aqxk` (`organization_id`),
  ADD KEY `FKfmrml2a622f39ylokwcx9oi36` (`user_role`);

--
-- Indexes for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD PRIMARY KEY (`user_activity_id`),
  ADD KEY `FKs41is1raa3f0y5q5g0pw2rfd4` (`user_id`),
  ADD KEY `FK6rxfhwypn5bcna20leny2mebd` (`organization_id`),
  ADD KEY `FK3m4ykocn4cydicpt842gy04lj` (`post_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`vote_id`),
  ADD KEY `FKolv9no5c48keylidna7dv9oov` (`organization_id`),
  ADD KEY `FKli4uj3ic2vypf5pialchj925e` (`user_id`);

--
-- Indexes for table `vote_comments`
--
ALTER TABLE `vote_comments`
  ADD PRIMARY KEY (`vote_comment_id`),
  ADD KEY `FKqlw3wk2rdxueinahf91ohw3nt` (`user_id`),
  ADD KEY `FKk4qxe066j0r1ayt7avjjc7bkc` (`vote_id`);

--
-- Indexes for table `vote_likes`
--
ALTER TABLE `vote_likes`
  ADD PRIMARY KEY (`vote_like_id`),
  ADD KEY `FK3a4ii5y2e2pelm4gh5e69tw1t` (`user_id`),
  ADD KEY `FKj4mbfe9bla2h3toutrfah5cve` (`vote_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `blog_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `chat_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;
--
-- AUTO_INCREMENT for table `chat_rooms`
--
ALTER TABLE `chat_rooms`
  MODIFY `chat_room_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `chat_room_members`
--
ALTER TABLE `chat_room_members`
  MODIFY `chat_room_member_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `forgot_passwords`
--
ALTER TABLE `forgot_passwords`
  MODIFY `forgot_password_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `image_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `invitations`
--
ALTER TABLE `invitations`
  MODIFY `invitation_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `login_users`
--
ALTER TABLE `login_users`
  MODIFY `login_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT for table `new_entity`
--
ALTER TABLE `new_entity`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `organization_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pins`
--
ALTER TABLE `pins`
  MODIFY `pin_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `plan_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `plan_manager`
--
ALTER TABLE `plan_manager`
  MODIFY `plan_manager_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=248;
--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `post_comment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `post_files`
--
ALTER TABLE `post_files`
  MODIFY `post_files_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `post_like_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `post_sharing`
--
ALTER TABLE `post_sharing`
  MODIFY `post_sharing_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `privacy_level`
--
ALTER TABLE `privacy_level`
  MODIFY `privacy_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `project_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `project_comments`
--
ALTER TABLE `project_comments`
  MODIFY `project_comment_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `project_milestones`
--
ALTER TABLE `project_milestones`
  MODIFY `project_milestone_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `talk_hives`
--
ALTER TABLE `talk_hives`
  MODIFY `talk_hives_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `task_members`
--
ALTER TABLE `task_members`
  MODIFY `task_member_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `team_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `team_member_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_activity`
--
ALTER TABLE `user_activity`
  MODIFY `user_activity_id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `vote_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `vote_comments`
--
ALTER TABLE `vote_comments`
  MODIFY `vote_comment_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `vote_likes`
--
ALTER TABLE `vote_likes`
  MODIFY `vote_like_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `FKd3hupdqimepujqpq15cu9g6j8` FOREIGN KEY (`image_id`) REFERENCES `images` (`image_id`),
  ADD CONSTRAINT `FKnfnxii05mcn97yorongcp40w7` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKpg4damav6db6a6fh5peylcni5` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `FK23gnfyyutie4dxee1pbby5nfi` FOREIGN KEY (`chat_room_id`) REFERENCES `chat_rooms` (`chat_room_id`),
  ADD CONSTRAINT `FKnily3yln8u34fc4vp2ckniesv` FOREIGN KEY (`sender`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `chat_rooms`
--
ALTER TABLE `chat_rooms`
  ADD CONSTRAINT `FK134cnqavvpcuc5l1x5vg3pc8f` FOREIGN KEY (`user_two`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKin9277aywbjursj2b4e3bmw3s` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKs9o1q56sfhb29ao5qwl2dh9xe` FOREIGN KEY (`user_one`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `chat_room_members`
--
ALTER TABLE `chat_room_members`
  ADD CONSTRAINT `FK6x7kwk21yt5odfxv5ubbrmo0h` FOREIGN KEY (`chat_room_id`) REFERENCES `chat_rooms` (`chat_room_id`),
  ADD CONSTRAINT `FKbemsjj4g0iny4xpkvj5rwj6ab` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `FKqtabsk1bran5vu6akf0t5im81` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKtiuqdledq2lybrds2k3rfqrv4` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `invitations`
--
ALTER TABLE `invitations`
  ADD CONSTRAINT `FKex4qyxxsvv0imcv78b36qg2ng` FOREIGN KEY (`invited_as`) REFERENCES `user_role` (`role_id`),
  ADD CONSTRAINT `FKh67axu8o0vump4ii8d89e2244` FOREIGN KEY (`invited_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `FK2ktjq1slw0ldkuy5rx8fbte2p` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`),
  ADD CONSTRAINT `FK3ir6n13njkrg669t3igyk4s7j` FOREIGN KEY (`sender`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FK3ylay2wp5j90aoi1j7jtc9vxc` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`),
  ADD CONSTRAINT `FK599539lym3mnkbqks0u806eac` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `FK5ke2wwe92aixvisnkqvfrxb1c` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FK6fpt82588ru8v0imso3v8nan7` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  ADD CONSTRAINT `FKamgipnxddhwtkhlp3pl4vwy9v` FOREIGN KEY (`who`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKb24vbsa4ex6lv6bflt27mdbwo` FOREIGN KEY (`receiver`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKbcf20g9dpb11baeys7v4x337q` FOREIGN KEY (`vote_id`) REFERENCES `votes` (`vote_id`),
  ADD CONSTRAINT `FKiipbedgxt4856we8fgcaf5rvg` FOREIGN KEY (`privacy_id`) REFERENCES `privacy_level` (`privacy_id`),
  ADD CONSTRAINT `FKoabmk0oi6lx0x9gtbk43q1whq` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`blog_id`);

--
-- Constraints for table `organizations`
--
ALTER TABLE `organizations`
  ADD CONSTRAINT `FK3x7xa8km09wmd5mgdhquhm8xq` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `FK70f50cqfiyp9w8qi5fgikvsxd` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`plan_id`),
  ADD CONSTRAINT `FKef0yupohx30lw61gr8n57jlr0` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `pins`
--
ALTER TABLE `pins`
  ADD CONSTRAINT `FKjtdqg04rdo7uq71d7kwrwgoxl` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `plans`
--
ALTER TABLE `plans`
  ADD CONSTRAINT `FKtek3yglvdpqcwm3nf8570k8rv` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `FK5lidm6cqbc7u4xhqpxm898qme` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKdor22mv7c8vs14e9cwmgxmn7o` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKdq6juqo0pj8om309r82rpthig` FOREIGN KEY (`shared_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKomb4kyhve4sfj149qo0xu8a03` FOREIGN KEY (`privacy_id`) REFERENCES `privacy_level` (`privacy_id`);

--
-- Constraints for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `FKaawaqxjs3br8dw5v90w7uu514` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `FKsnxoecngu89u3fh4wdrgf0f2g` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `post_files`
--
ALTER TABLE `post_files`
  ADD CONSTRAINT `FK8xc9ew2bxk7axrmc9epq40v2h` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`);

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `FKa5wxsgl4doibhbed9gm7ikie2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `FKkgau5n0nlewg6o9lr4yibqgxj` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `post_sharing`
--
ALTER TABLE `post_sharing`
  ADD CONSTRAINT `FK64hdyipj7n00vv46pos2yagbv` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKpflkmsu7k1o4vfpvdxphmfbj3` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`);

--
-- Constraints for table `priority`
--
ALTER TABLE `priority`
  ADD CONSTRAINT `FKdi4eibr7r4w8pe7oissahgt2f` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKgbnak2anvilhy4vg4ji6t6n4k` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `FK3gwrleyyq6prcnqekmkobbimd` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKfg1kfdnypbpllnpvlqbao6nen` FOREIGN KEY (`client`) REFERENCES `clients` (`client_id`),
  ADD CONSTRAINT `FKhswfwa3ga88vxv1pmboss6jhm` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKmqih0928bq6r3gbuh47giq8w` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`),
  ADD CONSTRAINT `FKnlyte1pyv1mh64xi0cnekidhy` FOREIGN KEY (`status`) REFERENCES `status` (`status_tag`),
  ADD CONSTRAINT `FKpe4hrjaqqbcydvs54el28uq93` FOREIGN KEY (`manager`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `project_comments`
--
ALTER TABLE `project_comments`
  ADD CONSTRAINT `FKfsk4ll3g13rwc631iwek1vmj5` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  ADD CONSTRAINT `FKhfovv2g0k4e98sp5g8mqwg9pg` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `project_milestones`
--
ALTER TABLE `project_milestones`
  ADD CONSTRAINT `FKf89i5mou2qk96lrjgb8of4mdq` FOREIGN KEY (`project_id`) REFERENCES `projects` (`project_id`),
  ADD CONSTRAINT `FKob71jvbh29ddq6yo6cowy7mdo` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKqsyt4knrqbiyv6cmo45vgaao9` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKrgfn9lp5wx8utu1uole5ngjf` FOREIGN KEY (`status`) REFERENCES `status` (`status_tag`);

--
-- Constraints for table `status`
--
ALTER TABLE `status`
  ADD CONSTRAINT `FK41pnbjmhlw8pvggq86inm7le` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKj9suwfa0uf392mb37dg1qi1ja` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `talk_hives`
--
ALTER TABLE `talk_hives`
  ADD CONSTRAINT `FKee79s8s2rjytr254sor1h3x69` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`),
  ADD CONSTRAINT `FKkyfw45xnpmg7psa5m91g9pi2v` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKoxp9c1m1dh7eofbmslou7luih` FOREIGN KEY (`invited_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKry2dtsv7n76c6jdr73l9db9yp` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `FK6032xboy0vhwuey4n7sx5ec8q` FOREIGN KEY (`project_milestone_id`) REFERENCES `project_milestones` (`project_milestone_id`),
  ADD CONSTRAINT `FK636bkwxctg5ga3ttchmqgcqth` FOREIGN KEY (`priority`) REFERENCES `priority` (`priority_tag`),
  ADD CONSTRAINT `FK6s1ob9k4ihi75xbxe2w0ylsdh` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FK75spb8vjkba9g75smsk95lbsx` FOREIGN KEY (`status`) REFERENCES `status` (`status_tag`),
  ADD CONSTRAINT `FKgr44qo7c9sk5xqirvqwkdnd25` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `task_members`
--
ALTER TABLE `task_members`
  ADD CONSTRAINT `FK4doycdgws5rexgg71afo0pixa` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKdt52vbqd7of6qsw8rcjtliihk` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`task_id`),
  ADD CONSTRAINT `FKrl3dwc1wr947g91sbvnk7i053` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `FK5i52bhmm0nbq6lrbur63anlmc` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKab9ipjw80vbpjketttof4lnq1` FOREIGN KEY (`team_leader`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKlm88j38y90erf2rum00e85gw8` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `FKee8x7x5026imwmma9kndkxs36` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKtgca08el3ofisywcf11f0f76t` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK17herqt2to4hyl5q5r5ogbxk9` FOREIGN KEY (`image_id`) REFERENCES `images` (`image_id`),
  ADD CONSTRAINT `FKfmrml2a622f39ylokwcx9oi36` FOREIGN KEY (`user_role`) REFERENCES `user_role` (`role_id`),
  ADD CONSTRAINT `FKqpugllwvyv37klq7ft9m8aqxk` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD CONSTRAINT `FK3m4ykocn4cydicpt842gy04lj` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `FK6rxfhwypn5bcna20leny2mebd` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`),
  ADD CONSTRAINT `FKs41is1raa3f0y5q5g0pw2rfd4` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `FKli4uj3ic2vypf5pialchj925e` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKolv9no5c48keylidna7dv9oov` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`);

--
-- Constraints for table `vote_comments`
--
ALTER TABLE `vote_comments`
  ADD CONSTRAINT `FKk4qxe066j0r1ayt7avjjc7bkc` FOREIGN KEY (`vote_id`) REFERENCES `votes` (`vote_id`),
  ADD CONSTRAINT `FKqlw3wk2rdxueinahf91ohw3nt` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `vote_likes`
--
ALTER TABLE `vote_likes`
  ADD CONSTRAINT `FK3a4ii5y2e2pelm4gh5e69tw1t` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FKj4mbfe9bla2h3toutrfah5cve` FOREIGN KEY (`vote_id`) REFERENCES `votes` (`vote_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
