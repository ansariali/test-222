package com.ls.TalkHives.dto.postController;

import com.ls.TalkHives.dto.common.FileEntity;
import com.ls.TalkHives.dto.common.FileListEntity;
import com.ls.TalkHives.dto.common.PrivacyLevelEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import org.apache.catalina.User;

import java.util.List;

public class CreatePostRequest {
    private String title;
    private String message;
    private String info;
    private String privacyTag;
    private List<FileEntity> files;
    private List<UserInfo> specificUsers;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getPrivacyTag() {
        return privacyTag;
    }

    public void setPrivacyTag(String privacyTag) {
        this.privacyTag = privacyTag;
    }

    public List<FileEntity> getFiles() {
        return files;
    }

    public void setFiles(List<FileEntity> files) {
        this.files = files;
    }

    public List<UserInfo> getSpecificUsers() {
        return specificUsers;
    }

    public void setSpecificUsers(List<UserInfo> specificUsers) {
        this.specificUsers = specificUsers;
    }
}