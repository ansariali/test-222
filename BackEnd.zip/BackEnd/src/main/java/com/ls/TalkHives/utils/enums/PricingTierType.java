package com.ls.TalkHives.utils.enums;

public enum PricingTierType {

    NONE("NONE"), FREE_TIER("FREE-TIER"), PROFESSIONAL("PROFESSIONAL-TIER"), PREMIUM("PREMIUM-TIER");

    private final String pricingTierType;

    PricingTierType(String pricingTierType) {
        this.pricingTierType = pricingTierType;
    }

    public String getPricingTierType() {
        return pricingTierType;
    }
}
