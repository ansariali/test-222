package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.MeetingEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.MeetingMembers;
import com.ls.TalkHives.entities.Meetings;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public abstract class MeetingServiceImplHandler extends UniversalService {

    // Activity Action
    private void activityAction(String activityTag, Meetings meetings, Users users) {
        if (activityTag.equals(Activity.CREATE_MEETING.getActivity())) {
            meetings.setMeetingTag(getMeetingTag(users));
        }

        if (activityTag.equals(Activity.DELETE_MEETING.getActivity())) {
            users.setDeletedMeeting(users.getDeletedMeeting() + 1);
            users.getOrganizations().setDeletedMeeting(users.getOrganizations().getDeletedMeeting() + 1);
        }
    }

    // Create, Delete Meeting
    protected WsResponse sendMeeting(String activityTag, Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, meetings, users);

        // Send Meeting
        WsResponse wsResponse = sendMeetingToUser(activityTag, meetings, users, iDao);

        // Send Notification
        notifyTopLevel(activityTag, meetings, users, iDao);

        if (activityTag.equals(Activity.CREATE_MEETING.getActivity())) {
            // notifyMeetingLeader(meetings, users, iDao);
            notifyMeetingMembers(activityTag, meetings.getMembers(), meetings, users, iDao);
        }

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.MEETING, wsResponse.getActivityTag(), users, iDao);

        Activity activity = Activity.valueOf(activityTag);
        switch (activity) {
            case CREATE_MEETING:
                eventService.create(wsResponse, iDao);
                break;
            case DELETE_MEETING:
                eventService.delete(wsResponse, iDao);
                break;
        }

        return wsResponse;
    }

    // Update Meeting
    protected WsResponse sendMeeting(Boolean resetEvent, List<MeetingMembers> removedMember, HashSet<MeetingMembers> members, Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        String activityTag = Activity.UPDATE_MEETING.getActivity();

        // Send Meeting To Removed Member
        for (MeetingMembers meetingMembers : removedMember) {
            iDao.delete(meetingMembers);
            if (!hasAccess(2, meetingMembers.getUsers())) {
                sendActivity(Ascii.USER, meetingMembers.getUsers().getUserId().toString(), meetings.getMeetingId(), Ascii.MEETING, Activity.DELETE_MEETING.getActivity(), modelMapper.map(meetings, MeetingEntity.class));
            }
        }

        // Send Meeting To Member
        WsResponse wsResponse = sendMeetingToUser(activityTag, meetings, users, iDao);

        // Send Notification
        notifyTopLevel(activityTag, meetings, users, iDao);
        notifyMeetingMembers(activityTag, members, meetings, users, iDao);

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.MEETING, wsResponse.getActivityTag(), users, iDao);

        if (resetEvent) {
            eventService.update(wsResponse, iDao);
        }

        return wsResponse;
    }

    protected WsResponse sendMeetingToUser(String activityTag, Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        MeetingEntity meetingEntity = modelMapper.map(meetings, MeetingEntity.class);

        // getTopLevel People
        List<Users> list = getTopLevelPeople(users, iDao);

        // add Meeting Members
        for (MeetingMembers meetingMembers : meetings.getMembers()) {
            if (!list.contains(meetingMembers.getUsers())) {
                list.add(meetingMembers.getUsers());
            }
        }

        // Get rid of Duplicate
        Set<Users> list_ = new HashSet<>(list);

        WsResponse wsResponse = new WsResponse();
        // Send Meeting
        for (Users users_ : list_) {
            wsResponse = sendActivity(Ascii.USER, users_.getUserId().toString(), meetings.getMeetingId(), Ascii.MEETING, activityTag, meetingEntity);
        }

        return wsResponse;
    }

    private void notifyTopLevel(String activityTag, Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, meeting = meetings.getTitle();

        List<Users> list = getTopLevelPeople(users, iDao);

        if (list.contains(users)) {
            list.remove(users);
        }

        for (Users user_ : list) {
            user = setFullName(users);
            message = Notification.valueOf(activityTag).getCustomMessage()
                    .replace("{user}", user)
                    .replace("{meeting}", meeting);
            notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(), Boolean.FALSE, message, user_, users, iDao);
        }
    }

   /* protected void notifyMeetingCreator(Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, meeting = meetings.getTitle();

        if (meetings.getUsers().equals(users)) {
            user = "You";
            message = Notification.MEETING_LEADER.getSelfMessage()
                    .replace("{user}", user)
                    .replace("{meeting}", meeting);
            notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(), Boolean.TRUE, message, meetings.getMeetingLeader(), users, iDao);
        } else {
            user = users.getFirstName() + " " + users.getLastName();
            message = Notification.MEETING_LEADER.getPublicMessage()
                    .replace("{user}", user)
                    .replace("{meeting}", meeting);
            notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(), Boolean.FALSE, message, meetings.getMeetingLeader(), users, iDao);
        }
    }*/

    private void notifyMeetingMember(String activityTag, Meetings meetings, Users meetingMember, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, meeting = meetings.getTitle();

        if (meetingMember.equals(users)) {
            user = "You";
            message = Notification.valueOf(activityTag).getSelfMessage()
                    .replace("{user}", user)
                    .replace("{meeting}", meeting);
        } else {
            user = setFullName(users);
            message = Notification.valueOf(activityTag).getPublicMessage()
                    .replace("{user}", user)
                    .replace("{meeting}", meeting);
        }

        notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(), Boolean.FALSE, message, meetingMember, users, iDao);
    }

    protected void notifyMeetingMembers(String activity, Set<MeetingMembers> list, Meetings meetings, Users users, IDao<IEntity, Serializable> iDao) {
        for (MeetingMembers meetingMembers : list) {
            notifyMeetingMember(activity, meetings, meetingMembers.getUsers(), users, iDao);
        }
    }
}
