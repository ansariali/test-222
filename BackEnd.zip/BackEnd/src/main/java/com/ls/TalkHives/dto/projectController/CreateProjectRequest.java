package com.ls.TalkHives.dto.projectController;

import com.ls.TalkHives.dto.common.ClientEntity;
import com.ls.TalkHives.dto.common.TeamEntity;
import com.ls.TalkHives.dto.common.UserInfo;

import java.util.Date;
import java.util.List;

public class CreateProjectRequest {
    private String name;
    private String info;
    private Date initialDate;
    private Date deadline;

    private UserInfo manager;
    private ClientEntity client;
    private TeamEntity team;

    private List<CreateProjectMilestoneRequest> milestones;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public UserInfo getManager() {
        return manager;
    }

    public void setManager(UserInfo manager) {
        this.manager = manager;
    }

    public ClientEntity getClient() {
        return client;
    }

    public void setClient(ClientEntity client) {
        this.client = client;
    }

    public TeamEntity getTeam() {
        return team;
    }

    public void setTeam(TeamEntity team) {
        this.team = team;
    }

    public List<CreateProjectMilestoneRequest> getMilestones() {
        return milestones;
    }

    public void setMilestones(List<CreateProjectMilestoneRequest> milestones) {
        this.milestones = milestones;
    }
}
