package com.ls.TalkHives.dto.meetingController;

import com.ls.TalkHives.dto.common.MeetingEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllMeetings {

    private List<MeetingEntity> meetings = new ArrayList<>();

    public List<MeetingEntity> getMeetings() {
        return meetings;
    }

    public void setMeetings(List<MeetingEntity> meetings) {
        this.meetings = meetings;
    }
}
