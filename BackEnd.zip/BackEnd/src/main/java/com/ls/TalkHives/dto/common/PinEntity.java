package com.ls.TalkHives.dto.common;

import java.util.Date;

public class PinEntity {
    private Long pinId;
    private String pinTag;
    private String title;
    private String message;
    private Date createdAt;

    public Long getPinId() {
        return pinId;
    }

    public void setPinId(Long pinId) {
        this.pinId = pinId;
    }

    public String getPinTag() {
        return pinTag;
    }

    public void setPinTag(String pinTag) {
        this.pinTag = pinTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
