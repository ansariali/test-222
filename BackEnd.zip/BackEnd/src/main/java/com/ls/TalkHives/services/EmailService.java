package com.ls.TalkHives.services;

public interface EmailService {
    Boolean sendNewMail(String to, String message);

    Boolean welcomeMail(String to, String firstName, String organizationName);

    Boolean sendInvitationMail(String to, String personName, String organizationName, String invitedBy, String token);
}