package com.ls.TalkHives.dto.common;

public class PriorityEntity {
    private Long priorityTag;
    private String title;

    public Long getPriorityTag() {
        return priorityTag;
    }

    public void setPriorityTag(Long priorityTag) {
        this.priorityTag = priorityTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
