package com.ls.TalkHives.dto.postController;

import com.ls.TalkHives.dto.common.FileEntity;
import com.ls.TalkHives.dto.common.PostEntity;
import com.ls.TalkHives.dto.common.PrivacyLevelEntity;

import java.util.Date;
import java.util.List;

public class UpdatePostRequest {
    private Long postId;

    private String postTag;
    private String title;
    private String message;
    private String info;
    private Boolean shared;

    private List<FileEntity> files;
    private PrivacyLevelEntity privacy;

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getPostTag() {
        return postTag;
    }

    public void setPostTag(String postTag) {
        this.postTag = postTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Boolean getShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

    public List<FileEntity> getFiles() {
        return files;
    }

    public void setFiles(List<FileEntity> files) {
        this.files = files;
    }

    public PrivacyLevelEntity getPrivacy() {
        return privacy;
    }

    public void setPrivacy(PrivacyLevelEntity privacy) {
        this.privacy = privacy;
    }
}
