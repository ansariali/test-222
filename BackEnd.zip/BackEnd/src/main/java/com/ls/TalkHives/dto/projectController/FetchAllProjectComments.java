package com.ls.TalkHives.dto.projectController;

import com.ls.TalkHives.dto.common.ProjectCommentEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllProjectComments {

    private List<ProjectCommentEntity> projectComments = new ArrayList<>();

    public List<ProjectCommentEntity> getProjectComments() {
        return projectComments;
    }

    public void setProjectComments(List<ProjectCommentEntity> projectComments) {
        this.projectComments = projectComments;
    }
}
