package com.ls.TalkHives.dto.projectController;

import java.util.Date;

public class CreateProjectCommentRequest {
    private Long projectId;
    private String message;

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
