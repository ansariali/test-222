package com.ls.TalkHives.utils.enums;

public enum CurrencyType {

    INR("INR"), EURO("EURO"), USD("USD"), GBP("GBP"), AUD("AUD"),  HKD("HKD"), SWISS_FRANC("Swiss Franc"), YEN("yen"),OTHER("Other");

    private final String currencyType;

    CurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public String getCurrencyType() {
        return currencyType;
    }
}