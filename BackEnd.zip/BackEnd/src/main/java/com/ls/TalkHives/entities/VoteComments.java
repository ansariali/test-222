package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * VoteComments Entity
 */

@Entity
@Table(name = "vote_comments")
public class VoteComments extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long voteCommentId;

    private String voteCommentTag;
    private String message;
    private String info;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "voteId")
    private Votes votes;

    public Long getVoteCommentId() {
        return voteCommentId;
    }

    public void setVoteCommentId(Long voteCommentId) {
        this.voteCommentId = voteCommentId;
    }

    public String getVoteCommentTag() {
        return voteCommentTag;
    }

    public void setVoteCommentTag(String voteCommentTag) {
        this.voteCommentTag = voteCommentTag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Votes getVotes() {
        return votes;
    }

    public void setVotes(Votes votes) {
        this.votes = votes;
    }
}



