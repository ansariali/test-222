package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.UserInfo;

import java.util.ArrayList;
import java.util.List;

public class FetchAllUsersInfo {

    private List<UserInfo> users = new ArrayList<>();

    public List<UserInfo> getUsers() {
        return users;
    }

    public void setUsers(List<UserInfo> users) {
        this.users = users;
    }
}
