package com.ls.TalkHives.controllers;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ls.TalkHives.dto.newController.*;
import com.ls.TalkHives.entities.NewEntity;
import com.ls.TalkHives.entities.User;
import com.ls.TalkHives.services.NewService;
import com.ls.TalkHives.services.S3StorageService;
import com.ls.TalkHives.services.UserServices;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

// import com.ls.TalkHives.services.UserServices;

@CrossOrigin
@RestController
@RequestMapping("/newController")
public class NewController extends UniversalController /*implements ErrorController*/ {

    public static final String ACCOUNT_SID = "AC45da9e385584e10d7760480728cfa56b";
    public static final String AUTH_TOKEN = "ad2e7630ec23c0eb2c3dd99e7875dc5c";

    private static final String TAG = NewController.class.getSimpleName();

    //    private static final String PATH = "/error";
    //
    //    @RequestMapping(value = PATH)
    //    public String error() {
    //        return "Error handling";
    //    }
    //
    //    @Override
    //    public String getErrorPath() {
    //        return PATH;
    //    }
    List<String> files = new ArrayList<String>();
    @Autowired
    private NewService newService;

    // @Autowired
    // protected TransferManager transferManager;
    @Autowired
    private S3StorageService s3StorageService;
    @Autowired
    private AmazonS3 amazonS3;

    @Value("${jsa.s3.bucket}")
    private String bucketName;

    ////
    // S3Object s3object = s3Client.getObject(new GetObjectRequest(bucketName, fileName));

    //
    // String downloadUrl = s3object.getObjectContent().getHttpRequest().getURI().toString();
    //                         System.out.println("downloadUrl>>" + downloadUrl);

    // this is the login api/service

    @Autowired
    private UserServices userServices;

    /**
     * This method first deletes all the files in given folder and than the
     * folder itself
     */
    public static void deleteFolder(String bucketName, String folderName, AmazonS3 client) {
        // List fileList = client.listObjects(bucketName, folderName).getObjectSummaries();

        for (S3ObjectSummary file : client.listObjects(bucketName, folderName).getObjectSummaries()) {
            client.deleteObject(bucketName, file.getKey());
        }
        client.deleteObject(bucketName, folderName);
    }

    public static void getFolder(String bucketName, String folderName, AmazonS3 client) {
        // List fileList = client.listObjects(bucketName, folderName).getObjectSummaries();

        // for (Bucket bucket : .listBuckets()) {
        //     System.out.println(" - " + bucket.getName());
        // }
    }

    @CrossOrigin
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity<?> createUser(@RequestBody User newUser) {
        if (userServices.find(newUser.getUserName()) != null) {
            logger.error(TAG, "username Already exist " + newUser.getUserName());
            return new ResponseEntity(
                    "user with username " + newUser.getUserName() + "already exist ",
                    HttpStatus.CONFLICT);
        }
        newUser.setRole("USER");

        return new ResponseEntity<User>(userServices.save(newUser), HttpStatus.CREATED);
    }

    @CrossOrigin
    @RequestMapping("/login")
    public Principal user(Principal principal) {
        logger.info(TAG, "user logged " + principal);
        // logger.info(TAG, "user logged " + principal.getName());
        return principal;
    }

    @GetMapping("/getFile")
    public String getFile(@RequestParam String folderName) {

        String fileUrl = "";
        try {

            logger.info(TAG, "Oii khajur: " + bucketName);

            s3StorageService.findItem(folderName);


            logger.info(TAG, "Oii khajur: " + bucketName);


            // for (Bucket bucket : amazonS3.listBuckets()) {

            // amazonS3.listObjects(bucketName)..equals("folder1");
            // amazonS3.listObjects("logbids");
            // logger.info(TAG, "bucket.getName():  " + bucket.getName());

            // if (bucket.getName().equals(bucketName)) {

            // for (S3ObjectSummary s3ObjectSummary : amazonS3.listObjects(bucketName).getObjectSummaries()) {
            //     logger.info(TAG, "s3ObjectSummary:  " + s3ObjectSummary.getKey());
            //
            //     if (s3ObjectSummary.getKey().equals("TalkHives/")) {
            //         logger.info(TAG, "TalkHives malyu:  " + s3ObjectSummary.getKey());
            //     }
            // }
            // System.out.println(" - " + bucket.getName());
            // logger.info(TAG, "bucket.getName().equals 1:  " + amazonS3.listObjects(bucketName).equals("folder1"));
            // logger.info(TAG, "bucket.getName().equals 1:  " + amazonS3.listObjects(bucketName).equals("logbids"));
            // logger.info(TAG, "bucket.getName().equals 2:  " + bucket.getName().equals("logbids"));
            // }


            // }


            logger.info(TAG, "Oii khajur: " + bucketName);
            // S3Object s3object = amazonS3.getObject(new GetObjectRequest(bucketName, "1518089314056-images.png"));

            //
            // String downloadUrl = s3object.getObjectContent().getHttpRequest().getURI().toString();
            // System.out.println("downloadUrl>>" + downloadUrl);
            // _file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileUrl;
    }

    /*public static void createFolder(String bucketName, String folderName, AmazonS3 client) {
        // create meta-data for your folder and set content-length to 0
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(0);
        // create empty content
        InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
        // create a PutObjectRequest passing the folder name suffixed by /
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
                folderName + "/", emptyContent, metadata);
        // send request to S3 to create folder
        client.putObject(putObjectRequest);
    }
*/

    @GetMapping("/deleteFile")
    public String deleteFile() {

        String fileUrl = "";
        try {
            s3StorageService.deleteFile("1518175071960-images.png");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileUrl;
    }

    @PostMapping("/uploadFile")
    public String uploadFile() {

        String fileUrl = "";
        try {

            // logger.info(TAG, "Oii khajur: " + multipartFile.getOriginalFilename());
            // logger.info(TAG, "Oii khajur: " + multipartFile);

            s3StorageService.createFolder("TalkHives");
            // File _file = convertMultiPartToFile(multipartFile);
            // String fileName = generateFileKey(multipartFile);
            // amazonS3.putObject(new PutObjectRequest(bucketName, fileName, _file));
            // S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, fileName));
            // String downloadUrl = s3Object.getObjectContent().getHttpRequest().getURI().toString();
            // logger.info(TAG, "Oii khajur: " + bucketName);


            // amazonS3.deleteObject(bucketName, "1518175783697-1_(3).png");


            // createFolder(bucketName, "folder1", amazonS3);
            // deleteFolder(bucketName, "folder1", amazonS3);

            /*for (Bucket bucket : amazonS3.listBuckets()) {

                // amazonS3.listObjects(bucketName)..equals("folder1");
                // amazonS3.listObjects("logbids");


                if(bucket.getName().equals(bucketName)){

                    for (S3ObjectSummary s3ObjectSummary : amazonS3.listObjects(bucketName).getObjectSummaries()) {
                        logger.info(TAG, "s3ObjectSummary:  " + s3ObjectSummary.getStorageClass());
                    }
                    System.out.println(" - " + bucket.getName());
                    // logger.info(TAG, "bucket.getName().equals 1:  " + amazonS3.listObjects(bucketName).equals("folder1"));
                    // logger.info(TAG, "bucket.getName().equals 1:  " + amazonS3.listObjects(bucketName).equals("logbids"));
                    // logger.info(TAG, "bucket.getName().equals 2:  " + bucket.getName().equals("logbids"));
                }


            }*/


            // logger.info(TAG, "Oii khajur: " + bucketName);
            // File _file = convertMultiPartToFile(multipartFile);
            // String fileName = generateFileKey(multipartFile);
            // fileUrl = bucketName + "/" + fileName;
            // uploadFileTos3bucket(fileName, _file);
            // getFileFroms3bucket(fileName);
            // _file.delete();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileUrl;
    }


    /*private File convertMultiPartToFile(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }*/

    /*private String generateFileKey(MultipartFile multiPart) {
        return new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
    }*/

    /*private void uploadFileTos3bucket(String fileName, File file) {
        logger.info(TAG, "s3Config.s3client(): " + fileName);
        logger.info(TAG, "fileName: " + fileName);
        logger.info(TAG, "file: " + file);
        final PutObjectRequest request = new PutObjectRequest(bucketName, fileName, file);

        logger.info(TAG, "fileName: " + fileName);
        logger.info(TAG, "file: " + file);

        // transferManager.upload(request);

        S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, fileName));
        String downloadUrl = s3Object.getObjectContent().getHttpRequest().getURI().toString();

        logger.info(TAG, "downloadUrl: " + downloadUrl);

    }*/

    /*private void getFileFroms3bucket(String fileName) {
        logger.info(TAG, "bucketName: " + bucketName);
        logger.info(TAG, "fileName: " + fileName);

        S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, fileName));
        String downloadUrl = s3Object.getObjectContent().getHttpRequest().getURI().toString();

        logger.info(TAG, "downloadUrl: " + downloadUrl);
        //
        // String downloadUrl = s3object.getObjectContent().getHttpRequest().getURI().toString();
        // System.out.println("downloadUrl>>" + downloadUrl);

    }*/

    @ApiOperation(value = "Verify new method")
    @GetMapping(value = "/1/new")
    public ResponseEntity<UniversalResponse> newMethod(Principal _principal, HttpServletRequest request) {
        logger.info(TAG, "Inside /new");

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        logger.info(TAG, "auth: " + auth.getPrincipal());
        logger.info(TAG, "auth.getName: " + auth.getName());


        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof UserDetails) {
            String username = ((UserDetails) principal).getUsername();
            logger.info(TAG, "if username: " + username);
        } else {
            String username = principal.toString();
            logger.info(TAG, "else username: " + username);
        }

        // logger.info(TAG, "principal: " + principal.getName());


        // Principal principal = request.getUserPrincipal();

        // logger.info(TAG, "_principal: " + _principal);
        // logger.info(TAG, "_principal.getName(): " + _principal.getName());
        // logger.info(TAG, "_principal.toString(): " + _principal.toString());
        // logger.info(TAG, "principal: " + principal);
        // logger.info(TAG, "principal: " + principal.getName());
        return new ResponseEntity<>(new UniversalResponse(true, "Hello, I'm TalkHives."), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Create record")
    @PostMapping(value = "/v1/create")
    public ResponseEntity<CreateNewResponse> createNewRecord(@RequestBody CreateNewRequest createNewRequest) {
        logger.info(TAG, "Inside createNewRecord");

        NewEntity req = modelMapper.map(createNewRequest, NewEntity.class);
        CreateNewResponse res = modelMapper.map(newService.create_v1(req, iDao), CreateNewResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Fetch record")
    @GetMapping(value = "/v1/fetch/{newId}")
    public ResponseEntity<FetchNewResponse> fetchRecord(@PathVariable Long newId) {
        logger.info(TAG, "Inside fetchRecord");

        FetchNewResponse res = modelMapper.map(newService.fetch_v1(newId, iDao), FetchNewResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Fetch all record")
    @GetMapping(value = "/v1/fetch/all")
    public ResponseEntity<FetchAllNewResponse> fetchAllRecord() {
        logger.info(TAG, "Inside fetchAllRecord");

        FetchAllNewResponse res = modelMapper.map(newService.fetchAll_v1(iDao), FetchAllNewResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Update record")
    @PutMapping(value = "/v1/update/{newId}")
    public ResponseEntity<CreateNewResponse> updateRecord(@PathVariable Long newId, @RequestBody UpdateNewRequest updateNewRequest) {
        logger.info(TAG, "Inside updateRecord");

        NewEntity req = modelMapper.map(updateNewRequest, NewEntity.class);
        CreateNewResponse res = modelMapper.map(newService.update_v1(newId, req, iDao), CreateNewResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Deleted record")
    @DeleteMapping(value = "/v1/delete/{newId}")
    public ResponseEntity<UniversalResponse> deleteRecord(@PathVariable Long newId) {
        logger.info(TAG, "Inside deleteRecord");

        UniversalResponse res = modelMapper.map(newService.delete_v1(newId, iDao), UniversalResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }


    @ApiOperation(value = "Send sms")
    @GetMapping(value = "/v1/sms/{newId}")
    public ResponseEntity<?> sendSms(@PathVariable Long newId) {
        logger.info(TAG, "Inside sendSms");
        // Find your Account Sid and Auth Token at twilio.com/console

        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        System.out.println("ACCOUNT_SID   :"+ACCOUNT_SID);
        System.out.println("AUTH_TOKEN   :"+AUTH_TOKEN);


        Message message = Message
                .creator(new PhoneNumber("+919173302557"), // to
                        new PhoneNumber("+14252797443"), // from
                        "Send By TalkHives")
                .create();

        System.out.println("Message   :"+message.getSid());

        return new ResponseEntity<>(newId, responseHeaders, HttpStatus.OK);

    }
}