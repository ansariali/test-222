package com.ls.TalkHives.services.impl;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import com.ls.TalkHives.services.S3StorageService;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.ideal.UniversalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

@SuppressWarnings("deprecation")
@Component
public class S3StorageServiceImpl extends UniversalService implements S3StorageService {

    private static final String TAG = S3StorageServiceImpl.class.getSimpleName();

    @Autowired
    private AmazonS3 amazonS3;

    @Value("${jsa.s3.bucket}")
    private String bucketName;

    @Value("${jsa.s3.mainKey}")
    private String mainKey;

    @Override
    public String uploadFile(String prefix, MultipartFile multipartFile) throws IOException {
        File file = convertMultiPartToFile(multipartFile);
        String fileKey = generateFileKey(prefix, multipartFile);

        amazonS3.putObject(new PutObjectRequest(bucketName, fileKey, file));
        file.delete();

        return fileKey;
    }

    @Override
    public String getItem(String fileUrl) {
        S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, mainKey + fileUrl));

        return s3Object.getObjectContent().getHttpRequest().getURI().toString();
    }

    @Override
    public boolean findItem(String fileUrl) {
        S3Object object = amazonS3.getObject(bucketName, mainKey + fileUrl);

        return object == null;
    }

    @Override
    public File convertMultiPartToFile(MultipartFile file) throws IOException {
        File _file = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(_file);
        fos.write(file.getBytes());
        fos.close();
        return _file;
    }

    @Override
    public String generateFileKey(String prefix, MultipartFile multipartFile) {
        return mainKey + prefix + S3Storage.DASH.getValue() + multipartFile.getOriginalFilename().replace(S3Storage.SPACE.getValue(), S3Storage.UNDER_SCORE.getValue());
    }

    @Override
    public String copyFile(String fileNameWithPrefix, String fileUrl) {
        String _fileUrl = fileUrl.replace(S3Storage.BUCKET_URL.getValue(), S3Storage.BLANK.getValue());

        logger.info(TAG, "_fileUrl: " + _fileUrl);
        CopyObjectRequest copyObjectRequest = new CopyObjectRequest(bucketName, _fileUrl, bucketName, mainKey + fileNameWithPrefix);
        amazonS3.copyObject(copyObjectRequest);

        S3Object s3Object = amazonS3.getObject(new GetObjectRequest(bucketName, mainKey + fileNameWithPrefix));

        deleteFile(_fileUrl);

        return s3Object.getObjectContent().getHttpRequest().getURI().toString();
    }

    @Override
    public String deleteFile(String fileUrl) {
        amazonS3.deleteObject(new DeleteObjectRequest(bucketName, fileUrl));
        return "Successfully deleted";
    }

    @Override
    public void createFolder(String folderName) {
        // create meta-data for your folder and set content-length to 0
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(0);
        // create empty content
        InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
        // create a PutObjectRequest passing the folder name suffixed by /
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
                mainKey + folderName + S3Storage.SUFFIX.getValue(), emptyContent, metadata);
        // send request to S3 to create folder
        amazonS3.putObject(putObjectRequest);
    }

    @Override
    public void deleteFolder(String folderName) {
        // List fileList = client.listObjects(bucketName, folderName).getObjectSummaries();

        for (S3ObjectSummary file : amazonS3.listObjects(bucketName, folderName).getObjectSummaries()) {
            amazonS3.deleteObject(bucketName, file.getKey());
        }
        amazonS3.deleteObject(bucketName, folderName);
    }
}