package com.ls.TalkHives.dto.mileStoneController;

import com.ls.TalkHives.dto.projectController.StatusEntity;
import com.ls.TalkHives.dto.projectController.fetchProject;

import java.util.Date;
import java.util.List;

public class MileStoneEntity {
    private Long projectMilestoneId;
    private String name;
    private String info;
    private Date initialDate;
    private Date deadline;
    private Integer level;
    private Integer totalTask;
    private Double taskPercentage;
    private StatusEntity status;
    private fetchProject projects;
    private List<FetchTask> tasks;

    public Long getProjectMilestoneId() {
        return projectMilestoneId;
    }

    public void setProjectMilestoneId(Long projectMilestoneId) {
        this.projectMilestoneId = projectMilestoneId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public fetchProject getProjects() {
        return projects;
    }

    public void setProjects(fetchProject projects) {
        this.projects = projects;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getTotalTask() {
        return totalTask;
    }

    public void setTotalTask(Integer totalTask) {
        this.totalTask = totalTask;
    }

    public Double getTaskPercentage() {
        return taskPercentage;
    }

    public void setTaskPercentage(Double taskPercentage) {
        this.taskPercentage = taskPercentage;
    }

    public StatusEntity getStatus() {
        return status;
    }

    public void setStatus(StatusEntity status) {
        this.status = status;
    }

    public List<FetchTask> getTasks() {
        return tasks;
    }

    public void setTasks(List<FetchTask> tasks) {
        this.tasks = tasks;
    }
}
