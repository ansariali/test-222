package com.ls.TalkHives.dto.blogController;

import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.WsEntity;

public class BlogResponse extends WsEntity {

    private BlogEntity content;

    public BlogEntity getContent() {
        return content;
    }

    public void setContent(BlogEntity content) {
        this.content = content;
    }
}
