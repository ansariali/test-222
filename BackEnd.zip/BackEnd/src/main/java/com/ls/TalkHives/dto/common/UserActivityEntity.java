package com.ls.TalkHives.dto.common;

import java.util.Date;

public class UserActivityEntity extends WsEntity {

    private Long userActivityId;
    private String userActivityTag;
    private String type;
    private String message;
    private String info;
    private Date createdAt;

    public Long getUserActivityId() {
        return userActivityId;
    }

    public void setUserActivityId(Long userActivityId) {
        this.userActivityId = userActivityId;
    }

    public String getUserActivityTag() {
        return userActivityTag;
    }

    public void setUserActivityTag(String userActivityTag) {
        this.userActivityTag = userActivityTag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}