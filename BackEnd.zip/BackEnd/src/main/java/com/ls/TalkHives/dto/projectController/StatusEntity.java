package com.ls.TalkHives.dto.projectController;

public class StatusEntity {
    private Long statusTag;
    private String title;

    public Long getStatusTag() {
        return statusTag;
    }

    public void setStatusTag(Long statusTag) {
        this.statusTag = statusTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
