package com.ls.TalkHives.dto.projectController;

import com.ls.TalkHives.dto.taskController.CreateTaskRequest;

import java.util.Date;
import java.util.List;

public class CreateProjectMilestoneRequest {
    private String name;
    private String info;
    private String level;
    private Date initialDate;
    private Date deadline;
    private List<CreateTaskRequest> tasks;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public List<CreateTaskRequest> getTasks() {
        return tasks;
    }

    public void setTasks(List<CreateTaskRequest> tasks) {
        this.tasks = tasks;
    }
}
