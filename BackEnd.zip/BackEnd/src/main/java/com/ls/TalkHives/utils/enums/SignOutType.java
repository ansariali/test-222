package com.ls.TalkHives.utils.enums;

public enum SignOutType {
    NONE(400), AUTO(1), MANUAL(2);

    private final Integer code;

    SignOutType(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }
}
