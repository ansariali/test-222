package com.ls.TalkHives.services;

import com.ls.TalkHives.entities.NewEntity;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface NewService {
    NewEntity create_v1(NewEntity newEntity, IDao<IEntity, Serializable> dao);

    NewEntity fetch_v1(Long newId, IDao<IEntity, Serializable> dao);

    Map<String, List<NewEntity>> fetchAll_v1(IDao<IEntity, Serializable> dao);

    NewEntity update_v1(Long newId, NewEntity newEntity, IDao<IEntity, Serializable> dao);

    UniversalResponse delete_v1(Long newId, IDao<IEntity, Serializable> dao);
}