package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * PostLikes Entity
 */

@Entity
@Table(name = "post_likes")
public class PostLikes extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long postLikeId;

    private String postLikeTag;
    private Boolean liked;
    private String info;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "postId")
    private Posts posts;

    public Long getPostLikeId() {
        return postLikeId;
    }

    public void setPostLikeId(Long postLikeId) {
        this.postLikeId = postLikeId;
    }

    public String getPostLikeTag() {
        return postLikeTag;
    }

    public void setPostLikeTag(String postLikeTag) {
        this.postLikeTag = postLikeTag;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Posts getPosts() {
        return posts;
    }

    public void setPosts(Posts posts) {
        this.posts = posts;
    }
}



