package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.validator.constraints.Email;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.Date;

/**
 * Users Entity
 */
@Entity
@Table(name = "users")
public class Users extends UniversalEntity implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long userId;

    @NotNull
    @Size(min = 3, max = 30)
    private String firstName;

    @NotNull
    @Size(min = 3, max = 30)
    private String lastName;

    @Column(unique = true)
    @NotNull
    @Size(min = 3, max = 30)
    private String userName;

    @Email
    @NotNull
    @Size(max = 254)
    private String emailId;


    private String password;

    @NotNull
    private String countryCode;

    @NotNull
    private String mobileNo;

    @NotNull
    private String gender;

    private Date birthDay;
    private String hashTag;
    private String designation;
    private String bio;
    private String address;
    private String pinCode;
    private String city;
    private String state;
    private String country;
    private Double latitude;
    private Double longitude;

    private String pinTagPrefix;

    @ColumnDefault("0")
    private Integer totalPin = 0;

    @ColumnDefault("0")
    private Integer deletedPin = 0;

    @ColumnDefault("0")
    private Integer totalBlog = 0;

    @ColumnDefault("0")
    private Integer deletedBlog = 0;

    @ColumnDefault("0")
    private Integer totalClient = 0;

    @ColumnDefault("0")
    private Integer deletedClient = 0;

    @ColumnDefault("0")
    private Integer totalVote = 0;

    @ColumnDefault("0")
    private Integer deletedVote = 0;

    @ColumnDefault("0")
    private Integer totalPost = 0;

    @ColumnDefault("0")
    private Integer deletedPost = 0;

    @ColumnDefault("0")
    private Integer totalTeam = 0;

    @ColumnDefault("0")
    private Integer deletedTeam = 0;

    @ColumnDefault("0")
    private Integer totalProject = 0;

    @ColumnDefault("0")
    private Integer deletedProject = 0;

    @ColumnDefault("0")
    private Integer totalMeeting = 0;

    @ColumnDefault("0")
    private Integer deletedMeeting = 0;

    private String taskTagPrefix;

    @ColumnDefault("0")
    private Integer totalTask = 0;

    @ColumnDefault("0")
    private Integer deletedTask = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "imageId")
    private Images images;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userRole")
    private UserRole userRole;

    public Users() {
    }

    public Users(Users users) {
        this.firstName = users.firstName;
        this.lastName = users.lastName;
        this.userName = users.userName;
        this.emailId = users.emailId;
        this.password = users.password;
        this.countryCode = users.countryCode;
        this.mobileNo = users.mobileNo;
        this.gender = users.gender;
        this.birthDay = users.birthDay;
        this.hashTag = users.hashTag;
        this.designation = users.designation;
        this.bio = users.bio;
        this.address = users.address;
        this.pinCode = users.pinCode;
        this.city = users.city;
        this.state = users.state;
        this.country = users.country;
        this.latitude = users.latitude;
        this.longitude = users.longitude;
        this.pinTagPrefix = users.pinTagPrefix;
        this.totalPin = users.totalPin;
        this.deletedPin = users.deletedPin;
        this.totalBlog = users.totalBlog;
        this.deletedBlog = users.deletedBlog;
        this.totalClient = users.totalClient;
        this.deletedClient = users.deletedClient;
        this.totalVote = users.totalVote;
        this.deletedVote = users.deletedVote;
        this.totalPost = users.totalPost;
        this.deletedPost = users.deletedPost;
        this.totalTeam = users.totalTeam;
        this.deletedTeam = users.deletedTeam;
        this.totalProject = users.totalProject;
        this.deletedProject = users.deletedProject;
        this.totalMeeting = users.totalMeeting;
        this.deletedMeeting = users.deletedMeeting;
        this.taskTagPrefix = users.taskTagPrefix;
        this.totalTask = users.totalTask;
        this.deletedTask = users.deletedTask;
        this.organizations = users.organizations;
        this.images = users.images;
        this.userRole = users.userRole;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getHashTag() {
        return hashTag;
    }

    public void setHashTag(String hashTag) {
        this.hashTag = hashTag;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getPinTagPrefix() {
        return pinTagPrefix;
    }

    public void setPinTagPrefix(String pinTagPrefix) {
        this.pinTagPrefix = pinTagPrefix;
    }

    public Integer getTotalPin() {
        return totalPin;
    }

    public void setTotalPin(Integer totalPin) {
        this.totalPin = totalPin;
    }

    public Integer getDeletedPin() {
        return deletedPin;
    }

    public void setDeletedPin(Integer deletedPin) {
        this.deletedPin = deletedPin;
    }

    public Integer getTotalBlog() {
        return totalBlog;
    }

    public void setTotalBlog(Integer totalBlog) {
        this.totalBlog = totalBlog;
    }

    public Integer getDeletedBlog() {
        return deletedBlog;
    }

    public void setDeletedBlog(Integer deletedBlog) {
        this.deletedBlog = deletedBlog;
    }

    public Integer getTotalClient() {
        return totalClient;
    }

    public void setTotalClient(Integer totalClient) {
        this.totalClient = totalClient;
    }

    public Integer getDeletedClient() {
        return deletedClient;
    }

    public void setDeletedClient(Integer deletedClient) {
        this.deletedClient = deletedClient;
    }

    public Integer getTotalVote() {
        return totalVote;
    }

    public void setTotalVote(Integer totalVote) {
        this.totalVote = totalVote;
    }

    public Integer getDeletedVote() {
        return deletedVote;
    }

    public void setDeletedVote(Integer deletedVote) {
        this.deletedVote = deletedVote;
    }

    public Integer getTotalPost() {
        return totalPost;
    }

    public void setTotalPost(Integer totalPost) {
        this.totalPost = totalPost;
    }

    public Integer getDeletedPost() {
        return deletedPost;
    }

    public void setDeletedPost(Integer deletedPost) {
        this.deletedPost = deletedPost;
    }

    public Integer getTotalTeam() {
        return totalTeam;
    }

    public void setTotalTeam(Integer totalTeam) {
        this.totalTeam = totalTeam;
    }

    public Integer getDeletedTeam() {
        return deletedTeam;
    }

    public void setDeletedTeam(Integer deletedTeam) {
        this.deletedTeam = deletedTeam;
    }

    public Integer getTotalProject() {
        return totalProject;
    }

    public void setTotalProject(Integer totalProject) {
        this.totalProject = totalProject;
    }

    public Integer getDeletedProject() {
        return deletedProject;
    }

    public void setDeletedProject(Integer deletedProject) {
        this.deletedProject = deletedProject;
    }

    public Integer getTotalMeeting() {
        return totalMeeting;
    }

    public void setTotalMeeting(Integer totalMeeting) {
        this.totalMeeting = totalMeeting;
    }

    public Integer getDeletedMeeting() {
        return deletedMeeting;
    }

    public void setDeletedMeeting(Integer deletedMeeting) {
        this.deletedMeeting = deletedMeeting;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Images getImages() {
        return images;
    }

    public void setImages(Images images) {
        this.images = images;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    public String getTaskTagPrefix() {
        return taskTagPrefix;
    }

    public void setTaskTagPrefix(String taskTagPrefix) {
        this.taskTagPrefix = taskTagPrefix;
    }

    public Integer getTotalTask() {
        return totalTask;
    }

    public void setTotalTask(Integer totalTask) {
        this.totalTask = totalTask;
    }

    public Integer getDeletedTask() {
        return deletedTask;
    }

    public void setDeletedTask(Integer deletedTask) {
        this.deletedTask = deletedTask;
    }
}