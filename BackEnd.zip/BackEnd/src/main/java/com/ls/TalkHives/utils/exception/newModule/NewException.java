package com.ls.TalkHives.utils.exception.newModule;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class NewException extends BaseException {

	private static final long serialVersionUID = 1L;

	public NewException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}

	public NewException() {
		super(ExceptionStatus.OPERATION_FAILED);
	}
}