package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.meetingController.CreateMeetingRequest;
import com.ls.TalkHives.dto.meetingController.UpdateMeetingRequest;
import com.ls.TalkHives.entities.Meetings;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface MeetingService {
    WsResponse create(CreateMeetingRequest createTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Meetings>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdateMeetingRequest updateTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long teamId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}