package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class UniversalException extends BaseException {

    private static final long serialVersionUID = 1L;

    public UniversalException(ExceptionStatus exceptionStatus) {
        super(exceptionStatus);
    }

    public UniversalException() {
        super(ExceptionStatus.SYSTEM_FAILURE);
    }
}