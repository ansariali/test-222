package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.VoteCommentEntity;
import com.ls.TalkHives.dto.common.VoteEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.voteController.*;
import com.ls.TalkHives.entities.VoteComments;
import com.ls.TalkHives.services.VoteService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/voteController")
@Controller
public class VoteController extends UniversalController {

    private static final String TAG = VoteController.class.getSimpleName();

    @Autowired
    private VoteService voteService;

    @ApiOperation(value = "V1 Create Vote")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/vote/1/create/{organizationId}")
    // @SendTo("/topic/vote/1/create/{organizationId}")
    public ResponseEntity<WsResponse> createVote(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody CreateVoteRequest createVoteRequest) {
        logger.info(TAG, "Inside V1 | /1/create");

        return new ResponseEntity<>(voteService.create(createVoteRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "V2 FetchAll Vote")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllVotes> fetchAllVote(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside V2 | /1/fetch/all: " + requestHeader);

        FetchAllVotes res = modelMapper.map(voteService.fetchAll(requestHeader, iDao), FetchAllVotes.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "V3 Create Vote Like")
    @MessageMapping("/vote/1/like/create/{organizationId}")
    @SendTo("/topic/vote/1/like/create/{organizationId}")
    public ResponseEntity<CreateVoteLikeResponse> createVoteLike(StompHeaderAccessor stompHeaderAccessor, @PathVariable String organizationId, CreateVoteLikeRequest createVoteLikeRequest) {
        logger.info(TAG, "Inside createVoteLike ");

        // CreateVoteLikeResponse res = modelMapper.map(voteService.createLike(createVoteLikeRequest, stompHeaderAccessor, iDao), CreateVoteLikeResponse.class);

        return new ResponseEntity<>(voteService.createLike(createVoteLikeRequest, stompHeaderAccessor, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "V4 Create Vote Comment")
    // @PostMapping(value = "/1/create/vote/comment")
    @MessageMapping("/vote/1/comment/create/{organizationId}")
    @SendTo("/topic/vote/1/comment/create/{organizationId}")
    public ResponseEntity<VoteCommentEntity> createVoteComment(StompHeaderAccessor stompHeaderAccessor, @PathVariable String organizationId, @PathVariable String voteId,
                                                               @RequestBody CreateVoteCommentRequest createVoteCommentRequest) {
        logger.info(TAG, "Inside createVoteComment ");

        // VoteCommentEntity res = modelMapper.map(voteService.createComment(createVoteCommentRequest, stompHeaderAccessor, iDao), VoteCommentEntity.class);

        return new ResponseEntity<>(voteService.createComment(createVoteCommentRequest, stompHeaderAccessor, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "V5 FetchAll Vote Comment")
    @GetMapping(value = "/1/fetch/all/vote/comment/{voteId}")
    public ResponseEntity<FetchAllVoteComments> fetchAllVoteComment(@RequestHeader Map<String, Object> requestHeader,
                                                                    @PathVariable Long voteId) {
        logger.info(TAG, "Inside V5 | : " + requestHeader);

        FetchAllVoteComments res = modelMapper.map(voteService.fetchAllComments(voteId, requestHeader, iDao), FetchAllVoteComments.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }


    @ApiOperation(value = "V6 Update Vote")
    @PutMapping(value = "/1/update")
    // @MessageMapping("/vote/1/update/{organizationId}")
    // @SendTo("/topic/vote/1/update/{organizationId}")
    public ResponseEntity<WsResponse> updateBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody UpdateVoteRequest updateVoteRequest) {
        logger.info(TAG, "Inside V6");

        return new ResponseEntity<>(voteService.update(updateVoteRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "V7 Delete Vote")
    @DeleteMapping(value = "/1/delete/{voteId}")
    // @MessageMapping("/vote/1/delete/{organizationId}/{voteId}")
    // @SendTo("/topic/vote/1/delete/{organizationId}")
    public ResponseEntity<WsResponse> deleteBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @PathVariable Long voteId) {
        logger.info(TAG, "Inside V7");

        return new ResponseEntity<>(voteService.delete(voteId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }
}