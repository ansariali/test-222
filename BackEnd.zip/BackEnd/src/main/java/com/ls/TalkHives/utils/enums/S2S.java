package com.ls.TalkHives.utils.enums;
public enum S2S {

    TEST(""),
    VERIFY_USER("userController/v1/verify/User?emailAddress={EMAIL-ADDRESS}&productId={PRODUCT-ID}"),
    FETCH_OWNER("bizDeskController/v1/fetch/owner?s2sToken={s2sToken}"),
    VERIFY_MASTER_USER("userController/v1/verify/masterUser?productId={PRODUCT-ID}&emailAddress={EMAIL-ID}"),
    FETCH_MASTER_USER("bizDeskController/fetch/promoter?emailId={EMAIL-ID}"),
    REGISTER_PURCHASED_PRODUCT("purchaseController/create/"),
    SIGN_IN_USER("userController/signIn"),
    SIGN_OUT_USER("userController/signOut/"),
    CROSS_AUTHENTICATION("userController/verifyUser/"),
    EP_MAIL_CUSTOM_VENDOR_ACCEPT_INVITATION("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_FETCH_CUSTOM_VENDOR_PROFILE("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_QUOTE_TO_TENDER("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_NOT_INTERESTED_TO_TENDER("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_VIEW_TENDER_STATUS("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_TO_ACCEPT_COUNTER_AMOUNT("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),
    EP_MAIL_TO_REJECT_AND_RE_COUNTER("1125/#/guest/welcome/{GUEST-TYPE}/{GUEST-REASON}/{TOKEN}"),;

    private static final String TalkHives_Host = UniversalInfo.TalkHives_Host.getInfo();

    private final String url;

    S2S(String url) {
        this.url = url;
    }

    public String getEazeProcureUrl() {
        return TalkHives_Host + url;
    }
}