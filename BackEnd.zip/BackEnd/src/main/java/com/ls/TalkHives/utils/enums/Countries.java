package com.ls.TalkHives.utils.enums;

public enum Countries {

    DEMO("", "", "");

    private final String name;
    private final String countryCode;
    private final String stdCode;

    Countries(String name, String countryCode, String stdCode) {
        this.name = name;
        this.countryCode = countryCode;
        this.stdCode = stdCode;
    }

    public String getName() {
        return name;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getStdCode() {
        return stdCode;
    }
}