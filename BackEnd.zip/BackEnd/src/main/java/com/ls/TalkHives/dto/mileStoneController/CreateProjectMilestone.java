package com.ls.TalkHives.dto.mileStoneController;

import com.ls.TalkHives.dto.projectController.Project_;

import java.util.Date;
import java.util.List;

public class CreateProjectMilestone {
    private String name;
    private String info;
    private Date initialDate;
    private Date deadline;
    private List<Project_> project;
    private String level;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public List<Project_> getProject() {
        return project;
    }

    public void setProject(List<Project_> project) {
        this.project = project;
    }
}
