package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.entities.NewEntity;
import com.ls.TalkHives.services.NewService;
import com.ls.TalkHives.services.impl.handler.NewServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Transactional
public class NewServiceImpl extends NewServiceImplHandler implements NewService {

    /*private static final String TAG = NewServiceImpl.class.getSimpleName();*/

    @Override
    public NewEntity create_v1(NewEntity newEntity, IDao<IEntity, Serializable> dao) {
        // STEP:1: .
        // 1.1: Verify newEntity is exist.
        if (newEntity == null) {
            throw new UniversalException(ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        }

        // 1.2: Verify new tag is exist.
        if (newEntity.getTag() == null) {
            throw new UniversalException(ExceptionStatus.NEW_TAG_MISSING);
        }

        // STEP:2: .
        // 2.1: Create and fetch new record.
        NewEntity aNewEntity = dao.find(NewEntity.class, dao.persist(newEntity));

        // 2.1.1: Verify new is created.
        if (aNewEntity == null) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_ADDED);
        }

        return aNewEntity;
    }

    @Override
    public NewEntity fetch_v1(Long newId, IDao<IEntity, Serializable> dao) {
        // STEP:1: .
        // 1.1: Verify new id is exist.
        if (newId == null) {
            throw new UniversalException(ExceptionStatus.NEW_ID_MISSING);
        }

        // STEP:2: .
        // 2.1: Fetch new.
        NewEntity aNewEntity = dao.find(NewEntity.class, newId);

        // 2.1.1: .
        if (aNewEntity == null) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_FOUND);
        }

        return aNewEntity;
    }

    @Override
    public Map<String, List<NewEntity>> fetchAll_v1(IDao<IEntity, Serializable> dao) {
        // STEP:1: .
        // 1.1: .
        Map<String, List<NewEntity>> aMap = new HashMap<>();

        // 1.2: .
        List<NewEntity> aList = dao.findAll(NewEntity.class, false);

        // 1.3: .
        aMap.put("newList", aList);

        return aMap;
    }

    @Override
    public NewEntity update_v1(Long newId, NewEntity newEntity, IDao<IEntity, Serializable> dao) {
        // STEP:1: .
        // 1.1: .Verify new id is exist.
        if (newId == null) {
            throw new UniversalException(ExceptionStatus.NEW_ID_MISSING);
        }

        // 1.2: Verify newEntity is exist.
        if (newEntity == null) {
            throw new UniversalException(ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        }

        // 1.3: Verify new tag is exist.
        if (newEntity.getTag() == null) {
            throw new UniversalException(ExceptionStatus.NEW_TAG_MISSING);
        }

        // STEP:2: .
        // 2.1: .
        NewEntity aNewEntity = dao.find(NewEntity.class, newId);

        // 2.1.1: .
        if (aNewEntity == null) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_FOUND);
        }

        // STEP:3: .
        // 3.1: Set tag for update.
        aNewEntity.setTag(newEntity.getTag());

        // 3.2: Update newEntity.
        aNewEntity = dao.update(aNewEntity);

        // 3.2.1: Verify newEntity is updated.
        if (!Objects.equals(aNewEntity.getTag(), newEntity.getTag())) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_UPDATED);
        }

        return aNewEntity;
    }

    @Override
    public UniversalResponse delete_v1(Long newId, IDao<IEntity, Serializable> dao) {
        // STEP:1: .
        // 1.1: Verify new id is exist.
        if (newId == null) {
            throw new UniversalException(ExceptionStatus.NEW_ID_MISSING);
        }

        // STEP:2: .
        // 2.1: .
        NewEntity aNewEntity = dao.find(NewEntity.class, newId);

        // 2.1.1: .
        if (aNewEntity == null) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_FOUND);
        }

        // STEP:3: .
        // 3.1: Delete targeted newEntity.
        dao.delete(aNewEntity);

        // STEP:4: .
        aNewEntity = dao.find(NewEntity.class, newId);

        // 4.1: Verify new is deleted.
        if (aNewEntity.getDeleted()) {
            return new UniversalResponse(true, "Record successfully deleted.");
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }
    }
}