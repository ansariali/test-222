package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * ChatRoomMembers Entity
 */

@Entity
@Table(name = "chat_room_members")
public class ChatRoomMembers extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatRoomMemberId;

    private String chatRoomMemberTag;
    private Boolean admin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chatRoomId")
    private ChatRooms chatRooms;

    public Long getChatRoomMemberId() {
        return chatRoomMemberId;
    }

    public void setChatRoomMemberId(Long chatRoomMemberId) {
        this.chatRoomMemberId = chatRoomMemberId;
    }

    public String getChatRoomMemberTag() {
        return chatRoomMemberTag;
    }

    public void setChatRoomMemberTag(String chatRoomMemberTag) {
        this.chatRoomMemberTag = chatRoomMemberTag;
    }

    public Boolean getAdmin() {
        return admin;
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public ChatRooms getChatRooms() {
        return chatRooms;
    }

    public void setChatRooms(ChatRooms chatRooms) {
        this.chatRooms = chatRooms;
    }
}



