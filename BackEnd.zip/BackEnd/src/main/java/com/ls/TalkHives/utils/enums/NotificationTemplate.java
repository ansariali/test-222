package com.ls.TalkHives.utils.enums;

public enum NotificationTemplate {

    DEMO("Demo", "//.txt");

    private final String tag;
    private final String url;

    NotificationTemplate(String tag, String url) {
        this.tag = tag;
        this.url = url;
    }

    public String getTag() {
        return tag;
    }

    public String getUrl() {
        return url;
    }
}