package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.chatController.CreateChatRequest;
import com.ls.TalkHives.dto.chatController.CreateGroupChatRequest;
import com.ls.TalkHives.dto.common.ChatEntity;
import com.ls.TalkHives.dto.common.ChatRoomEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.ChatService;
import com.ls.TalkHives.services.impl.handler.ChatServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class ChatServiceImpl extends ChatServiceImplHandler implements ChatService {

    private static final String TAG = ChatServiceImpl.class.getSimpleName();

    @Override
    public UniversalResponse createChatRoom(Long to, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        Users users_ = iDao.find(Users.class, to);

        if (Objects.equals(users.getUserId(), users_.getUserId())) {
            throw new UniversalException(ExceptionStatus.SAME_USER_FOUND);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("userOne", users);
        hashtable.put("userTwo", users_);
        ChatRooms chatRooms = iDao.getEntity(ChatRooms.class, queryManager.getChatRoomOfUsers(), hashtable, false);
        hashtable.clear();

        if (chatRooms == null) {
            ChatRooms _chatRooms = new ChatRooms();
            _chatRooms.setChatRoomTag(util.getTokenNumber());
            _chatRooms.setGroupChat(Boolean.FALSE);
            _chatRooms.setUserOne(users);
            _chatRooms.setUserTwo(users_);

            ChatRooms chatRooms_ = iDao.find(ChatRooms.class, iDao.persist(_chatRooms));

            return new UniversalResponse(true, "Chat room created!", null, null, chatRooms_.getChatRoomTag());
        } else {
            return new UniversalResponse(true, "Chat room created!", null, null, chatRooms.getChatRoomTag());
        }
    }

    @Override
    public ChatRooms createGroupChat(CreateGroupChatRequest createGroupChatRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        ChatRooms chatRooms = new ChatRooms();
        chatRooms.setChatRoomTag(util.getTokenNumber());
        chatRooms.setName(createGroupChatRequest.getName());
        chatRooms.setInfo(createGroupChatRequest.getInfo());
        chatRooms.setGroupChat(Boolean.TRUE);

        HashSet<ChatRoomMembers> members = new HashSet<>();

        for (UserInfo userInfo : createGroupChatRequest.getMembers()) {
            ChatRoomMembers chatRoomMembers = new ChatRoomMembers();
            chatRoomMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
            chatRoomMembers.setAdmin(Boolean.FALSE);
            chatRoomMembers.setChatRooms(chatRooms);
            chatRoomMembers.setCreatedAt(getCurrentTime());
            members.add(chatRoomMembers);
        }

        ChatRoomMembers chatRoomMembers = new ChatRoomMembers();
        chatRoomMembers.setUsers(users);
        chatRoomMembers.setAdmin(Boolean.TRUE);
        chatRoomMembers.setChatRooms(chatRooms);
        chatRoomMembers.setCreatedAt(getCurrentTime());
        members.add(chatRoomMembers);

        chatRooms.setMembers(members);

        ChatRooms chatRooms_ = iDao.find(ChatRooms.class, iDao.persist(chatRooms));

        for (ChatRoomMembers chatRoomMembers_ : chatRooms_.getMembers()) {
            ChatRoomEntity chatRoomEntity = modelMapper.map(chatRooms_, ChatRoomEntity.class);
            simpMessagingTemplate.convertAndSend("/topic/1/groupChat/create/" + chatRoomMembers_.getUsers().getUserId(), chatRoomEntity);
        }

        return chatRooms_;
    }

    @Override
    public Map<String, List<ChatRooms>> getGroups(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<ChatRooms>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("users", users);
        List<ChatRoomMembers> list = iDao.getEntities(ChatRoomMembers.class, queryManager.getAllChatRoomForGroup(), hashtable, false);
        hashtable.clear();

        List<ChatRooms> rooms = new ArrayList<>();

        for (ChatRoomMembers chatRoomMembers : list) {
            ChatRooms chatRooms = iDao.find(ChatRooms.class, chatRoomMembers.getChatRooms().getChatRoomId());
            rooms.add(chatRooms);
        }

        // rooms.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("chatRooms", rooms);

        return map;
    }

    @Override
    public Map<String, List<Chats>> getMessages(String chatRoomTag, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        ChatRooms chatRooms = findChatRoom(chatRoomTag, iDao);

        logger.info(TAG, "hola: " + chatRooms.getChatRoomId());

        hashtable.put("chatRooms", chatRooms);
        List<Chats> list = iDao.getEntities(Chats.class, queryManager.getChats(), hashtable, false);
        hashtable.clear();

        Map<String, List<Chats>> map = new HashMap<>();

        map.put("chats", list);

        return map;
    }

    @Override
    public Chats sendMessage(CreateChatRequest createChatRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);

        Chats chats = new Chats();
        chats.setContent(createChatRequest.getContent());
        chats.setChatRooms(findChatRoom(createChatRequest.getChatRoomTag(), iDao));
        chats.setSender(users);
        chats.setCreatedAt(getCurrentTime());

        Chats chats_ = iDao.find(Chats.class, iDao.persist(chats));

        ChatEntity chatEntity = modelMapper.map(chats_, ChatEntity.class);
        // test(chatEntity);

        return chats_;
    }

    public void test(ChatEntity chatEntity) {
        logger.info(TAG, "Inside Test");
        simpMessagingTemplate.convertAndSend("/topic/1/notification/1", chatEntity);
    }

}