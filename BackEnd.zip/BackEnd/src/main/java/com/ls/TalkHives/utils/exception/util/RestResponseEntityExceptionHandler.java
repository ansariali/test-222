package com.ls.TalkHives.utils.exception.util;

import com.ls.TalkHives.utils.Logger;
import com.ls.TalkHives.utils.exception.*;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.newModule.NewException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.lang.Exception;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

    private final static String TAG = RestResponseEntityExceptionHandler.class.getSimpleName();
    private final Logger logger = Logger.getInstance(true, RestResponseEntityExceptionHandler.class);

    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<?> handleAnyException(Exception e) {
        e.printStackTrace();
        ServiceError serviceError = new ServiceError(ExceptionStatus.SYSTEM_FAILURE);
        return new ResponseEntity<>(serviceError, HttpStatus.BAD_REQUEST);
    }

    /**
     * Generic Exceptions
     **/
    @ExceptionHandler(UniversalException.class)
    public ResponseEntity<ServiceError> genericException(UniversalException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Operation Failed Exceptions
     **/
    @ExceptionHandler(OperationFailedException.class)
    public ResponseEntity<ServiceError> operationFailedException(OperationFailedException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    /**
     * HttpRequest Exceptions
     **/
    @ExceptionHandler(HttpRequestMethodNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestMethodNotValidException(HttpRequestMethodNotValidException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpRequestHeaderNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestHeaderNotValidException(HttpRequestHeaderNotValidException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpRequestBodyNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestBodyNotValidException(HttpRequestBodyNotValidException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    /**
     * New Exceptions
     **/
    @ExceptionHandler(NewException.class)
    public ResponseEntity<ServiceError> newException(NewException e) {
        logger.error(TAG, "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }
}