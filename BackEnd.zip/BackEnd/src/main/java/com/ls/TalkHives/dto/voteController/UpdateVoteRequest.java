package com.ls.TalkHives.dto.voteController;

import com.ls.TalkHives.dto.common.VoteEntity;

public class UpdateVoteRequest extends VoteEntity {
}
