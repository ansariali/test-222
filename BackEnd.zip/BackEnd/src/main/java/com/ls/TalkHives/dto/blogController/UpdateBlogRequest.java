package com.ls.TalkHives.dto.blogController;

import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.FileEntity;

public class UpdateBlogRequest extends BlogEntity {

    private FileEntity file;

    public FileEntity getFile() {
        return file;
    }

    public void setFile(FileEntity file) {
        this.file = file;
    }
}
