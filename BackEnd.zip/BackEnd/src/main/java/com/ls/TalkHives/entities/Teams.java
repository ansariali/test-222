package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * Teams Entity
 */

@Entity
@Table(name = "teams")
public class Teams extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long teamId;

    private String teamTag;

    @NotNull
    @Size(min = 1)
    private String name;

    private String title;
    private String info;

    @ColumnDefault("0")
    private Integer totalMember = 0;

    @ColumnDefault("0")
    private Integer totalProjects = 0;

    @ColumnDefault("0")
    private Integer liveProjects = 0;

    @ColumnDefault("0")
    private Integer successProjects = 0;

    @ColumnDefault("0")
    private Integer ranking = 0;

    private BigDecimal budget;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teamLeader")
    private Users teamLeader;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    @Where(clause = "deleted = false")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "teams")
    private Set<TeamMembers> members = new HashSet<>();

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getTeamTag() {
        return teamTag;
    }

    public void setTeamTag(String teamTag) {
        this.teamTag = teamTag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Integer getTotalProjects() {
        return totalProjects;
    }

    public void setTotalProjects(Integer totalProjects) {
        this.totalProjects = totalProjects;
    }

    public Integer getLiveProjects() {
        return liveProjects;
    }

    public void setLiveProjects(Integer liveProjects) {
        this.liveProjects = liveProjects;
    }

    public Integer getSuccessProjects() {
        return successProjects;
    }

    public void setSuccessProjects(Integer successProjects) {
        this.successProjects = successProjects;
    }

    public Integer getRanking() {
        return ranking;
    }

    public void setRanking(Integer ranking) {
        this.ranking = ranking;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }

    public Users getTeamLeader() {
        return teamLeader;
    }

    public void setTeamLeader(Users teamLeader) {
        this.teamLeader = teamLeader;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Set<TeamMembers> getMembers() {
        return members;
    }

    public void setMembers(Set<TeamMembers> members) {
        this.members = members;
    }
}



