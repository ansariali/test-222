package com.ls.TalkHives.utils.ideal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ls.TalkHives.services.S3StorageService;
import com.ls.TalkHives.utils.Logger;
import com.ls.TalkHives.utils.Refactor;
import com.ls.TalkHives.utils.Util;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.io.Serializable;
import java.util.Date;

public abstract class UniversalController {

    @Autowired
    protected IDao<IEntity, Serializable> iDao;

    @Autowired
    protected ModelMapper modelMapper;

    @Autowired
    protected S3StorageService s3StorageService;

    protected Logger logger = Logger.getInstance(true, UniversalController.class);

    protected static HttpHeaders responseHeaders = new HttpHeaders();

    protected Util util = Util.getInstance();

    protected Refactor refactor = Refactor.getInstance();

    protected Gson gson = new GsonBuilder()
            .setDateFormat("dd-MM-yyyy hh:ss a")
            .registerTypeAdapter(Date.class, refactor.serializeDate)
            .registerTypeAdapter(Date.class, refactor.deserializeDate)
            // .registerTypeAdapter(Date.class, refactor.serializeCurrency)
            // .registerTypeAdapter(Date.class, refactor.deserializeCurrency)
            .create();

    static {
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
    }
}