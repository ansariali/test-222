package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * TaskDelegation Entity
 */

@Entity
@Table(name = "task_delegation")
public class TaskDelegation extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long taskDelegationId;

    private String taskDelegationTag;

    private String info;
    private Boolean thInfo = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignedBy")
    private Users delegatedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    @Where(clause = "deleted = false")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "taskDelegation")
    private Set<TaskDelegationMember> delegationMembers = new HashSet<>();

    public Long getTaskDelegationId() {
        return taskDelegationId;
    }

    public void setTaskDelegationId(Long taskDelegationId) {
        this.taskDelegationId = taskDelegationId;
    }

    public String getTaskDelegationTag() {
        return taskDelegationTag;
    }

    public void setTaskDelegationTag(String taskDelegationTag) {
        this.taskDelegationTag = taskDelegationTag;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Boolean getThInfo() {
        return thInfo;
    }

    public void setThInfo(Boolean thInfo) {
        this.thInfo = thInfo;
    }

    public Users getDelegatedBy() {
        return delegatedBy;
    }

    public void setDelegatedBy(Users delegatedBy) {
        this.delegatedBy = delegatedBy;
    }

    public Tasks getTasks() {
        return tasks;
    }

    public void setTasks(Tasks tasks) {
        this.tasks = tasks;
    }

    public Set<TaskDelegationMember> getDelegationMembers() {
        return delegationMembers;
    }

    public void setDelegationMembers(Set<TaskDelegationMember> delegationMembers) {
        this.delegationMembers = delegationMembers;
    }
}



