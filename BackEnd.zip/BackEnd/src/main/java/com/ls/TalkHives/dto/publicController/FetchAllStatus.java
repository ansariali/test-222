package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.StatusEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllStatus {

    private List<StatusEntity> status = new ArrayList<>();

    public List<StatusEntity> getStatus() {
        return status;
    }

    public void setStatus(List<StatusEntity> status) {
        this.status = status;
    }
}
