package com.ls.TalkHives.dto.pinController;

import com.ls.TalkHives.dto.common.PinEntity;

public class UpdatePinRequest extends PinEntity {
}
