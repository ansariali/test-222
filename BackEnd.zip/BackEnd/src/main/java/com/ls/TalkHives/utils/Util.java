package com.ls.TalkHives.utils;

import com.ls.TalkHives.utils.enums.NotificationTemplate;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Util {

    private static final String TAG = Util.class.getSimpleName();

    private Logger logger = Logger.getInstance(true, Util.class);

    private Refactor refactor = Refactor.getInstance();

    private Util() {
    }

    public static Util getInstance() {
        return new Util();
    }

    /**
     * @return
     */
    public String capitalizeFirstLetter(String original) {
        if (original == null || original.length() == 0) {
            return original;
        }
        return original.substring(0, 1).toUpperCase() + original.substring(1);
    }

    /**
     * @return
     */
    public Integer getPinNumber() {
        try {
            Random rnd = new Random();

            Long time = new Date().getTime();

            String a = "" + String.valueOf(time).charAt(7);
            String b = "" + String.valueOf(time).charAt(8);
            String c = "" + String.valueOf(time).charAt(9);
            String d = "" + String.valueOf(time).charAt(10);
            String e = "" + String.valueOf(time).charAt(11);
            String f = "" + String.valueOf(time).charAt(12);

            Integer newNumber = Integer.valueOf(a + b + c + d + e + f);

            return newNumber + rnd.nextInt(99999);
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }

    /**
     * @return
     */
    public String getDefaultTimeZone() {
        return com.ls.TalkHives.utils.enums.TimeZone.DEFAULT.getTimeZone();
    }

    /**
     * @return
     */
    public Date getCurrentTime() {
        return new Date();
    }

    /**
     * @return
     */
    public int getCurrentSecond() {
        return LocalDateTime.now().getSecond();
    }

    /**
     * @return
     */
    public Integer getOtpNumber() {
        try {
            Random rnd = new Random();

            Long time = new Date().getTime();

            String a = "" + String.valueOf(time).charAt(7);
            String b = "" + String.valueOf(time).charAt(8);
            String c = "" + String.valueOf(time).charAt(9);
            String d = "" + String.valueOf(time).charAt(10);
            String e = "" + String.valueOf(time).charAt(11);
            String f = "" + String.valueOf(time).charAt(12);

            Integer newNumber = Integer.valueOf(a + b + c + d + e + f);

            return newNumber + rnd.nextInt(99999);
        } catch (Exception e) {
            logger.error(TAG, e);
            return 0;
        }
    }

    /**
     * @return
     */
    public String getTokenNumber() {
        try {
            return UUID.randomUUID().toString();
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }

    /**
     * @param fromDate
     * @param toDate
     * @return
     */
    public Long getTimeDeference(long fromDate, long toDate) {
        try {
            Integer[] dmhs = {0, 0, 0, 0};

            Date cycleFrom = new Date(fromDate);
            Date cycleTo = new Date(toDate);

            Long diff = cycleTo.getTime() - cycleFrom.getTime();

            Long day = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
            Long hour = TimeUnit.HOURS.convert(diff, TimeUnit.MILLISECONDS);
            Long minute = TimeUnit.MINUTES.convert(diff, TimeUnit.MILLISECONDS);
            Long second = TimeUnit.SECONDS.convert(diff, TimeUnit.MILLISECONDS);

            dmhs[0] = Math.toIntExact(day);
            dmhs[1] = Math.toIntExact((hour - day * 24));
            dmhs[2] = Math.toIntExact((minute - hour * 60));
            dmhs[3] = Math.toIntExact((second - minute * 60));

            Integer totalTime = (dmhs[0] * 24 * 60 * 60 * 1000) + (dmhs[1] * 60 * 60 * 1000) + (dmhs[2] * 60 * 1000) + (dmhs[3] * 1000);

            return Long.valueOf(totalTime);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return 60000L;
        }
    }

    /**
     * @param data
     * @return
     */
    public Object getCoveredData(Object data) {
        return data != null ? data : "NONE";
    }

    /**
     * Get file content.
     *
     * @param notificationTemplate - Object of targeted file.
     * @return file content as String
     */
    public String getFileContent(NotificationTemplate notificationTemplate) {
        try {
            return new BufferedReader(new FileReader(new ClassPathResource(notificationTemplate.getUrl()).getFile())).readLine();
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }

    /**
     * @param map -
     * @param <K> -
     * @param <V> -
     * @return -
     */
    public <K, V extends Comparable<? super V>> List<Map.Entry<K, V>> descendingOrder(Map<K, V> map) {

        List<Map.Entry<K, V>> sortedEntries = new ArrayList<>(map.entrySet());

        Collections.sort(sortedEntries,
                (e1, e2) -> e2.getValue().compareTo(e1.getValue())
        );

        return sortedEntries;
    }

    /**
     * @param map -
     * @param <K> -
     * @param <V> -
     * @return -
     */
    public <K, V extends Comparable<? super V>> List<Map.Entry<K, V>> ascendingOrder(Map<K, V> map) {
        List<Map.Entry<K, V>> sortedEntries = new ArrayList<>(map.entrySet());

        Collections.sort(sortedEntries,
                Comparator.comparing(Map.Entry::getValue)
        );

        return sortedEntries;
    }

    /**
     * @param requestHeader -
     * @return -
     */
    public String getAccessTokenFromHttpRequestHeader(Map<String, Object> requestHeader) {
        for (Map.Entry<String, Object> entry : requestHeader.entrySet()) {
            String key = entry.getKey().toUpperCase();
            String value = entry.getValue().toString();

            if (key.equals("ACCESS-TOKEN")) {
                return value;
            }
        }

        return "";
    }

    public Date getDate(com.ls.TalkHives.utils.enums.TimeZone timeZone, Integer days) {
        try {
            DateFormat aDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");
            Date aDate = refactor.getTimeBySpecificZone(timeZone.getTimeZone(), getCurrentTime());
            aDate = aDateFormat.parse(aDateFormat.format(aDate));
            Calendar aCalendar = Calendar.getInstance();
            aCalendar.setTime(aDate);
            aCalendar.add(Calendar.DATE, days);

            return aCalendar.getTime();
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }
}