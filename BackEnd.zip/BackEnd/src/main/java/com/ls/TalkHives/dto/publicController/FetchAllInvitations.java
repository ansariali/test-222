package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.InvitationsEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllInvitations {

    private List<InvitationsEntity> invitations = new ArrayList<>();

    public List<InvitationsEntity> getInvitations() {
        return invitations;
    }

    public void setInvitations(List<InvitationsEntity> invitations) {
        this.invitations = invitations;
    }
}
