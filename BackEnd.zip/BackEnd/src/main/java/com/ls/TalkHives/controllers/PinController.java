package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.pinController.CreatePinRequest;
import com.ls.TalkHives.dto.pinController.FetchAllPins;
import com.ls.TalkHives.dto.pinController.UpdatePinRequest;
import com.ls.TalkHives.services.PinService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/pinController")
public class PinController extends UniversalController {

    private static final String TAG = PinController.class.getSimpleName();

    @Autowired
    private PinService pinService;

    @ApiOperation(value = "P1 Create Pin")
    @PostMapping(value = "/1/create")
    public ResponseEntity<WsResponse> createPin(@RequestHeader Map<String, Object> requestHeader,
                                                @RequestBody CreatePinRequest createPinRequest) {
        logger.info(TAG, "Inside P1 | /1/create");

        return new ResponseEntity<>(pinService.create(createPinRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P2 FetchAll Pin")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllPins> fetchAllPin(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P2 | /1/fetch/all");

        FetchAllPins res = modelMapper.map(pinService.fetchAll(requestHeader, iDao), FetchAllPins.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P3 Update Pin")
    @PutMapping(value = "/1/update")
    public ResponseEntity<WsResponse> updatePin(@RequestHeader Map<String, Object> requestHeader,
                                                @RequestBody UpdatePinRequest updatePinRequest) {
        logger.info(TAG, "Inside P3");

        return new ResponseEntity<>(pinService.update(updatePinRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P4 Deleted Pin")
    @DeleteMapping(value = "/1/delete/{pinId}")
    public ResponseEntity<WsResponse> deletePin(@RequestHeader Map<String, Object> requestHeader,
                                                @PathVariable Long pinId) {
        logger.info(TAG, "Inside P4");

        return new ResponseEntity<>(pinService.delete(pinId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }
}