package com.ls.TalkHives.dto.pinController;

import com.ls.TalkHives.dto.common.PinEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllPins {

    private List<PinEntity> pins = new ArrayList<>();

    public List<PinEntity> getPins() {
        return pins;
    }

    public void setPins(List<PinEntity> pins) {
        this.pins = pins;
    }
}
