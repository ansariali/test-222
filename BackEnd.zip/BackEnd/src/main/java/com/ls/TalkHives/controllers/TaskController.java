package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.blogController.CreateBlogRequest;
import com.ls.TalkHives.dto.blogController.FetchAllBlogs;
import com.ls.TalkHives.dto.blogController.UpdateBlogRequest;
import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.TaskEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.taskController.CreateTaskRequest;
import com.ls.TalkHives.dto.taskController.FetchAllTasks;
import com.ls.TalkHives.entities.Tasks;
import com.ls.TalkHives.services.BlogService;
import com.ls.TalkHives.services.TaskService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/taskController")
@Controller
public class TaskController extends UniversalController {

    private static final String TAG = TaskController.class.getSimpleName();

    @Autowired
    private TaskService taskService;

    @ApiOperation(value = "T1 Create Task")
    @PostMapping(value = "/1/create")
    public ResponseEntity<TaskEntity> createTask(@RequestHeader Map<String, Object> requestHeader, @RequestBody CreateTaskRequest createTaskRequest) {
        logger.info(TAG, "Inside T1 | /1/create");

        TaskEntity res = modelMapper.map(taskService.create(createTaskRequest, requestHeader, iDao), TaskEntity.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T2 FetchAll Tasks")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllTasks> fetchAllTask(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside T2 | /1/fetch/all: ");

        FetchAllTasks res = modelMapper.map(taskService.fetchAll(requestHeader, iDao), FetchAllTasks.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value =" Update Task")
    @PutMapping(value = "/1/update/{taskId}")
    public ResponseEntity<TaskEntity> updateTask(@PathVariable Long taskId, @RequestHeader Map<String, Object> requestHeader, @RequestBody CreateTaskRequest tasks) {
        logger.info(TAG, "Inside updateTask");

        TaskEntity res = modelMapper.map(taskService.updateTask(taskId, tasks, requestHeader, iDao), TaskEntity.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Delete Task")
    @DeleteMapping(value = "/1/delete/{taskId}")
    public ResponseEntity<WsResponse> deleteTask(@PathVariable Long taskId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside deleteTask");

        return new ResponseEntity<>(taskService.delete(taskId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }



    /* @ApiOperation(value = "T2 FetchAll Blog")
    @GetMapping(value = "/1/fetch/all")
    // @MessageMapping("/receive")
    // @SendTo("/server/first")
    public ResponseEntity<FetchAllBlogs> fetchAllBlog(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside B2 | /1/fetch/all: " + requestHeader);

        FetchAllBlogs res = modelMapper.map(blogService.fetchAll(requestHeader, iDao), FetchAllBlogs.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T3 Update Blog")
    // @PutMapping(value = "/1/update/{blogId}")
    @MessageMapping("/blog/1/update/{organizationId}")
    @SendTo("/topic/blog/1/update/{organizationId}")
    public ResponseEntity<BlogEntity> updateBlog(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                                 @RequestBody UpdateBlogRequest updateBlogRequest,
                                                 @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside B3");

        BlogEntity res = modelMapper.map(blogService.update(updateBlogRequest, stompHeaderAccessor, iDao), BlogEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T4 Delete Blog")
    // @DeleteMapping(value = "/1/delete/{blogId}")
    @MessageMapping("/blog/1/delete/{organizationId}/{blogId}")
    @SendTo("/topic/blog/1/delete/{organizationId}")
    public ResponseEntity<UniversalResponse> deleteBlog(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                                        @DestinationVariable String blogId, @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside B4" + blogId + organizationId);

        UniversalResponse res = modelMapper.map(blogService.delete(Long.parseLong(blogId), stompHeaderAccessor, iDao), UniversalResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }
*/
    @ApiOperation(value = "T5 Send Task")
    @SendTo("/topic/task/1/sendToUser/{userId}")
    public TaskEntity send(@PathVariable Long userId, TaskEntity taskEntity) {
        logger.info(TAG, "Inside T5");

        return taskEntity;
    }
}