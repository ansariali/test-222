package com.ls.TalkHives.utils;

import java.time.LocalDateTime;

public class Tag {

    private String globalTag;
    private String letterL = "l";
    private String letterS = "s";
    private String letterG = "g";
    private String letterO = "o";
    private Integer number7 = 7;

    private Tag() {
    }

    public static Tag getInstance() {
        return new Tag();
    }

    public String THTag(Long organizationId, Long userId) {

        String zeroUserId = String.format("%4d", userId).replace(' ', '0');
        String zeroOrganizationId = String.format("%3d", organizationId).replace(' ', '0');
        Integer currentSecond = LocalDateTime.now().getSecond();

        if (currentSecond > 0 && currentSecond < 7) {
            this.globalTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterL;
        } else if (currentSecond > 6 && currentSecond < 13) {
            this.globalTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterS;
        } else if (currentSecond > 12 && currentSecond < 19) {
            this.globalTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterG;
        } else if (currentSecond > 18 && currentSecond < 25) {
            this.globalTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterO;
        } else if (currentSecond > 24 && currentSecond < 31) {
            this.globalTag = this.letterL + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 30 && currentSecond < 43) {
            this.globalTag = this.letterS + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 42 && currentSecond < 49) {
            this.globalTag = this.letterG + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 48 && currentSecond < 55) {
            this.globalTag = this.letterO + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 54 && currentSecond < 61) {
            this.globalTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterL;
        } else {
            this.globalTag = this.letterL + zeroOrganizationId + this.number7 + zeroUserId;
        }
        System.out.println(this.globalTag);

        return this.globalTag;
    }

    public String getGlobalTag() {
        return globalTag;
    }

    public void setGlobalTag(String globalTag) {
        this.globalTag = globalTag;
    }

    public String getLetterL() {
        return letterL;
    }

    public void setLetterL(String letterL) {
        this.letterL = letterL;
    }

    public String getLetterS() {
        return letterS;
    }

    public void setLetterS(String letterS) {
        this.letterS = letterS;
    }

    public String getLetterG() {
        return letterG;
    }

    public void setLetterG(String letterG) {
        this.letterG = letterG;
    }

    public String getLetterO() {
        return letterO;
    }

    public void setLetterO(String letterO) {
        this.letterO = letterO;
    }

    public Integer getNumber7() {
        return number7;
    }

    public void setNumber7(Integer number7) {
        this.number7 = number7;
    }
}
