package com.ls.TalkHives.utils.enums;

public enum FrontEndPath {

    LOGIN("login", "", "");

    private final String redirectTo;
    private final String reason;
    private final String message;

    FrontEndPath(String redirectTo, String reason, String message) {
        this.redirectTo = redirectTo;
        this.reason = reason;
        this.message = message;
    }

    public String getRedirectTo() {
        return redirectTo;
    }

    public String getReason() {
        return reason;
    }

    public String getMessage() {
        return message;
    }
}