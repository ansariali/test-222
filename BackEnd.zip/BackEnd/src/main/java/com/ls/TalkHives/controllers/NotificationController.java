package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.NotificationEntity;
import com.ls.TalkHives.dto.notificationController.FetchAllNotifications;
import com.ls.TalkHives.services.NotificationService;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/notificationController")
public class NotificationController extends UniversalController {

    private static final String TAG = UniversalController.class.getSimpleName();

    @Autowired
    private NotificationService notificationService;

    @ApiOperation(value = "N-- Clock")
    @SendTo("/topic/clock/1")
    public String clock(String date) {
        logger.info(TAG, "Inside N1");

        return date;
    }

    @ApiOperation(value = "N-- Initiate Protocol")
    @MessageMapping("/protocol/1/{userId}")
    @SendTo("/topic/protocol/1/{userId}")
    public String protocol(@PathVariable Long userId, @Payload String code) {
        logger.info(TAG, "Inside N-- Initiate Protocol" + code);

        return code;
    }

    @ApiOperation(value = "N1 SendToUser Notification")
    @SendTo("/topic/notification/1/create/sendToUser/{userId}")
    public NotificationEntity sendToUser(@PathVariable Long userId, @Payload NotificationEntity notificationEntity) {
        logger.info(TAG, "Inside P3");

        return notificationEntity;
    }

    @ApiOperation(value = "N2 SendToOrganization Notification")
    @SendTo("/topic/notification/1/create/sendToOrganization/{organizationId}")
    public NotificationEntity sendToOrganization(@PathVariable Long organizationId, @Payload NotificationEntity notificationEntity) {
        logger.info(TAG, "Inside P4");

        return notificationEntity;
    }

    @ApiOperation(value = "N3 SendToDesignation Notification")
    @SendTo("/topic/notification/1/create/sendToDesignation/{userRoleTag}")
    public NotificationEntity sendToDesignation(@PathVariable Long userRoleTag, @Payload NotificationEntity notificationEntity) {
        logger.info(TAG, "Inside P4");

        return notificationEntity;
    }

    @ApiOperation(value = "N4 FetchAll Notification")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllNotifications> fetchAllNotification(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllNotification ");

        FetchAllNotifications res = modelMapper.map(notificationService.fetchAll(requestHeader, iDao), FetchAllNotifications.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

}