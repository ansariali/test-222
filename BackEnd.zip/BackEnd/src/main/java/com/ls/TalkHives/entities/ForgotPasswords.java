package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * Blogs Entity
 */

@Entity
@Table(name = "forgotPasswords")
public class ForgotPasswords extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long forgotPasswordId;

    private String forgotPasswordTag;
    private String token;
    private String emailId;

    private Date visitedAt;


}
