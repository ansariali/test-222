package com.ls.TalkHives.dto.voteController;

public class CreateVoteCommentRequest {
    private Long voteId;
    private String message;

    public Long getVoteId() {
        return voteId;
    }

    public void setVoteId(Long voteId) {
        this.voteId = voteId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
