package com.ls.TalkHives.dto.meetingController;

import com.ls.TalkHives.dto.common.*;

import java.util.Date;
import java.util.List;

public class CreateMeetingRequest {
    private String title;
    private String info;
    private Date timing;

    private FrequencyEntity frequency;
    private List<UserInfo> members;
    private List<MeetingPointsEntity> points;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getTiming() {
        return timing;
    }

    public void setTiming(Date timing) {
        this.timing = timing;
    }

    public FrequencyEntity getFrequency() {
        return frequency;
    }

    public void setFrequency(FrequencyEntity frequency) {
        this.frequency = frequency;
    }

    public List<UserInfo> getMembers() {
        return members;
    }

    public void setMembers(List<UserInfo> members) {
        this.members = members;
    }

    public List<MeetingPointsEntity> getPoints() {
        return points;
    }

    public void setPoints(List<MeetingPointsEntity> points) {
        this.points = points;
    }
}
