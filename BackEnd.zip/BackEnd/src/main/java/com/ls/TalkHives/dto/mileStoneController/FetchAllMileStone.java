package com.ls.TalkHives.dto.mileStoneController;

import java.util.ArrayList;
import java.util.List;

public class FetchAllMileStone {
    private List<MileStoneEntity> mileStones = new ArrayList<>();

    public List<MileStoneEntity> getMileStones() {
        return mileStones;
    }

    public void setMileStones(List<MileStoneEntity> mileStones) {
        this.mileStones = mileStones;
    }
}
