package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.PinEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Blogs;
import com.ls.TalkHives.entities.Pins;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class PinServiceImplHandler extends UniversalService {

    private void activityAction(String activityTag, Pins pins, Users users) {
        if (activityTag.equals(Activity.CREATE_PIN.getActivity())) {
            pins.setPinTag(getPinTag(users));
        }

        if (activityTag.equals(Activity.DELETE_PIN.getActivity())) {
            users.setDeletedPin(users.getDeletedPin() + 1);
            users.getOrganizations().setDeletedPin(users.getOrganizations().getDeletedPin() + 1);
        }
    }

    protected WsResponse sendPin(String activityTag, Pins pins, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, pins, users);

        PinEntity pinEntity = modelMapper.map(pins, PinEntity.class);

        // Send Pin
        WsResponse wsResponse = sendActivity(Ascii.USER.getCode(), users.getUserId().toString(), pins.getPinId(), Ascii.PIN.getCode(), activityTag, pinEntity);

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.PIN, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }

}