package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * TalkHives Entity
 */
@Entity
@Table(name = "talk_hives")
public class TalkHives extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long talkHivesId;

    private String thTag;

    private boolean thTeam = false;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users user;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paymentId")
    private Payments payments;

    private Boolean verified = false;
    private Boolean disabled = false;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invitedBy")
    private Users invitedBy;

    public Long getTalkHivesId() {
        return talkHivesId;
    }

    public void setTalkHivesId(Long talkHivesId) {
        this.talkHivesId = talkHivesId;
    }

    public String getThTag() {
        return thTag;
    }

    public void setThTag(String thTag) {
        this.thTag = thTag;
    }

    public boolean isThTeam() {
        return thTeam;
    }

    public void setThTeam(boolean thTeam) {
        this.thTeam = thTeam;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Payments getPayments() {
        return payments;
    }

    public void setPayments(Payments payments) {
        this.payments = payments;
    }

    public Boolean getVerified() {
        return verified;
    }

    public void setVerified(Boolean verified) {
        this.verified = verified;
    }

    public Boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public Users getInvitedBy() {
        return invitedBy;
    }

    public void setInvitedBy(Users invitedBy) {
        this.invitedBy = invitedBy;
    }
}
