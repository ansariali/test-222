package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.userController.*;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.Serializable;
import java.util.Map;

public interface UserService {
    UniversalResponse register(CreateUserRequest createUserRequest, IDao<IEntity, Serializable> iDao);

    LoginResponse login(String userName, String password, IDao<IEntity, Serializable> iDao);

    UniversalResponse logOut(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    LoginResponse rememberMe(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    UniversalResponse sendInvite(CreateInvitationRequest createInvitationRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    UniversalResponse registerByInvite(MultipartFile multipartFile, MultipartHttpServletRequest multipartHttpServletRequest, String token, IDao<IEntity, Serializable> iDao);

    UpdateUserRequest fetchProfile(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse updateProfile(Long profileId, Map<String, Object> requestHeader, UpdateUserRequest users, IDao<IEntity, Serializable> iDao);
}