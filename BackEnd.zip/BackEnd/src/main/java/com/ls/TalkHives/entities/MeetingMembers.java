package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * MeetingMembers Entity
 */

@Entity
@Table(name = "meeting_members")
public class MeetingMembers extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long meetingMemberId;

    private String meetingMemberTag;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invitedBy")
    private Users invitedBy;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "meetingId")
    private Meetings meetings;

    public Long getMeetingMemberId() {
        return meetingMemberId;
    }

    public void setMeetingMemberId(Long meetingMemberId) {
        this.meetingMemberId = meetingMemberId;
    }

    public String getMeetingMemberTag() {
        return meetingMemberTag;
    }

    public void setMeetingMemberTag(String meetingMemberTag) {
        this.meetingMemberTag = meetingMemberTag;
    }

    public Users getInvitedBy() {
        return invitedBy;
    }

    public void setInvitedBy(Users invitedBy) {
        this.invitedBy = invitedBy;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Meetings getMeetings() {
        return meetings;
    }

    public void setMeetings(Meetings meetings) {
        this.meetings = meetings;
    }
}



