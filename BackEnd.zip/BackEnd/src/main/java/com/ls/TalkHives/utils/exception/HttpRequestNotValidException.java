package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class HttpRequestNotValidException extends BaseException {

	private static final long serialVersionUID = 1L;

	public HttpRequestNotValidException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public HttpRequestNotValidException() {
		super(ExceptionStatus.HTTP_REQUEST_METHOD_NOT_VALID);
	}
}