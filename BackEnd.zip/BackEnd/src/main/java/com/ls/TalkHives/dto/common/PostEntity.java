package com.ls.TalkHives.dto.common;

import java.util.Date;
import java.util.List;

public class PostEntity {
    private Long postId;

    private String postTag;
    private String title;
    private String message;
    private String info;
    private Boolean shared;

    private Integer likes;
    private Integer comments;
    private Integer share;
    private Boolean liked;
    private Boolean self;
    private Date createdAt;

    private List<FileEntity> files;
    private PrivacyLevelEntity privacy;
    private UserInfo sharedBy;
    private UserInfo user;

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getPostTag() {
        return postTag;
    }

    public void setPostTag(String postTag) {
        this.postTag = postTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Boolean getShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

    public Integer getLikes() {
        return likes;
    }

    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    public Integer getComments() {
        return comments;
    }

    public void setComments(Integer comments) {
        this.comments = comments;
    }

    public Integer getShare() {
        return share;
    }

    public void setShare(Integer share) {
        this.share = share;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public Boolean getSelf() {
        return self;
    }

    public void setSelf(Boolean self) {
        this.self = self;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public List<FileEntity> getFiles() {
        return files;
    }

    public void setFiles(List<FileEntity> files) {
        this.files = files;
    }

    public PrivacyLevelEntity getPrivacy() {
        return privacy;
    }

    public void setPrivacy(PrivacyLevelEntity privacy) {
        this.privacy = privacy;
    }

    public UserInfo getSharedBy() {
        return sharedBy;
    }

    public void setSharedBy(UserInfo sharedBy) {
        this.sharedBy = sharedBy;
    }

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }
}
