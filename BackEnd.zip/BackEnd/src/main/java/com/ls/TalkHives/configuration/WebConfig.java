//package com.ls.TalkHives.configuration;
//
//import com.ls.TalkHives.dao.AppUserDetailsService;
//import com.ls.TalkHives.utils.enums.UserRoleType;
//import org.apache.http.client.HttpClient;
//import org.apache.http.impl.client.HttpClientBuilder;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Configurable;
//import org.springframework.context.annotation.Bean;
//import org.springframework.core.annotation.Order;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.MediaType;
//import org.springframework.http.client.ClientHttpRequestFactory;
//import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
//import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
//import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.builders.WebSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.csrf.CsrfFilter;
//import org.springframework.security.web.csrf.CsrfToken;
//import org.springframework.security.web.csrf.CsrfTokenRepository;
//import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
//import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
//import org.springframework.security.web.util.matcher.RequestMatcher;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.filter.OncePerRequestFilter;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
//import org.springframework.web.util.WebUtils;
//
//import javax.servlet.Filter;
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.util.Collections;
//import java.util.regex.Pattern;
//
//@Configurable
//// @EnableJpaRepositories({"com.ls.TalkHives.entities"})
//@EnableWebSecurity
//@Order(1)
//// Modifying or overriding the default spring boot security.
//public class WebConfig extends WebSecurityConfigurerAdapter {
//
//    private static final Logger logger = LoggerFactory.getLogger(WebSocketEventListener.class);
//
//    @Autowired
//    AppUserDetailsService appUserDetailsService;
//
//    // This method is for overriding the default AuthenticationManagerBuilder.
//    // We can specify how the user details are kept in the application. It may
//    // be in a database, LDAP or in memory.
//    @Override
//    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//        auth.userDetailsService(appUserDetailsService);
//        auth.authenticationProvider(authenticationProvider());
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//
//    @Bean
//    public DaoAuthenticationProvider authenticationProvider() {
//        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
//        authenticationProvider.setUserDetailsService(appUserDetailsService);
//        authenticationProvider.setPasswordEncoder(passwordEncoder());
//        return authenticationProvider;
//    }
//
//    // this configuration allow the client app to access the this api
//    // all the domain that consume this api must be included in the allowed o'rings
//    @Bean
//    public WebMvcConfigurer mvcConfigurer() {
//        return new WebMvcConfigurerAdapter() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                // registry.addMapping("/**").allowedOrigins("http://localhost:4200");
//                // registry.addMapping("/**").allowedOrigins("http://192.168.0.22:8081/907/#/");
//                registry.addMapping("/**").allowedOrigins("http://192.168.0.13:5020");
//            }
//        };
//    }
//
//    // This method is for overriding some configuration of the WebSecurity
//    // If you want to ignore some request or request patterns then you can
//    // specify that inside this method
//    @Override
//    public void configure(WebSecurity web) throws Exception {
//        super.configure(web);
//    }
//
//    // This method is used for override HttpSecurity of the web Application.
//    // We can specify our authorization criteria inside this method.
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//        http.csrf().csrfTokenRepository(csrfTokenRepository())
//                .requireCsrfProtectionMatcher(csrfRequestMatcher).and()
//                .addFilterAfter(csrfHeaderFilter(), CsrfFilter.class);
//
//        http.cors().and()
//                // starts authorizing configurations
//                .authorizeRequests()
//                // ignoring the guest's urls "
//                .antMatchers("/", "/login").permitAll()
//                .antMatchers("/userController/register").permitAll()
//                .antMatchers(HttpMethod.GET,"/clientController/1/fetch/all").permitAll()
//                .antMatchers(HttpMethod.GET,"/blogController/1/fetch/all").permitAll()
//                .antMatchers(HttpMethod.GET,"/newController/1/new").permitAll()
//                .antMatchers(HttpMethod.GET,"/newController/login").permitAll()
//                // authenticate all remaining URLS
//                // .anyRequest().fullyAuthenticated().and() // .anyRequest().permitAll().and()
//                .anyRequest().authenticated().and() // .anyRequest().permitAll().and()
//
//
//                // enabling the basic authentication
//                .httpBasic().and()
//                //"/logout" will log the user out by invalidating the HTTP Session,
//                //                cleaning up any {link rememberMe()} authentication that was configured,
//                .logout()
//                .permitAll()
//                .logoutRequestMatcher(new AntPathRequestMatcher("/logout", "POST"))
//                .logoutSuccessUrl("/login")
//                .deleteCookies("JSESSIONID").permitAll();
//
//        // configuring the session on the server
//        // .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and()
//        // disabling the CSRF - Cross Site Request Forgery
//        // .csrf().disable();
//    }
//
//    private CsrfTokenRepository csrfTokenRepository() {
//        HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
//        repository.setHeaderName("X-XSRF-TOKEN");
//        return repository;
//    }
//
//    private Filter csrfHeaderFilter() {
//        return new OncePerRequestFilter() {
//            @Override
//            protected void doFilterInternal(HttpServletRequest request,
//                                            HttpServletResponse response, FilterChain filterChain)
//                    throws ServletException, IOException {
//
//                CsrfToken csrf = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
//                System.out.println("doFilter - csrf " + csrf);
//                if (csrf != null) {
//                    Cookie cookie = WebUtils.getCookie(request, "XSRF-TOKEN");
//                    System.out.println("doFilter - cookie " + cookie);
//
//                    String token = csrf.getToken();
//                    System.out.println("doFilter - token " + token);
//
//                    if (cookie == null || token != null && !token.equals(cookie.getValue())) {
//                        cookie = new Cookie("XSRF-TOKEN", token);
//                        cookie.setPath("/");
//                        response.addCookie(cookie);
//                        System.out.println("doFilter - cookie222 " + cookie);
//
//                    }
//                }
//                System.out.println("doFilter - " + request.getMethod());
//                System.out.println("doFilter - " + request.getRequestURL());
//                filterChain.doFilter(request, response);
//            }
//        };
//    }
//
//    @Bean
//    public RestTemplate restTemplate(ClientHttpRequestFactory httpRequestFactory) {
//        RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
//        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
//        converter.setSupportedMediaTypes(Collections.singletonList(MediaType.TEXT_HTML));
//        restTemplate.getMessageConverters().add(converter);
//        return restTemplate;
//    }
//
//    @Bean
//    public ClientHttpRequestFactory httpRequestFactory(HttpClient httpClient) {
//        return new HttpComponentsClientHttpRequestFactory(httpClient);
//    }
//
//    @Bean
//    public HttpClient httpClient() {
//        return HttpClientBuilder.create().build();
//    }
//
//    private RequestMatcher csrfRequestMatcher = new RequestMatcher() {
//
//        // Always allow the HTTP GET,HEAD,TRACE,OPTIONS method
//        private Pattern allowedMethods = Pattern.compile("^(GET|HEAD|TRACE|OPTIONS)$");
//
//        // Disable CSFR protection on the following urls:
//        private AntPathRequestMatcher[] requestMatcher = {
//                new AntPathRequestMatcher("/mobile/**"),
//                new AntPathRequestMatcher("/logout")};
//
//        @Override
//        public boolean matches(HttpServletRequest request) {
//            // Skip allowed methods
//
//            if (allowedMethods.matcher(request.getMethod()).matches()) {
//                return false;
//            }
//
//            System.out.println("Matches - " + request.getMethod());
//            System.out.println("Matches - " + request.getRequestURL());
//
//            // If the request match one url the CSFR protection will be disabled
//            for (AntPathRequestMatcher rm : requestMatcher) {
//                if (rm.matches(request)) {
//                    System.out.println("Matched request disabled");
//                    return false;
//                }
//            }
//
//            return true;
//        } // method matches
//
//    };
//}
