package com.ls.TalkHives.dto.projectController;

import com.ls.TalkHives.dto.common.ProjectEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllProjects {

    private List<ProjectEntity> projects = new ArrayList<>();

    public List<ProjectEntity> getProjects() {
        return projects;
    }

    public void setProjects(List<ProjectEntity> projects) {
        this.projects = projects;
    }
}
