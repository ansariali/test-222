package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.PriorityEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllPriority {

    private List<PriorityEntity> priorities = new ArrayList<>();

    public List<PriorityEntity> getPriorities() {
        return priorities;
    }

    public void setPriorities(List<PriorityEntity> priorities) {
        this.priorities = priorities;
    }
}
