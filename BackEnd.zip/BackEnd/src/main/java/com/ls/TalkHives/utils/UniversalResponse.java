package com.ls.TalkHives.utils;

import java.util.List;

public class UniversalResponse {

    private Boolean status;
    private String subject;
    private String serverUrl;
    private String redirectTo;
    private String message;
    private List<String> descriptions;

    public UniversalResponse(Boolean status) {
        this.status = status;
    }

    public UniversalResponse(Boolean status, String subject) {
        this.status = status;
        this.subject = subject;
    }

    public UniversalResponse(Boolean status, String subject, String serverUrl) {
        this.status = status;
        this.subject = subject;
        this.serverUrl = serverUrl;
    }

    public UniversalResponse(Boolean status, String subject, String serverUrl, String redirectTo) {
        this.status = status;
        this.subject = subject;
        this.serverUrl = serverUrl;
        this.redirectTo = redirectTo;
    }

    public UniversalResponse(Boolean status, String subject, String serverUrl, String redirectTo, String message) {
        this.status = status;
        this.subject = subject;
        this.serverUrl = serverUrl;
        this.redirectTo = redirectTo;
        this.message = message;
    }

    public UniversalResponse(Boolean status, String subject, String serverUrl, String redirectTo, String message, List<String> descriptions) {
        this.status = status;
        this.subject = subject;
        this.serverUrl = serverUrl;
        this.redirectTo = redirectTo;
        this.message = message;
        this.descriptions = descriptions;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public void setServerUrl(String serverUrl) {
        this.serverUrl = serverUrl;
    }

    public String getRedirectTo() {
        return redirectTo;
    }

    public void setRedirectTo(String redirectTo) {
        this.redirectTo = redirectTo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<String> getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(List<String> descriptions) {
        this.descriptions = descriptions;
    }
}