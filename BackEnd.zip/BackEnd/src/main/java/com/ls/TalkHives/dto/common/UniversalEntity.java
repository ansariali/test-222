package com.ls.TalkHives.dto.common;

public class UniversalEntity {

    private Long version;

    private Boolean deleted;

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}