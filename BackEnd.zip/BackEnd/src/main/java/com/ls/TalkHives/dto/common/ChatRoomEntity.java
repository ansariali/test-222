package com.ls.TalkHives.dto.common;

import com.ls.TalkHives.entities.ChatRoomMembers;
import com.ls.TalkHives.entities.Users;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class ChatRoomEntity {
    private Long chatRoomId;

    private String chatRoomTag;
    private String name;
    private String info;
    private String status;
    private Boolean groupChat;
    private _UserEntity users;
    private _UserEntity userOne;
    private _UserEntity userTwo;
    private Date createdAt;

    private List<ChatRoomMemberEntity> members;

    public Long getChatRoomId() {
        return chatRoomId;
    }

    public void setChatRoomId(Long chatRoomId) {
        this.chatRoomId = chatRoomId;
    }

    public String getChatRoomTag() {
        return chatRoomTag;
    }

    public void setChatRoomTag(String chatRoomTag) {
        this.chatRoomTag = chatRoomTag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getGroupChat() {
        return groupChat;
    }

    public void setGroupChat(Boolean groupChat) {
        this.groupChat = groupChat;
    }

    public _UserEntity getUsers() {
        return users;
    }

    public void setUsers(_UserEntity users) {
        this.users = users;
    }

    public _UserEntity getUserOne() {
        return userOne;
    }

    public void setUserOne(_UserEntity userOne) {
        this.userOne = userOne;
    }

    public _UserEntity getUserTwo() {
        return userTwo;
    }

    public void setUserTwo(_UserEntity userTwo) {
        this.userTwo = userTwo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public List<ChatRoomMemberEntity> getMembers() {
        return members;
    }

    public void setMembers(List<ChatRoomMemberEntity> members) {
        this.members = members;
    }
}
