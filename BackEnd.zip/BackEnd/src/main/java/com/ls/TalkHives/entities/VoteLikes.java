package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * VoteLikes Entity
 */

@Entity
@Table(name = "vote_likes")
public class VoteLikes extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long voteLikeId;

    private String voteLikeTag;
    private Boolean liked;
    private String info;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "voteId")
    private Votes votes;

    public Long getVoteLikeId() {
        return voteLikeId;
    }

    public void setVoteLikeId(Long voteLikeId) {
        this.voteLikeId = voteLikeId;
    }

    public String getVoteLikeTag() {
        return voteLikeTag;
    }

    public void setVoteLikeTag(String voteLikeTag) {
        this.voteLikeTag = voteLikeTag;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Votes getVotes() {
        return votes;
    }

    public void setVotes(Votes votes) {
        this.votes = votes;
    }
}



