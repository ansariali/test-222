package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.FrequencyEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllFrequency {

    private List<FrequencyEntity> frequencies = new ArrayList<>();

    public List<FrequencyEntity> getFrequencies() {
        return frequencies;
    }

    public void setFrequencies(List<FrequencyEntity> frequencies) {
        this.frequencies = frequencies;
    }
}
