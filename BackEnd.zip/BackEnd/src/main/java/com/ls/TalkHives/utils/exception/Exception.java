package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class Exception extends BaseException {

	private static final long serialVersionUID = 1L;

	public Exception(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public Exception() {
		super(ExceptionStatus.GENERIC_FAILURE);
	}
}