package com.ls.TalkHives.dto.common;

import java.math.BigDecimal;
import java.util.Date;

public class ProjectCommentEntity {
    private Long projectCommentId;
    private String message;
    private Date createdAt;

    private UserInfo users;

    public Long getProjectCommentId() {
        return projectCommentId;
    }

    public void setProjectCommentId(Long projectCommentId) {
        this.projectCommentId = projectCommentId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }
}
