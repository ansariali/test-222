package com.ls.TalkHives.services;

import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface PublicService {

    Map<String, List<UserRole>> getUserRoles(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    UniversalResponse verifyInvitation(String token, IDao<IEntity, Serializable> iDao);

    UniversalResponse verifyUserName(String userName, IDao<IEntity, Serializable> iDao);

    UniversalResponse verifyEmailId(String emailId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Invitations>> getInvitations(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Users>> getUsers(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<PrivacyLevel>> getPrivacyLevels(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Users getUser(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Status>> getAllStatus(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Priority>> getPriorities(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Frequency>> getFrequencies(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<UserActivity>> getActivities(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}