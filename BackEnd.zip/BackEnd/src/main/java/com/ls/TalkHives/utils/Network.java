package com.ls.TalkHives.utils;

import com.ls.TalkHives.utils.impl.NetworkResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

public class Network {

    private static final String TAG = Network.class.getSimpleName();

    private static Logger mLogger = Logger.getInstance(true, Network.class);

    public static void makeHttpRequest(String requestMethod, String requestUrl, Map<String, String> requestParams, Map<String, String> requestHeader, String requestBody, NetworkResponse response) {
        try {
            mLogger.info(TAG, "S2S Url: " + requestUrl);

            URL uRL;
            HttpURLConnection httpURLConnection;
            if (requestParams.size() > 0) {
                StringBuilder stringBuilder = new StringBuilder();

                stringBuilder.append(requestUrl);
                stringBuilder.append("?");

                Integer numOfParams = requestParams.size();

                for (Map.Entry<String, String> entry : requestParams.entrySet()) {
                    stringBuilder.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                    stringBuilder.append("=");
                    stringBuilder.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
                    if(numOfParams > 1) {
                        stringBuilder.append("&");
                    }
                    numOfParams--;
                }

                requestUrl = stringBuilder.toString();
            }

            uRL = new URL(requestUrl);
            httpURLConnection = (HttpURLConnection) uRL.openConnection();

            httpURLConnection.setRequestMethod(requestMethod);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setConnectTimeout(60000);
            httpURLConnection.setReadTimeout(60000);

            if (requestHeader.size() > 0) {
                for (Map.Entry<String, String> entry : requestHeader.entrySet()) {
                    httpURLConnection.setRequestProperty(entry.getKey(), entry.getValue());
                }
            }

            httpURLConnection.connect();

            if(requestBody != null) {
                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(requestBody.getBytes());
                outputStream.flush();
            }

            StringBuilder responseBody = new StringBuilder();

            try {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((httpURLConnection.getInputStream())));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    responseBody.append(line);
                }
                httpURLConnection.disconnect();

                response.onSuccess(httpURLConnection.getResponseCode(), httpURLConnection.getHeaderFields(), responseBody.toString());
            } catch (IOException e) {
                response.onFailure(httpURLConnection.getResponseCode(), httpURLConnection.getHeaderFields(), responseBody.toString());
            }
        } catch (IOException e) {
            mLogger.error(TAG, e);
            e.printStackTrace();
        }
    }
}