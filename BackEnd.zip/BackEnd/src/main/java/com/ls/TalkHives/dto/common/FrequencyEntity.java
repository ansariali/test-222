package com.ls.TalkHives.dto.common;

public class FrequencyEntity {
    private Long frequencyTag;
    private String title;

    public Long getFrequencyTag() {
        return frequencyTag;
    }

    public void setFrequencyTag(Long frequencyTag) {
        this.frequencyTag = frequencyTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
