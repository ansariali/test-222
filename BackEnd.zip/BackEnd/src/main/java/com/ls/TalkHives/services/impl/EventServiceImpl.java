package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.MeetingEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Events;
import com.ls.TalkHives.entities.Maintenance;
import com.ls.TalkHives.entities.Meetings;
import com.ls.TalkHives.services.EventService;
import com.ls.TalkHives.services.impl.handler.EventServiceImplHandler;
import com.ls.TalkHives.utils.Logger;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;

@Service
@Transactional
public class EventServiceImpl extends EventServiceImplHandler implements EventService {

    protected static Logger logger = Logger.getInstance(true, EventServiceImpl.class);

    private static final String TAG = EventServiceImpl.class.getSimpleName();

    @Override
    public void eventTest() {
        // Integer period = 1000;
        // Integer delay = 0;
        // class SayHello extends TimerTask {
        //     public void run() {
        //         logger.info(TAG, "Finally Date: " + new Date());
        //     }
        // }
        //
        // new SayHello();
        // Timer timer = new Timer();
        // timer.schedule(new SayHello(), delay, period);

        // meetingEvent();

    }

    @Override
    public void eventStart(IDao<IEntity, Serializable> iDao) {
        resetMeetingEvent(null, null, iDao);
    }

    @Override
    public void create(WsResponse wsResponse, IDao<IEntity, Serializable> iDao) {
        Maintenance maintenance = getMaintenance(iDao);

        if (wsResponse.getActivity().equals(Ascii.MEETING.getCode())) {
            Meetings meetings = iDao.find(Meetings.class, wsResponse.getActivityId());
            createMeetingEvent(maintenance, meetings, iDao);
        }
    }

    @Override
    public void update(WsResponse wsResponse, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();
        List<Events> list;

        if (wsResponse.getActivity().equals(Ascii.MEETING.getCode())) {
            hashtable.put("meetings", iDao.find(Meetings.class, wsResponse.getActivityId()));
            list = iDao.getEntities(Events.class, queryManager.getMeetingEvent(), hashtable, false);
            hashtable.clear();

            for (Events events : list) {
                MeetingEntity meetingEntity = (MeetingEntity) wsResponse.getContent();
                events.setTiming(meetingEntity.getTiming());
            }

            list.sort(Comparator.comparing(Events::getTiming));

            // Refresh Event
            resetMeetingEvent(null, list.get(0).getTiming(), iDao);
        }
    }

    @Override
    public void delete(WsResponse wsResponse, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();
        List<Events> list;

        if (wsResponse.getActivity().equals(Ascii.MEETING.getCode())) {
            hashtable.clear();
            hashtable.put("meetings",  iDao.find(Meetings.class, wsResponse.getActivityId()));
            list = iDao.getEntities(Events.class, queryManager.getMeetingEvent(), hashtable, false);
            hashtable.clear();

            for (Events events : list) {
                iDao.delete(events);
            }

            list.sort(Comparator.comparing(Events::getTiming));

            // Refresh Event
            resetMeetingEvent(null, list.get(0).getTiming(), iDao);
        }
    }

    /*@Override
    public void meetingEvent(Maintenance maintenance, IDao<IEntity, Serializable> iDao) {
        if (maintenance.getMeetingEvent()) {
            // Todo: 2nd Time +
        } else {
            // Get Next Meeting Timing
            // logger.info(TAG, "Before null " + getNextMeeting(iDao));
            // Meetings meetings = getNextMeeting(iDao);
            // logger.info(TAG, "Before null " + meetings.getMeetingId());

            List<Events> list = iDao.getEntities(Events.class, queryManager.getAllNextMeetingEvents());

            if (list.size() > 0) {
                logger.info(TAG, "Before maintenance.setMeetingEvent " + maintenance.getMeetingEvent());

                maintenance.setMeetingEvent(Boolean.TRUE);

                logger.info(TAG, "After maintenance.setMeetingEvent " + maintenance.getMeetingEvent());

                // Get Timing for Thread or Loop
                Date currentTime = getCurrentTime();
                Date futureTime = list.get(0).getTiming();

                // Todo: WorldWild [ Switch-case according to Org.Timezone then loop also need update ]
                Long delay = currentTime.getTime() - getIndianTime(futureTime).getTime();
                Integer period = 1000;
                class execute extends TimerTask {
                    public void run() {
                        logger.info(TAG, "Checkpoint | run-meetingEvent: ");

                        for (Events events : list) {
                            Meetings meetings = events.getMeetings();
                            for (MeetingMembers meetingMembers : meetings.getMembers()) {
                                String message = "Meeting 6 la jaldi dod " + meetings.getTitle();
                                notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(),
                                        Boolean.TRUE, message, meetingMembers.getUsers(), meetings.getUsers(), iDao);

                                create();


                            }
                        }

                        // logger.info(TAG, "Checkpoint | iDao.delete(meetings)-meetingEvent: " + meetings.getDeleted());
                        // iDao.delete(meetings);
                        // logger.info(TAG, "Checkpoint | iDao.delete(meetings)-meetingEvent: " + meetings.getDeleted());
                        //
                        // if (meetings.getDeleted()) {
                        //     logger.info(TAG, "Checkpoint | meetingEvent_restart-meetingEvent: " + meetings.getDeleted());
                        //     meetingEvent(iDao);
                        // }
                    }
                }

                new execute();
                Timer timer = new Timer();
                timer.schedule(new execute(), delay, period);


            }
        }
    }*/



   /* private void _eventTest() throws InterruptedException {
        String loggerText = "Inside run";
        Long diff = 0L;

        List<Meetings> list = iDao.findAll(Meetings.class, false);

        for (Meetings meetings : list) {
            // logger.info(TAG, "Inside For loop title: " + meetings.getTitle());
            // logger.info(TAG, "Inside For loop timing: " + meetings.getTiming());
            Long diff1;
            diff1 = new Date().getTime() - getIndianTime(meetings.getTiming()).getTime();

            logger.info(TAG, "Gapppppppppp >>>>>>>>> " + diff);
        }

        Thread.sleep(diff);

        logger.info(TAG, loggerText + new Date());


        // Thread.sleep(6000);
        class SayHello extends TimerTask {
            public void run() {

                List<Meetings> list = iDao.findAll(Meetings.class, false);

                for (Meetings meetings : list) {
                    // logger.info(TAG, "Inside For loop title: " + meetings.getTitle());
                    // logger.info(TAG, "Inside For loop timing: " + meetings.getTiming());


                    diff = new Date().getTime() - getIndianTime(meetings.getTiming()).getTime();

                    long diffSeconds = diff / 1000 % 60;
                    long diffMinutes = diff / (60 * 1000) % 60;
                    long diffHours = diff / (60 * 60 * 1000) % 24;
                    long diffDays = diff / (24 * 60 * 60 * 1000);

                    System.out.print(diffDays + " days, ");
                    System.out.print(diffHours + " hours, ");
                    System.out.print(diffMinutes + " minutes, ");
                    System.out.print(diffSeconds + " seconds.");

                    logger.info(TAG, "Gapppppppppp >>>>>>>>> " + diff);


                }

                logger.info(TAG, loggerText + new Date());


            }
        }

        new SayHello();
        Integer period = 2500;
        Timer timer = new Timer();
        timer.schedule(new SayHello(), 0, diff);
    }*/

    /*private void eventTest() {
        Integer period = 1000;
        Integer delay = 0;
        class SayHello extends TimerTask {
            public void run() {
                logger.info(TAG, "Finally Date: " + new Date());
            }
        }

        new SayHello();
        Timer timer = new Timer();
        timer.schedule(new SayHello(), delay, period);

    }
*/
}