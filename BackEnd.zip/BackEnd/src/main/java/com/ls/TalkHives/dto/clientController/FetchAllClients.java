package com.ls.TalkHives.dto.clientController;

import com.ls.TalkHives.dto.common.ClientEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllClients {

    private List<ClientEntity> clients = new ArrayList<>();

    public List<ClientEntity> getClients() {
        return clients;
    }

    public void setClients(List<ClientEntity> clients) {
        this.clients = clients;
    }
}
