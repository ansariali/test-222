package com.ls.TalkHives.utils.impl;

import com.ls.TalkHives.entities.Users;

import java.util.Date;

public interface IEntity {
    Long getVersion();

    void setVersion(Long version);

    Boolean getDeleted();

    void setDeleted(Boolean deleted);

    Date getDeletedAt();

    void setDeletedAt(Date deletedAt);

    Users getDeletedBy();

    void setDeletedBy(Users deletedBy);

    Date getCreatedAt();

    void setCreatedAt(Date createdAt);

    Date getUpdatedAt();

    void setUpdatedAt(Date updatedAt);

    Users getUpdatedBy();

    void setUpdatedBy(Users updatedBy);
}