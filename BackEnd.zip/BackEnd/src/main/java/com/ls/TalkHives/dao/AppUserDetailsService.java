package com.ls.TalkHives.dao;

import com.ls.TalkHives.entities.User;
import com.ls.TalkHives.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    UserServices userServices;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        System.out.println("loadUserByUsername username " + userName);
        User user = userServices.find(userName);
        System.out.println("loadUserByUsername user " + user);

        return user;
    }

}
