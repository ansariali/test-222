package com.ls.TalkHives.dto.taskController;

import com.ls.TalkHives.dto.common.StatusEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.projectController.fetchProject;

import java.util.Date;

public class ProjectMilestoneE {
    private Long projectMilestoneId;
    private String name;
    private String info;
    private Date initialDate;
    private Date deadline;
    private Integer level;
    private Double completion;
    private Integer totalTask;
    private Double taskPercentage;
    private Date createdAt;
    private StatusEntity status;
    private UserInfo users;
    private fetchProject projects;

    public Long getProjectMilestoneId() {
        return projectMilestoneId;
    }

    public void setProjectMilestoneId(Long projectMilestoneId) {
        this.projectMilestoneId = projectMilestoneId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Double getCompletion() {
        return completion;
    }

    public void setCompletion(Double completion) {
        this.completion = completion;
    }

    public Integer getTotalTask() {
        return totalTask;
    }

    public void setTotalTask(Integer totalTask) {
        this.totalTask = totalTask;
    }

    public Double getTaskPercentage() {
        return taskPercentage;
    }

    public void setTaskPercentage(Double taskPercentage) {
        this.taskPercentage = taskPercentage;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public StatusEntity getStatus() {
        return status;
    }

    public void setStatus(StatusEntity status) {
        this.status = status;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }

    public fetchProject getProjects() {
        return projects;
    }

    public void setProjects(fetchProject projects) {
        this.projects = projects;
    }
}
