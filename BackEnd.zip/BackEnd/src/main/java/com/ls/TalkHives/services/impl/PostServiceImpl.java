package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.*;
import com.ls.TalkHives.dto.postController.*;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.PostService;
import com.ls.TalkHives.services.impl.handler.PostServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.*;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class PostServiceImpl extends PostServiceImplHandler implements PostService {

    private static final String TAG = PostServiceImpl.class.getSimpleName();

    @Override
    public Posts create(CreatePostRequest createPostRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(createPostRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        Users users = findUserByLoginToken(requestHeader, iDao);

        Posts posts = new Posts();

        posts.setTitle(createPostRequest.getTitle());
        posts.setMessage(createPostRequest.getMessage());
        posts.setInfo(createPostRequest.getInfo());
        posts.setLikes(0);
        posts.setComments(0);
        posts.setShare(0);
        posts.setShared(Boolean.FALSE);
        posts.setUser(users);
        posts.setOrganizations(users.getOrganizations());
        posts.setCreatedAt(getCurrentTime());

        Posts posts_ = iDao.find(Posts.class, iDao.persist(posts));
        checkNullObject(posts_, ExceptionStatus.NEW_NOT_ADDED);

        posts.setPrivacyLevel(findPrivacyLevel(createPostRequest.getPrivacyTag(), iDao));

        HashSet<PostSharing> postSharing = new HashSet<>();
        if (createPostRequest.getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL10.getGlobalTag())) {
            for (UserInfo userInfo : createPostRequest.getSpecificUsers()) {
                PostSharing postSharing_ = new PostSharing();
                postSharing_.setUser(iDao.find(Users.class, userInfo.getUserId()));
                postSharing_.setPosts(posts_);
                postSharing_.setCreatedAt(getCurrentTime());
                postSharing.add(postSharing_);
            }
        }

        HashSet<PostFiles> postFiles_ = new HashSet<>();

        for (FileEntity fileEntity : createPostRequest.getFiles()) {
            PostFiles postFiles = new PostFiles();
            postFiles.setFileTag(fileEntity.getFileTag());
            postFiles.setFileName(fileEntity.getName());
            postFiles.setType(fileEntity.getType());
            postFiles.setPosts(posts_);
            postFiles.setCreatedAt(posts_.getCreatedAt());

            String prefix = S3Storage.FOLDER_POST.getValue() + S3Storage.SUFFIX.getValue() + posts_.getPostId() + S3Storage.SUFFIX.getValue() + fileEntity.getName();
            postFiles.setFileUrl(s3StorageService.copyFile(prefix, fileEntity.getFileUrl()));
            postFiles_.add(postFiles);
        }

        posts_.setFiles(postFiles_);
        posts_.setPostSharing(postSharing);

        send(posts_, users, iDao);

        sendPost(Activity.CREATE_POST.getActivity(), posts_, users, iDao);

        return posts_;
    }

    @Override
    public Map<String, List<PostEntity>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        Map<String, List<PostEntity>> map = new HashMap<>();
        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        hashtable.put("privacyLevel", iDao.find(PrivacyLevel.class, users.getUserRole().getRoleId()));
        List<Posts> list = iDao.getEntities(Posts.class, queryManager.getAllPosts(), hashtable, false);
        hashtable.clear();

        List<Posts> list_ = new ArrayList<>();

        // Filter Post according to privacy
        for (Posts posts : list) {
            if (!posts.getUser().getUserId().equals(users.getUserId())) {
                if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL10.getGlobalTag())) {
                    hashtable.put("user", users);
                    hashtable.put("posts", posts);
                    PostSharing postSharing = iDao.getEntity(PostSharing.class, queryManager.getPostSharing(), hashtable, false);
                    hashtable.clear();

                    if (postSharing == null) {
                        list_.add(posts);
                    }
                }
            }
        }
        list.removeAll(list_);

        // Fetch OnlyMe Post
        hashtable.put("user", users);
        hashtable.put("privacyLevel", iDao.find(PrivacyLevel.class, GlobalTag.PRIVACY_LEVEL1.getLongTag()));
        List<Posts> _list = iDao.getEntities(Posts.class, queryManager.getAllOnlyMePost(), hashtable, false);
        hashtable.clear();

        list.addAll(_list);

        List<PostEntity> posts_ = new ArrayList<>();

        // Post liked or not & Self
        for (Posts posts : list) {
            PostEntity postEntity = modelMapper.map(posts, PostEntity.class);

            hashtable.put("posts", posts);
            hashtable.put("users", users);
            PostLikes postLikes = iDao.getEntity(PostLikes.class, queryManager.getPostLike(), hashtable, false);
            hashtable.clear();

            if (postLikes != null) {
                postEntity.setLiked(postLikes.getLiked());
            } else {
                postEntity.setLiked(null);
            }

            if (users.getUserId().equals(posts.getUser().getUserId())) {
                postEntity.setSelf(Boolean.TRUE);
            } else {
                postEntity.setSelf(Boolean.FALSE);
            }

            posts_.add(postEntity);
        }

        posts_.sort(Comparator.comparing(PostEntity::getCreatedAt));

        map.put("posts", posts_);

        return map;
    }

    @Override
    public void send(Posts posts, Users users, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside Post Send");
        PostEntity postEntity = modelMapper.map(posts, PostEntity.class);

        String message;

        if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL10.getGlobalTag())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_POST.getSendTo().replace("{userId}", posts.getUser().getUserId().toString()), postEntity);
            for (PostSharing postSharing : posts.getPostSharing()) {
                simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_POST.getSendTo().replace("{userId}", "" + postSharing.getUser().getUserId()), postEntity);

                message = Notification.CREATE_POST.getPublicMessage().replace("{user}", users.getFirstName() + " " + users.getLastName());
                notificationService.sentToUser(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, postSharing.getUser(), users, iDao);
            }
        } else if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL9.getGlobalTag()) || posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL6.getGlobalTag())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_ORGANIZATION_POST.getSendTo().replace("{organizationId}", users.getOrganizations().getOrganizationId().toString()), postEntity);

            if (posts.getShared()) {
                message = Notification.SHARE_POST.getPublicMessage().replace("{creator}", posts.getSharedBy().getFirstName() + " " + posts.getSharedBy().getLastName()).replace("{user}", posts.getUser().getFirstName() + " " + posts.getUser().getLastName());
                notificationService.sentToOrganization(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);

                message = Notification.SHARE_POST.getSelfMessage().replace("{creator}", posts.getSharedBy().getFirstName() + " " + posts.getSharedBy().getLastName());
                notificationService.sentToUser(posts.getPostId(), Ascii.POST.getCode(), Boolean.TRUE, message, posts.getUser(), users, iDao);

            } else {
                message = Notification.CREATE_POST.getPublicMessage().replace("{user}", users.getFirstName() + " " + users.getLastName());
                notificationService.sentToOrganization(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);
            }

        } else if (Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag()) > 0 && Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag()) < 6) {

            int j = Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag());
            message = Notification.CREATE_POST.getPublicMessage()
                    .replace("{user}", users.getFirstName() + " " + users.getLastName());
            for (int i = 1; i <= j; i++) {
                simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_DESIGNATION_POST.getSendTo().replace("{userRoleTag}", "" + i), postEntity);

                notificationService.sendToDesignation(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);
            }
        } else if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL0.getGlobalTag())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_POST.getSendTo().replace("{userId}", posts.getUser().getUserId().toString()), postEntity);
        }
    }

    @Override
    public CreateCommentLikeResponse createCommentLikes(CreateCommentLikeRequest createCommentLikeRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(createCommentLikeRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(createCommentLikeRequest.getCommentId(), ExceptionStatus.COMMENT_ID_MISSING);

        PostComments comment = iDao.find(PostComments.class, createCommentLikeRequest.getCommentId());
        checkNullObject(comment, ExceptionStatus.COMMENT_NOT_FOUND);

        Hashtable<String, Object> hashTable = new Hashtable<>();
        hashTable.put("usersId", users);
        hashTable.put("commentId", comment);
        CommentLikes commentLikes = iDao.getEntity(CommentLikes.class, queryManager.getCommentLike(), hashTable, false);
        hashTable.clear();

        if (commentLikes != null) {
            if (createCommentLikeRequest.getLiked()) {
                commentLikes.setLiked(createCommentLikeRequest.getLiked());
                commentLikes.setDeleted(Boolean.FALSE);
                commentLikes.setDeletedAt(null);
                commentLikes.setUpdatedAt(util.getCurrentTime());
                if (commentLikes.getLiked()) {
                    comment.setTotalLikes(comment.getTotalLikes() + 1);
                } else {
                    comment.setTotalLikes(comment.getTotalLikes() - 1);
                }
            } else {
                commentLikes.setDeleted(Boolean.TRUE);
                commentLikes.setDeletedAt(util.getCurrentTime());
                if (commentLikes.getLiked()) {
                    comment.setTotalLikes(comment.getTotalLikes() - 1);
                } else {
                    comment.setTotalLikes(comment.getTotalLikes() + 1);
                }
            }
        } else {

            CommentLikes commentLikes_ = new CommentLikes();
            commentLikes_.setLiked(createCommentLikeRequest.getLiked());
            commentLikes_.setUsersId(users);
            commentLikes_.setCommentId(iDao.find(PostComments.class, createCommentLikeRequest.getCommentId()));
            commentLikes_.setCreatedAt(getCurrentTime());
            CommentLikes _commentLikes = iDao.find(CommentLikes.class, iDao.persist(commentLikes_));
            checkNullObject(_commentLikes, ExceptionStatus.NEW_NOT_ADDED);
                if (_commentLikes.getLiked()) {
                    comment.setTotalLikes(comment.getTotalLikes() + 1);
                } else {
                    comment.setTotalLikes(comment.getTotalLikes() - 1);
                }
        }

        CreateCommentLikeResponse createCommentLikeResponse = new CreateCommentLikeResponse();
        createCommentLikeResponse.setPostCommentId(createCommentLikeRequest.getCommentId());
        createCommentLikeResponse.setUserId(users.getUserId());
        createCommentLikeResponse.setLiked(createCommentLikeRequest.getLiked());
        createCommentLikeResponse.setTotalLikes(comment.getTotalLikes());

        return createCommentLikeResponse;
    }

    @Override
    public CreatePostLikeResponse createLike(CreatePostLikeRequest createPostLikeRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);

        checkNullObject(createPostLikeRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(createPostLikeRequest.getPostId(), ExceptionStatus.POST_ID_MISSING);

        Posts posts = iDao.find(Posts.class, createPostLikeRequest.getPostId());

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("users", users);
        hashtable.put("posts", posts);
        PostLikes postLikes_ = iDao.getEntity(PostLikes.class, queryManager.getPostLike(), hashtable);
        hashtable.clear();

        if (postLikes_ != null) {
            if (createPostLikeRequest.getLiked()) {
                postLikes_.setLiked(createPostLikeRequest.getLiked());
                postLikes_.setDeleted(Boolean.FALSE);
                postLikes_.setDeletedAt(null);
                postLikes_.setUpdatedAt(util.getCurrentTime());

                if (postLikes_.getLiked()) {
                    posts.setLikes(posts.getLikes() + 1);
                } else {
                    posts.setLikes(posts.getLikes() - 1);
                }
            } else {
                postLikes_.setDeleted(Boolean.TRUE);
                postLikes_.setDeletedAt(util.getCurrentTime());

                if (postLikes_.getLiked()) {
                    posts.setLikes(posts.getLikes() - 1);
                } else {
                    posts.setLikes(posts.getLikes() + 1);
                }
            }
        } else {
            PostLikes postLikes = new PostLikes();
            postLikes.setLiked(createPostLikeRequest.getLiked());
            postLikes.setUsers(users);
            postLikes.setPosts(iDao.find(Posts.class, createPostLikeRequest.getPostId()));
            postLikes.setCreatedAt(getCurrentTime());
            PostLikes _PostLikes = iDao.find(PostLikes.class, iDao.persist(postLikes));
            checkNullObject(_PostLikes, ExceptionStatus.NEW_NOT_ADDED);

            if (_PostLikes.getLiked()) {
                posts.setLikes(posts.getLikes() + 1);
            } else {
                posts.setLikes(posts.getLikes() - 1);
            }
        }

        CreatePostLikeResponse createPostLikeResponse = new CreatePostLikeResponse();
        createPostLikeResponse.setPostId(createPostLikeRequest.getPostId());
        createPostLikeResponse.setUserId(users.getUserId());
        createPostLikeResponse.setLiked(createPostLikeRequest.getLiked());
        createPostLikeResponse.setLikes(posts.getLikes());

//        notificationService.postNotification("LIKE_POST", posts, users, iDao);

        return createPostLikeResponse;
    }

    @Override
    public PostCommentEntity createComment(CreatePostCommentRequest createPostCommentRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        checkNullObject(createPostCommentRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(createPostCommentRequest.getPostId(), ExceptionStatus.POST_ID_MISSING);

        Posts posts = iDao.find(Posts.class, createPostCommentRequest.getPostId());

        PostComments postComments = new PostComments();
        postComments.setMessage(createPostCommentRequest.getMessage());
        postComments.setPosts(posts);
        postComments.setUsers(users);
        postComments.setTotalLikes(0);
        postComments.setCreatedAt(getCurrentTime());

        PostComments postComments_ = iDao.find(PostComments.class, iDao.persist(postComments));
        checkNullObject(postComments_, ExceptionStatus.NEW_NOT_ADDED);

        posts.setComments(posts.getComments() + 1);

        PostCommentEntity postCommentEntity = modelMapper.map(postComments_, PostCommentEntity.class);
        postCommentEntity.setComments(posts.getComments());
        postCommentEntity.setPostId(posts.getPostId());

        notificationService.postNotification("COMMENT_POST", posts, users, iDao);

        return postCommentEntity;
    }

    @Override
    public Map<String, List<PostCommentEntity>> fetchAllComments(Long postId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(postId, ExceptionStatus.POST_ID_MISSING);

        Map<String, List<PostCommentEntity>> map = new HashMap<>();
        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("posts", iDao.find(Posts.class, postId));
        List<PostComments> list = iDao.getEntities(PostComments.class, queryManager.getAllPostComments(), hashtable, false);
        hashtable.clear();

        List<PostCommentEntity> comment_ = new ArrayList<>();
        // Comment liked or not & Self
        for (PostComments postComments : list) {
            PostCommentEntity commentEntity = modelMapper.map(postComments, PostCommentEntity.class);

            hashtable.put("commentId", postComments);
            hashtable.put("usersId", users);
            CommentLikes commentLikes = iDao.getEntity(CommentLikes.class, queryManager.getCommentLike(), hashtable, false);
            hashtable.clear();

            if (commentLikes != null) {
                commentEntity.setLiked(commentLikes.getLiked());
            } else {
                commentEntity.setLiked(null);
            }

            if (users.getUserId().equals(postComments.getUsers().getUserId())) {
                commentEntity.setSelf(Boolean.TRUE);
            } else {
                commentEntity.setSelf(Boolean.FALSE);
            }

            comment_.add(commentEntity);
        }

        comment_.sort(Comparator.comparing(PostCommentEntity::getCreatedAt));
        map.put("postComments", comment_);

        return map;
    }

    @Override
    public Posts share(Long postId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(postId, ExceptionStatus.POST_ID_MISSING);
        Users users = findUserByLoginToken(requestHeader, iDao);

        Posts posts = iDao.find(Posts.class, postId);
        checkNullObject(posts, ExceptionStatus.POST_NOT_FOUND);

        Posts posts_ = new Posts();
        if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL9.getGlobalTag())) {

            Posts _posts = new Posts();
            _posts.setTitle(posts.getTitle());
            _posts.setMessage(posts.getMessage());
            _posts.setPrivacyLevel(posts.getPrivacyLevel());

            _posts.setLikes(0);
            _posts.setComments(0);
            _posts.setShare(0);
            _posts.setShared(Boolean.TRUE);
            _posts.setSharedBy(users);
            _posts.setUser(posts.getUser());
            _posts.setOrganizations(posts.getOrganizations());
            _posts.setCreatedAt(getCurrentTime());

            HashSet<PostFiles> postFiles_ = new HashSet<>();
            postFiles_.addAll(posts.getFiles());
            posts_.setFiles(postFiles_);

            posts_ = iDao.find(Posts.class, iDao.persist(_posts));
            checkNullObject(posts_, ExceptionStatus.NEW_NOT_ADDED);

            posts.setShare(posts.getShare() + 1);
        } else {
            throw new UniversalException(ExceptionStatus.POST_IS_NOT_PUBLIC);
        }

        send(posts_, users, iDao);
        PostEntity postEntity = modelMapper.map(iDao.find(Posts.class, postId), PostEntity.class);
        simpMessagingTemplate.convertAndSend(WSApi.SEND_SHARED_POST.getSendTo().replace("{organizationId}", users.getOrganizations().getOrganizationId().toString()), postEntity);

        return posts_;
    }

    @Override
    public Map<String, List<PostEntity>> fetchPostByUser(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<PostEntity>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        hashtable.put("user", users);
        hashtable.put("sharedBy", users);
        List<Posts> list = iDao.getEntities(Posts.class, queryManager.getAllPostByUser(), hashtable, false);
        hashtable.clear();

        List<PostEntity> posts_ = new ArrayList<>();

        for (Posts posts : list) {
            PostEntity postEntity = modelMapper.map(posts, PostEntity.class);

            hashtable.put("users", users);
            hashtable.put("posts", posts);
            PostLikes postLikes = iDao.getEntity(PostLikes.class, queryManager.getPostLike(), hashtable, false);
            hashtable.clear();

            if (postLikes != null) {
                postEntity.setLiked(postLikes.getLiked());
            } else {
                postEntity.setLiked(null);
            }

            if (users.getUserId().equals(posts.getUser().getUserId())) {
                postEntity.setSelf(Boolean.TRUE);
            } else {
                postEntity.setSelf(Boolean.FALSE);
            }

            posts_.add(postEntity);
        }

        posts_.sort(Comparator.comparing(PostEntity::getCreatedAt));

        map.put("posts", posts_);

        return map;
    }

    @Override
    public PostEntity update(UpdatePostRequest updatePostRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updatePostRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updatePostRequest.getPostId(), ExceptionStatus.POST_ID_MISSING);

        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);
        Posts posts = iDao.find(Posts.class, updatePostRequest.getPostId());

        checkNullObject(posts, ExceptionStatus.POST_NOT_FOUND);

        if (!Objects.equals(posts.getUser(), users)) {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        posts.setTitle(updatePostRequest.getTitle());
        posts.setMessage(updatePostRequest.getMessage());
        posts.setInfo(updatePostRequest.getInfo());
        posts.setPrivacyLevel(findPrivacyLevel(updatePostRequest.getPrivacy().getPrivacyTag(), iDao));

        Set<PostFiles> files = posts.getFiles();

        HashSet<PostFiles> postFiles_ = new HashSet<>();

        for (FileEntity fileEntity : updatePostRequest.getFiles()) {
            if (fileEntity.getPostFilesId() == null) {
                PostFiles postFiles = new PostFiles();
                postFiles.setFileName(fileEntity.getName());
                postFiles.setFileTag(fileEntity.getFileTag());
                postFiles.setType(fileEntity.getType());
                postFiles.setPosts(posts);
                postFiles.setCreatedAt(posts.getCreatedAt());

                String prefix = S3Storage.FOLDER_POST.getValue() + S3Storage.SUFFIX.getValue() + posts.getPostId() + S3Storage.SUFFIX.getValue() + fileEntity.getName();
                postFiles.setFileUrl(s3StorageService.copyFile(prefix, fileEntity.getFileUrl()));
                postFiles_.add(postFiles);
            } else {
                PostFiles _postFiles = iDao.find(PostFiles.class, fileEntity.getPostFilesId());
                postFiles_.add(_postFiles);
            }
        }

        files.removeAll(postFiles_);
        if (files.size() > 0) {
            for (PostFiles postFiles : files) {
                iDao.purge(postFiles);
            }
        }

        posts.setFiles(postFiles_);

        Posts posts_ = iDao.update(posts);

        PostEntity postEntity = modelMapper.map(posts_, PostEntity.class);

        sendPost(Activity.UPDATE_POST.getActivity(), posts_, users, iDao);

        return postEntity;
    }

    @Override
    public UniversalResponse delete(Long postId, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);
        checkNullLongId(postId, ExceptionStatus.POST_ID_MISSING);

        Posts posts = iDao.find(Posts.class, postId);
        checkNullObject(posts, ExceptionStatus.POST_NOT_FOUND);

        if (Integer.parseInt(users.getUserRole().getRoleTag()) < 3 || posts.getUser().equals(users)) {
            iDao.delete(posts);
        } else {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        posts = iDao.find(Posts.class, postId);

        if (posts.getDeleted()) {
            return new UniversalResponse(true, "Post has been successfully deleted!", "", "", "" + postId);
        } else {
            throw new UniversalException(ExceptionStatus.POST_NOT_DELETED);
        }
    }


}