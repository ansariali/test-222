package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class HttpRequestBodyNotValidException extends BaseException {

	private static final long serialVersionUID = 1L;

	public HttpRequestBodyNotValidException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public HttpRequestBodyNotValidException() {
		super(ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
	}
}