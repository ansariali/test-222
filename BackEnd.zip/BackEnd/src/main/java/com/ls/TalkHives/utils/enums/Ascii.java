package com.ls.TalkHives.utils.enums;

public enum Ascii {

    FRONTEND("907"),
    FILE("384"),
    IMAGE("483"),
    PROFILE("721"),
    POST("422"),
    TEAM("319"),
    PROJECT("727"),
    BLOG("388"),
    CLIENT("607"),
    PIN("295"),
    VOTE("410"),
    TASK("403"),
    MEETING("713"),
    GENERAL("702"),
    TRASH("514"),
    PUBLIC("607"),
    SELF("394"),
    USER("415"),
    ORGANIZATION("1269"),
    PRIVACY("734"),
    NOTIFICATION("1255"),
    CREATE("596"),
    UPDATE("611"),
    DELETE("595"),
    REFRESH("719"),
    RELOAD("599"),
    DEFAULT("709"),

    TODAY("513"),
    TOMORROW("873"),
    NEXT_WEEK("811"),

    // Status
    NEW("298"),
    ACTIVE("604"),
    COMPLETED("925"),
    PENDING("709"),
    POSTPONED("956"),
    DELETED("695"),
    OVERDUE("730"),
    REJECTED("806"),
    NEED_HELP("773"),
    NOT_FOND("813"),
    UNDEFINED("914"),

    // Priority
    URGENT("629"),
    HIGH("384"),
    NORMAL("617"),
    LOW("306"),

    // Frequencies
    ONCE("389"),
    DAILY("499"),
    WEEKLY("657"),
    MONTHLY("747"),
    ANNUALLY("836"),

    Last("");

    private final String code;

    Ascii(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}