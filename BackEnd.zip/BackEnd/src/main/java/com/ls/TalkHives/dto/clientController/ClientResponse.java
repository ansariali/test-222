package com.ls.TalkHives.dto.clientController;

import com.ls.TalkHives.dto.common.WsEntity;
import com.ls.TalkHives.dto.common.ClientEntity;

public class ClientResponse extends WsEntity {

    private ClientEntity content;

    public ClientEntity getContent() {
        return content;
    }

    public void setContent(ClientEntity content) {
        this.content = content;
    }
}
