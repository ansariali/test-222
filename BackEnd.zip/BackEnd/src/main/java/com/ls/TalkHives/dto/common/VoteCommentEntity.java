package com.ls.TalkHives.dto.common;

import java.util.Date;

public class VoteCommentEntity {
    private Long voteId;
    private Long voteCommentId;
    private String message;
    private Integer comments;
    private Date createdAt;

    private UserInfo users;

    public Long getVoteId() {
        return voteId;
    }

    public void setVoteId(Long voteId) {
        this.voteId = voteId;
    }

    public Long getVoteCommentId() {
        return voteCommentId;
    }

    public void setVoteCommentId(Long voteCommentId) {
        this.voteCommentId = voteCommentId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getComments() {
        return comments;
    }

    public void setComments(Integer comments) {
        this.comments = comments;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }
}
