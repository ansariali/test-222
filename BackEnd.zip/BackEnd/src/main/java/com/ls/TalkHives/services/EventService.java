package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;

public interface EventService {

    void eventTest();

    void eventStart(IDao<IEntity, Serializable> iDao);

    void create(WsResponse wsResponse, IDao<IEntity, Serializable> iDao);

    void update(WsResponse wsResponse, IDao<IEntity, Serializable> iDao);

    void delete(WsResponse wsResponse, IDao<IEntity, Serializable> iDao);

    // void meetingEvent(Maintenance maintenance, IDao<IEntity, Serializable> iDao);

    // WsResponse create(CreateBlogRequest createBlogRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    // Map<String, List<Blogs>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

}