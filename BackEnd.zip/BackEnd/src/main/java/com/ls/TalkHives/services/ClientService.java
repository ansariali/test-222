package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.clientController.CreateClientRequest;
import com.ls.TalkHives.dto.clientController.UpdateClientRequest;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Clients;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ClientService {
    WsResponse create(CreateClientRequest createClientRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Clients>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdateClientRequest updateClientRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long clientId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}