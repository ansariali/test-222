package com.ls.TalkHives.dto.taskController;

import com.ls.TalkHives.dto.common.TaskEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllTasks {

    private List<TaskEntity> tasks = new ArrayList<>();

    public List<TaskEntity> getTasks() {
        return tasks;
    }

    public void setTasks(List<TaskEntity> tasks) {
        this.tasks = tasks;
    }
}
