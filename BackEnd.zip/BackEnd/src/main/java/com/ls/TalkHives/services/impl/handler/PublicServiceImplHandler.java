package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.utils.ideal.UniversalService;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public abstract class PublicServiceImplHandler extends UniversalService {

}