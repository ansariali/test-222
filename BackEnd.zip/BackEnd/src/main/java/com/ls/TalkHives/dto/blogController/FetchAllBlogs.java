package com.ls.TalkHives.dto.blogController;

import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.PinEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllBlogs {

    private List<BlogEntity> blogs = new ArrayList<>();

    public List<BlogEntity> getBlogs() {
        return blogs;
    }

    public void setBlogs(List<BlogEntity> blogs) {
        this.blogs = blogs;
    }
}
