package com.ls.TalkHives.dto.newController;

import com.ls.TalkHives.dto.newController.entity.NewEntity;

public class FetchNewResponse extends NewEntity {
}