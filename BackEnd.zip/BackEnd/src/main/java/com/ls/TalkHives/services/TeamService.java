package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.teamController.CreateTeamRequest;
import com.ls.TalkHives.dto.teamController.UpdateTeamRequest;
import com.ls.TalkHives.entities.Teams;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface TeamService {
    WsResponse create(CreateTeamRequest createTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Teams>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdateTeamRequest updateTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long teamId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}