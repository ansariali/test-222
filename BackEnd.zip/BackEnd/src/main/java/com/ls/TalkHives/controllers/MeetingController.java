package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.meetingController.CreateMeetingRequest;
import com.ls.TalkHives.dto.meetingController.FetchAllMeetings;
import com.ls.TalkHives.dto.meetingController.UpdateMeetingRequest;
import com.ls.TalkHives.services.MeetingService;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/meetingController")
public class MeetingController extends UniversalController {

    private static final String TAG = MeetingController.class.getSimpleName();

    @Autowired
    private MeetingService meetingService;

    @ApiOperation(value = "M1 Create Meeting")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/meeting/1/create/{organizationId}")
    // @SendTo("/topic/meeting/1/create/{organizationId}")
    public ResponseEntity<WsResponse> createMeeting(@RequestHeader Map<String, Object> requestHeader,
                                                    @RequestBody CreateMeetingRequest createMeetingRequest) {
        logger.info(TAG, "Inside M1 | /1/create");

        return new ResponseEntity<>(meetingService.create(createMeetingRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "M2 FetchAll Meeting")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllMeetings> fetchAllMeeting(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside M2 | /1/fetch/all: ");

        FetchAllMeetings res = modelMapper.map(meetingService.fetchAll(requestHeader, iDao), FetchAllMeetings.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "M3 Update Meeting")
    @PutMapping(value = "/1/update")
    // @MessageMapping("/meeting/1/update/{organizationId}")
    // @SendTo("/topic/meeting/1/update/{organizationId}")
    public ResponseEntity<WsResponse> updateMeeting(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody UpdateMeetingRequest updateMeetingRequest) {
        logger.info(TAG, "Inside updateMeeting");

        return new ResponseEntity<>(meetingService.update(updateMeetingRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "M4 Delete Meeting")
    @DeleteMapping(value = "/1/delete/{meetingId}")
    // @MessageMapping("/meeting/1/delete/{organizationId}/{meetingId}")
    // @SendTo("/topic/meeting/1/delete/{organizationId}")
    public ResponseEntity<WsResponse> deleteMeeting(@RequestHeader Map<String, Object> requestHeader,
                                                    @PathVariable String meetingId) {
        logger.info(TAG, "Inside deleteMeeting");

        return new ResponseEntity<>(meetingService.delete(Long.parseLong(meetingId), requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }
}