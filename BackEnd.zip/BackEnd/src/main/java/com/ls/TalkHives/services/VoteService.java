package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.VoteCommentEntity;
import com.ls.TalkHives.dto.common.VoteEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.voteController.*;
import com.ls.TalkHives.entities.VoteComments;
import com.ls.TalkHives.entities.Votes;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface VoteService {
    WsResponse create(CreateVoteRequest createVoteRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<VoteEntity>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    CreateVoteLikeResponse createLike(CreateVoteLikeRequest createVoteLikeRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    VoteCommentEntity createComment(CreateVoteCommentRequest createVoteCommentRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    Map<String, List<VoteComments>> fetchAllComments(Long voteId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdateVoteRequest updateVoteRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long voteId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}