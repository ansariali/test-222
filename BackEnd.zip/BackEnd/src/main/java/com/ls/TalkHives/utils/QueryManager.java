package com.ls.TalkHives.utils;

public class QueryManager {

    private QueryManager() {
    }

    public static QueryManager getInstance() {
        return new QueryManager();
    }

    public String selectQueryOfFetchAllData() {
        return "SELECT o FROM NewEntity AS o";
    }

    public String selectQueryOfFetchUserAccountByPromoterAndSuperAdminEmailAddress() {
        return "SELECT o FROM UserAccount AS o WHERE o.emailAddress = :promoterEmail OR o.emailAddress = :superAdminEmail";
    }

    public String selectQueryOfFetchUserAccountByEmailAddress() {
        return "SELECT o FROM UserAccount AS o WHERE o.emailAddress = :emailAddress";
    }

    // Maintenance
    public String getMaintenance() {
        return "SELECT o FROM Maintenance AS o WHERE o.live IS true";
    }

    public String getNextMeeting() {
        return "SELECT o FROM Meetings AS o WHERE o.timing IN (SELECT min(b.timing) FROM Meetings AS b WHERE b.deleted IS NOT true)";
    }

    public String getMeetingEvent() {
        return "SELECT o FROM Events AS o WHERE o.meetings  = :meetings";
    }

    public String getAllNextMeetingEvents() {
        return "SELECT o FROM Events AS o WHERE o.timing IN (SELECT min(e.timing) FROM Events AS e WHERE e.deleted IS NOT true)";
    }

    // Public
    public String getUsersByUserName() {
        return "SELECT o FROM Users AS o WHERE o.userName = :userName";
    }

    public String getUsersByEmailId() {
        return "SELECT o FROM Users AS o WHERE o.emailId = :emailId";
    }

    public String getUsersByUserRole() {
        return "SELECT o FROM Users AS o WHERE o.organizations = :organizations AND o.userRole < :userRole";
    }

    public String getAllUserRole() {
        return "SELECT o FROM UserRole AS o WHERE o.roleTag > :roleTag";
    }

    public String getUserRole() {
        return "SELECT o FROM UserRole AS o WHERE o.roleTag = :roleTag";
    }

    public String getTHTagStep1() {
        return "SELECT o FROM Users AS o WHERE (o.userName = :userName OR o.emailId = :userName) AND o.password = :password";
    }

    public String getTHTagStep2() {
        return "SELECT o FROM TalkHives AS o WHERE o.user = :userId AND o.organizations = :organizationId";
    }

    public String getUserByLoginToken() {
        return "SELECT o FROM LoginUsers AS o WHERE o.loginToken = :loginToken";
    }

    public String getUserByThTag() {
        return "SELECT o FROM TalkHives AS o WHERE o.thTag = :thTag";
    }

    public String verifyInviteToken() {
        return "SELECT o FROM Invitations AS o WHERE o.inviteToken = :inviteToken";
    }

    public String getAllInvitation() {
        return "SELECT o FROM Invitations AS o WHERE o.users = :users";
    }

    public String getLoginUser() {
        return "SELECT o FROM LoginUsers AS o WHERE o.loginToken = :loginToken";
    }

    public String getAllPins() {
        return "SELECT o FROM Pins AS o WHERE o.user = :user";
    }

    public String getAllBlogs() {
        return "SELECT o FROM Blogs AS o WHERE o.organizations = :organizations";
    }

    public String getAllUserByOrg() {
        return "SELECT o FROM Users AS o WHERE o.organizations = :organizations";
    }

    public String getPrivacyLevel() {
        return "SELECT o FROM PrivacyLevel AS o WHERE o.privacyTag = :privacyTag";
    }

    public String getAllActivity() {
        return "SELECT o FROM UserActivity AS o WHERE o.users = :users";
    }

    public String getAllPosts() {
        return "SELECT o FROM Posts AS o WHERE o.organizations = :organizations AND o.privacyLevel > :privacyLevel";
    }

    public String getAllPostByUser() {
        return "SELECT o FROM Posts AS o WHERE o.organizations = :organizations AND o.user IN (:user, :sharedBy)";
    }

    public String getAllOnlyMePost() {
        return "SELECT o FROM Posts AS o WHERE o.user = :user AND o.privacyLevel = :privacyLevel";
    }

    public String getPostSharing() {
        return "SELECT o FROM PostSharing AS o WHERE o.posts = :posts AND o.user = :user";
    }

    public String getChatRoom() {
        return "SELECT o FROM ChatRooms AS o WHERE o.chatRoomTag = :chatRoomTag";
    }

    public String getChatRoomOfUsers() {
        return "SELECT o FROM ChatRooms AS o WHERE o.userOne IN (:userOne, :userTwo) AND o.userTwo IN (:userOne, :userTwo)";
    }

    public String getChats() {
        return "SELECT o FROM Chats AS o WHERE o.chatRooms = :chatRooms";
    }

    public String getAllTeams() {
        return "SELECT o FROM Teams AS o WHERE o.organizations = :organizations";
    }

    public String getAllTeamMember() {
        return "SELECT o FROM TeamMembers AS o WHERE o.teams = :teams";
    }

    public String getClientName() {
        return "SELECT o FROM Clients AS o WHERE o.name = :name AND o.organizations = :organizations";
    }

    public String getTeamMember() {
        return "SELECT o FROM TeamMembers AS o WHERE o.teams = :teams AND o.users = :users";
    }

    public String getAllProject() {
        return "SELECT o FROM Projects AS o WHERE o.organizations = :organizations";
    }

    public String getAllProjectComments() {
        return "SELECT o FROM ProjectComments AS o WHERE o.projects = :projects";
    }

    public String getAllVote() {
        return "SELECT o FROM Votes AS o WHERE o.organizations = :organizations";
    }

    public String getVoteLike() {
        return "SELECT o FROM VoteLikes AS o WHERE o.votes = :votes AND o.users = :users";
    }

    public String getVoteTrueLike() {
        return "SELECT o FROM VoteLikes AS o WHERE o.votes = :votes AND o.liked = true";
    }

    public String getVoteFalseLike() {
        return "SELECT o FROM VoteLikes AS o WHERE o.votes = :votes AND o.liked = false";
    }

    public String getAllVoteComments() {
        return "SELECT o FROM VoteComments AS o WHERE o.votes = :votes";
    }

    public String getAllChatRoomForGroup() {
        return "SELECT o FROM ChatRoomMembers AS o WHERE o.users = :users";
    }

    public String getPostLike() {
        return "SELECT o FROM PostLikes AS o WHERE o.posts = :posts AND o.users = :users";
    }

    public String getCommentLike() {
        return "SELECT o FROM CommentLikes AS o WHERE o.commentId = :commentId AND o.usersId = :usersId";
    }

    public String getCommentId() {
        return "SELECT o FROM PostComments AS o WHERE o.postCommentId = :postCommentId";
    }

    public String getPostTrueLike() {
        return "SELECT o FROM PostLikes AS o WHERE o.posts = :posts AND o.liked = true";
    }

    public String getAllPostComments() {
        return "SELECT o FROM PostComments AS o WHERE o.posts = :posts";
    }

    public String getAllNotifications() {
        return "SELECT o FROM Notifications AS o WHERE o.organizations = :organizations";
    }

    public String getAllClients() {
        return "SELECT o FROM Clients AS o WHERE o.organizations = :organizations";
    }

    public String getAllTasks() {
        return "SELECT o FROM Tasks AS o WHERE o.organizations = :organizations";
    }

    public String getAllMileStones() {
        return "SELECT o FROM ProjectMilestones AS o WHERE o.organizations = :organizations";
    }

    public String getTaskMember() {
        return "SELECT o FROM TaskMembers AS o WHERE o.tasks = :tasks AND o.users = :users";
    }

    public String getAllMeetings() {
        return "SELECT o FROM Meetings AS o WHERE o.organizations = :organizations";
    }

    public String getAllMeetingMember() {
        return "SELECT o FROM MeetingMembers AS o WHERE o.meetings = :meetings";
    }

    public String getMeetingMember() {
        return "SELECT o FROM MeetingMembers AS o WHERE o.meetings = :meetings AND o.users = :users";
    }

    public String getAllMeetingPoint() {
        return "SELECT o FROM MeetingPoints AS o WHERE o.meetings = :meetings";
    }

    public String getMeetingPoint() {
        return "SELECT o FROM MeetingPoints AS o WHERE o.meetings = :meetings AND o.title = :title";
    }


}