package com.ls.TalkHives.dto.common;

import java.util.Date;
import java.util.List;

public class MeetingEntity {
    private Long meetingId;
    private String meetingTag;
    private String title;
    private String info;
    private Integer totalMember;
    private Integer totalPoints;
    private Date timing;
    private Date createdAt;

    private UserInfo users;

    private List<MeetingMembersEntity> members;
    private List<MeetingPointsEntity> points;

    public Long getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(Long meetingId) {
        this.meetingId = meetingId;
    }

    public String getMeetingTag() {
        return meetingTag;
    }

    public void setMeetingTag(String meetingTag) {
        this.meetingTag = meetingTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public Date getTiming() {
        return timing;
    }

    public void setTiming(Date timing) {
        this.timing = timing;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }

    public List<MeetingMembersEntity> getMembers() {
        return members;
    }

    public void setMembers(List<MeetingMembersEntity> members) {
        this.members = members;
    }

    public List<MeetingPointsEntity> getPoints() {
        return points;
    }

    public void setPoints(List<MeetingPointsEntity> points) {
        this.points = points;
    }
}
