package com.ls.TalkHives.utils.enums;

public enum S3Storage {

    BLANK(""),
    SPACE(" "),
    DASH("-"),
    UNDER_SCORE("_"),
    SUFFIX("/"),

    BUCKET_URL("https://s3-us-west-2.amazonaws.com/lynkersoft-s3-filestorage-bucket/"),
     S3_URL("https://lynkersoft-s3-filestorage-bucket.s3-us-west-2.amazonaws.com/"),

    DEFAULT_USER_PIC_URL("https://s3-us-west-2.amazonaws.com/lynkersoft-s3-filestorage-bucket/TalkHives/Public/Images/1518587202385-userDefault.png"),

    TEMP_POST("Temp"),

    FOLDER_TEMP("Temp"),
    FOLDER_PUBLIC("Public"),
    FOLDER_IMAGES("Images"),
    FOLDER_USERS("Users"),
    FOLDER_POST("Post"),
    FOLDER_BLOG("Blog"),
    FOLDER_TRASH("Trash");

    private final String value;

    S3Storage(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public String getTestValue() {
        return TEMP_POST.getValue() + SUFFIX.getValue() + value;
    }

}