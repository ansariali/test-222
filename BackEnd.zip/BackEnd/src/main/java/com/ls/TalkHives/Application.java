package com.ls.TalkHives;

import com.ls.TalkHives.utils.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.web.ErrorMvcAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.ui.velocity.VelocityEngineFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

@Configuration
@EntityScan({"com.ls.TalkHives.entities"})
// @EnableJpaRepositories({"com.ls.TalkHives.entities"})
//@ComponentScan(basePackages = {"com.ls.TalkHives"})
@SpringBootApplication(scanBasePackages = {"com.ls.TalkHives"}, exclude = {ErrorMvcAutoConfiguration.class})
@SuppressWarnings("deprecation")
public class Application {

    private static final String TAG = Application.class.getSimpleName();
    private static Logger logger = Logger.getInstance(true, Application.class);

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        logger.info(TAG, "TalkHives is live...");
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    @Bean
    public VelocityEngine getVelocityEngine() throws VelocityException, IOException {
        VelocityEngineFactory factory = new VelocityEngineFactory();
        Properties props = new Properties();
        props.put("resource.loader", "class");
        props.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        factory.setVelocityProperties(props);
        return factory.createVelocityEngine();
    }
}