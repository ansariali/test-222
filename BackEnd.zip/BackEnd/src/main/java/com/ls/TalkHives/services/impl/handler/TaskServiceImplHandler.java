package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.TaskEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.TaskMembers;
import com.ls.TalkHives.entities.Tasks;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.enums.WSApi;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class TaskServiceImplHandler extends UniversalService {

    protected void sendTaskToUsers(String activity, Tasks tasks, Users users, IDao<IEntity, Serializable> iDao) {
        TaskEntity taskEntity = modelMapper.map(tasks, TaskEntity.class);

        // Send Task
        for (TaskMembers taskMembers : tasks.getMembers()) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_TASK.getSendTo()
                    .replace("{userId}", "" + taskMembers.getUsers().getUserId()), taskEntity);

            String user;
            String message;
            String priority = tasks.getPriority().getTitle();

            if (checkEqualLongId(users.getUserId(), taskMembers.getUsers().getUserId())) {
                user = "You";
            } else {
                user = users.getFirstName() + " " + users.getLastName();
            }

            message = Notification.CREATE_GENERAL_TASK.getPublicMessage()
                    .replace("{user}", user)
                    .replace("{priority}", priority);

            notificationService.sentToUser(tasks.getTaskId(), Ascii.TASK.getCode(), Boolean.TRUE, message, taskMembers.getUsers(), users, iDao);
        }


    }

    // Activity Action
    private void activityAction(String activityTag, Tasks tasks, Users users) {
        if (activityTag.equals(Activity.CREATE_TASK.getActivity())) {
            tasks.setTaskTag(getTaskTag(users));
        }

        if (activityTag.equals(Activity.DELETE_TASK.getActivity())) {
            users.setDeletedTask(users.getDeletedTask() + 1);
            users.getOrganizations().setDeletedTask(users.getOrganizations().getDeletedTask() + 1);
        }
    }

    // Create, Delete Task
    protected WsResponse sendTask(String activityTag, Tasks tasks, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, tasks, users);

        // Send Task
        WsResponse wsResponse = new WsResponse();
        // WsResponse wsResponse = sendTaskToUsers(activityTag, tasks, users, iDao);


        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.TASK, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }

}