package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.VoteEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.entities.Votes;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class VoteServiceImplHandler extends UniversalService {

    private void activityAction(String activityTag, Votes votes, Users users) {
        if (activityTag.equals(Activity.CREATE_VOTE.getActivity())) {
            votes.setVoteTag(getVoteTag(users));
        }

        if (activityTag.equals(Activity.DELETE_VOTE.getActivity())) {
            users.setDeletedVote(users.getDeletedVote() + 1);
            users.getOrganizations().setDeletedVote(users.getOrganizations().getDeletedVote() + 1);
        }
    }

    protected WsResponse sendVote(String activityTag, Votes votes, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, votes, users);

        VoteEntity voteEntity = modelMapper.map(votes, VoteEntity.class);

        // Send Vote
        WsResponse wsResponse = sendActivity(Ascii.ORGANIZATION.getCode(), users.getOrganizations().getOrganizationId().toString(), votes.getVoteId(), Ascii.VOTE.getCode(), activityTag, voteEntity);

        // Send Notification
        if (activityTag.equals(Activity.CREATE_VOTE.getActivity())) {
            String message = Notification.valueOf(activityTag).getPublicMessage()
                    .replace("{user}", setFullName(users));
            notificationService.sentToOrganization(votes.getVoteId(), Ascii.VOTE.getCode(), Boolean.FALSE, message, users, iDao);
        }

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.VOTE, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }


}