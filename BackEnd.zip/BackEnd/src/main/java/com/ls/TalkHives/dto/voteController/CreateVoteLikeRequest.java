package com.ls.TalkHives.dto.voteController;

public class CreateVoteLikeRequest {
    private Long voteId;
    private Boolean liked;

    public Long getVoteId() {
        return voteId;
    }

    public void setVoteId(Long voteId) {
        this.voteId = voteId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }
}
