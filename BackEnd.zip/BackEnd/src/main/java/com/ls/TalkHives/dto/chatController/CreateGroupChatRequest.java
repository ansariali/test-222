package com.ls.TalkHives.dto.chatController;

import com.ls.TalkHives.dto.common.UserInfo;

import java.util.List;

public class CreateGroupChatRequest {
    private String name;
    private String info;
    private List<UserInfo> members;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public List<UserInfo> getMembers() {
        return members;
    }

    public void setMembers(List<UserInfo> members) {
        this.members = members;
    }
}
