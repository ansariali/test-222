package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.FileEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.mileStoneController.CreateProjectMilestone;
import com.ls.TalkHives.dto.mileStoneController.MileStoneEntity;
import com.ls.TalkHives.dto.projectController.*;
import com.ls.TalkHives.dto.taskController.CreateTaskRequest;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.ProjectService;
import com.ls.TalkHives.services.impl.handler.ProjectServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class ProjectServiceImpl extends ProjectServiceImplHandler implements ProjectService {

    private static final String TAG = ProjectServiceImpl.class.getSimpleName();

    @Override
    public UniversalResponse uploadFile(DocumentEntity uploadFileDetail, Map<String, Object> requestHeader, MultipartFile[] files, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(uploadFileDetail.getProjectId(), ExceptionStatus.PROJECT_ID_MISSING);
        checkNullString(uploadFileDetail.getTitle(), ExceptionStatus.DOCUMENT_TITLE_MISSING);
        checkNullString(uploadFileDetail.getInfo(), ExceptionStatus.DOCUMENT_DESCRIPTION_MISSING);

        Projects aProjects = iDao.find(Projects.class, uploadFileDetail.getProjectId());
        checkNullObject(aProjects, ExceptionStatus.PROJECT_NOT_FOUND);
        Images images = new Images();

        FileEntity fileEntity = new FileEntity();
        Long fileSize = 0L;
        for (int i = 0; i < files.length; i++) {
            String prefix = S3Storage.FOLDER_PUBLIC.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_TRASH.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();
            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.TRASH.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, files[i]));
            fileEntity.setName(files[i].getOriginalFilename());
            fileEntity.setType(files[i].getContentType());
            System.out.println("Bytes :"+ i +"-" + files[i].getBytes());
            fileSize +=  files[i].getSize();
            System.out.println("FileSize i :"+ i +"-" + fileSize);
        }
        System.out.println("FileSize :"+ fileSize);
        tasks.setCreatedAt(getCurrentTime());
        try {

        }catch (Exception e) {
            checkNullString("Error", ExceptionStatus.NEW_NOT_ADDED);
        }

        return null;
    }

    @Override
    public Projects create(CreateProjectRequest createProjectRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Projects projects = new Projects();
        projects.setName(createProjectRequest.getName());
        projects.setInfo(createProjectRequest.getInfo());

        checkNullDate(createProjectRequest.getInitialDate(), ExceptionStatus.PROJECT_INITIAL_DATE_MISSING);
        checkNullDate(createProjectRequest.getDeadline(), ExceptionStatus.PROJECT_DEADLINE_MISSING);

        Date initialDate = getUTCTime(createProjectRequest.getInitialDate());
        Date deadline = getUTCTime(createProjectRequest.getDeadline());
        Boolean b = isFutureDate(initialDate, deadline);
        exception(b, ExceptionStatus.INVALID_TIME_FRAME_OF_PROJECT);

        projects.setInitialDate(initialDate);
        projects.setDeadline(deadline);

        projects.setStatus(iDao.find(Status.class, GlobalTag.NEW.getLongTag()));
        projects.setUsers(users);
        projects.setOrganizations(users.getOrganizations());

        projects.setClient(iDao.find(Clients.class, createProjectRequest.getClient().getClientId()));
        projects.setManager(iDao.find(Users.class, createProjectRequest.getManager().getUserId()));
        projects.setTeams(iDao.find(Teams.class, createProjectRequest.getTeam().getTeamId()));

        // TODO: GET Size from for loop / from table using Query
        projects.setTotalMember(projects.getTeams().getMembers().size());
        projects.setCreatedAt(getCurrentTime());

        Set<ProjectMilestones> milestoneList = new HashSet<>();
        for (CreateProjectMilestoneRequest createProjectMilestoneRequest : createProjectRequest.getMilestones()) {
            ProjectMilestones projectMilestones = new ProjectMilestones();
            projectMilestones.setName(createProjectMilestoneRequest.getName());
            projectMilestones.setInfo(createProjectMilestoneRequest.getInfo());
            projectMilestones.setLevel(getInt(createProjectMilestoneRequest.getLevel()));

            checkNullDate(createProjectMilestoneRequest.getInitialDate(), ExceptionStatus.PROJECT_MILESTONE_INITIAL_DATE_MISSING);
            checkNullDate(createProjectMilestoneRequest.getDeadline(), ExceptionStatus.PROJECT_MILESTONE_DEADLINE_MISSING);

            Date _initialDate = getUTCTime(createProjectMilestoneRequest.getInitialDate());
            Date _deadline = getUTCTime(createProjectMilestoneRequest.getDeadline());

            Boolean _b = isFutureDate(_initialDate, _deadline);
            exception(_b, ExceptionStatus.INVALID_TIME_FRAME_OF_PROJECT_MILESTONE);

            projectMilestones.setInitialDate(_initialDate);
            projectMilestones.setDeadline(_deadline);

            projectMilestones.setStatus(iDao.find(Status.class, GlobalTag.NEW.getLongTag()));

            projectMilestones.setUsers(users);
            projectMilestones.setOrganizations(users.getOrganizations());
            projectMilestones.setProjects(projects);
            projectMilestones.setCreatedAt(getCurrentTime());

            Set<Tasks> taskList = new HashSet<>();

            for (CreateTaskRequest createTaskRequest : createProjectMilestoneRequest.getTasks()) {
                Tasks tasks = new Tasks();
                tasks.setTitle(createTaskRequest.getTitle());
                tasks.setInfo(createTaskRequest.getInfo());
                tasks.setType(Ascii.PROJECT.getCode());
                tasks.setInitialDate(_initialDate);
                tasks.setDeadline(_deadline);

                tasks.setPriority(iDao.find(Priority.class, createTaskRequest.getPriority().getPriorityTag()));
                tasks.setStatus(iDao.find(Status.class, GlobalTag.NEW.getLongTag()));
                tasks.setUsers(users);
                tasks.setOrganizations(users.getOrganizations());
                tasks.setProjectMilestones(projectMilestones);
                tasks.setCreatedAt(getCurrentTime());


                Set<TaskMembers> taskMembersList = new HashSet<>();
                for (UserInfo userInfo : createTaskRequest.getMembers()) {
                    TaskMembers taskMembers = new TaskMembers();
                    taskMembers.setAssignedBy(users);
                    taskMembers.setTasks(tasks);
                    taskMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
                    taskMembers.setCreatedAt(getCurrentTime());

                    taskMembersList.add(taskMembers);
                }

                tasks.setMembers(taskMembersList);
                tasks.setTotalMember(tasks.getMembers().size());
                taskList.add(tasks);
            }

            if (taskList.size() != 0) {
                projectMilestones.setTasks(taskList);
                projectMilestones.setTotalTask(projectMilestones.getTasks().size());

                Double d = (double) (100 / projectMilestones.getTotalTask());
                projectMilestones.setTaskPercentage(d);

                Double total = projectMilestones.getTaskPercentage() * projectMilestones.getTotalTask();
                if (total < 100) {
                    Double remaining = 100 - total;
                    projectMilestones.setCompletion(remaining);
                }
            }

            milestoneList.add(projectMilestones);
        }

        if (milestoneList.size() != 0) {
            projects.setMilestones(milestoneList);
            projects.setTotalMilestone(projects.getMilestones().size());

            Double d = (double) (100 / projects.getTotalMilestone());
            projects.setMilestonePercentage(d);

            Double total = projects.getMilestonePercentage() * projects.getTotalMilestone();
            if (total < 100) {
                Double remaining = 100 - total;
                projects.setCompletion(remaining);
            }
        }

        Projects projects_ = iDao.find(Projects.class, iDao.persist(projects));
        checkNullObject(projects_, ExceptionStatus.NEW_NOT_ADDED);

        return projects_;
    }

    @Override
    public ProjectMilestones createMileStone(CreateProjectMilestone createProjectMilestoneRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {

        Users users = findUserByLoginToken(requestHeader, iDao);
        Projects project = iDao.find(Projects.class, createProjectMilestoneRequest.getProject().get(0).getId());
        checkNullObject(project, ExceptionStatus.PROJECT_NOT_FOUND);

        ProjectMilestones projectMilestones = new ProjectMilestones();
        projectMilestones.setName(createProjectMilestoneRequest.getName());
        projectMilestones.setInfo(createProjectMilestoneRequest.getInfo());
        projectMilestones.setLevel(getInt(createProjectMilestoneRequest.getLevel()));
        checkNullDate(createProjectMilestoneRequest.getInitialDate(), ExceptionStatus.PROJECT_MILESTONE_INITIAL_DATE_MISSING);
        checkNullDate(createProjectMilestoneRequest.getDeadline(), ExceptionStatus.PROJECT_MILESTONE_DEADLINE_MISSING);
        Date _initialDate = getUTCTime(createProjectMilestoneRequest.getInitialDate());
        Date _deadline = getUTCTime(createProjectMilestoneRequest.getDeadline());
        Boolean _b = isFutureDate(_initialDate, _deadline);
        exception(_b, ExceptionStatus.INVALID_TIME_FRAME_OF_PROJECT_MILESTONE);
        projectMilestones.setInitialDate(_initialDate);
        projectMilestones.setDeadline(_deadline);
        projectMilestones.setStatus(iDao.find(Status.class, GlobalTag.NEW.getLongTag()));
        projectMilestones.setUsers(users);
        projectMilestones.setOrganizations(users.getOrganizations());
        projectMilestones.setProjects(project);
        projectMilestones.setCreatedAt(getCurrentTime());

        ProjectMilestones projectMilestones_ = null;
        try {
            projectMilestones_ = iDao.find(ProjectMilestones.class, iDao.persist(projectMilestones));
        } catch (Exception e) {
            checkNullString("Error", ExceptionStatus.NEW_NOT_ADDED);
        }
        return projectMilestones_;
    }

    @Override
    public Map<String, List<ProjectMilestones>> fetchAllMileStone(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        Map<String, List<ProjectMilestones>> map = new HashMap<>();

        Hashtable<String, Object> hashTable = new Hashtable<>();

        hashTable.put("organizations", users.getOrganizations());
        List<ProjectMilestones> list = iDao.getEntities(ProjectMilestones.class, queryManager.getAllMileStones(), hashTable, false, "DESC");
        hashTable.clear();
        map.put("mileStones", list);
        return map;
    }


    @Override
    public ProjectMilestones updateMileStone(Long mileStoneId, MileStoneEntity createMileStoneRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {

        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(createMileStoneRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(mileStoneId, ExceptionStatus.MILE_STONE_ID_MISSING);
        checkNullDate(createMileStoneRequest.getInitialDate(), ExceptionStatus.MILE_STONE_STARTING_DATE_MISSING);
        checkNullDate(createMileStoneRequest.getDeadline(), ExceptionStatus.MILE_STONE_DEADLINE_MISSING);

        Projects aProjects = iDao.find(Projects.class, createMileStoneRequest.getProjects().getProjectId());
        checkNullObject(aProjects, ExceptionStatus.PROJECT_NOT_FOUND);

        ProjectMilestones aProjectMilestones = iDao.find(ProjectMilestones.class, mileStoneId);
        checkNullObject(aProjectMilestones, ExceptionStatus.MILE_STONE_NOT_FOUND);
        aProjectMilestones.setName(createMileStoneRequest.getName());
        aProjectMilestones.setInfo(createMileStoneRequest.getInfo());
        aProjectMilestones.setInitialDate(getUTCTime(createMileStoneRequest.getInitialDate()));
        aProjectMilestones.setDeadline(getUTCTime(createMileStoneRequest.getDeadline()));
        aProjectMilestones.setUsers(users);
        aProjectMilestones.setOrganizations(users.getOrganizations());
        aProjectMilestones.setUpdatedAt(getCurrentTime());
//        aTask.setUpdatedBy(users);
        aProjectMilestones.setProjects(aProjects);

        ProjectMilestones projectMilestones_ = iDao.update(aProjectMilestones);
        checkNullObject(projectMilestones_, ExceptionStatus.MILE_STONE_NOT_UPDATE);

        return projectMilestones_;
    }

    @Override
    public WsResponse deleteMilestone(Long mileStoneId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        checkNullLongId(mileStoneId, ExceptionStatus.MILE_STONE_ID_MISSING);

        ProjectMilestones aProjectMilestones = iDao.find(ProjectMilestones.class, mileStoneId);
        checkNullObject(aProjectMilestones, ExceptionStatus.MILE_STONE_NOT_FOUND);

        try {
            iDao.delete(aProjectMilestones);
        } catch (Exception e) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }

        aProjectMilestones = iDao.find(ProjectMilestones.class, mileStoneId);

        if (aProjectMilestones.getDeleted()) {
            return new WsResponse();
        } else {
            throw new UniversalException(ExceptionStatus.MILE_STONE_NOT_DELETE);
        }
    }

    @Override
    public Map<String, List<Projects>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Projects>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Projects> list = iDao.getEntities(Projects.class, queryManager.getAllProject(), hashtable, false, "DESC");
        hashtable.clear();

        if (Integer.parseInt(users.getUserRole().getRoleTag()) > 2) {
            List<Projects> _list = new ArrayList<>();
            for (Projects projects : list) {
                for (TeamMembers teamMembers : projects.getTeams().getMembers()) {
                    if (!teamMembers.getUsers().equals(users)) {
                        _list.add(projects);
                    }
                }
            }
            list.removeAll(_list);
        }

//        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));
        map.put("projects", list);

        return map;
    }

    @Override
    public ProjectComments createComment(CreateProjectCommentRequest createProjectCommentRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);

        ProjectComments projectComments = new ProjectComments();
        projectComments.setMessage(createProjectCommentRequest.getMessage());
        projectComments.setProjects(iDao.find(Projects.class, createProjectCommentRequest.getProjectId()));
        projectComments.setUsers(users);
        projectComments.setCreatedAt(getCurrentTime());

        ProjectComments projectComments_ = iDao.find(ProjectComments.class, iDao.persist(projectComments));
        checkNullObject(projectComments_, ExceptionStatus.NEW_NOT_ADDED);

        return projectComments_;
    }

    @Override
    public Map<String, List<ProjectComments>> fetchAllComments(Long projectId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(projectId, ExceptionStatus.PROJECT_ID_MISSING);

        Map<String, List<ProjectComments>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("projects", iDao.find(Projects.class, projectId));
        List<ProjectComments> list = iDao.getEntities(ProjectComments.class, queryManager.getAllProjectComments(), hashtable, false);
        hashtable.clear();

        map.put("projectComments", list);

        return map;
    }

    @Override
    public Projects update(UpdateProjectRequest updateProjectRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateProjectRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateProjectRequest.getProjectId(), ExceptionStatus.PROJECT_ID_MISSING);

        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);
        Projects projects = iDao.find(Projects.class, updateProjectRequest.getProjectId());

        checkNullObject(projects, ExceptionStatus.PROJECT_NOT_FOUND);

        if (Integer.parseInt(users.getUserRole().getRoleTag()) < 3) {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

      /*  projects.setName(updateProjectRequest.getName());
        projects.setInfo(updateProjectRequest.getInfo());
         projects.setClient(updateProjectRequest.getClient());
         projects.setStartDate(getUTCTime(updateProjectRequest.getStartDate()));
         projects.setEndDate(getUTCTime(updateProjectRequest.getEndDate()));

        if (!Objects.equals(projects.getTeams().getTeamId(), updateProjectRequest.getTeamId())) {
            projects.setTeams(iDao.find(Teams.class, updateProjectRequest.getTeamId()));
        }*/

        iDao.update(projects);

        return projects;
    }


    @Override
    public WsResponse updateProject(Long projectId, UpdateProjectRequest updateProjectRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(updateProjectRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(projectId, ExceptionStatus.PROJECT_ID_MISSING);
        checkNullLongId(updateProjectRequest.getManagerId(), ExceptionStatus.PROJECT_MANAGER_ID_MISSING);
        checkNullLongId(updateProjectRequest.getTeamId(), ExceptionStatus.TEAM_ID_MISSING);
        checkNullString(updateProjectRequest.getClient(), ExceptionStatus.CLIENT_ID_MISSING);
        checkNullDate(updateProjectRequest.getInitialDate(), ExceptionStatus.PROJECT_INITIAL_DATE_MISSING);
        checkNullDate(updateProjectRequest.getDeadline(), ExceptionStatus.PROJECT_DEADLINE_MISSING);

        Projects projects = iDao.find(Projects.class, projectId);
        checkNullObject(projects, ExceptionStatus.PROJECT_NOT_FOUND);

        Users manager = iDao.find(Users.class, updateProjectRequest.getManagerId());
        checkNullObject(manager, ExceptionStatus.PROJECT_MANAGER_NOT_FOUND);

        Teams team = iDao.find(Teams.class, updateProjectRequest.getTeamId());
        checkNullObject(team, ExceptionStatus.TEAM_NOT_FOUND);

        Hashtable<String, Object> hashTable = new Hashtable<>();
        hashTable.clear();
        hashTable.put("name", updateProjectRequest.getClient());
        hashTable.put("organizations", users.getOrganizations());
        Clients aClient = iDao.getEntity(Clients.class, queryManager.getClientName(), hashTable, false);
        hashTable.clear();
        checkNullObject(aClient, ExceptionStatus.CLIENT_NOT_FOUND);

        projects.setName(updateProjectRequest.getName());
        projects.setInfo(updateProjectRequest.getInfo());
        projects.setClient(aClient);
        Date initialDate = getUTCTime(updateProjectRequest.getInitialDate());
        Date deadline = getUTCTime(updateProjectRequest.getDeadline());
        projects.setInitialDate(initialDate);
        projects.setDeadline(deadline);
        Boolean b = isFutureDate(initialDate, deadline);
        exception(b, ExceptionStatus.INVALID_TIME_FRAME_OF_PROJECT);
        projects.setManager(manager);
        projects.setTeams(team);
        projects.setTotalMember(team.getMembers().size());
        projects.setUpdatedAt(getCurrentTime());

        try {
            projects = iDao.update(projects);
            return new WsResponse();
        } catch (Exception e) {
            checkNullObject(projects, ExceptionStatus.NEW_NOT_UPDATED);
            return new WsResponse();
        }
    }

    @Override
    public WsResponse deleteProject(Long projectId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        checkNullLongId(projectId, ExceptionStatus.PROJECT_ID_MISSING);

        Projects project = iDao.find(Projects.class, projectId);
        checkNullObject(projectId, ExceptionStatus.PROJECT_NOT_FOUND);

        try {
            iDao.delete(project);
        } catch (Exception e) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }

        project = iDao.find(Projects.class, projectId);

        if (project.getDeleted()) {
            return new WsResponse();
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }
    }

    @Override
    public UniversalResponse delete(Long projectId, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);
        checkNullLongId(projectId, ExceptionStatus.PROJECT_ID_MISSING);

        Projects projects = iDao.find(Projects.class, projectId);
        checkNullObject(projects, ExceptionStatus.PROJECT_NOT_FOUND);

        if (Integer.parseInt(users.getUserRole().getRoleTag()) < 3) {
            iDao.delete(projects);
        } else {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        projects = iDao.find(Projects.class, projectId);

        if (projects.getDeleted()) {
            return new UniversalResponse(true, "Project has been successfully deleted!", "", "", "" + projectId);
        } else {
            throw new UniversalException(ExceptionStatus.PROJECT_NOT_DELETED);
        }
    }
}