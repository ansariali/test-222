package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;
import javax.persistence.*;

@Entity
@Table(name = "comment_likes")
public class CommentLikes extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long commentLikeId;

    private Boolean liked;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users usersId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "commentId")
    private PostComments commentId;

    public Long getCommentLikeId() {
        return commentLikeId;
    }

    public void setCommentLikeId(Long commentLikeId) {
        this.commentLikeId = commentLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public Users getUsersId() {
        return usersId;
    }

    public void setUsersId(Users usersId) {
        this.usersId = usersId;
    }

    public PostComments getCommentId() {
        return commentId;
    }

    public void setCommentId(PostComments commentId) {
        this.commentId = commentId;
    }
}
