package com.ls.TalkHives.utils.ideal;

import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.impl.IEntity;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.util.Date;

@MappedSuperclass
public abstract class UniversalEntity implements IEntity, Serializable {

    /**
     * UniversalEntity
     */
    private static final long serialVersionUID = 1L;

    private Long version = 1L;

    private Boolean deleted = false;

    private Date deletedAt;

    private Users deletedBy;

    private Date createdAt;

    private Date updatedAt;

    private Users updatedBy;

    @Override
    public Long getVersion() {
        return version;
    }

    @Override
    public void setVersion(Long version) {
        this.version = version;
    }

    @Override
    public Boolean getDeleted() {
        return deleted;
    }

    @Override
    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    @Override
    public Date getDeletedAt() {
        return deletedAt;
    }

    @Override
    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    @Override
    public Users getDeletedBy() {
        return deletedBy;
    }

    @Override
    public void setDeletedBy(Users deletedBy) {
        this.deletedBy = deletedBy;
    }

    @Override
    public Date getCreatedAt() {
        return createdAt;
    }

    @Override
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public Date getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public Users getUpdatedBy() {
        return updatedBy;
    }

    @Override
    public void setUpdatedBy(Users updatedBy) {
        this.updatedBy = updatedBy;
    }
}