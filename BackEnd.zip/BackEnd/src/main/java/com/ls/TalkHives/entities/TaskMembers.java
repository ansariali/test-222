package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * TaskMembers Entity
 */

@Entity
@Table(name = "task_members")
public class TaskMembers extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long taskMemberId;

    private String taskMemberTag;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignedBy")
    private Users assignedBy;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "taskId")
    private Tasks tasks;

    public Long getTaskMemberId() {
        return taskMemberId;
    }

    public void setTaskMemberId(Long taskMemberId) {
        this.taskMemberId = taskMemberId;
    }

    public String getTaskMemberTag() {
        return taskMemberTag;
    }

    public void setTaskMemberTag(String taskMemberTag) {
        this.taskMemberTag = taskMemberTag;
    }

    public Users getAssignedBy() {
        return assignedBy;
    }

    public void setAssignedBy(Users assignedBy) {
        this.assignedBy = assignedBy;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Tasks getTasks() {
        return tasks;
    }

    public void setTasks(Tasks tasks) {
        this.tasks = tasks;
    }
}



