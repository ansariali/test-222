package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * TaskDelegation Entity
 */

@Entity
@Table(name = "task_delegation_member")
public class TaskDelegationMember extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long taskDelegationMemberId;

    private String taskDelegationMemberTag;

    private String info;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "taskDelegationId")
    private TaskDelegation taskDelegation;

    public Long getTaskDelegationMemberId() {
        return taskDelegationMemberId;
    }

    public void setTaskDelegationMemberId(Long taskDelegationMemberId) {
        this.taskDelegationMemberId = taskDelegationMemberId;
    }

    public String getTaskDelegationMemberTag() {
        return taskDelegationMemberTag;
    }

    public void setTaskDelegationMemberTag(String taskDelegationMemberTag) {
        this.taskDelegationMemberTag = taskDelegationMemberTag;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public TaskDelegation getTaskDelegation() {
        return taskDelegation;
    }

    public void setTaskDelegation(TaskDelegation taskDelegation) {
        this.taskDelegation = taskDelegation;
    }
}



