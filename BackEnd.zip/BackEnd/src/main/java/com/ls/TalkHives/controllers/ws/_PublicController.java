package com.ls.TalkHives.controllers.ws;

import com.ls.TalkHives.dto.publicController.FetchAllUsers;
import com.ls.TalkHives.dump.Greeting;
import com.ls.TalkHives.dump.HelloMessage;
import com.ls.TalkHives.services.PublicService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;

@Controller
public class _PublicController extends UniversalController {

    private static final String TAG = _PublicController.class.getSimpleName();

    @Autowired
    private PublicService publicService;

    @ApiOperation(value = "_P1 First Api")
//    @MessageMapping("/receive/{token}")
//    @SendTo("/server/first")
    public ResponseEntity<UniversalResponse> universalResponse(@DestinationVariable String token
            , @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "/server/first" + token);
        logger.info(TAG, "/server/first | requestHeader" + requestHeader);
        logger.info(TAG, "/server/first | loginToken" + token);

//        FetchAllUsers res = modelMapper.map(publicService.getUsers(requestHeader, iDao), FetchAllUsers.class);

        return new ResponseEntity<>(new UniversalResponse(true, "First testing of WS!"), responseHeaders, HttpStatus.OK);


        // Integer str = 129018;
        // String str2 = String.format("%10s", str).replace(' ', '0');
        // System.out.println(str2);

        // Thread.sleep(1000); // simulated delay
        // return new UniversalResponse(true, "Hello, " + LocalDateTime.now().getSecond());
    }

   /* private String createTHTag() {
        System.out.println("thTag: " + this.thTag);
        System.out.println("letterL: " + this.letterL);
        System.out.println("letterS: " + this.letterS);
        System.out.println("letterG: " + this.letterG);
        System.out.println("letterO: " + this.letterO);
        System.out.println("number7: " + this.number7);

        System.out.println("userId: " + this.userId);

        System.out.println("organizationId: " + this.organizationId);

        String zeroUserId = String.format("%4d", this.userId).replace(' ', '0');
        String zeroOrganizationId = String.format("%3d", this.organizationId).replace(' ', '0');
        System.out.println(zeroUserId);
        System.out.println(zeroOrganizationId);
//        System.out.println(bigUserId);
//        System.out.println(bigOrganizationId);

//        String sOrganizationId = this.letterS + zeroOrganizationId;

//        String gUserId = this.letterG + zeroUserId;
//        String oOrganizationId = this.letterO + zeroOrganizationId;


//        System.out.println(bigOrganizationId);

        System.out.println("Date 1: " + new Date());
        System.out.println("Date 2: " + new Date().getSeconds());
        System.out.println(LocalDateTime.now().getSecond());

        Integer currentSecond = LocalDateTime.now().getSecond();
        System.out.println("currentSecond: " + currentSecond);

        if (currentSecond > 0 && currentSecond < 7) {
            thTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterL;
        } else if (currentSecond > 6 && currentSecond < 13) {
            thTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterS;
        } else if (currentSecond > 12 && currentSecond < 19) {
            thTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterG;
        } else if (currentSecond > 18 && currentSecond < 25) {
            thTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterO;
        } else if (currentSecond > 24 && currentSecond < 31) {
            thTag = this.letterL + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 30 && currentSecond < 43) {
            thTag = this.letterS + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 42 && currentSecond < 49) {
            thTag = this.letterG + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 48 && currentSecond < 55) {
            thTag = this.letterO + zeroOrganizationId + this.number7 + zeroUserId;
        } else if (currentSecond > 54 && currentSecond < 61) {
            thTag = zeroUserId + this.number7 + zeroOrganizationId + this.letterL;
        } else {
            thTag = this.letterL + zeroOrganizationId + this.number7 + zeroUserId;
        }
        System.out.println(thTag);

        return thTag;

    }*/
}