package com.ls.TalkHives.utils;

import org.slf4j.LoggerFactory;

public class Logger {

    private org.slf4j.Logger logger;

    private boolean logStatus = true;

    private Logger(final boolean logStatus, Class<?> clazz) {
        this.logStatus = logStatus;
        logger = LoggerFactory.getLogger(clazz.getClass());
    }

    public static Logger getInstance(Boolean logStatus, Class<?> clazz) {
        return new Logger(logStatus, clazz);
    }

    public void error(final String TAG, Exception e) {
        if (logStatus) logger.error(TAG + " | " + e.getMessage());
    }

    public void error(final String TAG, String e) {
        if (logStatus) logger.error(TAG + " | " + e);
    }

    public void warn(final String TAG, final String message) {
        if (logStatus) logger.warn(TAG + " | " + message);
    }

    public void info(final String TAG, final String message) {
        if (logStatus) logger.info(TAG + " | " + message);
    }

    public void info(final String TAG, final String message, final String message1) {
        if (logStatus) logger.info(TAG + " | " + message, message1);
    }

    public void debug(final String TAG, final String message) {
        if (logStatus) logger.debug(TAG + " | " + message);
    }
}