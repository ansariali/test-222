package com.ls.TalkHives.utils;

public class EmailSender {

    private static EmailSender emailSender = null;

    private EmailSender() {

    }

    public static EmailSender getInstance() {
        if (emailSender == null) {
            emailSender = new EmailSender();
        }
        return emailSender;
    }

    /*public void onMailSendToOfficialVendor(Vendor vendor, OnMailSendToOfficialVendorListener onMailSendToOfficialVendorListener) {
        if (vendor == null) {
            return;
        }

        if (vendor.getEmailNotificationOn()) {
            if (vendor.getEmailNotificationSendOn() != null) {
                onMailSendToOfficialVendorListener.sendGeneralMail(vendor.getEmailNotificationSendOn(), "USER", vendor.getCompanyName());
            }
        }

        for (UserAccount userAccount : vendor.getUserAccounts()) {
            if (Objects.equals(userAccount.getUserRole(), UserRole.PROMOTER.getUserRole())) {
                onMailSendToOfficialVendorListener.sendToPromoter(userAccount.getEmailAddress(), userAccount.getFirstName(), vendor.getCompanyName());
            } else if (Objects.equals(userAccount.getUserRole(), UserRole.SUPER_ADMIN.getUserRole())) {
                onMailSendToOfficialVendorListener.sendToSuperAdmin(userAccount.getEmailAddress(), userAccount.getFirstName(), vendor.getCompanyName());
            } else if (Objects.equals(userAccount.getUserRole(), UserRole.WATCHER.getUserRole())) {
                onMailSendToOfficialVendorListener.sendToWatcher(userAccount.getEmailAddress(), userAccount.getFirstName(), vendor.getCompanyName());
            }
        }

        if (vendor.getBuyerEnable() && !vendor.getBuyerBlocked()) {
            if (vendor.getBuyer() != null) {
                if (vendor.getBuyer().getEmailNotificationOn() && vendor.getBuyer().getEmailNotificationSendOn() != null && vendor.getBuyer().getNodalContact() != null) {
                    onMailSendToOfficialVendorListener.sendToBuyer(vendor.getBuyer().getEmailNotificationSendOn(), vendor.getBuyer().getNodalContact().getFirstName(), vendor.getCompanyName());
                }
            }
        }

        if (vendor.getSellerEnable() && !vendor.getSellerBlocked()) {
            if (vendor.getSeller() != null) {
                if (vendor.getSeller().getEmailNotificationOn() && vendor.getSeller().getEmailNotificationSendOn() != null && vendor.getSeller().getNodalContact() != null) {
                    onMailSendToOfficialVendorListener.sendToSeller(vendor.getSeller().getEmailNotificationSendOn(), vendor.getSeller().getNodalContact().getFirstName(), vendor.getCompanyName());
                }
            }
        }
    }

    public void onMailSendToCustomVendor(CustomVendor customVendor, OnMailSendToCustomVendorListener onMailSendToCustomVendorListener) {
        if (customVendor == null) {
            return;
        }

        onMailSendToCustomVendorListener.sendGeneralMail(customVendor.getEmailAddress(), customVendor.getPointOfContact(), customVendor.getCompanyName());

        if (customVendor.getDefaultEmailAddress() != null) {
            onMailSendToCustomVendorListener.sendDefaultMail(customVendor.getDefaultEmailAddress(), "USER", customVendor.getCompanyName());
        }
    }

    public interface OnMailSendToOfficialVendorListener {
        void sendGeneralMail(String emailAddress, String firstName, String companyName);

        default void sendToPromoter(String emailAddress, String firstName, String companyName) {
        }

        default void sendToSuperAdmin(String emailAddress, String firstName, String companyName) {
        }

        default void sendToWatcher(String emailAddress, String firstName, String companyName) {
        }

        default void sendToBuyer(String emailAddress, String firstName, String companyName) {
        }

        default void sendToSeller(String emailAddress, String firstName, String companyName) {
        }
    }

    public interface OnMailSendToCustomVendorListener {
        void sendGeneralMail(String emailAddress, String firstName, String companyName);

        default void sendDefaultMail(String emailAddress, String firstName, String companyName) {
        }
    }*/
}
