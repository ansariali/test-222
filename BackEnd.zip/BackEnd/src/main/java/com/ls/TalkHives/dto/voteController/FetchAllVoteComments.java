package com.ls.TalkHives.dto.voteController;

import com.ls.TalkHives.dto.common.ProjectCommentEntity;
import com.ls.TalkHives.dto.common.VoteCommentEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllVoteComments {

    private List<VoteCommentEntity> voteComments = new ArrayList<>();

    public List<VoteCommentEntity> getVoteComments() {
        return voteComments;
    }

    public void setVoteComments(List<VoteCommentEntity> voteComments) {
        this.voteComments = voteComments;
    }
}
