package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.userController.*;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.UserService;
import com.ls.TalkHives.services.impl.handler.UserServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.FrontEndPath;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.transaction.Transactional;
import java.io.IOException;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

@Service
@Transactional
public class UserServiceImpl extends UserServiceImplHandler implements UserService {

    private static final String TAG = UserServiceImpl.class.getSimpleName();

    @Override
    public UniversalResponse register(CreateUserRequest createUserRequest, IDao<IEntity, Serializable> iDao) {
        checkNullObject(createUserRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);

        Organizations organizations = new Organizations();
        organizations.setName(createUserRequest.getOrgName());
        organizations.setInfo(createUserRequest.getOrgInfo());
        organizations.setType(createUserRequest.getOrgType());
        organizations.setSpecificType(createUserRequest.getSpecificOrgType());
        organizations.setCreatedAt(getCurrentTime());

        Organizations _Organizations = iDao.find(Organizations.class, iDao.persist(organizations));

        Users users = new Users();
        users.setFirstName(util.capitalizeFirstLetter(createUserRequest.getFirstName()));
        users.setLastName(util.capitalizeFirstLetter(createUserRequest.getLastName()));
        users.setUserRole(findUserRole(GlobalTag.ROLE_LEVEL1.getGlobalTag(), iDao));
        users.setDesignation(createUserRequest.getDesignation());
        users.setGender(createUserRequest.getGender());
        users.setBirthDay(createUserRequest.getBirthDay());

        findUserName(createUserRequest.getUserName(), iDao);
        users.setUserName(createUserRequest.getUserName());

        findEmailId(createUserRequest.getEmailId(), iDao);
        users.setEmailId(createUserRequest.getEmailId());

        users.setPassword(createUserRequest.getPassword());
        users.setCountryCode(createUserRequest.getCountryCode());
        users.setMobileNo(createUserRequest.getMobileNo());
        users.setCreatedAt(getCurrentTime());
        users.setOrganizations(organizations);

        Users _Users = iDao.find(Users.class, iDao.persist(users));

        if (createUserRequest.getFiles() != null) {
            Images images = new Images();
            images.setType(createUserRequest.getFiles().getType());
            images.setFileName(createUserRequest.getFiles().getName());

            String folderName = S3Storage.FOLDER_USERS.getValue() + S3Storage.SUFFIX.getValue();
            // s3StorageService.createFolder(folderName);
            String prefix = folderName + _Users.getUserId().toString();

            // images.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            images.setFileUrl(s3StorageService.copyFile(prefix, createUserRequest.getFiles().getFileUrl()));
            // try {
            //     images.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            // } catch (IOException e) {
            //     e.printStackTrace();
            // }

            images.setImageTag(Ascii.IMAGE.getCode() + Ascii.PROFILE.getCode());
            images.setCreatedAt(getCurrentTime());

            // Images _Images = iDao.find(Images.class, iDao.persist(images));

            _Users.setImages(images);
        } else {
            // Images _Images = iDao.find(Images.class, 1L);
            _Users.setImages(iDao.find(Images.class, 1L));
        }

        // Set HashTag
        _Users.setHashTag(getUserTag(_Users.getUserId()));
        _Organizations.setHashTag(getOrganizationTag(_Organizations.getOrganizationId()));

        // Set Total Employees
        _Organizations.setUser(_Users);
        _Organizations.setTotalEmployee(_Organizations.getTotalEmployee() + 1);

        TalkHives talkHives = new TalkHives();
        talkHives.setUser(_Users);
        talkHives.setOrganizations(_Organizations);
        talkHives.setThTag(tag.THTag(_Organizations.getOrganizationId(), _Users.getUserId()));
        talkHives.setCreatedAt(getCurrentTime());

        TalkHives _TalkHives = iDao.find(TalkHives.class, iDao.persist(talkHives));

        if (_TalkHives != null) {
            emailService.welcomeMail(users.getEmailId(), users.getFirstName(), organizations.getName());
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_ADDED);
        }

        return new UniversalResponse(true, "USER has been successfully registered!");
    }

    @Override
    public LoginResponse login(String userName, String password, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();

        if (userName == null || password == null) {
            throw new UniversalException(ExceptionStatus.USER_NAME_OR_PASSWORD_MISSING);
        }

        hashtable.put("userName", userName);
        hashtable.put("password", password);
        Users user_ = iDao.getEntity(Users.class, queryManager.getTHTagStep1(), hashtable, false);
        hashtable.clear();

        checkNullObject(user_, ExceptionStatus.USER_NOT_FOUND);

        hashtable.put("userId", user_);
        hashtable.put("organizationId", user_.getOrganizations());
        TalkHives talkHives_ = iDao.getEntity(TalkHives.class, queryManager.getTHTagStep2(), hashtable, false);
        hashtable.clear();

        logger.info(TAG, "getTHTagStep2: " + talkHives_.getThTag());

        // if (!talkHives_.getVerified()) {
        //     throw new UniversalException(ExceptionStatus.USER_ACCOUNT_NOT_VERIFIED);
        // }
        //
        // if (talkHives_.getDisabled()) {
        //     throw new UniversalException(ExceptionStatus.USER_ACCOUNT_DISABLED);
        // }

        LoginUsers loginUsers = new LoginUsers();
        loginUsers.setThTag(talkHives_.getThTag());
        loginUsers.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));
        loginUsers.setLoginToken(util.getTokenNumber());
        loginUsers.setWsConnection(Boolean.TRUE);

        LoginUsers _LoginUsers = iDao.find(LoginUsers.class, iDao.persist(loginUsers));
        checkNullObject(_LoginUsers, ExceptionStatus.LOGIN_SESSION_FAILURE);

        LoginResponse loginResponse = new LoginResponse();

        if (user_.getImages() != null) {
            loginResponse.setProfilePic(user_.getImages().getFileUrl());
        } else {
            loginResponse.setProfilePic(S3Storage.DEFAULT_USER_PIC_URL.getValue());
        }

        loginResponse.setLoginToken(_LoginUsers.getLoginToken());
        loginResponse.setUserId(talkHives_.getUser().getUserId());
        loginResponse.setFirstName(user_.getFirstName());
        loginResponse.setLastName(user_.getLastName());
        loginResponse.setUserName(user_.getUserName());
        loginResponse.setUserRole(user_.getUserRole().getRoleTitle());
        loginResponse.setUserLevel(user_.getUserRole().getRoleTag());
        loginResponse.setEmailId(user_.getEmailId());
        loginResponse.setCountryCode(user_.getCountryCode());
        loginResponse.setMobileNo(user_.getMobileNo());
        loginResponse.setGender(user_.getGender());
        loginResponse.setBirthDay(user_.getBirthDay());
        loginResponse.setDisabled(talkHives_.getDisabled());
        loginResponse.setCreatedAt(user_.getCreatedAt());

        loginResponse.setOrgId(user_.getOrganizations().getOrganizationId());
        loginResponse.setOrgName(user_.getOrganizations().getName());
        loginResponse.setOrgInfo(user_.getOrganizations().getInfo());
        loginResponse.setOrgType(user_.getOrganizations().getType());
        loginResponse.setSpecificOrgType(user_.getOrganizations().getSpecificType());

        return loginResponse;
    }

    @Override
    public UniversalResponse logOut(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        LoginUsers loginUsers = findLoginUser(requestHeader, iDao);

        loginUsers.setLoggedOut(Boolean.TRUE);
        loginUsers.setDeleted(Boolean.TRUE);
        loginUsers.setDeletedAt(getCurrentTime());
        loginUsers.setUpdatedAt(getCurrentTime());

        if (loginUsers.getLoggedOut()) {
            return new UniversalResponse(true, "USER has been successfully logged out!", null, FrontEndPath.LOGIN.getRedirectTo());
        } else {
            return new UniversalResponse(false, "Logout failed!");
        }
    }

    @Override
    public LoginResponse rememberMe(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        // LoginUsers _LoginUsers = findLoginUser(requestHeader, iDao);
        Users user_ = findUserByLoginToken(requestHeader, iDao);

        if (user_ == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }
        LoginResponse loginResponse = new LoginResponse();
        // loginResponse.setImageContent(user_.getImages().getContent());
        loginResponse.setProfilePic(user_.getImages().getFileUrl());

        // loginResponse.setLoginToken(_LoginUsers.getLoginToken());
        loginResponse.setFirstName(user_.getFirstName());
        loginResponse.setLastName(user_.getLastName());
        loginResponse.setUserName(user_.getUserName());
        loginResponse.setUserRole(user_.getUserRole().getRoleTitle());
        loginResponse.setUserLevel(user_.getUserRole().getRoleTag());
        loginResponse.setEmailId(user_.getEmailId());
        loginResponse.setCountryCode(user_.getCountryCode());
        loginResponse.setMobileNo(user_.getMobileNo());
        loginResponse.setCreatedAt(user_.getCreatedAt());

        loginResponse.setOrgId(user_.getOrganizations().getOrganizationId());
        loginResponse.setOrgName(user_.getOrganizations().getName());
        loginResponse.setOrgInfo(user_.getOrganizations().getInfo());
        loginResponse.setOrgType(user_.getOrganizations().getType());
        loginResponse.setSpecificOrgType(user_.getOrganizations().getSpecificType());

        return loginResponse;
    }

    @Override
    public UniversalResponse sendInvite(CreateInvitationRequest createInvitationRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {

        Users users = findUserByLoginToken(requestHeader, iDao);

        Invitations invitations = new Invitations();

        findEmailId(createInvitationRequest.getEmailId(), iDao);

        invitations.setEmailId(createInvitationRequest.getEmailId());
        invitations.setPersonName(createInvitationRequest.getPersonName());
        invitations.setInviteToken(util.getTokenNumber());
        invitations.setUserRole(findUserRole(createInvitationRequest.getUserRole(), iDao));
        invitations.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));
        invitations.setUsers(users);

        Invitations _Invitations = iDao.find(Invitations.class, iDao.persist(invitations));

        Organizations organizations = findOrgByUser(users.getOrganizations().getOrganizationId(), iDao);

        if (_Invitations != null) {
            emailService.sendInvitationMail(_Invitations.getEmailId(), _Invitations.getPersonName(), organizations.getName(), users.getFirstName(), _Invitations.getInviteToken());
        } else {
            throw new UniversalException(ExceptionStatus.INVITATION_FAILURE);
        }

        return new UniversalResponse(true, "Invitation has been successfully sent!");
    }

    @Override
    public UniversalResponse registerByInvite(MultipartFile multipartFile, MultipartHttpServletRequest multipartHttpServletRequest, String token, IDao<IEntity, Serializable> iDao) {

        logger.info(TAG, "multipartHttpServletRequest.getParameter(\"info\"): " + multipartFile);
        logger.info(TAG, "multipartHttpServletRequest.getParameter(\"info\") 1111: " + multipartHttpServletRequest.getParameter("info"));
//        CreateInvitedUserRequest createInvitedUserRequest = gson.fromJson(multipartHttpServletRequest.getParameter("info"), CreateInvitedUserRequest.class);
        CreateInvitedUserRequest createInvitedUserRequest = (CreateInvitedUserRequest) refactor.jsonToJava(multipartHttpServletRequest.getParameter("info"), CreateInvitedUserRequest.class);
        checkNullObject(createInvitedUserRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);

        Invitations invitations = findInvitation(token, iDao);

        // Images images = new Images();
        // images.setContent(createInvitedUserRequest.getImages().getContent());
        // images.setType(createInvitedUserRequest.getImages().getType());
        // images.setFileName(createInvitedUserRequest.getImages().getFileName());
        // images.setImageTag(Ascii.IMAGE.getCode() + Ascii.PROFILE.getCode());
        // images.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));
        //
        // Images _Images = iDao.find(Images.class, iDao.persist(images));

        Organizations organizations = findOrgByUser(invitations.getUsers().getOrganizations().getOrganizationId(), iDao);
        Users users = new Users();
        // users.setImages(_Images);
        users.setFirstName(util.capitalizeFirstLetter(createInvitedUserRequest.getFirstName()));
        users.setLastName(util.capitalizeFirstLetter(createInvitedUserRequest.getLastName()));
        users.setUserRole(invitations.getUserRole());
        users.setDesignation(createInvitedUserRequest.getDesignation());
        users.setGender(createInvitedUserRequest.getGender());
        users.setBirthDay(createInvitedUserRequest.getBirthDay());

//        findUserName(createInvitedUserRequest.getUserName(), iDao);
//        findEmailId(createInvitedUserRequest.getEmailId(), iDao);

        users.setUserName(createInvitedUserRequest.getUserName());
        users.setEmailId(createInvitedUserRequest.getEmailId());
        users.setPassword(createInvitedUserRequest.getPassword());
        users.setCountryCode(createInvitedUserRequest.getCountryCode());
        users.setMobileNo(createInvitedUserRequest.getMobileNo());
        users.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));
        users.setOrganizations(organizations);

        Users _Users = iDao.find(Users.class, iDao.persist(users));

        if (multipartFile != null) {
            Images images = new Images();
            images.setType(multipartFile.getContentType());
            images.setFileName(multipartFile.getOriginalFilename());

            String folderName = S3Storage.FOLDER_USERS.getValue() + S3Storage.SUFFIX.getValue();
            String prefix = folderName + _Users.getUserId().toString();
            try {
                String generateUrl = s3StorageService.uploadFile(prefix, multipartFile);
                images.setFileUrl(S3Storage.S3_URL.getValue() + generateUrl);

            } catch (IOException e) {
                e.printStackTrace();
            }
            images.setImageTag(Ascii.IMAGE.getCode() + Ascii.PROFILE.getCode());
            images.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));

            Images _Images = iDao.find(Images.class, iDao.persist(images));
            _Users.setImages(_Images);
        } else {
            Images _Images = iDao.find(Images.class, 1L);
            _Users.setImages(_Images);
        }

        organizations.setTotalEmployee(organizations.getTotalEmployee() + 1);

        TalkHives talkHives = new TalkHives();
        talkHives.setUser(_Users);
        talkHives.setInvitedBy(invitations.getUsers());
        talkHives.setOrganizations(organizations);
        talkHives.setThTag(tag.THTag(organizations.getOrganizationId(), _Users.getUserId()));
        talkHives.setCreatedAt(refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime()));

        TalkHives _TalkHives = iDao.find(TalkHives.class, iDao.persist(talkHives));

        if (_TalkHives != null) {
            invitations.setRegistered(Boolean.TRUE);
            emailService.welcomeMail(_Users.getEmailId(), _Users.getFirstName(), organizations.getName());
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_ADDED);
        }

        logger.info(TAG, "IMPL 2: " + _TalkHives.getThTag());

        return new UniversalResponse(true, "USER has been successfully registered!");
    }

    @Override
    public UpdateUserRequest fetchProfile(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {

        Users user = findUserByLoginToken(requestHeader, iDao);

        return modelMapper.map(user, UpdateUserRequest.class);
    }

    @Override
    public WsResponse updateProfile(Long profileId, Map<String, Object> requestHeader, UpdateUserRequest RequestUsers, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(RequestUsers, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(profileId, ExceptionStatus.USER_ID_MISSING);

        Users aUsers = iDao.find(Users.class, profileId);
        checkNullObject(aUsers, ExceptionStatus.USER_NOT_FOUND);
        if (!aUsers.getUserId().equals(users.getUserId())) {
            checkNullObject(aUsers, ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        aUsers.setFirstName(RequestUsers.getFirstName());
        aUsers.setLastName(RequestUsers.getLastName());
        aUsers.setMobileNo(RequestUsers.getMobileNo());
        aUsers.setUpdatedAt(getCurrentTime());

        try {
            aUsers = iDao.update(aUsers);
            return new WsResponse();
        } catch (Exception e) {
            checkNullObject(aUsers, ExceptionStatus.NEW_NOT_UPDATED);
            return new WsResponse();
        }
    }
}