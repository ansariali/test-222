package com.ls.TalkHives.dto.chatController;

public class CreateChatRequest {

    private String chatRoomTag;
    private String content;

    public String getChatRoomTag() {
        return chatRoomTag;
    }

    public void setChatRoomTag(String chatRoomTag) {
        this.chatRoomTag = chatRoomTag;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
