package com.ls.TalkHives.dto.teamController;

import com.ls.TalkHives.dto.common.TeamEntity;
import com.ls.TalkHives.dto.common.TeamInfoEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllTeamInfo {

    private List<TeamInfoEntity> teams = new ArrayList<>();

    public List<TeamInfoEntity> getTeams() {
        return teams;
    }

    public void setTeams(List<TeamInfoEntity> teams) {
        this.teams = teams;
    }
}
