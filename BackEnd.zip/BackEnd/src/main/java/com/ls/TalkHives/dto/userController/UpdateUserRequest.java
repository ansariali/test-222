package com.ls.TalkHives.dto.userController;

import com.ls.TalkHives.dto.common.FileEntity;

import java.util.Date;

public class UpdateUserRequest {
    private Long userId;
    private String firstName;
    private String lastName;
    private String mobileNo;
    private String designation;
    private String emailId;
    private String userName;
    private String countryCode;
    private String gender;
    private Date birthDay;
    private String orgName;
    private String orgInfo;
    private String orgType;
    private String specificOrgType;
    private FileEntity files;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getOrgInfo() {
        return orgInfo;
    }

    public void setOrgInfo(String orgInfo) {
        this.orgInfo = orgInfo;
    }

    public String getOrgType() {
        return orgType;
    }

    public void setOrgType(String orgType) {
        this.orgType = orgType;
    }

    public String getSpecificOrgType() {
        return specificOrgType;
    }

    public void setSpecificOrgType(String specificOrgType) {
        this.specificOrgType = specificOrgType;
    }

    public FileEntity getFiles() {
        return files;
    }

    public void setFiles(FileEntity files) {
        this.files = files;
    }
}
