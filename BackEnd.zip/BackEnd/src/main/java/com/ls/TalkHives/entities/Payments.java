package com.ls.TalkHives.entities;

import com.ls.TalkHives.entities.common.CommonEntity;

import javax.persistence.*;

/**
 * Payments Entity
 */

@Entity
@Table(name = "payments")
public class Payments extends CommonEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long paymentId;

    private String paymentStatus;
    private Integer paymentDays;
    private Integer paymentInfo;
    private Double paidAmount;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "planId")
    private Plans plans;

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Integer getPaymentDays() {
        return paymentDays;
    }

    public void setPaymentDays(Integer paymentDays) {
        this.paymentDays = paymentDays;
    }

    public Integer getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(Integer paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Plans getPlans() {
        return plans;
    }

    public void setPlans(Plans plans) {
        this.plans = plans;
    }
}
