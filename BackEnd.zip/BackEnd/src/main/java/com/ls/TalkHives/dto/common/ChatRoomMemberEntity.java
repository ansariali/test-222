package com.ls.TalkHives.dto.common;

import com.ls.TalkHives.entities.ChatRoomMembers;
import com.ls.TalkHives.entities.Users;

import java.util.Date;
import java.util.Set;

public class ChatRoomMemberEntity {

    private Long chatRoomMemberId;
    private Boolean admin;
    private _UserEntity users;
    private ChatEntity chatRooms;
    private Date createdAt;

    public Long getChatRoomMemberId() {
        return chatRoomMemberId;
    }

    public void setChatRoomMemberId(Long chatRoomMemberId) {
        this.chatRoomMemberId = chatRoomMemberId;
    }

    public Boolean getAdmin() {
        return admin;
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }

    public _UserEntity getUsers() {
        return users;
    }

    public void setUsers(_UserEntity users) {
        this.users = users;
    }

    public ChatEntity getChatRooms() {
        return chatRooms;
    }

    public void setChatRooms(ChatEntity chatRooms) {
        this.chatRooms = chatRooms;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
