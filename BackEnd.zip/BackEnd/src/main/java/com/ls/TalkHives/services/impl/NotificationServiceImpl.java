package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.NotificationEntity;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.NotificationService;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.enums.WSApi;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.*;

@SuppressWarnings("deprecation")
@Component
public class NotificationServiceImpl extends UniversalService implements NotificationService {

    private static final String TAG = NotificationServiceImpl.class.getSimpleName();

    @Override
    public Date clock() {
        logger.info(TAG, "Inside clock" + new Date());

        class SayHello extends TimerTask {
            public void run() {
                simpMessagingTemplate.convertAndSend("/topic/clock/1", new Date());

                // System.out.println(new Date());
            }
        }
        Timer timer = new Timer();
        // timer.schedule(new SayHello(), 0, 1000);
        timer.schedule(new SayHello(), 0, 1000);

        return new Date();
    }

    @Override
    public Notifications create(Long activityId, String tag, Users users, IDao<IEntity, Serializable> iDao) {
        Notifications notifications = new Notifications();
        notifications.setToken(util.getTokenNumber());
        notifications.setSender(users);
        notifications.setOrganizations(users.getOrganizations());
        notifications.setCreatedAt(getCurrentTime());

        if (Ascii.POST.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.POST.getCode());
            notifications.setPosts(iDao.find(Posts.class, activityId));
            notifications.setWho(notifications.getPosts().getUser());
            notifications.setPrivacyLevel(notifications.getPosts().getPrivacyLevel());
        } else if (Ascii.BLOG.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.BLOG.getCode());
            notifications.setBlogs(iDao.find(Blogs.class, activityId));
            notifications.setWho(notifications.getBlogs().getUser());
        } else if (Ascii.VOTE.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.VOTE.getCode());
            notifications.setVotes(iDao.find(Votes.class, activityId));
            notifications.setWho(notifications.getVotes().getUsers());
        } else if (Ascii.TEAM.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.VOTE.getCode());
            notifications.setTeams(iDao.find(Teams.class, activityId));
            notifications.setWho(notifications.getTeams().getUsers());
        } else if (Ascii.TASK.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.TASK.getCode());
            notifications.setTasks(iDao.find(Tasks.class, activityId));
            notifications.setWho(notifications.getTasks().getUsers());
        } else if (Ascii.MEETING.getCode().equals(tag)) {
            notifications.setNotificationTag(Ascii.MEETING.getCode());
            notifications.setMeetings(iDao.find(Meetings.class, activityId));
            notifications.setWho(notifications.getMeetings().getUsers());
        }

        return notifications;
    }

    @Override
    public Map<String, List<Notifications>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Notifications>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Notifications> list = iDao.getEntities(Notifications.class, queryManager.getAllNotifications(), hashtable, false);
        hashtable.clear();

        List<Notifications> _list = new ArrayList<>();

        for (Notifications notifications : list) {
            if (notifications.getType().equals(Ascii.USER.getCode())) {
                if (!notifications.getReceiver().equals(users)) {
                    _list.add(notifications);
                }
            } else if (notifications.getType().equals(Ascii.ORGANIZATION.getCode())) {
                if (notifications.getWho() != null) {
                    if (notifications.getWho().equals(users) || notifications.getSender().equals(users)) {
                        _list.add(notifications);
                    }
                }
            } else if (notifications.getType().equals(Ascii.PRIVACY.getCode())) {
                int i = Integer.parseInt(users.getUserRole().getRoleTag());
                int j = Integer.parseInt(notifications.getPrivacyLevel().getPrivacyTag());
                if (j < i) {
                    _list.add(notifications);
                }
            }
        }

        list.removeAll(_list);

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("notifications", list);

        return map;
    }

    @Override
    public void sentToUser(Long activityId, String tag, Boolean self, String message, Users receiver, Users users, IDao<IEntity, Serializable> iDao) {
        Notifications notifications = create(activityId, tag, users, iDao);
        notifications.setSelf(self);
        notifications.setMessage(message);
        notifications.setReceiver(receiver);
        notifications.setType(Ascii.USER.getCode());
        Notifications notifications_ = iDao.find(Notifications.class, iDao.persist(notifications));
        NotificationEntity notificationEntity = modelMapper.map(notifications_, NotificationEntity.class);

        simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_NOTIFICATION.getSendTo()
                .replace("{userId}", notifications_.getReceiver().getUserId().toString()), notificationEntity);
    }

    @Override
    public void sentToOrganization(Long activityId, String tag, Boolean self, String message, Users users, IDao<IEntity, Serializable> iDao) {
        Notifications notifications = create(activityId, tag, users, iDao);
        notifications.setSelf(self);
        notifications.setMessage(message);
        notifications.setType(Ascii.ORGANIZATION.getCode());

        Notifications notifications_ = iDao.find(Notifications.class, iDao.persist(notifications));
        NotificationEntity notificationEntity = modelMapper.map(notifications_, NotificationEntity.class);

        simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_ORGANIZATION_NOTIFICATION.getSendTo().replace("{organizationId}", notifications_.getOrganizations().getOrganizationId().toString()), notificationEntity);
    }

    @Override
    public void sendToDesignation(Long activityId, String tag, Boolean self, String message, Users users, IDao<IEntity, Serializable> iDao) {
        Notifications notifications = create(activityId, tag, users, iDao);
        notifications.setSelf(self);
        notifications.setMessage(message);
        notifications.setType(Ascii.PRIVACY.getCode());

        Notifications notifications_ = iDao.find(Notifications.class, iDao.persist(notifications));
        NotificationEntity notificationEntity = modelMapper.map(notifications_, NotificationEntity.class);

        int j = Integer.parseInt(notifications_.getPrivacyLevel().getPrivacyTag());
        for (int i = 1; i <= j; i++) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_DESIGNATION_NOTIFICATION.getSendTo().replace("{userRoleTag}", "" + i), notificationEntity);
        }
    }

    @Override
    public void postNotification(String Activity, Posts posts, Users users, IDao<IEntity, Serializable> iDao) {
        String message;
        String creator;
        String verb;

        // Send notification to Post Owner
        if (posts.getUser().equals(users)) {
            creator = "You";
            verb = "have";
        } else {
            creator = users.getFirstName() + " " + users.getLastName();
            verb = "has";
        }

        message = Notification.valueOf(Activity).getSelfMessage()
                .replace("{verb}", verb)
                .replace("{creator}", creator);
        notificationService.sentToUser(posts.getPostId(), Ascii.POST.getCode(), Boolean.TRUE, message, posts.getUser(), users, iDao);

        if (posts.getUser().equals(users)) {
            message = Notification.valueOf(Activity).getCustomMessage()
                    .replace("{user}", posts.getUser().getFirstName() + " " + posts.getUser().getLastName());
        } else {
            message = Notification.valueOf(Activity).getPublicMessage()
                    .replace("{creator}", users.getFirstName() + " " + users.getLastName())
                    .replace("{user}", posts.getUser().getFirstName() + " " + posts.getUser().getLastName());
        }

        if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL10.getGlobalTag())) {
            for (PostSharing postSharing : posts.getPostSharing()) {
                notificationService.sentToUser(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, postSharing.getUser(), users, iDao);
            }

        } else if (posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL9.getGlobalTag()) || posts.getPrivacyLevel().getPrivacyTag().equals(GlobalTag.PRIVACY_LEVEL6.getGlobalTag())) {

            // if (posts.getShared()) {
            //     // TODO: !!!!
            //     String _message;
            //     message = NOTIFICATION.SHARE_POST.getPublicMessage().replace("{creator}", posts.getSharedBy().getFirstName() + " " + posts.getSharedBy().getLastName()).replace("{user}", posts.getUser().getFirstName() + " " + posts.getUser().getLastName());
            //     notificationService.sentToOrganization(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);
            //
            //     message = NOTIFICATION.SHARE_POST.getSelfMessage().replace("{creator}", posts.getSharedBy().getFirstName() + " " + posts.getSharedBy().getLastName());
            //     notificationService.sentToUser(posts.getPostId(), Ascii.POST.getCode(), Boolean.TRUE, message, posts.getUser(), users, iDao);
            //     // TODO: !!!!
            // } else {
            notificationService.sentToOrganization(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);
            // }

        } else if (Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag()) > 0 && Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag()) < 6) {
            int j = Integer.parseInt(posts.getPrivacyLevel().getPrivacyTag());
            for (int i = 1; i <= j; i++) {
                notificationService.sendToDesignation(posts.getPostId(), Ascii.POST.getCode(), Boolean.FALSE, message, users, iDao);
            }
        }
    }

    @Override
    public void voteNotification(String Activity, Votes votes, Users users, IDao<IEntity, Serializable> iDao) {
        String message;
        String creator;
        String verb;

        // Send notification to Vote Owner
        if (votes.getUsers().equals(users)) {
            creator = "You";
            verb = "have";
        } else {
            creator = users.getFirstName() + " " + users.getLastName();
            verb = "has";
        }

        message = Notification.valueOf(Activity).getSelfMessage()
                .replace("{verb}", verb)
                .replace("{creator}", creator);
        notificationService.sentToUser(votes.getVoteId(), Ascii.VOTE.getCode(), Boolean.TRUE, message, votes.getUsers(), users, iDao);

        // Send notification to ORGANIZATION
        if (votes.getUsers().equals(users)) {
            message = Notification.valueOf(Activity).getCustomMessage()
                    .replace("{user}", votes.getUsers().getFirstName() + " " + votes.getUsers().getLastName());
        } else {
            message = Notification.valueOf(Activity).getPublicMessage()
                    .replace("{creator}", users.getFirstName() + " " + users.getLastName())
                    .replace("{user}", votes.getUsers().getFirstName() + " " + votes.getUsers().getLastName());
        }

        notificationService.sentToOrganization(votes.getVoteId(), Ascii.VOTE.getCode(), Boolean.FALSE, message, users, iDao);
    }
}