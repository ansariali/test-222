package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class HttpRequestMethodNotValidException extends BaseException {

	private static final long serialVersionUID = 1L;

	public HttpRequestMethodNotValidException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public HttpRequestMethodNotValidException() {
		super(ExceptionStatus.HTTP_REQUEST_METHOD_NOT_VALID);
	}
}