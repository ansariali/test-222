package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.UserActivityEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllActivity {

    private List<UserActivityEntity> selfActivities = new ArrayList<>();

    public List<UserActivityEntity> getSelfActivities() {
        return selfActivities;
    }

    public void setSelfActivities(List<UserActivityEntity> selfActivities) {
        this.selfActivities = selfActivities;
    }
}
