package com.ls.TalkHives.dto.projectController;

public class fetchProjectMilestone {
    private Long projectMilestoneId;
    private String name;

    public Long getProjectMilestoneId() {
        return projectMilestoneId;
    }

    public void setProjectMilestoneId(Long projectMilestoneId) {
        this.projectMilestoneId = projectMilestoneId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
