package com.ls.TalkHives.dto.pinController;

import com.ls.TalkHives.dto.common.PinEntity;

import java.util.Date;

public class CreatePinRequest {
    private String title;
    private String message;
    private Date createdAt;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
