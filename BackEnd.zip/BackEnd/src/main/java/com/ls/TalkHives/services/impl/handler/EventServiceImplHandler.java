package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.entities.Events;
import com.ls.TalkHives.entities.Maintenance;
import com.ls.TalkHives.entities.MeetingMembers;
import com.ls.TalkHives.entities.Meetings;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public abstract class EventServiceImplHandler extends UniversalService {

    private Long getEventTimeGap(Date _eventTiming) {
        Long eventTiming = _eventTiming.getTime();
        Long currentTime = getCurrentTime().getTime();

        if (eventTiming > currentTime) {
            Long gap = eventTiming - currentTime;

            Long msPerMinute = 60L * 1000L;
            // Long msPerHour = msPerMinute * 60L;
            // Long msPerDay = msPerHour * 24L;
            // Long msPerMonth = msPerDay * 30L;
            // Long msPerYear = msPerDay * 365L;

            Long _30Minutes = msPerMinute * 30L;
            // Long _5Minutes = msPerMinute * 5L;

            if (gap > _30Minutes) {
                return _30Minutes;
            } else
                return 0L;
        } else {
            return 0L;
        }
    }

    //
    protected void resetMeetingEvent(Maintenance maintenance, Date date, IDao<IEntity, Serializable> iDao) {
        if (maintenance == null) {
            maintenance = getMaintenance(iDao);
        }
        if (maintenance.getMeetingEvent()) {
            // Check for resetting event with timing
            if (!isFutureDate(maintenance.getMeetingTime(), date)) {
                meetingEvent(maintenance, iDao);
            }
        } else {
            // Start up
            meetingEvent(maintenance, iDao);
        }
    }

    protected void createMeetingEvent(Maintenance maintenance, Meetings meetings, IDao<IEntity, Serializable> iDao) {
        Events events = new Events();
        events.setType(Ascii.MEETING.getCode());
        events.setTiming(meetings.getTiming());

        // Timing gap for notification
        // events.setTimingGap(getEventTimeGap(meetings.getTiming()));
        events.setTimingGap(0L);

        events.setMeetings(meetings);
        events.setUsers(meetings.getUsers());
        events.setOrganizations(meetings.getUsers().getOrganizations());
        events.setCreatedAt(getCurrentTime());

        Events events_ = iDao.find(Events.class, iDao.persist(events));

        // Reset meeting Event
        resetMeetingEvent(maintenance, events.getTiming(), iDao);
    }

    protected void meetingEvent(Maintenance maintenance, IDao<IEntity, Serializable> iDao) {
        List<Events> list = iDao.getEntities(Events.class, queryManager.getAllNextMeetingEvents());
        List<Events> deleteEvent = new ArrayList<>();

        if (list.size() > 0) {
            // Get Timing for Thread or Loop
            Date currentTime = getCurrentTime();
            Date futureTime = list.get(0).getTiming();

            maintenance.setMeetingEvent(Boolean.TRUE);
            maintenance.setMeetingTime(futureTime);

            // Todo: WorldWild [ Switch-case according to Org.Timezone then loop also need update ]
            Long delay = getIndianTime(futureTime).getTime() - currentTime.getTime();

            Timer timer = new Timer();
            class execute extends TimerTask {
                public void run() {
                    for (Events events : list) {
                        Meetings meetings = events.getMeetings();
                        for (MeetingMembers meetingMembers : meetings.getMembers()) {

                            // Notify Meeting members
                            String message = Notification.MEETING_EVENT.getSelfMessage()
                                    .replace("{meeting}", meetings.getTitle());
                            notificationService.sentToUser(meetings.getMeetingId(), Ascii.MEETING.getCode(),
                                    Boolean.TRUE, message, meetingMembers.getUsers(), meetings.getUsers(), iDao);

                            // Delete this event
                            // iDao.delete(events);
                            deleteEvent.add(events);

                            // Add this event as New
                            if (!events.getTimingGap().equals(0L)) {
                                createMeetingEvent(maintenance, meetings, iDao);
                            }
                        }
                    }

                    for (Events events : deleteEvent) {
                        iDao.delete(events);
                    }

                    maintenance.setMeetingEvent(Boolean.FALSE);
                    timer.cancel();

                    // callBack
                    resetMeetingEvent(null, null, iDao);
                }
            }

            new execute();
            timer.schedule(new execute(), delay, 150);
        }
    }
}