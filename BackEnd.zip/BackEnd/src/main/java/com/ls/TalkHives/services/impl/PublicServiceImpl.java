package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.PrivacyLevelEntity;
import com.ls.TalkHives.dto.common.UserEntity;
import com.ls.TalkHives.dto.common.UserRoleEntity;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.PublicService;
import com.ls.TalkHives.services.impl.handler.UserServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class PublicServiceImpl extends UserServiceImplHandler implements PublicService {

    private static final String TAG = PublicServiceImpl.class.getSimpleName();

    @Override
    public Map<String, List<UserRole>> getUserRoles(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getAllUserRoles: ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("roleTag", users.getUserRole().getRoleTag());
        List<UserRole> list = iDao.getEntities(UserRole.class, queryManager.getAllUserRole(), hashtable, false);
        hashtable.clear();

        Map<String, List<UserRole>> map = new HashMap<>();

        map.put("userRoles", list);

        return map;
    }

    @Override
    public UniversalResponse verifyInvitation(String token, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside verifyInvitation: " + token);

        if (token == null) {
            throw new UniversalException(ExceptionStatus.INVITATION_NOT_FOUND);
        }

        return verifyToken(token, iDao);
    }

    @Override
    public UniversalResponse verifyUserName(String userName, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();

        if (userName == null) {
            throw new UniversalException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        hashtable.put("userName", userName);
        Users users = iDao.getEntity(Users.class, queryManager.getUsersByUserName(), hashtable, false);
        hashtable.clear();

        if (users != null) {
            return new UniversalResponse(true, ExceptionStatus.USER_NAME_IS_TAKEN.getErrorMessage());
        } else {
            return new UniversalResponse(false, "Username is available");
        }
    }

    @Override
    public UniversalResponse verifyEmailId(String emailId, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();

        if (emailId == null) {
            throw new UniversalException(ExceptionStatus.EMAIL_ID_IS_MISSING);
        }

        hashtable.put("emailId", emailId);
        Users users = iDao.getEntity(Users.class, queryManager.getUsersByEmailId(), hashtable, false);
        hashtable.clear();

        if (users != null) {
            return new UniversalResponse(true, ExceptionStatus.EMAIL_ID_IS_IN_USE.getErrorMessage());
        } else {
            return new UniversalResponse(false, "EmailId is available");
        }
    }

    @Override
    public Map<String, List<Invitations>> getInvitations(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getInvitations: ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("users", users);
        List<Invitations> list = iDao.getEntities(Invitations.class, queryManager.getAllInvitation(), hashtable, false);
        hashtable.clear();

        Map<String, List<Invitations>> map = new HashMap<>();

        map.put("invitations", list);

        return map;
    }

    @Override
    public Map<String, List<Users>> getUsers(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        Organizations organizations = findOrgByUser(users.getOrganizations().getOrganizationId(), iDao);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", organizations);
        List<Users> list = iDao.getEntities(Users.class, queryManager.getAllUserByOrg(), hashtable, false);
        hashtable.clear();

        Map<String, List<Users>> map = new HashMap<>();

        map.put("users", list);

        return map;
    }

    @Override
    public Map<String, List<PrivacyLevel>> getPrivacyLevels(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        List<PrivacyLevel> list = iDao.findAll(PrivacyLevel.class, false);
        Map<String, List<PrivacyLevel>> map = new HashMap<>();
        map.put("privacyLevels", list);

        return map;
    }

    @Override
    public Users getUser(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        return users;
    }

    @Override
    public Map<String, List<Status>> getAllStatus(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getAllStatus | ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        List<Status> list = iDao.findAll(Status.class, false);
        Map<String, List<Status>> map = new HashMap<>();
        map.put("status", list);

        return map;
    }

    @Override
    public Map<String, List<Priority>> getPriorities(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getPriorities | ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        List<Priority> list = iDao.findAll(Priority.class, false);
        Map<String, List<Priority>> map = new HashMap<>();
        map.put("priorities", list);

        return map;
    }

    @Override
    public Map<String, List<Frequency>> getFrequencies(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getFrequencies | ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        List<Frequency> list = iDao.findAll(Frequency.class, false);
        Map<String, List<Frequency>> map = new HashMap<>();
        map.put("frequencies", list);

        return map;
    }

    @Override
    public Map<String, List<UserActivity>> getActivities(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        logger.info(TAG, "Inside getActivities | ");

        Users users = findUserByLoginToken(requestHeader, iDao);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("users", users);
        List<UserActivity> list = iDao.getEntities(UserActivity.class, queryManager.getAllActivity(), hashtable, false);
        hashtable.clear();

        Map<String, List<UserActivity>> map = new HashMap<>();

        map.put("selfActivities", list);

        return map;
    }
}