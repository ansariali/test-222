package com.ls.TalkHives.utils.enums;

public enum Activity {

    // Post
    CREATE_POST("CREATE_POST", "{creator} added a new post", "", ""),
    UPDATE_POST("UPDATE_POST", "{creator} updated post", "", ""),
    DELETE_POST("DELETE_POST", "{creator} removed a post", "", ""),
    SHARE_POST("SHARE_POST", "", "{creator} shared a post", ""),
    LIKE_POST("LIKE_POST", "{creator} liked a post", "", ""),
    COMMENT_POST("COMMENT_POST", "{creator} commented on a post", "", ""),

    // Pin
    CREATE_PIN("CREATE_PIN", "{creator} added a new pin", "{user} added a new pin", ""),
    UPDATE_PIN("UPDATE_PIN", "{creator} updated pin", "{user} updated a new pin", ""),
    DELETE_PIN("DELETE_PIN", "{creator} removed a pin", "{user} removed a pin", ""),

    // Blog
    CREATE_BLOG("CREATE_BLOG", "{creator} added a new blog", "{user} added a new blog", ""),
    UPDATE_BLOG("UPDATE_BLOG", "{creator} updated blog", "{user} added a new blog", ""),
    DELETE_BLOG("DELETE_BLOG", "{creator} removed a blog", "{user} removed a blog", ""),

    // Client
    CREATE_CLIENT("CREATE_CLIENT", "{creator} added a new client", "{user} added a new client", ""),
    UPDATE_CLIENT("UPDATE_CLIENT", "{creator} updated client", "{user} added a new client", ""),
    DELETE_CLIENT("DELETE_CLIENT", "{creator} removed a client", "{user} removed a client", ""),

    // Vote
    CREATE_VOTE("CREATE_VOTE", "{creator} added a new vote", "", ""),
    UPDATE_VOTE("UPDATE_VOTE", "{creator} updated vote", "", ""),
    DELETE_VOTE("DELETE_VOTE", "{creator} removed a vote", "", ""),
    LIKE_VOTE("LIKE_VOTE", "{creator} voted on vote", "", ""),
    COMMENT_VOTE("COMMENT_VOTE", "{creator} commented on vote", "", ""),

    // Team
    CREATE_TEAM("CREATE_TEAM", "{creator} added a new team", "", ""),
    UPDATE_TEAM("UPDATE_TEAM", "{creator} updated team", "", ""),
    DELETE_TEAM("DELETE_TEAM", "{creator} removed a team", "", ""),

    // Team
    CREATE_MEETING("CREATE_MEETING", "{creator} added a new meeting", "", ""),
    UPDATE_MEETING("UPDATE_MEETING", "{creator} updated meeting", "", ""),
    DELETE_MEETING("DELETE_MEETING", "{creator} removed a meeting", "", ""),

    // Team
    CREATE_TASK("CREATE_TASK", "{creator} added a new task", "", ""),
    UPDATE_TASK("UPDATE_TASK", "{creator} updated task", "", ""),
    DELETE_TASK("DELETE_TASK", "{creator} removed a task", "", ""),

    // Last
    TEST("", "", "", ""),
    DEMO("", "", "", "");

    private final String activity;
    private final String directMessage;
    private final String inDirectMessage;
    private final String customMessage;


    Activity(String activity, String directMessage, String inDirectMessage, String customMessage) {
        this.activity = activity;
        this.directMessage = directMessage;
        this.inDirectMessage = inDirectMessage;
        this.customMessage = customMessage;
    }

    public String getActivity() {
        return activity;
    }

    public String getDirectMessage() {
        return directMessage;
    }

    public String getInDirectMessage() {
        return inDirectMessage;
    }

    public String getCustomMessage() {
        return customMessage;
    }
}