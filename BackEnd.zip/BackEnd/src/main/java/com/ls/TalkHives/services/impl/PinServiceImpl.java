package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.pinController.CreatePinRequest;
import com.ls.TalkHives.dto.pinController.UpdatePinRequest;
import com.ls.TalkHives.entities.NewEntity;
import com.ls.TalkHives.entities.Pins;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.PinService;
import com.ls.TalkHives.services.impl.handler.PinServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class PinServiceImpl extends PinServiceImplHandler implements PinService {

    private static final String TAG = PinServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreatePinRequest createPinRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Pins pins = new Pins();
        pins.setTitle(createPinRequest.getTitle());
        pins.setMessage(createPinRequest.getMessage());
        pins.setUser(users);
        pins.setCreatedAt(getCurrentTime());

        Pins pins_ = iDao.find(Pins.class, iDao.persist(pins));

        checkNullObject(pins_, ExceptionStatus.NEW_NOT_ADDED);

        return sendPin(Activity.CREATE_PIN.getActivity(), pins_, users, iDao);
    }

    @Override
    public Map<String, List<Pins>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        // findLoginUser(requestHeader, iDao);

        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Pins>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("user", users);
        List<Pins> list = iDao.getEntities(Pins.class, queryManager.getAllPins(), hashtable, false);
        hashtable.clear();

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("pins", list);

        return map;
    }

    @Override
    public WsResponse update(UpdatePinRequest updatePinRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        checkNullLongId(updatePinRequest.getPinId(), ExceptionStatus.PIN_ID_MISSING);
        checkNullObject(updatePinRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);

        Pins pins = iDao.find(Pins.class, updatePinRequest.getPinId());

        checkNullObject(pins, ExceptionStatus.PIN_NOT_FOUND);

        pins.setTitle(updatePinRequest.getTitle());
        pins.setMessage(updatePinRequest.getMessage());
        pins.setUpdatedAt(getCurrentTime());

        pins = iDao.update(pins);

        return sendPin(Activity.UPDATE_PIN.getActivity(), pins, users, iDao);
    }

    @Override
    public WsResponse delete(Long pinId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(pinId, ExceptionStatus.PIN_ID_MISSING);

        Pins pins = iDao.find(Pins.class, pinId);

        checkNullObject(pins, ExceptionStatus.PIN_NOT_FOUND);

        iDao.delete(pins);

        pins = iDao.find(Pins.class, pinId);

        if (pins.getDeleted()) {
            return sendPin(Activity.DELETE_PIN.getActivity(), pins, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.PIN_NOT_DELETE);
        }
    }
}