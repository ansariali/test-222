package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class HttpRequestHeaderNotValidException extends BaseException {

	private static final long serialVersionUID = 1L;

	public HttpRequestHeaderNotValidException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public HttpRequestHeaderNotValidException() {
		super(ExceptionStatus.HTTP_REQUEST_HEADER_NOT_VALID);
	}
}