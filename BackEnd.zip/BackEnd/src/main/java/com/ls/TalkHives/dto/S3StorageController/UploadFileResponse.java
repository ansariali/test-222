package com.ls.TalkHives.dto.S3StorageController;

import com.ls.TalkHives.dto.common.InviteEntity;

public class UploadFileResponse {

}
