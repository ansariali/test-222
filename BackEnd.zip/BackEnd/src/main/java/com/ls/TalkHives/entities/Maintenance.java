package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * Maintenance Entity
 */

@Entity
@Table(name = "maintenance")
public class Maintenance extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long maintenanceId;

    private String maintenanceTag;
    private Boolean live = true;
    private String info;

    private Date startTime;
    private Date endTime;

    private Boolean meetingEvent = false;
    private Date meetingTime;

    private Boolean projectEvent = false;
    private Date projectTime;

    private Boolean taskEvent = false;
    private Date taskTime;

    private Boolean birthDayEvent = false;
    private Date birthDayTime;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    public Long getMaintenanceId() {
        return maintenanceId;
    }

    public void setMaintenanceId(Long maintenanceId) {
        this.maintenanceId = maintenanceId;
    }

    public String getMaintenanceTag() {
        return maintenanceTag;
    }

    public void setMaintenanceTag(String maintenanceTag) {
        this.maintenanceTag = maintenanceTag;
    }

    public Boolean getLive() {
        return live;
    }

    public void setLive(Boolean live) {
        this.live = live;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Boolean getMeetingEvent() {
        return meetingEvent;
    }

    public void setMeetingEvent(Boolean meetingEvent) {
        this.meetingEvent = meetingEvent;
    }

    public Date getMeetingTime() {
        return meetingTime;
    }

    public void setMeetingTime(Date meetingTime) {
        this.meetingTime = meetingTime;
    }

    public Boolean getProjectEvent() {
        return projectEvent;
    }

    public void setProjectEvent(Boolean projectEvent) {
        this.projectEvent = projectEvent;
    }

    public Date getProjectTime() {
        return projectTime;
    }

    public void setProjectTime(Date projectTime) {
        this.projectTime = projectTime;
    }

    public Boolean getTaskEvent() {
        return taskEvent;
    }

    public void setTaskEvent(Boolean taskEvent) {
        this.taskEvent = taskEvent;
    }

    public Date getTaskTime() {
        return taskTime;
    }

    public void setTaskTime(Date taskTime) {
        this.taskTime = taskTime;
    }

    public Boolean getBirthDayEvent() {
        return birthDayEvent;
    }

    public void setBirthDayEvent(Boolean birthDayEvent) {
        this.birthDayEvent = birthDayEvent;
    }

    public Date getBirthDayTime() {
        return birthDayTime;
    }

    public void setBirthDayTime(Date birthDayTime) {
        this.birthDayTime = birthDayTime;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }
}
