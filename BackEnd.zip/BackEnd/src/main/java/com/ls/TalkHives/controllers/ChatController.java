package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.chatController.ChatRoomMessages;
import com.ls.TalkHives.dto.chatController.CreateChatRequest;
import com.ls.TalkHives.dto.chatController.CreateGroupChatRequest;
import com.ls.TalkHives.dto.chatController.FetchAllGroupChat;
import com.ls.TalkHives.dto.common.ChatEntity;
import com.ls.TalkHives.dto.common.ChatRoomEntity;
import com.ls.TalkHives.services.ChatService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@Controller
@RequestMapping("/chatController")
public class ChatController extends UniversalController {

    private static final String TAG = ChatController.class.getSimpleName();

    @Autowired
    private ChatService chatService;

    @ApiOperation(value = "C1 Create Private ChatRoom")
    @PutMapping(value = "/1/privateChat/{to}")
    public ResponseEntity<UniversalResponse> createChatRoom(@PathVariable Long to,
                                                            @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside createChatRoom");

        return new ResponseEntity<>(chatService.createChatRoom(to, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C2 Get Private ChatRoom Messages")
    @GetMapping(value = "/1/chat/messages/{chatRoomTag}")
    public ResponseEntity<ChatRoomMessages> getExistingChatMessages(@PathVariable String chatRoomTag,
                                                                    @RequestHeader Map<String, Object> requestHeader) {

        logger.info(TAG, "Inside getExistingChatMessages");

        ChatRoomMessages res = modelMapper.map(chatService.getMessages(chatRoomTag, requestHeader, iDao), ChatRoomMessages.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @MessageMapping("/1/chat/{chatRoomTag}")
    @SendTo("/topic/1/chat/{chatRoomTag}")
    public ResponseEntity<ChatEntity> sendMessage(StompHeaderAccessor stompHeaderAccessor, @PathVariable String chatRoomTag,
                                                  CreateChatRequest createChatRequest) {
        logger.info(TAG, "Inside C3 " + stompHeaderAccessor.getNativeHeader("LOGIN-TOKEN"));

        ChatEntity res = modelMapper.map(chatService.sendMessage(createChatRequest, stompHeaderAccessor, iDao), ChatEntity.class);

        // chatService.test();

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C4 Create Group Chat")
    @PostMapping(value = "/1/groupChat/create")
    public ResponseEntity<ChatRoomEntity> createGroupChat(@RequestHeader Map<String, Object> requestHeader,
                                                          @RequestBody CreateGroupChatRequest createGroupChatRequest) {
        logger.info(TAG, "Inside C4 " + requestHeader);

        ChatRoomEntity res = modelMapper.map(chatService.createGroupChat(createGroupChatRequest, requestHeader, iDao), ChatRoomEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }


    @ApiOperation(value = "C5 FetchAll Group Chat")
    @GetMapping(value = "/1/groupChat/fetch/all")
    public ResponseEntity<FetchAllGroupChat> fetchAllGroupChat(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside C5 ");

        FetchAllGroupChat res = modelMapper.map(chatService.getGroups(requestHeader, iDao), FetchAllGroupChat.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @SendTo("/topic/1/groupChat/create/{userId}")
    public ChatRoomEntity sendGroupChat(@DestinationVariable Long userId, ChatRoomEntity chatRoomEntity) {
        logger.info(TAG, "Inside C6 Notification");

        return chatRoomEntity;
    }

    // @MessageMapping("/1/notification")
    @SendTo("/topic/1/notification/{userId}")
    public String sampleNotification(@DestinationVariable long userId, String message) {
        logger.info(TAG, "Inside _CCC1 Notification");

        return message;

        // return new ResponseEntity<>(new UniversalResponse(true, "Sample Notification!"), responseHeaders, HttpStatus.OK);
    }


}