package com.ls.TalkHives.utils.enums;

public enum UserRoleType {
    // COMMON ROLES
    USER("USER") /* Employees in the department */, DBA("DBA") /* Maintenance */, ADMIN("ADMIN") /* Organization head */,
    MANAGER("MANAGER") /* Department head */, WATCHER("WATCHER");

    // SC ROLES

    // TSP ROLES
    String userRoleType;

    private UserRoleType(String userRoleType) {
        this.userRoleType = userRoleType;
    }

    public String getUserRoleType() {
        return userRoleType;
    }

}
