package com.ls.TalkHives.utils.exception;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.exception.util.BaseException;

public class OperationFailedException extends BaseException {

	private static final long serialVersionUID = 1L;

	public OperationFailedException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus);
	}
	
	public OperationFailedException() {
		super(ExceptionStatus.OPERATION_FAILED);
	}
}