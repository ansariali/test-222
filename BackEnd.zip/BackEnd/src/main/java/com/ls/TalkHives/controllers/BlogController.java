package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.blogController.CreateBlogRequest;
import com.ls.TalkHives.dto.blogController.FetchAllBlogs;
import com.ls.TalkHives.dto.blogController.UpdateBlogRequest;
import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.services.BlogService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/blogController")
@Controller
public class BlogController extends UniversalController {

    private static final String TAG = BlogController.class.getSimpleName();

    @Autowired
    private BlogService blogService;

    @ApiOperation(value = "B1 Create Blog")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/blog/1/create/{organizationId}")
    // @SendTo("/topic/blog/1/create/{organizationId}")
    public ResponseEntity<WsResponse> createBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody CreateBlogRequest createBlogRequest, @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside createBlog");

        return new ResponseEntity<>(blogService.create(createBlogRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "B2 FetchAll Blog")
    @GetMapping(value = "/1/fetch/all")
    // @MessageMapping("/receive")
    // @SendTo("/server/first")
    public ResponseEntity<FetchAllBlogs> fetchAllBlog(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllBlog");

        FetchAllBlogs res = modelMapper.map(blogService.fetchAll(requestHeader, iDao), FetchAllBlogs.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "B3 Update Blog")
    @PutMapping(value = "/1/update")
    // @MessageMapping("/blog/1/update/{organizationId}")
    // @SendTo("/topic/blog/1/update/{organizationId}")
    public ResponseEntity<WsResponse> updateBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody UpdateBlogRequest updateBlogRequest) {
        logger.info(TAG, "Inside B3");

        return new ResponseEntity<>(blogService.update(updateBlogRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "B4 Delete Blog")
    @DeleteMapping(value = "/1/delete/{blogId}")
    // @MessageMapping("/blog/1/delete/{organizationId}/{blogId}")
    // @SendTo("/topic/blog/1/delete/{organizationId}")
    public ResponseEntity<WsResponse> deleteBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @PathVariable Long blogId, @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside deleteBlog");

        return new ResponseEntity<>(blogService.delete(blogId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }
}