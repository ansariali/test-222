package com.ls.TalkHives.configuration;

import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.utils.Logger;
import com.ls.TalkHives.utils.Refactor;
import com.ls.TalkHives.utils.Util;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class StartUpConfig extends UniversalService implements ApplicationListener<ContextRefreshedEvent> {

    private static final String TAG = StartUpConfig.class.getSimpleName();

    private Logger logger = Logger.getInstance(true, StartUpConfig.class);

    private Refactor refactor = Refactor.getInstance();
    private Util util = Util.getInstance();

    @Autowired
    private IDao<IEntity, Serializable> iDao;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        logger.info(TAG, "Inside onApplicationEvent");
        logger.info(TAG, "Application Id   : " + event.getApplicationContext().getId());

        if (event.getApplicationContext().getParent() == null) {
            // Maintenance
             maintenance();

            // Event Execution
            // eventService.eventStart(iDao);

            // Default Database entry
            createUserRole();
            createPrivacyLevel();
            createDefaultPicOfUser();
            createStatus();
            createPriority();
            createFrequency();

            // notificationService.clock();
        }
    }

    private void maintenance() {
        Maintenance maintenance_ = getMaintenance(iDao);

        if (maintenance_ == null) {
            Maintenance maintenance = new Maintenance();
            maintenance.setLive(Boolean.TRUE);
            maintenance.setInfo("First Release of application");
            maintenance.setStartTime(getCurrentTime());
            maintenance.setCreatedAt(getCurrentTime());

            maintenance = iDao.find(Maintenance.class, iDao.persist(maintenance));
        } else {
            // TODO: stop current session add new if needed
        }
    }

    private void createUserRole() {
        List<UserRole> list = iDao.findAll(UserRole.class, false);

        if (list.size() == 0) {
            UserRole owner = new UserRole();
            owner.setDeleted(Boolean.FALSE);
            owner.setVersion(1L);
            owner.setCreatedAt(util.getCurrentTime());
            owner.setRoleTag(GlobalTag.ROLE_LEVEL1.getGlobalTag());
            owner.setRoleTitle("Owner");
            UserRole _owner = iDao.find(UserRole.class, iDao.persist(owner));

            UserRole admin = new UserRole();
            admin.setDeleted(Boolean.FALSE);
            admin.setVersion(1L);
            admin.setCreatedAt(util.getCurrentTime());
            admin.setRoleTag(GlobalTag.ROLE_LEVEL2.getGlobalTag());
            admin.setRoleTitle("Admin");
            UserRole _admin = iDao.find(UserRole.class, iDao.persist(admin));

            UserRole manager = new UserRole();
            manager.setDeleted(Boolean.FALSE);
            manager.setVersion(1L);
            manager.setCreatedAt(util.getCurrentTime());
            manager.setRoleTag(GlobalTag.ROLE_LEVEL3.getGlobalTag());
            manager.setRoleTitle("Manager");
            UserRole _manager = iDao.find(UserRole.class, iDao.persist(manager));

            UserRole employee = new UserRole();
            employee.setDeleted(Boolean.FALSE);
            employee.setVersion(1L);
            employee.setCreatedAt(util.getCurrentTime());
            employee.setRoleTag(GlobalTag.ROLE_LEVEL4.getGlobalTag());
            employee.setRoleTitle("Employee");
            UserRole _employee = iDao.find(UserRole.class, iDao.persist(employee));

            UserRole user = new UserRole();
            user.setDeleted(Boolean.FALSE);
            user.setVersion(1L);
            user.setCreatedAt(util.getCurrentTime());
            user.setRoleTag(GlobalTag.ROLE_LEVEL5.getGlobalTag());
            user.setRoleTitle("USER");
            UserRole _user = iDao.find(UserRole.class, iDao.persist(user));

            UserRole watcher = new UserRole();
            watcher.setDeleted(Boolean.FALSE);
            watcher.setVersion(1L);
            watcher.setCreatedAt(util.getCurrentTime());
            watcher.setRoleTag(GlobalTag.ROLE_LEVEL6.getGlobalTag());
            watcher.setRoleTitle("Watcher");
            UserRole _watcher = iDao.find(UserRole.class, iDao.persist(watcher));

        }
    }

    private void createPrivacyLevel() {
        List<PrivacyLevel> list = iDao.findAll(PrivacyLevel.class, false);

        if (list.size() == 0) {
            PrivacyLevel onlyMe = new PrivacyLevel();
            onlyMe.setDeleted(Boolean.FALSE);
            onlyMe.setVersion(1L);
            onlyMe.setCreatedAt(util.getCurrentTime());
            onlyMe.setPrivacyTag(GlobalTag.PRIVACY_LEVEL0.getGlobalTag());
            onlyMe.setTitle("Only Me");
            onlyMe.setInfo("Only you can see");
            PrivacyLevel _onlyMe = iDao.find(PrivacyLevel.class, iDao.persist(onlyMe));

            PrivacyLevel owner = new PrivacyLevel();
            owner.setDeleted(Boolean.FALSE);
            owner.setVersion(1L);
            owner.setCreatedAt(util.getCurrentTime());
            owner.setPrivacyTag(GlobalTag.PRIVACY_LEVEL1.getGlobalTag());
            owner.setTitle("Owners Only");
            owner.setInfo("Only owners can see");
            PrivacyLevel _owner = iDao.find(PrivacyLevel.class, iDao.persist(owner));

            PrivacyLevel admin = new PrivacyLevel();
            admin.setDeleted(Boolean.FALSE);
            admin.setVersion(1L);
            admin.setCreatedAt(util.getCurrentTime());
            admin.setPrivacyTag(GlobalTag.PRIVACY_LEVEL2.getGlobalTag());
            admin.setTitle("Admin & above");
            admin.setInfo("Admin & above");
            PrivacyLevel _admin = iDao.find(PrivacyLevel.class, iDao.persist(admin));

            PrivacyLevel manager = new PrivacyLevel();
            manager.setDeleted(Boolean.FALSE);
            manager.setVersion(1L);
            manager.setCreatedAt(util.getCurrentTime());
            manager.setPrivacyTag(GlobalTag.PRIVACY_LEVEL3.getGlobalTag());
            manager.setTitle("Manager & above");
            manager.setInfo("Manager & above");
            PrivacyLevel _manager = iDao.find(PrivacyLevel.class, iDao.persist(manager));

            PrivacyLevel employee = new PrivacyLevel();
            employee.setDeleted(Boolean.FALSE);
            employee.setVersion(1L);
            employee.setCreatedAt(util.getCurrentTime());
            employee.setPrivacyTag(GlobalTag.PRIVACY_LEVEL4.getGlobalTag());
            employee.setTitle("Employee & above");
            employee.setInfo("Employee & above");
            PrivacyLevel _employee = iDao.find(PrivacyLevel.class, iDao.persist(employee));

            PrivacyLevel user = new PrivacyLevel();
            user.setDeleted(Boolean.FALSE);
            user.setVersion(1L);
            user.setCreatedAt(util.getCurrentTime());
            user.setPrivacyTag(GlobalTag.PRIVACY_LEVEL5.getGlobalTag());
            user.setTitle("USER & above");
            user.setInfo("USER & above");
            PrivacyLevel _user = iDao.find(PrivacyLevel.class, iDao.persist(user));

            PrivacyLevel watcher = new PrivacyLevel();
            watcher.setDeleted(Boolean.FALSE);
            watcher.setVersion(1L);
            watcher.setCreatedAt(util.getCurrentTime());
            watcher.setPrivacyTag(GlobalTag.PRIVACY_LEVEL6.getGlobalTag());
            watcher.setTitle("Watcher & above");
            watcher.setInfo("Watcher & above");
            PrivacyLevel _watcher = iDao.find(PrivacyLevel.class, iDao.persist(watcher));

            PrivacyLevel _public = new PrivacyLevel();
            _public.setDeleted(Boolean.FALSE);
            _public.setVersion(1L);
            _public.setCreatedAt(util.getCurrentTime());
            _public.setPrivacyTag(GlobalTag.PRIVACY_LEVEL9.getGlobalTag());
            _public.setTitle("Public");
            _public.setInfo("Everyone can see");
            PrivacyLevel _public_ = iDao.find(PrivacyLevel.class, iDao.persist(_public));

            PrivacyLevel specificUser = new PrivacyLevel();
            specificUser.setDeleted(Boolean.FALSE);
            specificUser.setVersion(1L);
            specificUser.setCreatedAt(util.getCurrentTime());
            specificUser.setPrivacyTag(GlobalTag.PRIVACY_LEVEL10.getGlobalTag());
            specificUser.setTitle("Specific People");
            specificUser.setInfo("Selected People can see");
            PrivacyLevel _specificUser = iDao.find(PrivacyLevel.class, iDao.persist(specificUser));

        }
    }

    private void createDefaultPicOfUser() {
        List<Images> list = iDao.findAll(Images.class, false);
        if (list.size() == 0) {

            Images defaultProfilePic = new Images();
            defaultProfilePic.setImageTag("483607");
            defaultProfilePic.setFileName("userDefault.png");
            defaultProfilePic.setType("image/png");
            defaultProfilePic.setInfo("Default Profile Pic for any USER");
            defaultProfilePic.setFileUrl(S3Storage.DEFAULT_USER_PIC_URL.getValue());
            defaultProfilePic.setCreatedAt(util.getCurrentTime());

            Images _defaultProfilePic = iDao.find(Images.class, iDao.persist(defaultProfilePic));

        }
    }

    private void createStatus() {
        List<Status> list = iDao.findAll(Status.class, false);
        if (list.size() == 0) {

            Status _new = new Status();
            _new.setStatusTag(GlobalTag.NEW.getLongTag());
            _new.setTitle("New");
            _new.setCreatedAt(util.getCurrentTime());
            Status new_ = iDao.find(Status.class, iDao.persist(_new));

            Status active = new Status();
            active.setStatusTag(GlobalTag.ACTIVE.getLongTag());
            active.setTitle("Active");
            active.setCreatedAt(util.getCurrentTime());
            Status active_ = iDao.find(Status.class, iDao.persist(active));

            Status completed = new Status();
            completed.setStatusTag(GlobalTag.COMPLETED.getLongTag());
            completed.setTitle("Completed");
            completed.setCreatedAt(util.getCurrentTime());
            Status completed_ = iDao.find(Status.class, iDao.persist(completed));

            Status pending = new Status();
            pending.setStatusTag(GlobalTag.PENDING.getLongTag());
            pending.setTitle("Pending");
            pending.setCreatedAt(util.getCurrentTime());
            Status pending_ = iDao.find(Status.class, iDao.persist(pending));

            Status postponed = new Status();
            postponed.setStatusTag(GlobalTag.POSTPONED.getLongTag());
            postponed.setTitle("Postponed");
            postponed.setCreatedAt(util.getCurrentTime());
            Status postponed_ = iDao.find(Status.class, iDao.persist(postponed));

            Status deleted = new Status();
            deleted.setStatusTag(GlobalTag.DELETED.getLongTag());
            deleted.setTitle("Deleted");
            deleted.setCreatedAt(util.getCurrentTime());
            Status deleted_ = iDao.find(Status.class, iDao.persist(deleted));

            Status overdue = new Status();
            overdue.setStatusTag(GlobalTag.OVERDUE.getLongTag());
            overdue.setTitle("Overdue");
            overdue.setCreatedAt(util.getCurrentTime());
            Status overdue_ = iDao.find(Status.class, iDao.persist(overdue));

            Status rejected = new Status();
            rejected.setStatusTag(GlobalTag.REJECTED.getLongTag());
            rejected.setTitle("Rejected");
            rejected.setCreatedAt(util.getCurrentTime());
            Status rejected_ = iDao.find(Status.class, iDao.persist(rejected));

            Status needHelp = new Status();
            needHelp.setStatusTag(GlobalTag.NEED_HELP.getLongTag());
            needHelp.setTitle("Need Help");
            needHelp.setCreatedAt(util.getCurrentTime());
            Status needHelp_ = iDao.find(Status.class, iDao.persist(needHelp));

            Status notFound = new Status();
            notFound.setStatusTag(GlobalTag.NOT_FOND.getLongTag());
            notFound.setTitle("Not Found");
            notFound.setCreatedAt(util.getCurrentTime());
            Status notFound_ = iDao.find(Status.class, iDao.persist(notFound));

            Status undefined = new Status();
            undefined.setStatusTag(GlobalTag.UNDEFINED.getLongTag());
            undefined.setTitle("Undefined");
            undefined.setCreatedAt(util.getCurrentTime());
            Status undefined_ = iDao.find(Status.class, iDao.persist(undefined));
        }
    }

    private void createPriority() {
        List<Priority> list = iDao.findAll(Priority.class, false);
        if (list.size() == 0) {

            Priority urgent = new Priority();
            urgent.setPriorityTag(GlobalTag.URGENT.getLongTag());
            urgent.setTitle("Urgent");
            urgent.setCreatedAt(util.getCurrentTime());
            Priority urgent_ = iDao.find(Priority.class, iDao.persist(urgent));

            Priority high = new Priority();
            high.setPriorityTag(GlobalTag.HIGH.getLongTag());
            high.setTitle("High");
            high.setCreatedAt(util.getCurrentTime());
            Priority high_ = iDao.find(Priority.class, iDao.persist(high));

            Priority normal = new Priority();
            normal.setPriorityTag(GlobalTag.NORMAL.getLongTag());
            normal.setTitle("Normal");
            normal.setCreatedAt(util.getCurrentTime());
            Priority normal_ = iDao.find(Priority.class, iDao.persist(normal));

            Priority low = new Priority();
            low.setPriorityTag(GlobalTag.LOW.getLongTag());
            low.setTitle("Low");
            low.setCreatedAt(util.getCurrentTime());
            Priority low_ = iDao.find(Priority.class, iDao.persist(low));
        }
    }

    private void createFrequency() {
        List<Frequency> list = iDao.findAll(Frequency.class, false);

        if (list.size() == 0) {

            Frequency once = new Frequency();
            once.setFrequencyTag(GlobalTag.ONCE.getLongTag());
            once.setTitle("Once");
            once.setCreatedAt(util.getCurrentTime());
            Frequency once_ = iDao.find(Frequency.class, iDao.persist(once));

            Frequency daily = new Frequency();
            daily.setFrequencyTag(GlobalTag.DAILY.getLongTag());
            daily.setTitle("Daily");
            daily.setCreatedAt(util.getCurrentTime());
            Frequency daily_ = iDao.find(Frequency.class, iDao.persist(daily));

            Frequency weekly = new Frequency();
            weekly.setFrequencyTag(GlobalTag.WEEKLY.getLongTag());
            weekly.setTitle("Weekly");
            weekly.setCreatedAt(util.getCurrentTime());
            Frequency weekly_ = iDao.find(Frequency.class, iDao.persist(weekly));

            Frequency monthly = new Frequency();
            monthly.setFrequencyTag(GlobalTag.MONTHLY.getLongTag());
            monthly.setTitle("Monthly");
            monthly.setCreatedAt(util.getCurrentTime());
            Frequency monthly_ = iDao.find(Frequency.class, iDao.persist(monthly));

            Frequency annually = new Frequency();
            annually.setFrequencyTag(GlobalTag.ANNUALLY.getLongTag());
            annually.setTitle("Annually");
            annually.setCreatedAt(util.getCurrentTime());
            Frequency annually_ = iDao.find(Frequency.class, iDao.persist(annually));
        }
    }

    // private void createThTeamOwner() {
    //
    // }

}