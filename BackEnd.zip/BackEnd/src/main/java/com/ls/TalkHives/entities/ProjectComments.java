package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * ProjectComments Entity
 */

@Entity
@Table(name = "project_comments")
public class ProjectComments extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long projectCommentId;

    private String projectCommentTag;
    private String message;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projectId")
    private Projects projects;

    public Long getProjectCommentId() {
        return projectCommentId;
    }

    public void setProjectCommentId(Long projectCommentId) {
        this.projectCommentId = projectCommentId;
    }

    public String getProjectCommentTag() {
        return projectCommentTag;
    }

    public void setProjectCommentTag(String projectCommentTag) {
        this.projectCommentTag = projectCommentTag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Projects getProjects() {
        return projects;
    }

    public void setProjects(Projects projects) {
        this.projects = projects;
    }
}