package com.ls.TalkHives.entities;


/*******************************************************************************
 * 2017, this is the user entity class ,
 * this class implements users details of the spring security framework
 *******************************************************************************/

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.validator.constraints.Email;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Description of User.
 * 
 * @author kamal berriga
 */
@Entity
@Table(name="User")
@Scope("session")
public  class User implements UserDetails{
	public static enum Role{ USER }
	/**
	 * Description of the property id.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId ;
	/**
	 * Description of the property email.
	 */
	@Column(unique = true)
	private String userName ;
	/**
	 * Description of the property password.
	 */
	@JsonProperty(access = Access.WRITE_ONLY)
	private String password ;

	@NotNull
	@Size(min = 3, max = 30)
	private String firstName;

	@NotNull
	@Size(min = 3, max = 30)
	private String lastName;

	/**
	 * Description of the property role , to grant authority to the user .
	 */
    private String  role;
    /**
	 * Description of the property full name.
	 */
    private String fullName;

	@Email
	@NotNull
	@Size(max = 254)
	private String emailId;

	@NotNull
	private String countryCode;

	@NotNull
	private String mobileNo;

	@NotNull
	private String gender;

	private Date birthDay;
	private String hashTag;
	private String designation;
	private String bio;
	private String address;
	private String pinCode;
	private String city;
	private String state;
	private String country;
	private Double latitude;
	private Double longitude;

	private String pinTagPrefix;

	@ColumnDefault("0")
	private Integer totalPin;

	@ColumnDefault("0")
	private Integer deletedPin;

	@ColumnDefault("0")
	private Integer totalBlog;

	@ColumnDefault("0")
	private Integer deletedBlog;

	@ColumnDefault("0")
	private Integer totalClient;

	@ColumnDefault("0")
	private Integer deletedClient;

	@ColumnDefault("0")
	private Integer totalVote;

	@ColumnDefault("0")
	private Integer deletedVote;

	@ColumnDefault("0")
	private Integer totalPost;

	@ColumnDefault("0")
	private Integer deletedPost;

	@ColumnDefault("0")
	private Integer totalTeam;

	@ColumnDefault("0")
	private Integer deletedTeam;

	@ColumnDefault("0")
	private Integer totalProject;

	@ColumnDefault("0")
	private Integer deletedProject;

	@ColumnDefault("0")
	private Integer totalMeeting;

	@ColumnDefault("0")
	private Integer deletedMeeting;

	private String taskTagPrefix;

	@ColumnDefault("0")
	private Integer totalTask;

	@ColumnDefault("0")
	private Integer deletedTask;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "organizationId")
	private Organizations organizations;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "imageId")
	private Images images;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userRole")
	private UserRole userRole;


	public User(){ }

	public User(String userName, String password, String firstName, String lastName, String role, String fullName, String emailId, String countryCode, String mobileNo, String gender, Date birthDay, String hashTag, String designation, String bio, String address, String pinCode, String city, String state, String country, Double latitude, Double longitude, String pinTagPrefix, Integer totalPin, Integer deletedPin, Integer totalBlog, Integer deletedBlog, Integer totalClient, Integer deletedClient, Integer totalVote, Integer deletedVote, Integer totalPost, Integer deletedPost, Integer totalTeam, Integer deletedTeam, Integer totalProject, Integer deletedProject, Integer totalMeeting, Integer deletedMeeting, String taskTagPrefix, Integer totalTask, Integer deletedTask, Organizations organizations, Images images, UserRole userRole) {
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.fullName = fullName;
		this.emailId = emailId;
		this.countryCode = countryCode;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.birthDay = birthDay;
		this.hashTag = hashTag;
		this.designation = designation;
		this.bio = bio;
		this.address = address;
		this.pinCode = pinCode;
		this.city = city;
		this.state = state;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.pinTagPrefix = pinTagPrefix;
		this.totalPin = totalPin;
		this.deletedPin = deletedPin;
		this.totalBlog = totalBlog;
		this.deletedBlog = deletedBlog;
		this.totalClient = totalClient;
		this.deletedClient = deletedClient;
		this.totalVote = totalVote;
		this.deletedVote = deletedVote;
		this.totalPost = totalPost;
		this.deletedPost = deletedPost;
		this.totalTeam = totalTeam;
		this.deletedTeam = deletedTeam;
		this.totalProject = totalProject;
		this.deletedProject = deletedProject;
		this.totalMeeting = totalMeeting;
		this.deletedMeeting = deletedMeeting;
		this.taskTagPrefix = taskTagPrefix;
		this.totalTask = totalTask;
		this.deletedTask = deletedTask;
		this.organizations = organizations;
		this.images = images;
		this.userRole = userRole;
	}

    // public User(String username, String password, String fullName){
    // 	this.username=username;
    // 	this.password= password;
    // 	this.fullName=fullName;
    // }

	@JsonIgnore
	@Override
	public boolean isEnabled() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(role));
		return authorities;
	}

	@Override
	public String toString() {
		// return "User [id=" + id + ", username=" + username + ", password=" + password + ", role=" + role + ",]";
		return "User id=" + userId;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return userName;
	}

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public String getHashTag() {
        return hashTag;
    }

    public void setHashTag(String hashTag) {
        this.hashTag = hashTag;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getPinTagPrefix() {
        return pinTagPrefix;
    }

    public void setPinTagPrefix(String pinTagPrefix) {
        this.pinTagPrefix = pinTagPrefix;
    }

    public Integer getTotalPin() {
        return totalPin;
    }

    public void setTotalPin(Integer totalPin) {
        this.totalPin = totalPin;
    }

    public Integer getDeletedPin() {
        return deletedPin;
    }

    public void setDeletedPin(Integer deletedPin) {
        this.deletedPin = deletedPin;
    }

    public Integer getTotalBlog() {
        return totalBlog;
    }

    public void setTotalBlog(Integer totalBlog) {
        this.totalBlog = totalBlog;
    }

    public Integer getDeletedBlog() {
        return deletedBlog;
    }

    public void setDeletedBlog(Integer deletedBlog) {
        this.deletedBlog = deletedBlog;
    }

    public Integer getTotalClient() {
        return totalClient;
    }

    public void setTotalClient(Integer totalClient) {
        this.totalClient = totalClient;
    }

    public Integer getDeletedClient() {
        return deletedClient;
    }

    public void setDeletedClient(Integer deletedClient) {
        this.deletedClient = deletedClient;
    }

    public Integer getTotalVote() {
        return totalVote;
    }

    public void setTotalVote(Integer totalVote) {
        this.totalVote = totalVote;
    }

    public Integer getDeletedVote() {
        return deletedVote;
    }

    public void setDeletedVote(Integer deletedVote) {
        this.deletedVote = deletedVote;
    }

    public Integer getTotalPost() {
        return totalPost;
    }

    public void setTotalPost(Integer totalPost) {
        this.totalPost = totalPost;
    }

    public Integer getDeletedPost() {
        return deletedPost;
    }

    public void setDeletedPost(Integer deletedPost) {
        this.deletedPost = deletedPost;
    }

    public Integer getTotalTeam() {
        return totalTeam;
    }

    public void setTotalTeam(Integer totalTeam) {
        this.totalTeam = totalTeam;
    }

    public Integer getDeletedTeam() {
        return deletedTeam;
    }

    public void setDeletedTeam(Integer deletedTeam) {
        this.deletedTeam = deletedTeam;
    }

    public Integer getTotalProject() {
        return totalProject;
    }

    public void setTotalProject(Integer totalProject) {
        this.totalProject = totalProject;
    }

    public Integer getDeletedProject() {
        return deletedProject;
    }

    public void setDeletedProject(Integer deletedProject) {
        this.deletedProject = deletedProject;
    }

    public Integer getTotalMeeting() {
        return totalMeeting;
    }

    public void setTotalMeeting(Integer totalMeeting) {
        this.totalMeeting = totalMeeting;
    }

    public Integer getDeletedMeeting() {
        return deletedMeeting;
    }

    public void setDeletedMeeting(Integer deletedMeeting) {
        this.deletedMeeting = deletedMeeting;
    }

    public String getTaskTagPrefix() {
        return taskTagPrefix;
    }

    public void setTaskTagPrefix(String taskTagPrefix) {
        this.taskTagPrefix = taskTagPrefix;
    }

    public Integer getTotalTask() {
        return totalTask;
    }

    public void setTotalTask(Integer totalTask) {
        this.totalTask = totalTask;
    }

    public Integer getDeletedTask() {
        return deletedTask;
    }

    public void setDeletedTask(Integer deletedTask) {
        this.deletedTask = deletedTask;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Images getImages() {
        return images;
    }

    public void setImages(Images images) {
        this.images = images;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }
}
