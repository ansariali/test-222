package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.InvitationsEntity;
import com.ls.TalkHives.dto.common.UserEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllUsers {

    private List<UserEntity> users = new ArrayList<>();

    public List<UserEntity> getUsers() {
        return users;
    }

    public void setUsers(List<UserEntity> users) {
        this.users = users;
    }
}
