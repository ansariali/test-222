package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * PrivacyLevel Entity
 */

@Entity
@Table(name = "privacy_level")
public class PrivacyLevel extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long privacyId;

    private String privacyTag;
    private String title;
    private String info;

    public Long getPrivacyId() {
        return privacyId;
    }

    public void setPrivacyId(Long privacyId) {
        this.privacyId = privacyId;
    }

    public String getPrivacyTag() {
        return privacyTag;
    }

    public void setPrivacyTag(String privacyTag) {
        this.privacyTag = privacyTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
