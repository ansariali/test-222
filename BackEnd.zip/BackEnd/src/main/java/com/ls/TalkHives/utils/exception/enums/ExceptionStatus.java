package com.ls.TalkHives.utils.exception.enums;

public enum ExceptionStatus {

    SYSTEM_FAILURE(907100000L, "System Failure"),
    USER_NOT_FOUND(907100100L, "User not found"),
    USER_ROLE_LEVEL_NOT_FOUND(907100100L, "Invalid user role level"),
    LOGIN_SESSION_NOT_FOUND(907100101L, "Login session not found"),
    LOGIN_USER_NOT_FOUND(907100102L, "Login user not found"),
    LOGIN_SESSION_FAILURE(907100103L, "Login session failure"),
    INVITATION_FAILURE(907100104L, "Invitation failure"),
    INVITATION_TOKEN_NOT_FOUND(907100105L, "Invitation token not found"),
    INVITATION_NOT_FOUND(907100105L, "Invitation not found"),
    ORGANIZATION_NOT_FOUND(907100106L, "Organization not found"),
    USER_NAME_IS_TAKEN(9071001067L, "Username is not available"),
    USER_NAME_IS_MISSING(9071001067L, "Username is missing"),
    EMAIL_ID_IS_IN_USE(9071001067L, "Email address is not available"),
    EMAIL_ID_ALL_READY_USED(9071001067L, "Email address all ready used"),
    EMAIL_ID_IS_MISSING(9071001067L, "Email address is missing"),
    RESULT_NOT_FOUND(907100106L, "Result not found in request header"),
    DATE_MISSING(907100106L, "Date is missing"),

    UNAUTHORIZED_ACCESS(907100107L, "You don\'t have permission for this action"),

    // Chats
    SAME_USER_FOUND(90710000L, "I m not mirror"),
    CHAT_ROOM_NOT_FOUND(90710000L, "ChatRoom is not found"),

    // Pins
    PIN_ID_MISSING(6481125000000L, "Pin id is missing"),
    PIN_TAG_MISSING(6481125000000L, "Pin tag is missing"),
    PIN_NOT_ADDED(6481125000000L, "Failed to add Pin"),
    PIN_NOT_FOUND(6481125000000L, "Pin not found"),
    PIN_NOT_UPDATE(6481125000000L, "Failed to update Pin"),
    PIN_NOT_DELETE(6481125000000L, "Failed to delete Pin"),
    PIN_NOT_VALID(6481125000000L, "Pin not valid"),

    // Blogs
    BLOG_ID_MISSING(6481125000000L, "Blog id is missing"),
    BLOG_TAG_MISSING(6481125000000L, "Blog tag is missing"),
    BLOG_NOT_ADDED(6481125000000L, "Failed to add Blog"),
    BLOG_NOT_FOUND(6481125000000L, "Blog not found"),
    BLOG_NOT_UPDATE(6481125000000L, "Failed to update Blog"),
    BLOG_NOT_DELETED(6481125000000L, "Failed to delete Blog"),
    BLOG_NOT_VALID(6481125000000L, "Blog is not valid"),

    // Clients
    CLIENT_ID_MISSING(6481125000000L, "Client id is missing"),
    CLIENT_TAG_MISSING(6481125000000L, "Client tag is missing"),
    CLIENT_NOT_ADDED(6481125000000L, "Failed to add Client"),
    CLIENT_NOT_FOUND(6481125000000L, "Client not found"),
    CLIENT_NOT_UPDATE(6481125000000L, "Failed to update Client"),
    CLIENT_NOT_DELETED(6481125000000L, "Failed to delete Client"),
    CLIENT_NOT_VALID(6481125000000L, "Client is not valid"),

    // SignIn Exception.
    USER_NAME_OR_PASSWORD_MISSING(907100101L, "User name or password is missing"),
    LOGIN_FAILED(907100102L, "Failed to login user"),
    USER_ACCOUNT_NOT_VERIFIED(907100102L, "User account is not verified"),
    USER_ACCOUNT_DISABLED(907100102L, "User account is disabled"),

    // Post
    PRIVACY_LEVEL_NOT_FOUND(907100102L, "Privacy level not found"),
    PRIVACY_LEVEL_UNKNOWN(907100102L, "Failed to get privacy level"),

    // Team
    TEAM_MEMBER_NOT_ADDED(907100102L, "Team member not added"),
    TEAM_ID_MISSING(907100102L, "Team not found"),
    TEAM_NOT_FOUND(6481125000000L, "Team not found"),
    TEAM_NOT_VALID(6481125000000L, "Team is not valid"),
    TEAM_NOT_DELETED(6481125000000L, "Failed to delete Team"),

    // Project
    PROJECT_ID_MISSING(907100102L, "Project not found"),
    PROJECT_NOT_FOUND(6481125000000L, "Project not found"),
    PROJECT_NOT_VALID(6481125000000L, "Project is not valid"),
    PROJECT_NOT_DELETED(6481125000000L, "Failed to delete Project"),
    PROJECT_INITIAL_DATE_MISSING(6481125000000L, "Project starting date is missing"),
    PROJECT_DEADLINE_MISSING(6481125000000L, "Project deadline is missing"),
    INVALID_TIME_FRAME_OF_PROJECT(6481125000000L, "Invalid time frame of project"),
    PROJECT_MANAGER_ID_MISSING(6481125000000L, "Project manager id missing"),
    PROJECT_MANAGER_NOT_FOUND(6481125000000L, "Project manager not found"),
    DOCUMENT_TITLE_MISSING(6481125000000L, "Document title missing"),
    DOCUMENT_DESCRIPTION_MISSING(6481125000000L, "Document Description missing"),

    // Project Milestone
    PROJECT_MILESTONE_INITIAL_DATE_MISSING(6481125000000L, "Project milestone starting date is missing"),
    PROJECT_MILESTONE_DEADLINE_MISSING(6481125000000L, "Project milestone deadline is missing"),
    INVALID_TIME_FRAME_OF_PROJECT_MILESTONE(6481125000000L, "Invalid time frame of project milestone"),

    // Vote
    VOTE_ID_MISSING(907100102L, "Vote not found"),
    VOTE_NOT_FOUND(6481125000000L, "Vote not found"),
    VOTE_NOT_VALID(6481125000000L, "Vote is not valid"),
    VOTE_NOT_DELETED(6481125000000L, "Failed to delete Vote"),

    // Post
    POST_ID_MISSING(907100102L, "Post not found"),
    POST_NOT_FOUND(907100102L, "Post not found"),
    POST_IS_NOT_PUBLIC(907100102L, "Post is not public"),
    POST_NOT_DELETED(6481125000000L, "Failed to delete Post"),

    // Task
    Task_STARTING_DATE_MISSING(6481125000000L, "Task starting date is missing"),
    Task_DEADLINE_MISSING(6481125000000L, "Task deadline is missing"),
    TASK_ID_MISSING(6481125000000L, "Task Id is missing"),
    TASK_NOT_FOUND(6481125000000L, "Task not found"),

    // MileStone
    MILE_STONE_ID_MISSING(6481125000000L, "MileStone Id is missing"),
    MILE_STONE_STARTING_DATE_MISSING(6481125000000L, "MileStone starting date is missing"),
    MILE_STONE_DEADLINE_MISSING(6481125000000L, "MileStone deadline is missing"),
    MILE_STONE_NOT_FOUND(6481125000000L, "MileStone not found"),
    MILE_STONE_NOT_UPDATE(6481125000000L, "MileStone not Update"),
    MILE_STONE_NOT_DELETE(6481125000000L, "MileStone not Delete"),


    // Meeting
    MEETING_MEMBER_NOT_ADDED(907100102L, "Meeting member not added"),
    MEETING_ID_MISSING(907100102L, "Meeting not found"),
    MEETING_NOT_FOUND(6481125000000L, "Meeting not found"),
    MEETING_NOT_VALID(6481125000000L, "Meeting is not valid"),
    MEETING_NOT_DELETED(6481125000000L, "Failed to delete Meeting"),
    MEETING_TIMING_MISSING(6481125000000L, "Meeting timing is missing"),

    // Activity
    ACTIVITY_NOT_ADDED(6481125000000L, "Failed to add activity"),

    // 1: Common Exception.
    HTTP_REQUEST_METHOD_NOT_VALID(648112506171L, "HttpRequest method not valid"),
    HTTP_REQUEST_HEADER_NOT_VALID(648112506172L, "HttpRequest header not valid"),
    HTTP_REQUEST_BODY_NOT_VALID(648112506173L, "HttpRequest body not valid"),
    GENERIC_FAILURE(648112506174L, "Generic failure is failed"),
    OPERATION_FAILED(648112506175L, "Server operation is failed"),
    TOKEN_MISSING(648112506176L, "Token number is missing"),
    TOKEN_NOT_VALID(648112506177L, "Token number is not valid"),
    ACCESS_ID_MISSING(648112506178L, "Access id is missing"),
    DEVICE_ID_MISSING(648112506179L, "Device id is missing"),
    PARENT_ID_MISSING(6481125061710L, "Parent id is missing"),
    SERVICE_ID_MISSING(6481125061711L, "Service id missing"),
    SERVICE_NOT_AVAILABLE(6481125061712L, "Service not available"),
    TOKEN_ALL_READY_VERIFIED(6481125061713L, "Token number all ready verified"),
    REPORT_NOT_GENERATED(6481125061714L, "Failed to generate report"),
    COMMENT_ID_MISSING(6481125061714L, "Comment id missing"),
    COMMENT_NOT_FOUND(6481125061714L, "Comment not found"),

    USER_ACCOUNT_FIRST_NAME_MISSING(676116401L, "First name is missing"),
    USER_ACCOUNT_LAST_NAME_MISSING(676116402L, "Last name is missing"),
    USER_ACCOUNT_USER_NAME_MISSING(676116403L, "User name is missing"),
    USER_ACCOUNT_EMAIL_ADDRESS_MISSING(676116404L, "User email address is missing"),
    USER_ACCOUNT_PASSWORD_MISSING(676116405L, "User password is missing"),
    USER_ACCOUNT_MISSING(676116406L, "User account is missing"),
    USER_NAME_OR_EMAIL_ADDRESS_ALL_READY_EXIST(676059822L, "User name or email address all ready existed"),
    USER_NAME_ALL_READY_EXIST(676059822L, "User name all ready existed"),
    EMAIL_ADDRESS_ALL_READY_EXIST(676059822L, "Email address all ready existed"),
    VENDOR_MISSING(676059822L, "Vendor details is missing"),
    PASSWORD_MISSING(676059822L, "Password is missing"),
    ACCESS_TOKEN_MISSING(676059822L, "Access token is missing"),
    USER_SESSION_NOT_FOUND(676059822L, "User session is missing"),
    USER_ALL_READY_SIGN_OUT(676059822L, "User All Ready sign out"),
    POINT_OF_CONTACT_ALL_READY_EXIST(676059822L, "Point of contact all ready exist"),
    PRICING_TIER_NOT_FOUND(676059822L, "Pricing tier not found"),
    PLAN_CYCLE_NOT_FOUND(676039504L, "Plan cycle not found"),


    // 2: New Module Exception.
    NEW_ID_MISSING(6481125000000L, "Record id is missing"),
    NEW_TAG_MISSING(6481125000000L, "Record tag is missing"),
    NEW_NOT_ADDED(6481125000000L, "Failed to add record"),
    NEW_NOT_FOUND(6481125000000L, "Record not found"),
    NEW_NOT_UPDATED(6481125000000L, "Failed to update record"),
    NEW_NOT_DELETED(6481125000000L, "Failed to delete record"),
    NEW_NOT_VALID(6481125000000L, "Record not valid"),

    // 3: Appointment Exception.
    EazeProcure_APPOINTMENT_CONFLICT(6481125116701L, "Appointment conflict"),
    EazeProcure_APPOINTMENT_NOT_ADDED(6481125116702L, "Failed to add appointment"),
    EazeProcure_APPOINTMENT_STATUS_NOT_UPDATED(6481125116703L, "Failed to update appointment status"),
    EazeProcure_APPOINTMENT_MISSING(6481125116704L, "Appointment missing"),
    EazeProcure_APPOINTMENT_NOT_FOUND(6481125116705L, "Appointment not found"),
    EazeProcure_APPOINTMENT_ID_MISSING(6481125116706L, "Appointment id is missing"),
    EazeProcure_APPOINTMENT_NOT_VALID(6481125116707L, "Appointment not valid"),
    EazeProcure_APPOINTMENT_STATUS_MISSING(6481125116708L, "Appointment status is missing"),
    EazeProcure_APPOINTMENT_TYPE_NOT_VALID(6481125116709L, "Appointment type not valid"),
    APPOINTMENT_NOT_FOUND(6481125116710L, "Appointment not found"),
    APPOINTMENT_ID_MISSING(6481125116711L, "Appointment id is missing"),
    APPOINTMENT_STATUS_MISSING(6481125116712L, "Appointment status is missing"),
    APPOINTMENT_TYPE_MISSING(6481125116713L, "Appointment type is missing"),
    APPOINTMENT_TYPE_NOT_VALID(6481125116714L, "Appointment type not valid"),
    APPOINTMENT_MISSING(6481125116715L, "Appointment details is missing"),
    APPOINTMENT_ALL_READY_NOT_WORKING(6481125116716L, "Appointment all ready not working"),
    APPOINTMENT_ALL_READY_WORKING(6481125116717L, "Appointment all ready working"),
    APPOINTMENT_CONFLICT(6481125116718L, "Appointment conflict."),
    APPOINTMENT_NOT_ADDED(6481125116719L, "Failed to add create appointment"),
    APPOINTMENT_NOT_VALID(6481125116720L, "Appointment not valid"),
    APPOINTMENT_STATUS_NOT_UPDATED(6481125116721L, "Failed to update appointment status"),

    // 4: Setting Exception.
    EazeProcure_SETTING_NOT_FOUND(6481125073401L, "Setting not found"),
    EazeProcure_SETTING_NOT_ADDED(6481125073402L, "Failed to add setting"),
    EazeProcure_SETTING_NOT_ACTIVATED(6481125073403L, "Failed to activate setting"),
    EazeProcure_SETTING_BATCH_NOT_EFFECTED(6481125073404L, "Setting batch not effected"),
    EazeProcure_SETTING_NOT_ReNEW(6481125073405L, "Failed to renew setting"),
    EazeProcure_SETTING_CONFLICT(6481125073406L, "Setting all ready exist"),

    // 5: Service Exception.
    EazeProcure_SERVICE_NOT_ReNEW(6481125072101L, "Failed to renew service"),
    EazeProcure_SERVICE_BATCH_NOT_EFFECTED(6481125072102L, "Service batch not effected"),
    EazeProcure_SERVICE_NOT_ADDED(6481125072103L, "Failed to add service"),
    EazeProcure_SERVICE_NOT_ENABLED(6481125072104L, "Failed to enable service"),
    EazeProcure_SERVICE_NOT_AVAILABLE(6481125072105L, "Service not available"),
    EazeProcure_SERVICE_TYPE_MISSING(6481125072106L, "Service type is missing"),

    // 6: UserAccount Exception.
    TARGETED_USER_NOT_FOUND(6481125119601L, "Targeted user not found"),
    TARGETED_USER_NOT_VALID(6481125119602L, "Targeted user not valid"),
    NODAL_CONTACT_NOT_ADDED(6481125119603L, "Failed to add nodal contact"),
    NODAL_CONTACT_NOT_REMOVED(6481125119604L, "Failed to remove nodal contact"),
    EMAIL_ADDRESS_MISSING(6481125119605L, "Email address is missing"),
    COMPANY_NAME_MISSING(6481125119606L, "Company name is missing"),
    COMPANY_REGISTRATION_NUMBER_MISSING(6481125119607L, "Company registration number is missing"),
    USER_NAME_MISSING(6481125119608L, "User name is missing"),
    GST_NUMBER_MISSING(6481125000009L, "Gst number is missing"),
    PAN_CARD_NUMBER_MISSING(6481125119610L, "PanCard number is missing"),
    NATURE_OF_BUSINESS_TYPE_MISSING(6481125119611L, "Business nature type is missing"),
    SPECIFIC_NATURE_OF_BUSINESS_TYPE_MISSING(6481125119612L, "Specific business nature type is missing"),
    USER_ID_MISSING(6481125119613L, "User id is missing"),
    USER_ACCOUNT_NOT_ADDED(6481125119614L, "Failed to add user account"),
    USER_ACCOUNT_NOT_UPDATE(6481125119615L, "Failed to update user account"),
    USER_ACCOUNT_ALL_READY_EXIST(6481125119616L, "User account all ready exist"),
    USER_ACCOUNT_NOT_FOUND(6481125119617L, "User account not found"),
    USER_ACCOUNT_NOT_ACTIVE(6481125119618L, "User account not active"),
    USER_ACCOUNT_NOT_VALID(6481125119619L, "User account is not valid"),
    BUSINESS_TYPE_MISSING(6481125119620L, "Business type is missing"),
    SPECIFIC_BUSINESS_TYPE_MISSING(6481125119621L, "Specific business type is missing"),

    // SignUp Exception.
    MASTER_ACCOUNT_NOT_FOUND(6481125059801L, "Master account not found"),
    SIGN_UP_FAILED(6481125059802L, "Failed to signUp user"),
    PRODUCT_REGISTRATION_FAILED(6481125059803L, "Failed to register 1125 in purchase list"),
    SUPER_ADMIN_EMAIL_ADDRESS_MISSING(6481125059804L, "SuperAdmin email address is missing"),
    PROMOTER_EMAIL_ADDRESS_MISSING(6481125059805L, "Promoter email address is missing"),
    PROMOTER_ID_MISSING(6481125059806L, "Promoter id is missing"),
    PROMOTER_NOT_VALID(6481125059807L, "Promoter not valid"),
    SELF_CONFLICT(6481125059808L, "You are all ready exits"),
    USER_ROLE_NOT_VALID(6481125059809L, "User role not valid"),

    // OfficialVendor Exception.
    VENDOR_ID_MISSING(6481125148301L, "OfficialVendor id is missing"),
    VENDOR_NOT_FOUND(6481125148302L, "OfficialVendor not found"),
    VENDOR_NOT_ACTIVE(6481125148303L, "OfficialVendor not active"),
    VENDOR_NOT_BUYER(6481125148304L, "OfficialVendor not a buyer"),
    VENDOR_NOT_SELLER(6481125148305L, "OfficialVendor not a seller"),
    VENDOR_NOT_UPDATED(6481125148306L, "Failed to update vendor"),
    TARGETED_VENDOR_ID_MISSING(6481125148307L, "Targeted vendor id is missing"),
    TARGETED_VENDOR_NOT_FOUND(6481125148308L, "Targeted vendor not found"),
    TARGETED_VENDOR_NOT_ACTIVE(6481125148309L, "Targeted vendor not active"),
    TARGETED_VENDOR_NOT_VALID(6481125148310L, "Targeted vendor not valid"),
    OFFICIAL_VENDOR_MISSING(6481125148311L, "Official vendor missing"),
    OFFICIAL_VENDOR_NOT_FOUND_FOR_PARTICIPANT(6481125148312L, "Official vendor not found for participant"),
    OFFICIAL_VENDOR_PARTICIPANT_MISSING(6481125148313L, "Official vendor participant is missing"),
    VENDOR_NOT_VALID(6481125148300L, "OfficialVendor not valid"),

    // SignOut Exception.
    SIGN_OUT_FAILED(6481125071301L, "Failed to signOut user"),

    // Cross Authentication Exception.
    CROSS_AUTHENTICATION_FAILED(6481125000000L, "Cross authentication is failed"),

    // Search Exception
    SEARCH_FEED_MISSING(6481125202601L, "Search is missing"),

    // Material Exception.
    MATERIAL_NAME_MISSING(6481125081501L, "Material name is missing"),
    MATERIAL_ID_MISSING(6481125081502L, "Material id is missing"),
    MATERIAL_CATEGORY_MISSING(6481125081503L, "Material category is missing"),
    SPECIFIC_MATERIAL_CATEGORY_MISSING(6481125081504L, "Specific material category is missing"),
    MATERIAL_SECRET_STATUS_MISSING(6481125081505L, "Material secret status is missing"),
    MATERIAL_NOT_FOUND(6481125081506L, "Material not found"),
    MATERIAL_NOT_VALID(6481125081507L, "Material not valid"),
    MATERIAL_NOT_ADDED(6481125081508L, "Failed to add material"),
    MATERIAL_NOT_VERIFY(6481125081509L, "Failed to verify material"),
    MATERIAL_NOT_UPDATED(6481125081510L, "Failed to update material"),
    MATERIAL_NOT_VERIFIED(6481125081511L, "Material is not verified"),
    MATERIAL_CONFLICT(6481125081512L, "Material all ready added"),
    MATERIAL_VERIFIED(6481125081513L, "Material all ready verified"),

    // Preferred Material Exception.
    PREFERRED_MATERIAL_ID_MISSING(6481125180601L, "Preferred material id is missing"),
    PREFERRED_MATERIAL_NOT_ADDED(6481125180602L, "Failed to add preferred material"),
    PREFERRED_MATERIAL_NOT_FOUND(6481125180603L, "Preferred material not found"),
    PREFERRED_MATERIAL_NOT_VALID(6481125180604L, "Preferred material not valid"),

    // Preferred OfficialVendor Exception.
    PREFERRED_VENDOR_ID_MISSING(6481125161301L, "Preferred vendor id is missing"),
    PREFERRED_VENDOR_NOT_ADDED(6481125161302L, "Failed to add preferred vendor"),
    PREFERRED_VENDOR_NOT_FOUND(6481125161303L, "Preferred vendor not found"),
    PREFERRED_VENDOR_NOT_VALID(6481125161304L, "Preferred vendor not valid"),

    // Custom Vendor Exception.
    POINT_OF_CONTACT_MISSING(6481125132101L, "Point of contact missing"),
    VENDOR_TYPE_MISSING(6481125132102L, "Vendor type missing"),
    VENDOR_TYPE_NOT_VALID(6481125132103L, "Vendor type not valid"),
    VENDOR_CATEGORY_MISSING(6481125132104L, "Vendor category missing"),
    VENDOR_CATEGORY_NOT_VALID(6481125132105L, "Vendor category not valid"),
    CUSTOM_VENDOR_MISSING(6481125132106L, "Custom vendor missing"),
    VENDOR_ALL_READY_EXIST(6481125132107L, "Vendor all ready exists"),
    CUSTOM_VENDOR_NOT_FOUND_FOR_PARTICIPANT(6481125132108L, "Custom vendor not found for participant"),
    CONTACT_NUMBER_MISSING(6481125132109L, "Contact number missing"),
    CUSTOM_VENDOR_NOT_ADDED(6481125132110L, "Failed to add custom vendor"),
    CUSTOM_VENDOR_ID_MISSING(6481125132111L, "Custom vendor id missing"),
    CUSTOM_VENDOR_NOT_FOUND(6481125132112L, "Custom vendor not found"),
    CUSTOM_VENDOR_NOT_VALID(6481125132113L, "Custom vendor not valid"),
    SERVICE_ID_NOT_VALID(6481125132114L, "Service id not valid"),
    CUSTOM_VENDOR_NOT_UPDATED(6481125132115L, "Failed to update custom vendor"),
    CUSTOM_VENDOR_ALLOCATED_MATERIAL_NOT_ADDED(6481125132116L, "Failed to add custom vendor allocated material"),
    CUSTOM_VENDOR_ALLOCATED_MATERIAL_ID_MISSING(6481125132117L, "Custom vendor allocated material id is missing"),
    CUSTOM_VENDOR_ID_NOT_VALID(6481125132118L, "Custom vendor id not valid"),
    TARGETED_CUSTOM_VENDOR_ID_MISSING(6481125132119L, "Targeted custom vendor id is missing"),
    TARGETED_CUSTOM_VENDOR_NOT_FOUND(6481125132120L, "Targeted custom vendor not found"),
    TARGETED_CUSTOM_VENDOR_NOT_ACTIVE(6481125132121L, "Targeted custom vendor not active"),
    TARGETED_CUSTOM_VENDOR_NOT_VALID(6481125132122L, "Targeted custom vendor not valid"),
    CUSTOM_VENDOR_PARTICIPANT_MISSING(6481125132123L, "Custom vendor participant is missing"),
    CUSTOM_VENDOR_ALLOCATED_MATERIAL_NOT_REMOVED(6481125132124L, "Failed to remove custom vendor"),
    CUSTOM_VENDOR_TRACE_COMPANY_KEY_WORD_CONFLICT(6481125132125L, "Custom vendor keyword of trace company is conflict"),

    // Cluster Exception.
    CLUSTER_ID_MISSING(6481125073801L, "Cluster id is missing"),
    CLUSTER_NAME_MISSING(6481125073802L, "Cluster name is missing"),
    CLUSTER_DESCRIPTION_MISSING(6481125073803L, "Cluster description is missing"),
    CLUSTER_NOT_ADDED(6481125073804L, "Failed to add cluster"),
    CLUSTER_NOT_FOUND(6481125073805L, "Cluster not found"),
    CLUSTER_NOT_VALID(6481125073806L, "Cluster not valid"),
    CLUSTER_NOT_UPDATE(6481125073807L, "Failed to update cluster"),
    CLUSTER_CONFLICT(6481125073808L, "Cluster all ready exist"),
    CLUSTER_PARTICIPANT_MISSING(6481125073809L, "Cluster participant missing"),
    CLUSTER_ALL_READY_EXIST(6481125073810L, "Cluster all ready exist"),
    KEY_WORD_FOR_TRACE_COMPANY_MISSING(6481125073811L, "Key word of trace company is missing"),
    CLUSTER_NOT_FOUND_FOR_PARTICIPANT(6481125073812L, "Cluster_ not found for participant"),

    // Cluster Member Exception.
    CLUSTER_MEMBER_ID_MISSING(6481125140201L, "Cluster member id is missing"),
    CLUSTER_MEMBER_NOT_ADDED(6481125140202L, "Failed to add cluster member"),
    CLUSTER_MEMBER_NOT_FOUND(6481125140203L, "Cluster member not found"),
    CLUSTER_MEMBER_NOT_VALID(6481125140204L, "Cluster member not valid"),
    CLUSTER_MEMBER_OVERFLOW(6481125140205L, "Custom member all ready exist in cluster"),
    CLUSTER_MEMBER_NOT_REMOVED(6481125140206L, "Failed to remove cluster member"),

    // Tender Exception.
    TENDER_MATERIAL_MISSING(6481125061001L, "Tender material is missing"),
    TENDER_TITLE_MISSING(6481125061002L, "Tender title is missing"),
    TENDER_TYPE_MISSING(6481125061003L, "Tender type is missing"),
    TENDER_TYPE_NOT_VALID(6481125061004L, "Tender type is not valid"),
    FIX_TENDER_NOT_SUPPORT_FOR_BUY(6481125061005L, "Fix tender not supported for buying tender"),
    FIX_BID_NOT_SUPPORT_FOR_BUY(6481125061006L, "Fix bid not supported for buying"),
    TENDER_QUANTITY_TYPE_NOT_VALID(6481125061007L, "Quantity type is not valid"),
    TENDER_QUANTITY_TYPE_MISSING(6481125061008L, "Tender quantity type is missing"),
    TENDER_QUANTITY_MISSING(6481125061009L, "Tender quantity is missing"),
    TENDER_START_DATE_MISSING(6481125061010L, "Tender start date is missing"),
    TENDER_EXPIRY_DATE_MISSING(6481125061011L, "Tender expiry date is missing"),
    TENDER_DELIVERY_DATE_MISSING(6481125061012L, "Tender delivery date is missing"),
    TENDER_PAYMENT_TERMS_DAYS_MISSING(6481125061013L, "Tender payment terms days is missing"),
    TENDER_FREIGHT_MISSING(6481125061014L, "Tender freight is missing"),
    TENDER_PRE_QUALIFICATION_QUESTIONNAIRE_STATUS_MISSING(6481125061015L, "Tender preQualificationQuestionnaireStatus type is missing"),
    TENDER_PRE_QUALIFICATION_QUESTIONNAIRE_DESCRIPTION_MISSING(6481125061016L, "Tender preQualificationQuestionnaire description is missing"),
    TENDER_PRE_QUALIFICATION_QUESTIONNAIRE_DESCRIPTION_OVER_FLOW(6481125061017L, "Tender preQualificationQuestionnaire description length is out of 400 char"),
    TENDER_DESCRIPTION_OVER_FLOW(6481125061018L, "Tender Description length is out of 400 char"),
    TENDER_BIDING_TYPE_MISSING(6481125061019L, "Biding type is missing"),
    TENDER_BIDING_TYPE_NOT_VALID(6481125061020L, "Biding type is not valid"),
    TENDER_BID_AMOUNT_CONFLICTS(6481125061021L, "Bid threshold and amount conflict"),
    TENDER_AUCTION_BID_AMOUNT_NOT_VALID(6481125061022L, "Bid amount not valid for auction biding"),
    TENDER_RFQ_BID_AMOUNT_MISSING(6481125061023L, "Bid amount missing for rfq biding"),
    TENDER_RFQ_BID_AMOUNT_LESS_THEN_500(6481125000024L, "Bid amount not allowed to lest then 500 for rfq biding"),
    TENDER_INCREMENT_BID_AMOUNT_GRATER_THEN_BID_THRESHOLD(6481125061025L, "Increment bid amount not valid"),
    TENDER_DECREMENT_BID_AMOUNT_GRATER_THEN_BID_THRESHOLD(6481125061026L, "Decrement bid amount not valid"),
    TENDER_DELIVERY_DATE_NOT_VALID(6481125061027L, "Tender delivery date not valid"),
    TENDER_EXPIRY_DATE_NOT_VALID(6481125061028L, "Tender expiry date not valid"),
    TENDER_DELIVERY_ADDRESS_MISSING(6481125061029L, "Tender delivery address is missing"),
    TENDER_DELIVERY_ADDRESS_OVER_FLOW(6481125061030L, "Tender delivery delivery address length is out of 400 char"),
    TENDER_DELIVERY_PIN_CODE_MISSING(6481125061031L, "Tender delivery pin code is missing"),
    TENDER_DELIVERY_PIN_CODE_NOT_VALID(6481125061032L, "Tender delivery pin code is not valid"),
    TENDER_DELIVERY_CITY_MISSING(6481125061033L, "Tender delivery city is missing"),
    TENDER_DELIVERY_STATE_MISSING(6481125061034L, "Tender delivery state code is missing"),
    TENDER_DELIVERY_COUNTRY_MISSING(6481125061035L, "Tender delivery country code is missing"),
    TENDER_CONDUCTOR_NOT_ADDED(6481125061036L, "Tender conductor not add"),
    TENDER_PARTICIPANTS_MISSING(6481125061037L, "Tender Participants is missing"),
    TENDER_BID_THRESHOLD_MISSING(6481125061038L, "Tender bid threshold amount is missing"),
    TENDER_FIX_BID_AMOUNT_NOT_AGREED(6481125061039L, "You are not agree with fix bid amount"),
    TENDER_FIX_BID_AMOUNT_MISSING(6481125061040L, "Fix bid amount is missing"),
    TENDER_FIX_BID_AMOUNT_NOT_VALID(6481125061041L, "Fix bid amount not valid"),
    TENDER_NOT_ADDED(6481125061042L, "Tender not added"),
    TENDER_ID_MISSING(6481125061043L, "Tender id is missing"),
    TENDER_ATTACHMENT_ID_MISSING(6481125061044L, "Tender Attachment id is missing"),
    TENDER_NOT_FOUND(6481125061045L, "Tender not found"),
    TENDER_NOT_PARTICIPATED(6481125061046L, "Tender not participated"),
    TENDER_NOT_VALID(6481125061047L, "Tender not valid"),
    TENDER_NOT_READY_FOR_BID(6481125061048L, "Tender not ready for bid"),
    TENDER_NOT_READY(6481125061049L, "Tender not ready"),
    TENDER_BUY_NOT_SUPPORT(6481125061050L, "Tender buy tender not support"),
    TENDER_SELL_NOT_SUPPORT(6481125061051L, "Tender sell tender not support"),
    TENDER_NOT_APPLICABLE(6481125061052L, "Tender not applicable"),
    TENDER_NOT_CONVERTED_TO_RFQ(6481125061053L, "Tender failed to convert rfq to auction"),
    TENDER_ALL_READY_CONVERTED_TO_RFQ(6481125061054L, "Tender all ready to convert rfq"),
    TENDER_ALL_READY_FORTH_COMING_AUCTION(6481125061055L, "Tender all ready used forth coming auction"),
    TENDER_FORTH_COMING_AUCTION_FAILED(6481125061056L, "Tender forth coming auction failed"),
    TENDER_CONTRACTUAL_DATE_MISSING(6481125061057L, "Tender contractual date are missing"),
    TENDER_FROM_DATE_MISSING(6481125061058L, "Tender from date is missing"),
    TENDER_FROM_DATE_NOT_VALID(6481125061059L, "Tender from date not valid"),
    TENDER_TO_DATE_MISSING(6481125061060L, "Tender To date is missing"),
    TENDER_TO_DATE_NOT_VALID(6481125061061L, "Tender To date not valid"),
    TENDER_NOT_DELETE(6481125061062L, "Failed to delete tender"),
    TENDER_NOT_EXTENDED(6481125061062L, "Failed to extend tender"),
    TENDER_CATEGORY_MISSING(6481125061063L, "Tender category is missing"),
    TENDER_ATTACHMENT_NOT_FOUND(6481125061064L, "Tender attachment not found"),
    TENDER_PARTICIPANTS_ID_MISSING(6481125061065L, "Tender participants id missing"),
    TENDER_SPECIFIC_QUANTITY_TYPE_MISSING(6481125061000L, "Specific quantity type is missing"),
    TENDER_CATEGORY_NOT_VALID(6481125061000L, "Tender category is not valid"),
    TENDER_FORTH_COMING_AUCTION_NOT_STARTED(6481125061000L, "Tender forth coming auction not started"),
    TENDER_FORTH_COMING_AUCTION_FINISHED(6481125061000L, "Tender forth coming auction finished"),
    TENDER_TIME_OUT(6481125000000L, "Tender is expired"),
    TENDER_NOT_VALID_FOR_RANK(6481125000000L, "Tender not valid for rank"),
    TENDER_BID_THRESHOLDS_NOT_VALID_FOR_FIXED_TENDER(6481125000000L, "Both bid threshold not valid for fixed tender"),
    TENDER_BID_THRESHOLD_CAN_NOT_BE_LESS_THEN_MINIMUM_BID_THRESHOLD(6481125000000L, "Bid threshold can not be less then minimum bid threshold"),
    TENDER_MINIMUM_BID_THRESHOLD_MISSING(6481125000000L, "Minimum bid threshold amount is missing"),
    TENDER_MINIMUM_BID_THRESHOLD_LESS_500(6481125000000L, "Minimum bid threshold amount is less then 500"),
    TENDER_MAXIMUM_BID_THRESHOLD_MISSING(6481125000000L, "Maximum bid threshold amount is missing"),
    TENDER_MAXIMUM_BID_THRESHOLD_LESS_500(6481125000000L, "Maximum bid threshold amount is less then 500"),
    TENDER_BOTH_BID_THRESHOLD_MISSING(6481125000000L, "Both bid threshold amount is missing"),
    BID_AMOUNT_NOT_VALID(6481125000000L, "Bid amount not valid"),
    TENDER_MINIMUM_BID_THRESHOLD_AMOUNT_MISSING(6481125000000L, "Minimum bid threshold amount is missing"),
    TENDER_BID_THRESHOLD_CAN_NOT_BE_LESS_THEN_500(6481125000000L, "Bid threshold can not be less then 500"),
    TENDER_FIX_NOT_VALID_FOR_RANKED(6481125000000L, "Fix tender not supported to for find ranked"),
    TENDER_FIX_BID_AMOUNT_NOT_FOUND(6481125000000L, "Fix bid amount not found"),
    TENDER_AUCTION_STYLE_MISSING(6481125000000L, "Auction style is missing"),
    TENDER_TIME_ZONE_MISSING(6481125000000L, "Time zone is missing"),
    TENDER_CURRENCY_TYPE_MISSING(6481125000000L, "Currency type is missing"),
    TENDER_END_DATE_MISSING(6481125000000L, "Tender end date is missing"),

    // Bid Exception.
    BID_CONFLICTS(6481125027101L, "Bid is conflicts"),
    BID_AMOUNT_MISSING(6481125027102L, "Bid amount is missing"),
    BID_ID_MISSING(6481125027103L, "Bid id missing"),
    BID_NOT_FOUND(6481125027104L, "Bid not found"),
    BID_NOT_VALID(6481125027105L, "Bid not valid"),
    BID_BOUNCE(6481125027106L, "Rebid not allowed for fix tender"),
    BID_NOT_DELETE(6481125027107L, "Bid not delete"),
    BID_NOT_READY(6481125027108L, "Bid not ready"),
    TENDER_ALL_READY_ACHIEVED(6481125027109L, "Tender all ready achieved"),
    TENDER_ALL_READY_DELIVERED(6481125027110L, "Tender all ready delivered"),
    BID_NOT_UPDATED(6481125027111L, "Bid not update"),
    BID_AMOUNT_FIXED_NOT_VERIFIED(6481125027112L, "Bid not verified for fixed bid amount"),
    TENDER_ALL_READY_EXPIRED(6481125027113L, "Tender all ready expire"),
    BID_NOT_START_TODAY(6481125027114L, "Bid not start today"),
    BID_AMOUNT_CAN_NOT_BE_LESS_THEN_MINIMUM_BID_THRESHOLD(6481125027115L, "Bid amount can not be less then minimum bid threshold"),
    BID_NOT_ADDED(6481125027116L, "Bid not added"),

    // CounterOffer Exception
    COUNTER_OFFER_NOT_ADDED(6481125126601L, "Failed to add Counter Offer"),
    COUNTER_OFFER_NOT_FOUND(6481125126602L, "Counter Offer not found"),
    OFFER_NOT_ADDED(6481125126603L, "Failed to add Offer"),
    COUNTER_OFFER_NOT_AVAILABLE(6481125126604L, "Counter offer not available"),
    NEGOTIATION_LIMIT_OUT_OF_BOUND(6481125126605L, "Negotiation limit out of bound"),
    COUNTER_OFFER_NOT_VALID(6481125126606L, "Counter offer not valid"),
    COUNTER_OFFER_NOT_READY(6481125126607L, "Counter offer not ready"),
    OFFER_NOT_FOUND(6481125126608L, "Offer not found"),
    COUNTER_OFFER_ID_MISSING(6481125126609L, "Counter offer id missing"),
    OFFER_ID_MISSING(6481125126610L, "Offer id missing"),
    OFFER_TOKEN_MISSING(6481125126611L, "Offer token number is missing"),
    EMAIL_ADDRESS_NOT_SEND(6481125126612L, "Email address not send"),
    COUNTER_OFFER_STATUS_NOT_ACCEPTED(6481125126613L, "Counter offer status not accepted"),
    TENDER_NOT_ACTIVE(6481125126614L, "Tender  not active"),

    // DefaultAddress Exception
    DEFAULT_ADDRESS_ID_MISSING(6481125148301L, "Default address id missing"),
    DEFAULT_ADDRESS_TAG_MISSING(6481125148302L, "Default address tag is missing"),
    DEFAULT_ADDRESS_ADDRESS_MISSING(6481125148303L, "Default address address is missing"),
    DEFAULT_ADDRESS_PIN_CODE_MISSING(6481125148304L, "Default address pin code is missing"),
    DEFAULT_ADDRESS_CITY_MISSING(6481125148305L, "Default address city is missing"),
    DEFAULT_ADDRESS_STATE_MISSING(6481125148306L, "Default address state is missing"),
    DEFAULT_ADDRESS_COUNTRY_CODE_MISSING(6481125148307L, "Default address country code is missing"),
    DEFAULT_ADDRESS_COUNTRY_MISSING(6481125148308L, "Default address country is missing"),
    DEFAULT_ADDRESS_REGION_MISSING(6481125148309L, "Default address region is missing"),
    DEFAULT_ADDRESS_NOT_ADDED(6481125148310L, "Failed to add default address"),
    DEFAULT_ADDRESS_NOT_FOUND(6481125148311L, "Default address not found"),
    DEFAULT_ADDRESS_NOT_UPDATE(6481125148312L, "Failed to update default address"),
    DEFAULT_ADDRESS_NOT_DELETE(6481125148313L, "Failed to delete default address"),

    // Notification Exception
    NOTIFICATION_ID_MISSING(6481125125501L, "Notification id is missing"),
    NOTIFICATION_EMAIL_ADDRESS_MISSING(6481125125502L, "Notification email address is missing"),
    NOTIFICATION_STATUS_MISSING(6481125125503L, "Notification status is missing"),
    VENDOR_NOTIFICATION_NOT_FOUND(6481125125504L, "Vendor notification not found"),
    VENDOR_NOTIFICATION_NOT_VALID(6481125125505L, "Vendor notification not valid"),
    NOTIFICATION_NOT_DELETE(6481125125506L, "Failed to delete notification"),;

    private final Long errorCode;

    private final String errorMessage;

    ExceptionStatus(Long errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public Long getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String toString() {
        return errorCode + ": " + errorMessage;
    }
}