package com.ls.TalkHives.dto.common;

import java.util.ArrayList;
import java.util.List;

public class FileListEntity {
    private List<FileEntity> files = new ArrayList<>();

    public List<FileEntity> getFiles() {
        return files;
    }

    public void setFiles(List<FileEntity> files) {
        this.files = files;
    }
}
