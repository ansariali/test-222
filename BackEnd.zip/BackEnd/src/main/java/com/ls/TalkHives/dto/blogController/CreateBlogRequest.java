package com.ls.TalkHives.dto.blogController;

import com.ls.TalkHives.dto.common.FileEntity;

public class CreateBlogRequest {
    private String title;
    private String message;
    private String info;

    private FileEntity file;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public FileEntity getFile() {
        return file;
    }

    public void setFile(FileEntity file) {
        this.file = file;
    }
}
