package com.ls.TalkHives.dto.teamController;

import com.ls.TalkHives.dto.common.UserInfo;

import java.math.BigDecimal;
import java.util.List;

public class CreateTeamRequest {
    private String name;
    private String title;
    private String info;
    private BigDecimal budget;

    private UserInfo teamLeader;
    private List<UserInfo> members;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }

    public UserInfo getTeamLeader() {
        return teamLeader;
    }

    public void setTeamLeader(UserInfo teamLeader) {
        this.teamLeader = teamLeader;
    }

    public List<UserInfo> getMembers() {
        return members;
    }

    public void setMembers(List<UserInfo> members) {
        this.members = members;
    }
}
