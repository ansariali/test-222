/*
package com.ls.TalkHives.controllers.ws;

import com.ls.TalkHives.dto._ChatController.ChatRoomMessages;
import com.ls.TalkHives.dto._ChatController.CreateChatRequest;
import com.ls.TalkHives.dto._ChatController.CreateChatRoomRequest;
import com.ls.TalkHives.dto.common.ChatEntity;
import com.ls.TalkHives.dto.userController.LoginResponse;
import com.ls.TalkHives.entities.Chats;
import com.ls.TalkHives.services.ChatService;
import com.ls.TalkHives.services.UserService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin
@Controller
@RequestMapping("/chatController1")
public class _ChatController extends UniversalController {

    private static final String TAG = _ChatController.class.getSimpleName();

    @Autowired
    private ChatService chatService;

   */
/* @ApiOperation(value = "_C1 Send Message")
    @MessageMapping(value = "/1/login")
    @SendTo(value = "/topic/1/login")
    public ResponseEntity<ChatEntity> loginUser(@DestinationVariable String channelId, ChatEntity chatEntity) {
        logger.info(TAG, "Inside _C1 " + channelId);

        // chatService.sendMessage(message);


        return new ResponseEntity<>(new ChatEntity(), responseHeaders, HttpStatus.OK);
    }*//*


    @ApiOperation(value = "_C1 CREATE Private ChatRoom")
    @PutMapping(value = "/1/privateChat/{to}")
    public ResponseEntity<UniversalResponse> createChatRoom(@PathVariable Long to,
                                                            @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside _C1 " + requestHeader);
        return new ResponseEntity<>(chatService.createChatRoom(to, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "_C2 Get Private ChatRoom Messages")
    @GetMapping(value = "/1/privateChat/messages/{chatRoomTag}")
    public ResponseEntity<ChatRoomMessages> getExistingChatMessages(@PathVariable String chatRoomTag,
                                                                    @RequestHeader Map<String, Object> requestHeader) {

        ChatRoomMessages res = modelMapper.map(chatService.getMessages(chatRoomTag, requestHeader, iDao), ChatRoomMessages.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @MessageMapping("/1/chat/private/{chatRoomTag}")
    @SendTo("/topic/1/chat/private/{chatRoomTag}")
        public ResponseEntity<ChatEntity> sendMessage(@PathVariable String chatRoomTag, CreateChatRequest createChatRequest,
                                                  StompHeaderAccessor stompHeaderAccessor) {
        logger.info(TAG, "Inside _CCC " + stompHeaderAccessor.getNativeHeader("LOGIN-TOKEN"));

        ChatEntity res = modelMapper.map(chatService.sendMessage(createChatRequest, stompHeaderAccessor, iDao), ChatEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    // @MessageMapping("/1/notification")
    @SendTo("/topic/1/notification")
    public ResponseEntity<UniversalResponse> sampleNotification() {
        logger.info(TAG, "Inside _CCC1 NOTIFICATION");

        return new ResponseEntity<>(new UniversalResponse(true, "Sample NOTIFICATION!"), responseHeaders, HttpStatus.OK);
    }


}*/
