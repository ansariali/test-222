package com.ls.TalkHives.dto.common;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class TeamInfoEntity {
    private Long teamId;
    private String name;
    private String title;
    private UserInfo teamLeader;
    private List<TeamMembersEntity> members;

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public UserInfo getTeamLeader() {
        return teamLeader;
    }

    public void setTeamLeader(UserInfo teamLeader) {
        this.teamLeader = teamLeader;
    }

    public List<TeamMembersEntity> getMembers() {
        return members;
    }

    public void setMembers(List<TeamMembersEntity> members) {
        this.members = members;
    }
}
