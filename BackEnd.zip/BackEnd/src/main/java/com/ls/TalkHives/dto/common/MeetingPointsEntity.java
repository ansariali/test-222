package com.ls.TalkHives.dto.common;

import java.util.Date;

public class MeetingPointsEntity {
    private Long meetingPointId;
    private String title;
    private UserInfo notedBy;
    private Date createdAt;

    public Long getMeetingPointId() {
        return meetingPointId;
    }

    public void setMeetingPointId(Long meetingPointId) {
        this.meetingPointId = meetingPointId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public UserInfo getNotedBy() {
        return notedBy;
    }

    public void setNotedBy(UserInfo notedBy) {
        this.notedBy = notedBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}