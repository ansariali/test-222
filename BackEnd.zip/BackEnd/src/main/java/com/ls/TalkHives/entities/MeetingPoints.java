package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * MeetingPoints Entity
 */

@Entity
@Table(name = "meeting_points")
public class MeetingPoints extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long meetingPointId;

    private String meetingPointTag;
    private String title;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "notedBy")
    private Users notedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "meetingId")
    private Meetings meetings;

    public Long getMeetingPointId() {
        return meetingPointId;
    }

    public void setMeetingPointId(Long meetingPointId) {
        this.meetingPointId = meetingPointId;
    }

    public String getMeetingPointTag() {
        return meetingPointTag;
    }

    public void setMeetingPointTag(String meetingPointTag) {
        this.meetingPointTag = meetingPointTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Users getNotedBy() {
        return notedBy;
    }

    public void setNotedBy(Users notedBy) {
        this.notedBy = notedBy;
    }

    public Meetings getMeetings() {
        return meetings;
    }

    public void setMeetings(Meetings meetings) {
        this.meetings = meetings;
    }
}



