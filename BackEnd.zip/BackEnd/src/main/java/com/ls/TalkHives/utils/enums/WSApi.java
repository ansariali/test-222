package com.ls.TalkHives.utils.enums;

public enum WSApi {

    // Post
    SEND_TO_USER_POST("/topic/post/1/create/sendToUser/{userId}", ""),
    SEND_TO_ORGANIZATION_POST("/topic/post/1/create/sendToOrganization/{organizationId}", ""),
    SEND_TO_DESIGNATION_POST("/topic/post/1/create/sendToDesignation/{userRoleTag}", ""),
    SEND_SHARED_POST("/topic/post/1/share/{organizationId}", ""),


    // Team
    SEND_TO_USER_TEAM("/topic/team/1/sendToUser/{userId}", ""),

    // Task
    SEND_TO_USER_TASK("/topic/task/1/sendToUser/{userId}", ""),

    // Team
    // SEND_CLIENT("/topic/client/1/send?organizationId={organizationId}&userId={userId}", ""),
    SEND_CLIENT("/topic/client/1/send?organizationId={organizationId}", ""),

    // NOTIFICATION
    SEND_TO_USER_NOTIFICATION("/topic/notification/1/create/sendToUser/{userId}", ""),
    SEND_TO_ORGANIZATION_NOTIFICATION("/topic/notification/1/create/sendToOrganization/{organizationId}", ""),
    SEND_TO_DESIGNATION_NOTIFICATION("/topic/notification/1/create/sendToDesignation/{userRoleTag}", ""),
    SEND_SHARED_NOTIFICATION("/topic/notification/1/share/{organizationId}", ""),

    // ACTIVITY
    SEND_ACTIVITY_TO_USER("/topic/1/sendToUser/{userId}", ""),
    SEND_ACTIVITY_TO_ORGANIZATION("/topic/1/sendToOrganization/{organizationId}", ""),
    SEND_ACTIVITY_TO_DESIGNATION("/topic/1/sendToDesignation/{userRoleTag}", ""),

    SEND_SELF_ACTIVITY("/topic/selfActivity/1/sendToUser/{userId}", ""),

    // LAST [ DEMO ]
    LAST("", "");

    private final String sendTo;
    private final String messageMapping;

    WSApi(String sendTo, String messageMapping) {
        this.sendTo = sendTo;
        this.messageMapping = messageMapping;
    }

    public String getSendTo() {
        return sendTo;
    }

    public String getMessageMapping() {
        return messageMapping;
    }
}