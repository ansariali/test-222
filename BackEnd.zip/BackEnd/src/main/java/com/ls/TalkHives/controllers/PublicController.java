package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.UserEntity;
import com.ls.TalkHives.dto.publicController.*;
import com.ls.TalkHives.services.PublicService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/publicController")
public class PublicController extends UniversalController {

    private static final String TAG = PublicController.class.getSimpleName();

    @Autowired
    private PublicService publicService;

    @ApiOperation(value = "P1 FetchAll UserRole")
    @GetMapping(value = "/1/fetchAll/userRole")
    public ResponseEntity<FetchAllUserRole> fetchAllUserRoles(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P1 Verify Token | /1/verify/token");

        FetchAllUserRole res = modelMapper.map(publicService.getUserRoles(requestHeader, iDao), FetchAllUserRole.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P2 Verify Token")
    @GetMapping(value = "/1/verify/token/{token}")
    public ResponseEntity<UniversalResponse> verifyInvitation(@PathVariable String token) {
        logger.info(TAG, "Inside P1 Verify Token | /1/verify/token");

        return new ResponseEntity<>(publicService.verifyInvitation(token, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P3 Verify UserName")
    @GetMapping(value = "/1/verify/userName")
    public ResponseEntity<UniversalResponse> verifyUserName(@RequestParam String userName) {
        logger.info(TAG, "P3 Verify UserName | /1/verify/{userName}");

        return new ResponseEntity<>(publicService.verifyUserName(userName, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P4 Verify EmailId")
    @GetMapping(value = "/1/verify/emailId")
    public ResponseEntity<UniversalResponse> verifyEmailId(@RequestParam String emailId) {
        logger.info(TAG, "Inside P4 Verify EmailId | /1/verify/{emailId}");

        return new ResponseEntity<>(publicService.verifyEmailId(emailId, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P5 FetchAll Invitation")
    @GetMapping(value = "/1/fetchAll/invitations")
    public ResponseEntity<FetchAllInvitations> fetchAllInvitations(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P5 FetchAll Invitation | /1/fetchAll/invitations");

        FetchAllInvitations res = modelMapper.map(publicService.getInvitations(requestHeader, iDao), FetchAllInvitations.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P6 FetchAll Users")
    @GetMapping(value = "/1/fetchAll/users")
    public ResponseEntity<FetchAllUsers> fetchAllUsers(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllUsers");

        FetchAllUsers res = modelMapper.map(publicService.getUsers(requestHeader, iDao), FetchAllUsers.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P7 FetchAll Users Info")
    @GetMapping(value = "/1/fetchAll/usersInfo")
    public ResponseEntity<FetchAllUsersInfo> fetchAllUsersInfo(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P6 FetchAll Users | /1/fetchAll/users");

        FetchAllUsersInfo res = modelMapper.map(publicService.getUsers(requestHeader, iDao), FetchAllUsersInfo.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P8 FetchAll Privacy Levels")
    @GetMapping(value = "/1/fetchAll/privacyLevels")
    public ResponseEntity<FetchAllPrivacyLevels> fetchAllPrivacyLevels(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllPrivacyLevels");

        FetchAllPrivacyLevels res = modelMapper.map(publicService.getPrivacyLevels(requestHeader, iDao), FetchAllPrivacyLevels.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P9 Fetch User")
    @GetMapping(value = "/1/fetch/user")
    public ResponseEntity<UserEntity> fetchUser(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside U7 Fetch User | ");

        UserEntity res = modelMapper.map(publicService.getUser(requestHeader, iDao), UserEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P9 FetchAll Status")
    @GetMapping(value = "/1/fetchAll/status")
    public ResponseEntity<FetchAllStatus> fetchAllStatus(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P9 | ");

        FetchAllStatus res = modelMapper.map(publicService.getAllStatus(requestHeader, iDao), FetchAllStatus.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P10 FetchAll Priority")
    @GetMapping(value = "/1/fetchAll/priority")
    public ResponseEntity<FetchAllPriority> fetchAllPriority(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P10 | ");

        FetchAllPriority res = modelMapper.map(publicService.getPriorities(requestHeader, iDao), FetchAllPriority.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P11 FetchAll Frequency")
    @GetMapping(value = "/1/fetchAll/frequency")
    public ResponseEntity<FetchAllFrequency> fetchAllFrequency(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P11 | ");

        FetchAllFrequency res = modelMapper.map(publicService.getFrequencies(requestHeader, iDao), FetchAllFrequency.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P12 FetchAll Self Activity")
    @GetMapping(value = "/1/fetchAll/selfActivity")
    public ResponseEntity<FetchAllActivity> fetchAllActivity(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P12 | ");

        FetchAllActivity res = modelMapper.map(publicService.getActivities(requestHeader, iDao), FetchAllActivity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }




}