package com.ls.TalkHives.dto.common;

import java.util.Date;

public class TaskMembersEntity {
    private Long taskMemberId;
    private String type;
    private Date createdAt;

    private UserInfo assignedBy;
    private UserInfo users;

    public Long getTaskMemberId() {
        return taskMemberId;
    }

    public void setTaskMemberId(Long taskMemberId) {
        this.taskMemberId = taskMemberId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public UserInfo getAssignedBy() {
        return assignedBy;
    }

    public void setAssignedBy(UserInfo assignedBy) {
        this.assignedBy = assignedBy;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }
}
