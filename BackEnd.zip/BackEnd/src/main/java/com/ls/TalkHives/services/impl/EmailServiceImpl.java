package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.services.EmailService;
import com.ls.TalkHives.utils.enums.*;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("deprecation")
@Component
public class EmailServiceImpl implements EmailService {

    /*private static final String TAG = EmailServiceImpl.class.getSimpleName();*/

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private VelocityEngine velocityEngine;

    @Override
    public Boolean sendNewMail(String to, String message) {
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("message", message);

            sendEmail(to, EmailTemplate.SAMPLE.getEmailSubject(), model, EmailTemplate.SAMPLE.getTemplateUrl());

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Boolean welcomeMail(String to, String firstName, String organizationName) {
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("firstName", firstName);
            model.put("organizationName", organizationName);
            model.put("loginPage", FrontEnd.CONFIRM_INVITATION.getLoginPage());

            sendEmail(to, EmailTemplate.WELCOME.getEmailSubject(), model, EmailTemplate.WELCOME.getTemplateUrl());

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Boolean sendInvitationMail(String to, String personName, String organizationName, String invitedBy, String token) {
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("personName", personName);
            model.put("organizationName", organizationName);
            model.put("invitedBy", invitedBy);
            model.put("invitationLink", FrontEnd.CONFIRM_INVITATION.getTalkHivesUrl().replace("{REASON}", FrontEnd.CONFIRM_INVITATION.getReason()).replace("{TOKEN}", token));

            sendEmail(to, EmailTemplate.INVITATION.getEmailSubject().replace("{companyName}", organizationName), model, EmailTemplate.INVITATION.getTemplateUrl());

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Async
    void sendEmail(final String to, final String subject, final Map<String, Object> model, final String template) {
        MimeMessagePreparator mimeMessagePreparator = mimeMessage -> {
            try {
                MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage);

                mimeMessageHelper.setFrom(UniversalInfo.EazeProcure_Email_Host.getInfo());
                mimeMessageHelper.setTo(to);
                mimeMessageHelper.setSubject(subject);
                mimeMessageHelper.setText(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, template, "UTF-8", model), true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        };

        javaMailSender.send(mimeMessagePreparator);
    }
}