package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.blogController.CreateBlogRequest;
import com.ls.TalkHives.dto.blogController.UpdateBlogRequest;
import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Blogs;
import com.ls.TalkHives.entities.Images;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.BlogService;
import com.ls.TalkHives.services.impl.handler.BlogServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class BlogServiceImpl extends BlogServiceImplHandler implements BlogService {

    private static final String TAG = BlogServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreateBlogRequest createBlogRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Blogs blogs = new Blogs();
        blogs.setTitle(createBlogRequest.getTitle());
        blogs.setMessage(createBlogRequest.getMessage());
        blogs.setInfo(createBlogRequest.getInfo());
        blogs.setUser(users);
        blogs.setOrganizations(users.getOrganizations());
        blogs.setCreatedAt(getCurrentTime());

        Blogs blogs_ = iDao.find(Blogs.class, iDao.persist(blogs));
        checkNullObject(blogs_, ExceptionStatus.NEW_NOT_ADDED);

        if (createBlogRequest.getFile() != null) {
            Images images = new Images();
            images.setImageTag(Ascii.IMAGE.getCode() + Ascii.BLOG.getCode());
            images.setFileName(createBlogRequest.getFile().getName());
            images.setType(createBlogRequest.getFile().getType());
            images.setCreatedAt(getCurrentTime());

            String prefix = S3Storage.FOLDER_BLOG.getValue() + S3Storage.SUFFIX.getValue() + blogs_.getBlogId() + S3Storage.SUFFIX.getValue() + createBlogRequest.getFile().getName();
            images.setFileUrl(s3StorageService.copyFile(prefix, createBlogRequest.getFile().getFileUrl()));

            Images images_ = iDao.find(Images.class, iDao.persist(images));
            blogs_.setImages(images_);
        }

        return sendBlog(Activity.CREATE_BLOG.getActivity(), blogs_, users, iDao);
    }

    @Override
    public Map<String, List<Blogs>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Blogs>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Blogs> list = iDao.getEntities(Blogs.class, queryManager.getAllBlogs(), hashtable, false);
        hashtable.clear();

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("blogs", list);

        return map;
    }

    @Override
    public WsResponse update(UpdateBlogRequest updateBlogRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateBlogRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateBlogRequest.getBlogId(), ExceptionStatus.BLOG_ID_MISSING);

        Users users = findUserByLoginToken(requestHeader, iDao);
        Blogs blogs = iDao.find(Blogs.class, updateBlogRequest.getBlogId());

        checkNullObject(blogs, ExceptionStatus.BLOG_NOT_FOUND);

        if (!Objects.equals(blogs.getUser(), users)) {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        blogs.setTitle(updateBlogRequest.getTitle());
        blogs.setMessage(updateBlogRequest.getMessage());
        blogs.setInfo(updateBlogRequest.getInfo());

        if (updateBlogRequest.getFile() != null) {
            Images images = new Images();
            images.setImageTag(Ascii.IMAGE.getCode() + Ascii.BLOG.getCode());
            images.setType(updateBlogRequest.getFile().getType());
            images.setFileName(updateBlogRequest.getFile().getName());
            images.setCreatedAt(getCurrentTime());

            String prefix = S3Storage.FOLDER_BLOG.getValue() + S3Storage.SUFFIX.getValue() + blogs.getBlogId() + S3Storage.SUFFIX.getValue() + updateBlogRequest.getFile().getName();
            images.setFileUrl(s3StorageService.copyFile(prefix, updateBlogRequest.getFile().getFileUrl()));

            Images images_ = iDao.find(Images.class, iDao.persist(images));
            blogs.setImages(images_);
        }

        Blogs blogs_ = iDao.update(blogs);

        return sendBlog(Activity.UPDATE_BLOG.getActivity(), blogs_, users, iDao);
    }

    @Override
    public WsResponse delete(Long blogId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);

        Blogs blogs = iDao.find(Blogs.class, blogId);
        checkNullObject(blogs, ExceptionStatus.BLOG_NOT_FOUND);

        if (Integer.parseInt(users.getUserRole().getRoleTag()) < 3 || blogs.getUser().equals(users)) {
            iDao.delete(blogs);
        } else {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        blogs = iDao.find(Blogs.class, blogId);

        if (blogs.getDeleted()) {
            users.setDeletedBlog(users.getDeletedBlog() + 1);
            return sendBlog(Activity.DELETE_BLOG.getActivity(), blogs, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.BLOG_NOT_DELETED);
        }
    }
}