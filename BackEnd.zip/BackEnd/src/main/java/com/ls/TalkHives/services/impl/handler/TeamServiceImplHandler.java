package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.TeamEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.TeamMembers;
import com.ls.TalkHives.entities.Teams;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public abstract class TeamServiceImplHandler extends UniversalService {

    // Activity Action
    private void activityAction(String activityTag, Teams teams, Users users) {
        if (activityTag.equals(Activity.CREATE_TEAM.getActivity())) {
            teams.setTeamTag(getTeamTag(users));
        }

        if (activityTag.equals(Activity.DELETE_VOTE.getActivity())) {
            users.setDeletedTeam(users.getDeletedTeam() + 1);
            users.getOrganizations().setDeletedTeam(users.getOrganizations().getDeletedTeam() + 1);
        }
    }

    // Create, Delete Team
    protected WsResponse sendTeam(String activityTag, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, teams, users);

        // Send Team
        WsResponse wsResponse = sendTeamToUser(activityTag, teams, users, iDao);

        // Send Notification
        notifyTopLevel(activityTag, teams, users, iDao);

        if (activityTag.equals(Activity.CREATE_TEAM.getActivity())) {
            notifyTeamLeader(teams, users, iDao);
            notifyTeamMembers(activityTag, teams.getMembers(), teams, users, iDao);
        }

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.TEAM, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }

    // Update Team
    protected WsResponse sendTeam(Boolean notifyTeamLeader, List<TeamMembers> removedMember, HashSet<TeamMembers> members, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        String activityTag = Activity.UPDATE_TEAM.getActivity();

        // Send Team To Removed Member
        for (TeamMembers teamMembers : removedMember) {
            iDao.delete(teamMembers);
            if (!hasAccess(2, teamMembers.getUsers())) {
                sendActivity(Ascii.USER, teamMembers.getUsers().getUserId().toString(), teams.getTeamId(), Ascii.TEAM, Activity.DELETE_TEAM.getActivity(), modelMapper.map(teams, TeamEntity.class));
            }
        }

        // Send Team To Member
        WsResponse wsResponse = sendTeamToUser(activityTag, teams, users, iDao);

        // Send Notification
        notifyTopLevel(activityTag, teams, users, iDao);

        if (notifyTeamLeader) {
            notifyTeamLeader(teams, users, iDao);
        }
        notifyTeamMembers(activityTag, members, teams, users, iDao);

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.TEAM, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }

    protected WsResponse sendTeamToUser(String activityTag, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        TeamEntity teamEntity = modelMapper.map(teams, TeamEntity.class);

        // getTopLevel People
        List<Users> list = getTopLevelPeople(users, iDao);

        // add Team Leader
        if (!list.contains(teams.getTeamLeader()) && teams.getTeamLeader() != null) {
            list.add(teams.getTeamLeader());
        }

        // add Team Members
        for (TeamMembers teamMembers : teams.getMembers()) {
            if (!list.contains(teamMembers.getUsers())) {
                list.add(teamMembers.getUsers());
            }
        }

        // Get rid of Duplicate
        Set<Users> list_ = new HashSet<>(list);

        WsResponse wsResponse = new WsResponse();
        // Send Team
        for (Users users_ : list_) {
            wsResponse = sendActivity(Ascii.USER, users_.getUserId().toString(), teams.getTeamId(), Ascii.TEAM, activityTag, teamEntity);
        }

        return wsResponse;
    }

    private void notifyTopLevel(String activityTag, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, team = teams.getName();

        List<Users> list = getTopLevelPeople(users, iDao);

        if (list.contains(users)) {
            list.remove(users);
        }

        if (list.contains(teams.getTeamLeader()) && !activityTag.equals(Activity.DELETE_TEAM.getActivity())) {
            list.remove(teams.getTeamLeader());
        }

        if (!list.contains(teams.getTeamLeader()) && activityTag.equals(Activity.DELETE_TEAM.getActivity())) {
            list.add(teams.getTeamLeader());
        }

        for (Users user_ : list) {
            user = users.getFirstName() + " " + users.getLastName();
            message = Notification.valueOf(activityTag).getCustomMessage()
                    .replace("{user}", user)
                    .replace("{team}", team);
            notificationService.sentToUser(teams.getTeamId(), Ascii.TEAM.getCode(), Boolean.FALSE, message, user_, users, iDao);
        }
    }

    protected void notifyTeamLeader(Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, team = teams.getName();

        if (teams.getTeamLeader().equals(users)) {
            user = "You";
            message = Notification.TEAM_LEADER.getSelfMessage()
                    .replace("{user}", user)
                    .replace("{team}", team);
            notificationService.sentToUser(teams.getTeamId(), Ascii.TEAM.getCode(), Boolean.TRUE, message, teams.getTeamLeader(), users, iDao);
        } else {
            user = users.getFirstName() + " " + users.getLastName();
            message = Notification.TEAM_LEADER.getPublicMessage()
                    .replace("{user}", user)
                    .replace("{team}", team);
            notificationService.sentToUser(teams.getTeamId(), Ascii.TEAM.getCode(), Boolean.FALSE, message, teams.getTeamLeader(), users, iDao);
        }
    }

    private void notifyTeamMember(String activityTag, Teams teams, Users teamMember, Users users, IDao<IEntity, Serializable> iDao) {
        String user, message, team = teams.getName();

        if (teamMember.equals(users)) {
            user = "You";
            message = Notification.valueOf(activityTag).getSelfMessage()
                    .replace("{user}", user)
                    .replace("{team}", team);
        } else {
            user = setFullName(users);
            message = Notification.valueOf(activityTag).getPublicMessage()
                    .replace("{user}", user)
                    .replace("{team}", team);
        }

        notificationService.sentToUser(teams.getTeamId(), Ascii.TEAM.getCode(), Boolean.FALSE, message, teamMember, users, iDao);
    }

    protected void notifyTeamMembers(String activity, Set<TeamMembers> list, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        for (TeamMembers teamMembers : list) {
            notifyTeamMember(activity, teams, teamMembers.getUsers(), users, iDao);
        }
    }
}


 /*protected void sendTeamToUser(String activity, Teams teams, Users users, IDao<IEntity, Serializable> iDao) {
        TeamResponse teamResponse = new TeamResponse();
        teamResponse.setActivity(activity);
        teamResponse.setTeam(modelMapper.map(teams, TeamEntity.class));

        // getTopLevel People
        List<Users> list = getTopLevelPeople(users, iDao);

        // add Team Leader
        if (!list.contains(teams.getTeamLeader()) && teams.getTeamLeader() != null) {
            list.add(teams.getTeamLeader());
        }

        // add Team Members
        for (TeamMembers teamMembers : teams.getMembers()) {
            if (!list.contains(teamMembers.getUsers())) {
                list.add(teamMembers.getUsers());
            }
        }

        // Get rid of Duplicate
        Set<Users> list_ = new HashSet<>(list);

        // Remove Team Creator if exists
        if (list_.contains(users) && !activity.equals(Notification.DELETE_TEAM.getActivity())) {
            list_.remove(users);
        }

        // Send Team
        for (Users users_ : list_) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_TO_USER_TEAM.getSendTo()
                    .replace("{userId}", "" + users_.getUserId()), teamResponse);
        }

        if (!activity.equals(Notification.DELETE_TEAM.getActivity())) {
            notifyTopLevel(activity, teams, users, iDao);
        }

        if (activity.equals(Notification.CREATE_TEAM.getActivity())) {
            notifyTeamLeader(teams, users, iDao);
            notifyTeamMembers(activity, teams.getMembers(), teams, users, iDao);
        }
    }*/
