package com.ls.TalkHives.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import com.ls.TalkHives.utils.exception.UniversalException;
import org.apache.tomcat.util.codec.binary.Base64;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;
import java.util.TimeZone;

public class Refactor {

    private static final String TAG = Refactor.class.getSimpleName();

    private Logger logger = Logger.getInstance(true, Refactor.class);

    public JsonSerializer<Date> serializeDate = new JsonSerializer<Date>() {
        @Override
        public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
            return src == null ? null : new JsonPrimitive(src.getTime());
        }
    };

    public JsonDeserializer<Date> deserializeDate = new JsonDeserializer<Date>() {
        @Override
        public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return json == null ? null : new Date(json.getAsLong());
        }
    };

    public JsonSerializer<Currency> serializeCurrency = new JsonSerializer<Currency>() {
        @Override
        public JsonElement serialize(Currency src, Type typeOfSrc, JsonSerializationContext context) {
            return src == null ? null : new JsonPrimitive(src.getCurrencyCode());
        }
    };

    public JsonDeserializer<Currency> deserializeCurrency = new JsonDeserializer<Currency>() {
        @Override
        public Currency deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return json == null ? null : Currency.getInstance(json.getAsString());
        }
    };

    public JsonDeserializer<Date> deserializResponse = new JsonDeserializer<Date>() {
        @Override
        public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            return json == null ? null : new Date(json.getAsLong());
        }
    };

    private Refactor() {
    }

    public static Refactor getInstance() {
        return new Refactor();
    }

    /**
     * Convert object to JSON String
     *
     * @param object
     * @return
     */
    public String javaToJson(Object object) {
        try {
            ObjectMapper jsonMapper = new ObjectMapper();
            return jsonMapper.writeValueAsString(object);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Convert a JSON string to an object
     *
     * @param json
     * @return
     */
    public Object jsonToJava(String json, Class<?> clzz) {
        try {
            ObjectMapper jsonMapper = new ObjectMapper();
            return jsonMapper.readValue(json, clzz);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @param object
     * @return
     */
    public String toJson(Object object) {
        try {
            ObjectMapper mObjectMapper = new ObjectMapper();
            return mObjectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new UniversalException();
        }
    }

    /**
     * @param timeZone
     * @param date
     * @return
     */
    public Date getTimeBySpecificZone(final String timeZone, final Date date) {
        try {
            String DATE_FORMAT = "dd-MM-yyyy hh:mm:ss a";

            SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(DATE_FORMAT);

            SimpleDateFormat aSimpleDateFormat2 = new SimpleDateFormat(DATE_FORMAT);

            TimeZone aTimeZone = TimeZone.getTimeZone(timeZone);
            aSimpleDateFormat2.setTimeZone(aTimeZone);

            return aSimpleDateFormat.parse(aSimpleDateFormat2.format(date));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param timeZone
     * @param date
     * @return
     */
    public String getTimeBySpecificZone(final com.ls.TalkHives.utils.enums.TimeZone timeZone, final Date date) {
        try {
            String DATE_FORMAT = "dd-MM-yyyy hh:mm:ss a";

            SimpleDateFormat aSimpleDateFormat2 = new SimpleDateFormat(DATE_FORMAT);

            TimeZone aTimeZone = TimeZone.getTimeZone(timeZone.getTimeZone());
            aSimpleDateFormat2.setTimeZone(aTimeZone);

            return aSimpleDateFormat2.format(date);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param data
     * @return
     */
    public String encodeToBase64(final String data) {
        try {
            return new String(Base64.encodeBase64(data.getBytes()));
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }

    /**
     * @param data
     * @return
     */
    public String decodeToBase64(final String data) {
        try {
            return new String(Base64.decodeBase64(data));
        } catch (Exception e) {
            logger.error(TAG, e);
            return null;
        }
    }

    /**
     * @param timeZone
     * @param date
     * @return
     */
    public Date convertTimeBySpecificZone(final String timeZone, final Date date) {
        try {
            String DATE_FORMAT = "dd-MM-yyyy hh:mm:ss a";

            SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(DATE_FORMAT);

            SimpleDateFormat aSimpleDateFormat2 = new SimpleDateFormat(DATE_FORMAT);

            TimeZone aTimeZone = TimeZone.getTimeZone(timeZone);
            aSimpleDateFormat2.setTimeZone(aTimeZone);

            return aSimpleDateFormat.parse(aSimpleDateFormat2.format(date));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param targetUrl
     * @return
     */
    public ByteArrayOutputStream convertPDFToByteArray(String targetUrl) {
        InputStream aInputStream = null;
        ByteArrayOutputStream aByteArrayOutputStream = new ByteArrayOutputStream();

        try {

            aInputStream = new FileInputStream(targetUrl);
            byte[] buffer = new byte[1024 * 12];
            aByteArrayOutputStream = new ByteArrayOutputStream();

            int bytesRead;
            while ((bytesRead = aInputStream.read(buffer)) != -1) {
                aByteArrayOutputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (aInputStream != null) {
                try {
                    aInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return aByteArrayOutputStream;
    }
}