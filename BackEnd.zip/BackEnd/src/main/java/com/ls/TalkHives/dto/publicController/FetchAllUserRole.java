package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.UserRoleEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllUserRole {

    private List<UserRoleEntity> userRoles = new ArrayList<>();

    public List<UserRoleEntity> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRoleEntity> userRoles) {
        this.userRoles = userRoles;
    }
}
