package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.taskController.CreateTaskRequest;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.TaskService;
import com.ls.TalkHives.services.impl.handler.TaskServiceImplHandler;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class TaskServiceImpl extends TaskServiceImplHandler implements TaskService {

    private static final String TAG = TaskServiceImpl.class.getSimpleName();

    @Override
    public Map<String, List<Tasks>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Tasks>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Tasks> list = iDao.getEntities(Tasks.class, queryManager.getAllTasks(), hashtable, false, "DESC");
        hashtable.clear();
      /*  List<Tasks> _list = new ArrayList<>();
        for (Tasks tasks : list) {
            hashtable.put("tasks", tasks);
            hashtable.put("users", users);
            TaskMembers taskMembers = iDao.getEntity(TaskMembers.class, queryManager.getTaskMember(), hashtable, false);
            hashtable.clear();

            if (taskMembers == null) {
                _list.add(tasks);
            }
        }
        list.removeAll(_list);*/

//        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));
        map.put("tasks", list);

        return map;
    }

    @Override
    public Tasks create(CreateTaskRequest createTaskRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        ProjectMilestones aMilestones = iDao.find(ProjectMilestones.class, createTaskRequest.getMilestone().get(0).getProjectMilestoneId());
        checkNullMileStone(aMilestones, ExceptionStatus.Task_STARTING_DATE_MISSING);

        Tasks tasks = new Tasks();
        tasks.setTitle(createTaskRequest.getTitle());
        tasks.setInfo(createTaskRequest.getInfo());
        tasks.setType(createTaskRequest.getType());

        checkNullDate(createTaskRequest.getInitialDate(), ExceptionStatus.Task_STARTING_DATE_MISSING);
        checkNullDate(createTaskRequest.getDeadline(), ExceptionStatus.Task_DEADLINE_MISSING);

        tasks.setInitialDate(getUTCTime(createTaskRequest.getInitialDate()));
        tasks.setDeadline(getUTCTime(createTaskRequest.getDeadline()));

        tasks.setPriority(iDao.find(Priority.class, createTaskRequest.getPriority().getPriorityTag()));
        tasks.setStatus(iDao.find(Status.class, GlobalTag.NEW.getLongTag()));
        tasks.setUsers(users);
        tasks.setOrganizations(users.getOrganizations());
        tasks.setCreatedAt(getCurrentTime());
        tasks.setProjectMilestones(aMilestones);

        HashSet<TaskMembers> members = new HashSet<>();
        for (UserInfo userInfo : createTaskRequest.getMembers()) {
            if (userInfo != null) {
                TaskMembers taskMembers = new TaskMembers();
                taskMembers.setAssignedBy(users);
                taskMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
                taskMembers.setTasks(tasks);
                taskMembers.setCreatedAt(getCurrentTime());

                members.add(taskMembers);
            }
        }

        tasks.setMembers(members);
        tasks.setTotalMember(tasks.getMembers().size());

        Tasks tasks_ = iDao.find(Tasks.class, iDao.persist(tasks));
        checkNullObject(tasks_, ExceptionStatus.NEW_NOT_ADDED);

        sendTaskToUsers(tasks_.getType(), tasks_, users, iDao);

        // sendTask(Activity.CREATE_TASK.getActivity(), tasks_, users, iDao);

        return tasks_;
    }

    @Override
    public Tasks updateTask(Long taskId, CreateTaskRequest createTaskRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(createTaskRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(taskId, ExceptionStatus.TASK_ID_MISSING);

        checkNullDate(createTaskRequest.getInitialDate(), ExceptionStatus.Task_STARTING_DATE_MISSING);
        checkNullDate(createTaskRequest.getDeadline(), ExceptionStatus.Task_DEADLINE_MISSING);

        Tasks aTask = iDao.find(Tasks.class, taskId);
        checkNullObject(aTask, ExceptionStatus.TASK_NOT_FOUND);

        aTask.setTitle(createTaskRequest.getTitle());
        aTask.setInfo(createTaskRequest.getInfo());
        aTask.setInitialDate(getUTCTime(createTaskRequest.getInitialDate()));
        aTask.setDeadline(getUTCTime(createTaskRequest.getDeadline()));
        aTask.setUsers(users);
        aTask.setOrganizations(users.getOrganizations());
        aTask.setUpdatedAt(getCurrentTime());
//        aTask.setUpdatedBy(users);
        aTask.setProjectMilestones(aTask.getProjectMilestones());

        for (TaskMembers taskMembers : aTask.getMembers()) {
            iDao.purge(taskMembers);
        }

        HashSet<TaskMembers> members = new HashSet<>();
        for (UserInfo userInfo : createTaskRequest.getMembers()) {
            TaskMembers taskMemberes = new TaskMembers();
            taskMemberes.setAssignedBy(users);
            taskMemberes.setUsers(iDao.find(Users.class, userInfo.getUserId()));
            taskMemberes.setTasks(aTask);
            taskMemberes.setCreatedAt(getCurrentTime());
            members.add(taskMemberes);
        }
        aTask.setMembers(members);
        aTask.setTotalMember(aTask.getMembers().size());

        Tasks tasks_ = iDao.update(aTask);
        checkNullObject(tasks_, ExceptionStatus.NEW_NOT_ADDED);

        sendTaskToUsers(tasks_.getType(), tasks_, users, iDao);

        return tasks_;
    }

    @Override
    public WsResponse delete(Long taskId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        checkNullLongId(taskId, ExceptionStatus.TASK_ID_MISSING);

        Tasks task = iDao.find(Tasks.class, taskId);
        checkNullObject(taskId, ExceptionStatus.TASK_NOT_FOUND);

        try {
            iDao.delete(task);
        } catch (Exception e) {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }

        task = iDao.find(Tasks.class, taskId);

        if (task.getDeleted()) {
            return new WsResponse();
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }
    }
}