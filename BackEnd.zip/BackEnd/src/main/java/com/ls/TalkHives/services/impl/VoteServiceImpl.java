package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.common.VoteCommentEntity;
import com.ls.TalkHives.dto.common.VoteEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.voteController.*;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.VoteService;
import com.ls.TalkHives.services.impl.handler.VoteServiceImplHandler;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class VoteServiceImpl extends VoteServiceImplHandler implements VoteService {

    private static final String TAG = VoteServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreateVoteRequest createVoteRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullObject(createVoteRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);

        Votes votes = new Votes();
        votes.setMessage(createVoteRequest.getMessage());
        votes.setLikes(0);
        votes.setComments(0);
        votes.setUsers(users);
        votes.setOrganizations(users.getOrganizations());
        votes.setCreatedAt(getCurrentTime());

        Votes votes_ = iDao.find(Votes.class, iDao.persist(votes));
        checkNullObject(votes_, ExceptionStatus.NEW_NOT_ADDED);

        return sendVote(Activity.CREATE_VOTE.getActivity(), votes_, users, iDao);
    }

    @Override
    public Map<String, List<VoteEntity>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<VoteEntity>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Votes> list = iDao.getEntities(Votes.class, queryManager.getAllVote(), hashtable, false);
        hashtable.clear();

        List<VoteEntity> _list = new ArrayList<>();

        for (Votes votes : list) {
            VoteEntity voteEntity = new VoteEntity();
            voteEntity.setVoteId(votes.getVoteId());
            voteEntity.setMessage(votes.getMessage());
            voteEntity.setLikes(votes.getLikes());
            voteEntity.setComments(votes.getComments());
            voteEntity.setCreatedAt(votes.getCreatedAt());
            voteEntity.setUsers(modelMapper.map(votes.getUsers(), UserInfo.class));

            hashtable.put("users", users);
            hashtable.put("votes", votes);
            VoteLikes voteLikes_ = iDao.getEntity(VoteLikes.class, queryManager.getVoteLike(), hashtable, false);
            hashtable.clear();

            if (voteLikes_ != null) {
                voteEntity.setLiked(voteLikes_.getLiked());
            }

            if (users.getUserId().equals(votes.getUsers().getUserId())) {
                voteEntity.setSelf(Boolean.TRUE);
            } else {
                voteEntity.setSelf(Boolean.FALSE);
            }

            _list.add(voteEntity);
        }

        _list.sort(Comparator.comparing(VoteEntity::getCreatedAt));

        map.put("votes", _list);

        return map;
    }

    @Override
    public CreateVoteLikeResponse createLike(CreateVoteLikeRequest createVoteLikeRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);

        checkNullObject(createVoteLikeRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(createVoteLikeRequest.getVoteId(), ExceptionStatus.VOTE_ID_MISSING);

        Votes votes = iDao.find(Votes.class, createVoteLikeRequest.getVoteId());

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("users", users);
        hashtable.put("votes", votes);
        VoteLikes voteLikes_ = iDao.getEntity(VoteLikes.class, queryManager.getVoteLike(), hashtable);
        hashtable.clear();

        if (voteLikes_ != null) {
            if (createVoteLikeRequest.getLiked() == null) {
                voteLikes_.setDeleted(Boolean.TRUE);
                voteLikes_.setDeletedAt(util.getCurrentTime());

                if (voteLikes_.getLiked()) {
                    votes.setLikes(votes.getLikes() - 1);
                } else {
                    votes.setLikes(votes.getLikes() + 1);
                }
            } else {
                voteLikes_.setDeleted(Boolean.FALSE);
                voteLikes_.setDeletedAt(null);
                voteLikes_.setLiked(createVoteLikeRequest.getLiked());
                voteLikes_.setUpdatedAt(util.getCurrentTime());

                if (voteLikes_.getLiked()) {
                    votes.setLikes(votes.getLikes() + 1);
                } else {
                    votes.setLikes(votes.getLikes() - 1);
                }
            }
        } else {
            VoteLikes voteLikes = new VoteLikes();
            voteLikes.setLiked(createVoteLikeRequest.getLiked());
            voteLikes.setUsers(users);
            voteLikes.setVotes(iDao.find(Votes.class, createVoteLikeRequest.getVoteId()));
            voteLikes.setCreatedAt(getCurrentTime());
            VoteLikes _voteLikes = iDao.find(VoteLikes.class, iDao.persist(voteLikes));
            checkNullObject(_voteLikes, ExceptionStatus.NEW_NOT_ADDED);

            if (_voteLikes.getLiked()) {
                votes.setLikes(votes.getLikes() + 1);
            } else {
                votes.setLikes(votes.getLikes() - 1);
            }
        }

        CreateVoteLikeResponse createVoteLikeResponse = new CreateVoteLikeResponse();
        createVoteLikeResponse.setVoteId(createVoteLikeRequest.getVoteId());
        createVoteLikeResponse.setLiked(createVoteLikeRequest.getLiked());
        createVoteLikeResponse.setLikes(votes.getLikes());

        notificationService.voteNotification("LIKE_VOTE", votes, users, iDao);

        return createVoteLikeResponse;
    }

    @Override
    public VoteCommentEntity createComment(CreateVoteCommentRequest createVoteCommentRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(stompHeaderAccessor, iDao);

        checkNullObject(createVoteCommentRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(createVoteCommentRequest.getVoteId(), ExceptionStatus.VOTE_ID_MISSING);

        Votes votes = iDao.find(Votes.class, createVoteCommentRequest.getVoteId());

        VoteComments voteComments = new VoteComments();
        voteComments.setMessage(createVoteCommentRequest.getMessage());
        voteComments.setVotes(votes);
        voteComments.setUsers(users);
        voteComments.setCreatedAt(getCurrentTime());

        VoteComments voteComments_ = iDao.find(VoteComments.class, iDao.persist(voteComments));
        checkNullObject(voteComments_, ExceptionStatus.NEW_NOT_ADDED);

        votes.setComments(votes.getComments() + 1);

        VoteCommentEntity voteCommentEntity = modelMapper.map(voteComments_, VoteCommentEntity.class);
        voteCommentEntity.setVoteId(votes.getVoteId());
        voteCommentEntity.setComments(votes.getComments());

        notificationService.voteNotification("COMMENT_VOTE", votes, users, iDao);

        return voteCommentEntity;
    }

    @Override
    public Map<String, List<VoteComments>> fetchAllComments(Long voteId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(voteId, ExceptionStatus.VOTE_ID_MISSING);

        Map<String, List<VoteComments>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("votes", iDao.find(Votes.class, voteId));
        List<VoteComments> list = iDao.getEntities(VoteComments.class, queryManager.getAllVoteComments(), hashtable, false);
        hashtable.clear();

        map.put("voteComments", list);

        return map;
    }

    @Override
    public WsResponse update(UpdateVoteRequest updateVoteRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateVoteRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateVoteRequest.getVoteId(), ExceptionStatus.VOTE_ID_MISSING);

        Users users = findUserByLoginToken(requestHeader, iDao);
        Votes votes = iDao.find(Votes.class, updateVoteRequest.getVoteId());

        checkNullObject(votes, ExceptionStatus.VOTE_NOT_FOUND);

        if (!Objects.equals(votes.getUsers(), users)) {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        votes.setMessage(updateVoteRequest.getMessage());

        votes = iDao.update(votes);

        return sendVote(Activity.UPDATE_VOTE.getActivity(), votes, users, iDao);
    }

    @Override
    public WsResponse delete(Long voteId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(voteId, ExceptionStatus.VOTE_ID_MISSING);

        Votes votes = iDao.find(Votes.class, voteId);
        checkNullObject(voteId, ExceptionStatus.VOTE_NOT_FOUND);

        if (Integer.parseInt(users.getUserRole().getRoleTag()) < 3 || votes.getUsers().equals(users)) {
            iDao.delete(votes);
        } else {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }

        votes = iDao.find(Votes.class, voteId);

        if (votes.getDeleted()) {
            return sendVote(Activity.DELETE_VOTE.getActivity(), votes, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.VOTE_NOT_DELETED);
        }
    }
}