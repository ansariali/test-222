package com.ls.TalkHives.dto.common;

public class TeamMembersEntity {
    private Long teamMemberId;
    private Boolean teamLeader;
    private Boolean deleted;
    private UserInfo users;

    public Long getTeamMemberId() {
        return teamMemberId;
    }

    public void setTeamMemberId(Long teamMemberId) {
        this.teamMemberId = teamMemberId;
    }

    public Boolean getTeamLeader() {
        return teamLeader;
    }

    public void setTeamLeader(Boolean teamLeader) {
        this.teamLeader = teamLeader;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }
}
