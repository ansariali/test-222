package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Blogs;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class BlogServiceImplHandler extends UniversalService {

    private void activityAction(String activityTag, Blogs blogs, Users users) {
        if (activityTag.equals(Activity.CREATE_BLOG.getActivity())) {
            blogs.setBlogTag(getBlogTag(users));
        }

        if (activityTag.equals(Activity.DELETE_BLOG.getActivity())) {
            users.setDeletedBlog(users.getDeletedBlog() + 1);
            users.getOrganizations().setDeletedBlog(users.getOrganizations().getDeletedBlog() + 1);
        }
    }

    protected WsResponse sendBlog(String activityTag, Blogs blogs, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, blogs, users);

        BlogEntity blogEntity = modelMapper.map(blogs, BlogEntity.class);

        // Send Blog
        WsResponse wsResponse = sendActivity(Ascii.ORGANIZATION.getCode(), users.getOrganizations().getOrganizationId().toString(), blogs.getBlogId(), Ascii.BLOG.getCode(), activityTag, blogEntity);

        // Send Notification
        if (activityTag.equals(Activity.CREATE_BLOG.getActivity())) {
            String message = Notification.valueOf(activityTag).getPublicMessage()
                    .replace("{user}", users.getFirstName() + " " + users.getLastName());
            notificationService.sentToOrganization(blogs.getBlogId(), Ascii.BLOG.getCode(), Boolean.FALSE, message, users, iDao);
        }

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.BLOG, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }
}