package com.ls.TalkHives.utils.enums;

public enum EmailTemplate {

    SAMPLE("Sample Email", "templates/email/sample.vm"),
    WELCOME("Welcome to TalkHives.", "templates/email/welcome.vm"),
    INVITATION("You have been invited by {companyName} click to login", "templates/email/invitation.vm");

    private final String emailSubject;
    private final String emailTemplate;

    EmailTemplate(String emailSubject, String emailTemplate) {
        this.emailSubject = emailSubject;
        this.emailTemplate = emailTemplate;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public String getTemplateUrl() {
        return emailTemplate;
    }
    }