package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.blogController.CreateBlogRequest;
import com.ls.TalkHives.dto.blogController.FetchAllBlogs;
import com.ls.TalkHives.dto.blogController.UpdateBlogRequest;
import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.UserActivityEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.services.BlogService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/wsController")
@Controller
public class WsController extends UniversalController {

    private static final String TAG = WsController.class.getSimpleName();

    @ApiOperation(value = "W1 SendToUser Response")
    @SendTo("/topic/1/sendToUser/{userId}")
    public WsResponse sendToUser(@DestinationVariable Long userId, @Payload WsResponse wsResponse) {
        logger.info(TAG, "Inside W1");

        return wsResponse;
    }

    @ApiOperation(value = "W2 SendToOrganization Response")
    @SendTo("/topic/1/sendToOrganization/{organizationId}")
    public WsResponse sendToOrganization(@DestinationVariable Long organizationId, @Payload WsResponse wsResponse) {
        logger.info(TAG, "Inside W2");

        return wsResponse;
    }

    @ApiOperation(value = "W3 SendToDesignation Response")
    @SendTo("/topic/1/sendToDesignation/{userRoleTag}")
    public WsResponse sendToDesignation(@DestinationVariable Long userRoleTag, @Payload WsResponse wsResponse) {
        logger.info(TAG, "Inside W3");

        return wsResponse;
    }

    @ApiOperation(value = "W4 Send Self Activity")
    @SendTo("/topic/selfActivity/1/sendToUser/{userId}")
    public UserActivityEntity selfActivity(@DestinationVariable Long userId, @Payload UserActivityEntity userActivityEntity) {
        logger.info(TAG, "Inside W4");

        return userActivityEntity;
    }

}