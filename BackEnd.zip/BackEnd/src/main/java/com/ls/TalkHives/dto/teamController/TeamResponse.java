package com.ls.TalkHives.dto.teamController;

import com.ls.TalkHives.dto.common.TeamEntity;

public class TeamResponse {
    private String activity;

    private TeamEntity team;

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public TeamEntity getTeam() {
        return team;
    }

    public void setTeam(TeamEntity team) {
        this.team = team;
    }
}
