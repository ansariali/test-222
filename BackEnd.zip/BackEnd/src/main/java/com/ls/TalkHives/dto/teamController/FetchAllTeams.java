package com.ls.TalkHives.dto.teamController;

import com.ls.TalkHives.dto.common.TeamEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllTeams {

    private List<TeamEntity> teams = new ArrayList<>();

    public List<TeamEntity> getTeams() {
        return teams;
    }

    public void setTeams(List<TeamEntity> teams) {
        this.teams = teams;
    }
}
