package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.blogController.CreateBlogRequest;
import com.ls.TalkHives.dto.blogController.UpdateBlogRequest;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Blogs;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface BlogService {
    WsResponse create(CreateBlogRequest createBlogRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Blogs>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdateBlogRequest updateBlogRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long blogId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}