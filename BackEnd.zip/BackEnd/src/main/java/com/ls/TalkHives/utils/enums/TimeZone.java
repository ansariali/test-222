package com.ls.TalkHives.utils.enums;

public enum TimeZone {

	DEFAULT("UTC"), INDIAN("GMT+05:30"), IST("IST"), GMT("GMT") ,UTC("UTC"), ADST("ADST"),AST("AST"),  CEST("UTC"), AT("AT"),CET("CET"), OTHER("Other") ;

	private final String timeZone;

	TimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getTimeZone() {
		return timeZone;
	}
}