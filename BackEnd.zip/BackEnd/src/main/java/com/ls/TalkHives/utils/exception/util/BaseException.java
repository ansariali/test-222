package com.ls.TalkHives.utils.exception.util;

import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;

public abstract class BaseException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	private ExceptionStatus exceptionStatus = null;
	
	public BaseException(ExceptionStatus exceptionStatus) {
		super(exceptionStatus.getErrorMessage());
		this.exceptionStatus = exceptionStatus;
	}

	public ServiceError getServiceError() {
		return new ServiceError(exceptionStatus);
	}

	public ExceptionStatus getExceptionStatus() {
		return exceptionStatus;
	}
}