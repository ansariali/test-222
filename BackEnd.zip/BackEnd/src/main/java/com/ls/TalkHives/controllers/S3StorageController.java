package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.FileEntity;
import com.ls.TalkHives.dto.common.ImageEntity;
import com.ls.TalkHives.dto.userController.CreateInvitationRequest;
import com.ls.TalkHives.dto.userController.CreateInvitedUserRequest;
import com.ls.TalkHives.dto.userController.LoginResponse;
import com.ls.TalkHives.entities.Images;
import com.ls.TalkHives.services.S3StorageService;
import com.ls.TalkHives.services.UserService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/s3StorageController")
public class S3StorageController extends UniversalController {

    private static final String TAG = S3StorageController.class.getSimpleName();

    @Autowired
    private S3StorageService s3StorageService;

    @ApiOperation(value = "S31 Create Folder")
    @RequestMapping(value = "/drive", method = RequestMethod.POST)
    public ResponseEntity<UniversalResponse> createTest(@RequestParam("file") MultipartFile[] files) throws IOException {
        logger.info(TAG, "Inside createTest");
        FileEntity fileEntity = new FileEntity();
        Long fileSize = 0L;

        for (int i = 0; i < files.length; i++) {
            String prefix = S3Storage.FOLDER_PUBLIC.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_TRASH.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();
            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.TRASH.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, files[i]));
            fileEntity.setName(files[i].getOriginalFilename());
            fileEntity.setType(files[i].getContentType());
            System.out.println("Bytes :"+ i +"-" + files[i].getBytes());
            fileSize +=  files[i].getSize();
            System.out.println("FileSize i :"+ i +"-" + fileSize);
        }

        System.out.println("FileSize :"+ fileSize);

        return new ResponseEntity<>(new UniversalResponse(true, "Folder created"), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "S31 Create Folder")
    @PostMapping(value = "/1/create/folder")
    public ResponseEntity<UniversalResponse> createFolder(@RequestParam String folderName) {
        logger.info(TAG, "Inside S31");

        s3StorageService.createFolder(folderName);

        return new ResponseEntity<>(new UniversalResponse(true, "Folder created"), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "S32 Upload File")
    @PostMapping(value = "/1/upload/file/{of}")
    public ResponseEntity<FileEntity> uploadFile(@RequestPart(value = "file") MultipartFile multipartFile, @PathVariable String of) throws IOException {
        logger.info(TAG, "Inside uploadFile");

        FileEntity fileEntity = new FileEntity();
        if (of.equals(Ascii.PROFILE.getCode())) {
            String prefix = S3Storage.FOLDER_TEMP.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_USERS.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();

            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            fileEntity.setName(multipartFile.getOriginalFilename());

            fileEntity.setType(multipartFile.getContentType());

        } else if (of.equals(Ascii.POST.getCode())) {
            String prefix = S3Storage.FOLDER_TEMP.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_POST.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();

            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.POST.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            fileEntity.setName(multipartFile.getOriginalFilename());
            fileEntity.setType(multipartFile.getContentType());
        } else if (of.equals(Ascii.BLOG.getCode())) {
            String prefix = S3Storage.FOLDER_TEMP.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_BLOG.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();

            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.BLOG.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            fileEntity.setName(multipartFile.getOriginalFilename());
            fileEntity.setType(multipartFile.getContentType());
        } else {
            String prefix = S3Storage.FOLDER_PUBLIC.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_TRASH.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();

            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.TRASH.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, multipartFile));
            fileEntity.setName(multipartFile.getOriginalFilename());
            fileEntity.setType(multipartFile.getContentType());
        }

        return new ResponseEntity<>(fileEntity, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "S33 Copied File")
    @PostMapping(value = "/1/copy/file")
    public ResponseEntity<UniversalResponse> copyFile(@RequestParam String prefix, @RequestParam String fileUrl) throws IOException {
        logger.info(TAG, "Inside S33");

        s3StorageService.copyFile(prefix, fileUrl);

        return new ResponseEntity<>(new UniversalResponse(true, "Copied"), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "S34 Delete File")
    @PostMapping(value = "/1/delete/file")
    public ResponseEntity<UniversalResponse> deleteFile(@RequestParam String fileUrl) throws IOException {
        logger.info(TAG, "Inside S34");

        s3StorageService.deleteFile(fileUrl);
        // s3StorageService.deleteFolder(fileUrl);

        return new ResponseEntity<>(new UniversalResponse(true, "Deleted"), responseHeaders, HttpStatus.OK);
    }

}