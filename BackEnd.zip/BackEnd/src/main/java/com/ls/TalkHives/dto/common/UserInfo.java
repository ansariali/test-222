package com.ls.TalkHives.dto.common;

public class UserInfo {
    private Long userId;
    private String firstName;
    private String lastName;
    private String emailId;
    private String designation;
    private ImageEntity images;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public ImageEntity getImages() {
        return images;
    }

    public void setImages(ImageEntity images) {
        this.images = images;
    }
}