package com.ls.TalkHives.dto.postController;

import com.ls.TalkHives.dto.common.PostCommentEntity;
import com.ls.TalkHives.dto.common.VoteCommentEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllPostComments {

    private List<PostCommentEntity> postComments = new ArrayList<>();

    public List<PostCommentEntity> getPostComments() {
        return postComments;
    }

    public void setPostComments(List<PostCommentEntity> postComments) {
        this.postComments = postComments;
    }
}
