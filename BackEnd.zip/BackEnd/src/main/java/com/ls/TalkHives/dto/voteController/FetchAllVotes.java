package com.ls.TalkHives.dto.voteController;

import com.ls.TalkHives.dto.common.ProjectEntity;
import com.ls.TalkHives.dto.common.VoteEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllVotes {

    private List<VoteEntity> votes = new ArrayList<>();

    public List<VoteEntity> getVotes() {
        return votes;
    }

    public void setVotes(List<VoteEntity> votes) {
        this.votes = votes;
    }
}
