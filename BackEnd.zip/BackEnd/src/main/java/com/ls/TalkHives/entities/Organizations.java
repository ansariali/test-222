package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

/**
 * Organizations Entity
 */
@Entity
@Table(name = "organizations")
public class Organizations extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long organizationId;

    @NotNull
    @Size(min = 3)
    private String name;
    private String info;
    private String hashTag;
    private String timezone;
    private Integer totalEmployee = 0;
    private String type;
    private String specificType;

    @ColumnDefault("0")
    private Integer totalPin = 0;

    @ColumnDefault("0")
    private Integer deletedPin = 0;

    private String blogTagPrefix;

    @ColumnDefault("0")
    private Integer totalBlog = 0;

    @ColumnDefault("0")
    private Integer deletedBlog = 0;

    private String clientTagPrefix;

    @ColumnDefault("0")
    private Integer totalClient = 0;

    @ColumnDefault("0")
    private Integer deletedClient = 0;

    private String voteTagPrefix;

    @ColumnDefault("0")
    private Integer totalVote = 0;

    @ColumnDefault("0")
    private Integer deletedVote = 0;

    private String postTagPrefix;

    @ColumnDefault("0")
    private Integer totalPost = 0;
    @ColumnDefault("0")
    private Integer deletedPost = 0;


    private String teamTagPrefix;

    @ColumnDefault("0")
    private Integer totalTeam = 0;

    @ColumnDefault("0")
    private Integer deletedTeam = 0;

    private String projectTagPrefix;

    @ColumnDefault("0")
    private Integer totalProject = 0;

    @ColumnDefault("0")
    private Integer deletedProject = 0;

    private String meetingTagPrefix;

    @ColumnDefault("0")
    private Integer totalMeeting = 0;

    @ColumnDefault("0")
    private Integer deletedMeeting = 0;

    @ColumnDefault("0")
    private Integer ongoingMeeting = 0;

    @ColumnDefault("0")
    private Integer totalTask = 0;

    @ColumnDefault("0")
    private Integer deletedTask = 0;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private Users user;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "organizations")
    private Set<Users> users = new HashSet<>();

    public Long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getHashTag() {
        return hashTag;
    }

    public void setHashTag(String hashTag) {
        this.hashTag = hashTag;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public Integer getTotalEmployee() {
        return totalEmployee;
    }

    public void setTotalEmployee(Integer totalEmployee) {
        this.totalEmployee = totalEmployee;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSpecificType() {
        return specificType;
    }

    public void setSpecificType(String specificType) {
        this.specificType = specificType;
    }

    public Integer getTotalPin() {
        return totalPin;
    }

    public void setTotalPin(Integer totalPin) {
        this.totalPin = totalPin;
    }

    public Integer getDeletedPin() {
        return deletedPin;
    }

    public void setDeletedPin(Integer deletedPin) {
        this.deletedPin = deletedPin;
    }

    public String getBlogTagPrefix() {
        return blogTagPrefix;
    }

    public void setBlogTagPrefix(String blogTagPrefix) {
        this.blogTagPrefix = blogTagPrefix;
    }

    public Integer getTotalBlog() {
        return totalBlog;
    }

    public void setTotalBlog(Integer totalBlog) {
        this.totalBlog = totalBlog;
    }

    public Integer getDeletedBlog() {
        return deletedBlog;
    }

    public void setDeletedBlog(Integer deletedBlog) {
        this.deletedBlog = deletedBlog;
    }

    public String getClientTagPrefix() {
        return clientTagPrefix;
    }

    public void setClientTagPrefix(String clientTagPrefix) {
        this.clientTagPrefix = clientTagPrefix;
    }

    public Integer getTotalClient() {
        return totalClient;
    }

    public void setTotalClient(Integer totalClient) {
        this.totalClient = totalClient;
    }

    public Integer getDeletedClient() {
        return deletedClient;
    }

    public void setDeletedClient(Integer deletedClient) {
        this.deletedClient = deletedClient;
    }

    public String getVoteTagPrefix() {
        return voteTagPrefix;
    }

    public void setVoteTagPrefix(String voteTagPrefix) {
        this.voteTagPrefix = voteTagPrefix;
    }

    public Integer getTotalVote() {
        return totalVote;
    }

    public void setTotalVote(Integer totalVote) {
        this.totalVote = totalVote;
    }

    public Integer getDeletedVote() {
        return deletedVote;
    }

    public void setDeletedVote(Integer deletedVote) {
        this.deletedVote = deletedVote;
    }

    public String getPostTagPrefix() {
        return postTagPrefix;
    }

    public void setPostTagPrefix(String postTagPrefix) {
        this.postTagPrefix = postTagPrefix;
    }

    public Integer getTotalPost() {
        return totalPost;
    }

    public void setTotalPost(Integer totalPost) {
        this.totalPost = totalPost;
    }

    public Integer getDeletedPost() {
        return deletedPost;
    }

    public void setDeletedPost(Integer deletedPost) {
        this.deletedPost = deletedPost;
    }

    public String getTeamTagPrefix() {
        return teamTagPrefix;
    }

    public void setTeamTagPrefix(String teamTagPrefix) {
        this.teamTagPrefix = teamTagPrefix;
    }

    public Integer getTotalTeam() {
        return totalTeam;
    }

    public void setTotalTeam(Integer totalTeam) {
        this.totalTeam = totalTeam;
    }

    public Integer getDeletedTeam() {
        return deletedTeam;
    }

    public void setDeletedTeam(Integer deletedTeam) {
        this.deletedTeam = deletedTeam;
    }

    public String getProjectTagPrefix() {
        return projectTagPrefix;
    }

    public void setProjectTagPrefix(String projectTagPrefix) {
        this.projectTagPrefix = projectTagPrefix;
    }

    public Integer getTotalProject() {
        return totalProject;
    }

    public void setTotalProject(Integer totalProject) {
        this.totalProject = totalProject;
    }

    public Integer getDeletedProject() {
        return deletedProject;
    }

    public void setDeletedProject(Integer deletedProject) {
        this.deletedProject = deletedProject;
    }

    public String getMeetingTagPrefix() {
        return meetingTagPrefix;
    }

    public void setMeetingTagPrefix(String meetingTagPrefix) {
        this.meetingTagPrefix = meetingTagPrefix;
    }

    public Integer getTotalMeeting() {
        return totalMeeting;
    }

    public void setTotalMeeting(Integer totalMeeting) {
        this.totalMeeting = totalMeeting;
    }

    public Integer getDeletedMeeting() {
        return deletedMeeting;
    }

    public void setDeletedMeeting(Integer deletedMeeting) {
        this.deletedMeeting = deletedMeeting;
    }

    public Integer getOngoingMeeting() {
        return ongoingMeeting;
    }

    public void setOngoingMeeting(Integer ongoingMeeting) {
        this.ongoingMeeting = ongoingMeeting;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Set<Users> getUsers() {
        return users;
    }

    public void setUsers(Set<Users> users) {
        this.users = users;
    }

    public Integer getTotalTask() {
        return totalTask;
    }

    public void setTotalTask(Integer totalTask) {
        this.totalTask = totalTask;
    }

    public Integer getDeletedTask() {
        return deletedTask;
    }

    public void setDeletedTask(Integer deletedTask) {
        this.deletedTask = deletedTask;
    }
}
