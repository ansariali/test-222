package com.ls.TalkHives.dto.common;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class TeamEntity {
    private Long teamId;
    private String name;
    private String title;
    private String info;
    private Integer totalMember;
    private Integer totalProjects;
    private Integer liveProjects;
    private Integer successProjects;
    private Integer ranking;
    private BigDecimal budget;
    private Date createdAt;

    private UserInfo users;
    private UserInfo teamLeader;
    private List<TeamMembersEntity> members;

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Integer getTotalProjects() {
        return totalProjects;
    }

    public void setTotalProjects(Integer totalProjects) {
        this.totalProjects = totalProjects;
    }

    public Integer getLiveProjects() {
        return liveProjects;
    }

    public void setLiveProjects(Integer liveProjects) {
        this.liveProjects = liveProjects;
    }

    public Integer getSuccessProjects() {
        return successProjects;
    }

    public void setSuccessProjects(Integer successProjects) {
        this.successProjects = successProjects;
    }

    public Integer getRanking() {
        return ranking;
    }

    public void setRanking(Integer ranking) {
        this.ranking = ranking;
    }

    public BigDecimal getBudget() {
        return budget;
    }

    public void setBudget(BigDecimal budget) {
        this.budget = budget;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }

    public UserInfo getTeamLeader() {
        return teamLeader;
    }

    public void setTeamLeader(UserInfo teamLeader) {
        this.teamLeader = teamLeader;
    }

    public List<TeamMembersEntity> getMembers() {
        return members;
    }

    public void setMembers(List<TeamMembersEntity> members) {
        this.members = members;
    }
}
