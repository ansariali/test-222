package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.teamController.CreateTeamRequest;
import com.ls.TalkHives.dto.teamController.UpdateTeamRequest;
import com.ls.TalkHives.entities.TeamMembers;
import com.ls.TalkHives.entities.Teams;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.TeamService;
import com.ls.TalkHives.services.impl.handler.TeamServiceImplHandler;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class TeamServiceImpl extends TeamServiceImplHandler implements TeamService {

    private static final String TAG = TeamServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreateTeamRequest createTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        Teams teams = new Teams();
        teams.setName(createTeamRequest.getName());
        teams.setTitle(createTeamRequest.getTitle());
        teams.setInfo(createTeamRequest.getInfo());
        teams.setBudget(createTeamRequest.getBudget());
        teams.setTeamLeader(iDao.find(Users.class, createTeamRequest.getTeamLeader().getUserId()));
        teams.setUsers(users);
        teams.setOrganizations(users.getOrganizations());
        teams.setCreatedAt(getCurrentTime());

        Teams teams_ = iDao.find(Teams.class, iDao.persist(teams));
        checkNullObject(teams_, ExceptionStatus.NEW_NOT_ADDED);

        HashSet<TeamMembers> list = new HashSet<>();

        for (UserInfo userInfo : createTeamRequest.getMembers()) {
            TeamMembers teamMembers = new TeamMembers();
            teamMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
            teamMembers.setTeams(teams_);
            teamMembers.setCreatedAt(getCurrentTime());
            // TeamMembers teamMembers_ = iDao.find(TeamMembers.class, iDao.persist(teamMembers));
            // checkNullObject(teamMembers_, ExceptionStatus.TEAM_MEMBER_NOT_ADDED);

            list.add(teamMembers);
        }

        // TODO: GET Size from for loop / from table using Query
        teams_.setMembers(list);
        teams_.setTotalMember(list.size());

        return sendTeam(Activity.CREATE_TEAM.getActivity(), teams_, users, iDao);
    }

    @Override
    public Map<String, List<Teams>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Teams>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Teams> list = iDao.getEntities(Teams.class, queryManager.getAllTeams(), hashtable, false);
        hashtable.clear();

        if (!hasAccess(2, users)) {
            List<Teams> _list = new ArrayList<>();
            for (Teams teams : list) {

                hashtable.put("teams", teams);
                hashtable.put("users", users);
                TeamMembers teamMembers = iDao.getEntity(TeamMembers.class, queryManager.getTeamMember(), hashtable, false);
                hashtable.clear();

                if (teamMembers == null) {
                    _list.add(teams);
                }
            }
            list.removeAll(_list);
        }

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("teams", list);

        return map;
    }

    @Override
    public WsResponse update(UpdateTeamRequest updateTeamRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateTeamRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateTeamRequest.getTeamId(), ExceptionStatus.TEAM_ID_MISSING);

        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        Teams teams = iDao.find(Teams.class, updateTeamRequest.getTeamId());

        checkNullObject(teams, ExceptionStatus.TEAM_NOT_FOUND);

        teams.setName(updateTeamRequest.getName());
        teams.setTitle(updateTeamRequest.getTitle());
        teams.setInfo(updateTeamRequest.getInfo());
        teams.setBudget(updateTeamRequest.getBudget());

        Boolean notifyTeamLeader = false;
        if (teams.getTeamLeader() == null) {
            teams.setTeamLeader(iDao.find(Users.class, updateTeamRequest.getTeamLeader().getUserId()));
            notifyTeamLeader = true;
        } else if (!checkEqualLongId(teams.getTeamLeader().getUserId(), updateTeamRequest.getTeamLeader().getUserId())) {
            teams.setTeamLeader(iDao.find(Users.class, updateTeamRequest.getTeamLeader().getUserId()));
            notifyTeamLeader = true;
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("teams", teams);
        List<TeamMembers> list = iDao.getEntities(TeamMembers.class, queryManager.getAllTeamMember(), hashtable, false);
        hashtable.clear();

        HashSet<TeamMembers> _list = new HashSet<>();
        HashSet<TeamMembers> wsList = new HashSet<>();

        for (UserInfo userInfo : updateTeamRequest.getMembers()) {
            hashtable.put("teams", teams);
            hashtable.put("users", iDao.find(Users.class, userInfo.getUserId()));
            TeamMembers teamMembers = iDao.getEntity(TeamMembers.class, queryManager.getTeamMember(), hashtable);
            hashtable.clear();

            if (teamMembers == null) {
                TeamMembers _teamMembers = new TeamMembers();
                _teamMembers.setCreatedAt(getCurrentTime());
                _teamMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
                _teamMembers.setTeams(teams);
                TeamMembers teamMembers_ = iDao.find(TeamMembers.class, iDao.persist(_teamMembers));
                checkNullObject(teamMembers_, ExceptionStatus.TEAM_MEMBER_NOT_ADDED);

                _list.add(teamMembers_);
                wsList.add(teamMembers_);
            } else {
                if (teamMembers.getDeleted()) {
                    teamMembers.setDeleted(Boolean.FALSE);
                    teamMembers.setDeletedAt(null);
                    teamMembers.setUpdatedAt(getCurrentTime());
                    // teamMembers.setUpdatedBy(users);
                }
                _list.add(teamMembers);
            }
        }

        list.removeAll(_list);

        hashtable.put("teams", teams);
        List<TeamMembers> list_ = iDao.getEntities(TeamMembers.class, queryManager.getAllTeamMember(), hashtable, false);
        hashtable.clear();

        teams.setMembers(_list);
        teams.setTotalMember(list_.size());

        teams = iDao.update(teams);

        return sendTeam(notifyTeamLeader, list, wsList, teams, users, iDao);
    }

    @Override
    public WsResponse delete(Long teamId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        checkNullLongId(teamId, ExceptionStatus.TEAM_ID_MISSING);

        Teams teams = iDao.find(Teams.class, teamId);
        checkNullObject(teams, ExceptionStatus.TEAM_NOT_FOUND);

        iDao.delete(teams);

        teams = iDao.find(Teams.class, teamId);

        if (teams.getDeleted()) {
            return sendTeam(Activity.DELETE_TEAM.getActivity(), teams, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }
    }
}