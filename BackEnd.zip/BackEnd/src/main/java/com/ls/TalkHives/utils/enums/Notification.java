package com.ls.TalkHives.utils.enums;

public enum Notification {

    // Post
    CREATE_POST("CREATE_POST", "", "{user} added a new post", ""),
    SHARE_POST("SHARE_POST", "{creator} has shared your post", "{creator} has shared {user}'s post", ""),
    LIKE_POST("LIKE_POST", "{creator} {verb} liked your post", "{creator} has liked {user}'s post", "{user} has liked own post"),
    COMMENT_POST("COMMENT_POST", "{creator} {verb} commented on your post", "{creator} has commented on {user}'s post", "{user} has commented on own post"),

    // Blog
    CREATE_BLOG("CREATE_BLOG", "", "{user} added a new blog", ""),

    // Blog
    CREATE_CLIENT("CREATE_CLIENT", "", "{user} added a new blog", ""),

    // Vote
    CREATE_VOTE("CREATE_VOTE", "", "{user} added a new vote", ""),
    LIKE_VOTE("LIKE_VOTE", "{creator} {verb} voted your vote", "{creator} has voted {user}'s vote", "{user} has voted own vote"),
    COMMENT_VOTE("COMMENT_VOTE", "{creator} {verb} commented on your vote", "{creator} has commented on {user}'s vote", "{user} has commented on own vote"),

    // Team
    CREATE_TEAM("CREATE_TEAM", "{user} added yourself in team called {team}", "{user} added you in team called {team}", "{user} added a new team called {team}"),
    UPDATE_TEAM("UPDATE_TEAM", "{user} added yourself in team called {team}", "{user} added you in team called {team}", "{user} updated team called {team}"),
    DELETE_TEAM("DELETE_TEAM", "{user} deleted a team called {team}", "", "{user} deleted a team called {team}"),
    TEAM_LEADER("TEAM_LEADER", "{user} added yourself in team called {team} as Team leader", "{user} added you in team called {team} as Team leader", ""),

    // Meeting
    CREATE_MEETING("CREATE_MEETING", "{user} added yourself in meeting called {meeting}", "{user} added you in meeting called {meeting}", "{user} added a new meeting called {meeting}"),
    UPDATE_MEETING("UPDATE_MEETING", "{user} added yourself in meeting called {meeting}", "{user} added you in meeting called {meeting}", "{user} updated meeting called {meeting}"),
    DELETE_MEETING("DELETE_MEETING", "{user} deleted a meeting called {meeting}", "", "{user} deleted a meeting called {meeting}"),
    MEETING_CREATOR("TEAM_LEADER", "{user} added yourself in team called {team} as Team leader", "{user} added you in team called {team} as Team leader", ""),
    MEETING_EVENT("MEETING_EVENT", "Your meeting called {meeting} is just about to start! Good luck!", "{user} added you in team called {team} as Team leader", ""),

    // Task
    CREATE_GENERAL_TASK("createGeneralTask", "{user} assigned a new {priority} task to yourself", "{user} assigned a new {priority} task to you", ""),

    TEST("", "", "", ""),
    DEMO("", "", "", "");

    private final String activity;
    private final String selfMessage;
    private final String publicMessage;
    private final String customMessage;

    Notification(String activity, String selfMessage, String publicMessage, String customMessage) {
        this.activity = activity;
        this.selfMessage = selfMessage;
        this.publicMessage = publicMessage;
        this.customMessage = customMessage;
    }

    public String getActivity() {
        return activity;
    }

    public String getSelfMessage() {
        return selfMessage;
    }

    public String getPublicMessage() {
        return publicMessage;
    }

    public String getCustomMessage() {
        return customMessage;
    }

}