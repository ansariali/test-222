package com.ls.TalkHives.dto.common;

import java.util.Date;
import java.util.List;

public class ProjectEntity {

    private Long projectId;
    private String name;
    private String info;

    private Date initialDate;
    private Date deadline;
    private Integer totalMember;

    private Double completion;
    private Integer totalMilestone;
    private Double milestonePercentage;
    private Date createdAt;

    private StatusEntity status;
    private ClientEntity client;
    private UserInfo manager;
    private UserInfo users;
    private TeamInfoEntity teams;
    private List<ProjectMilestoneEntity> milestones;

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Double getCompletion() {
        return completion;
    }

    public void setCompletion(Double completion) {
        this.completion = completion;
    }

    public Integer getTotalMilestone() {
        return totalMilestone;
    }

    public void setTotalMilestone(Integer totalMilestone) {
        this.totalMilestone = totalMilestone;
    }

    public Double getMilestonePercentage() {
        return milestonePercentage;
    }

    public void setMilestonePercentage(Double milestonePercentage) {
        this.milestonePercentage = milestonePercentage;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public StatusEntity getStatus() {
        return status;
    }

    public void setStatus(StatusEntity status) {
        this.status = status;
    }

    public ClientEntity getClient() {
        return client;
    }

    public void setClient(ClientEntity client) {
        this.client = client;
    }

    public UserInfo getManager() {
        return manager;
    }

    public void setManager(UserInfo manager) {
        this.manager = manager;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }

    public TeamInfoEntity getTeams() {
        return teams;
    }

    public void setTeams(TeamInfoEntity teams) {
        this.teams = teams;
    }

    public List<ProjectMilestoneEntity> getMilestones() {
        return milestones;
    }

    public void setMilestones(List<ProjectMilestoneEntity> milestones) {
        this.milestones = milestones;
    }
}
