package com.ls.TalkHives.dto.chatController;

import com.ls.TalkHives.dto.common.ChatEntity;

import java.util.ArrayList;
import java.util.List;

public class ChatRoomMessages {
    private List<ChatEntity> chats = new ArrayList<>();

    public List<ChatEntity> getChats() {
        return chats;
    }

    public void setChats(List<ChatEntity> chats) {
        this.chats = chats;
    }
}
