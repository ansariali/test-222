package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.mileStoneController.CreateProjectMilestone;
import com.ls.TalkHives.dto.mileStoneController.MileStoneEntity;
import com.ls.TalkHives.dto.projectController.*;
import com.ls.TalkHives.dto.taskController.CreateTaskRequest;
import com.ls.TalkHives.entities.ProjectComments;
import com.ls.TalkHives.entities.ProjectMilestones;
import com.ls.TalkHives.entities.Projects;
import com.ls.TalkHives.entities.Tasks;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ProjectService {
    Projects create(CreateProjectRequest createProjectRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    UniversalResponse uploadFile(DocumentEntity uploadFileDetail, Map<String, Object> requestHeader, MultipartFile[] files, IDao<IEntity, Serializable> iDao);

    ProjectMilestones createMileStone(CreateProjectMilestone createProjectMilestoneRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    ProjectMilestones updateMileStone(Long mileStoneId, MileStoneEntity createMileStoneRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse deleteMilestone(Long mileStoneId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<ProjectMilestones>> fetchAllMileStone(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Projects>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    ProjectComments createComment(CreateProjectCommentRequest createProjectCommentRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    Map<String, List<ProjectComments>> fetchAllComments(Long projectId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Projects update(UpdateProjectRequest updateProjectRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    WsResponse updateProject(Long projectId, UpdateProjectRequest updateProjectRequest,  Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    UniversalResponse delete(Long projectId, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    WsResponse deleteProject(Long projectId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

}