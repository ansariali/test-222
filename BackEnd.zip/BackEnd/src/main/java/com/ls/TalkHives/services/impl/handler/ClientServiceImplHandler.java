package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.ClientEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Clients;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class ClientServiceImplHandler extends UniversalService {

    private void activityAction(String activityTag, Clients clients, Users users) {
        if (activityTag.equals(Activity.CREATE_CLIENT.getActivity())) {
            clients.setClientTag(getClientTag(users));
        }

        if (activityTag.equals(Activity.DELETE_CLIENT.getActivity())) {
            users.setDeletedClient(users.getDeletedClient() + 1);
            users.getOrganizations().setDeletedClient(users.getOrganizations().getDeletedClient() + 1);
        }
    }

    protected WsResponse sendClient(String activityTag, Clients clients, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, clients, users);

        ClientEntity clientEntity = modelMapper.map(clients, ClientEntity.class);

        // Send Client
        WsResponse wsResponse = sendActivity(Ascii.ORGANIZATION.getCode(), users.getOrganizations().getOrganizationId().toString(), clients.getClientId(), Ascii.CLIENT.getCode(), activityTag, clientEntity);

        // Send Notification
        if (activityTag.equals(Activity.CREATE_CLIENT.getActivity())) {
            String message = Notification.valueOf(activityTag).getPublicMessage()
                    .replace("{user}", setFullName(users));
            notificationService.sentToOrganization(clients.getClientId(), Ascii.CLIENT.getCode(), Boolean.FALSE, message, users, iDao);
        }

        // Send Activity
        setActivity(Boolean.TRUE, wsResponse.getActivityId(), Ascii.CLIENT, wsResponse.getActivityTag(), users, iDao);

        return wsResponse;
    }
}