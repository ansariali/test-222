package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.teamController.CreateTeamRequest;
import com.ls.TalkHives.dto.teamController.FetchAllTeams;
import com.ls.TalkHives.dto.teamController.UpdateTeamRequest;
import com.ls.TalkHives.services.TeamService;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/teamController")
@Controller
public class TeamController extends UniversalController {

    private static final String TAG = TeamController.class.getSimpleName();

    @Autowired
    private TeamService teamService;

    @ApiOperation(value = "T1 Create Team")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/team/1/create/{organizationId}")
    // @SendTo("/topic/team/1/create/{organizationId}")
    public ResponseEntity<WsResponse> createTeam(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody CreateTeamRequest createTeamRequest) {
        logger.info(TAG, "Inside T1 | /1/create");

        return new ResponseEntity<>(teamService.create(createTeamRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T2 FetchAll Team")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllTeams> fetchAllTeam(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "InsidefetchAllTeam");

        FetchAllTeams res = modelMapper.map(teamService.fetchAll(requestHeader, iDao), FetchAllTeams.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T3 Update Team")
    @PutMapping(value = "/1/update")
    // @MessageMapping("/team/1/update/{organizationId}")
    // @SendTo("/topic/team/1/update/{organizationId}")
    public ResponseEntity<WsResponse> updateBlog(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody UpdateTeamRequest updateTeamRequest) {
        logger.info(TAG, "Inside T3");

        return new ResponseEntity<>(teamService.update(updateTeamRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "T4 Delete Team")
    @DeleteMapping(value = "/1/delete/{teamId}")
    // @MessageMapping("/team/1/delete/{organizationId}/{teamId}")
    // @SendTo("/topic/team/1/delete/{organizationId}")
    public ResponseEntity<WsResponse> deleteTeam(@RequestHeader Map<String, Object> requestHeader,
                                                 @PathVariable String teamId) {
        logger.info(TAG, "Inside T4");

        return new ResponseEntity<>(teamService.delete(Long.parseLong(teamId), requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    // @ApiOperation(value = "T5 Send Team")
    // @SendTo("/topic/team/1/sendToUser/{userId}")
    // public TeamResponse send(@PathVariable Long userId, TeamResponse teamResponse) {
    //     logger.info(TAG, "Inside P4");
    //
    //     return teamResponse;
    // }

}