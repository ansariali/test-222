package com.ls.TalkHives.dto.common;

import com.ls.TalkHives.entities.Users;

import java.util.Date;

public class ChatEntity {
    private Long chatId;
    private String content;
    private String chatRoomTag;
    private _UserEntity sender;
    private Date createdAt;

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getChatRoomTag() {
        return chatRoomTag;
    }

    public void setChatRoomTag(String chatRoomTag) {
        this.chatRoomTag = chatRoomTag;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public _UserEntity getSender() {
        return sender;
    }

    public void setSender(_UserEntity sender) {
        this.sender = sender;
    }
}
