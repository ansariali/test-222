package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.chatController.CreateChatRequest;
import com.ls.TalkHives.dto.chatController.CreateGroupChatRequest;
import com.ls.TalkHives.dto.common.ChatEntity;
import com.ls.TalkHives.entities.ChatRooms;
import com.ls.TalkHives.entities.Chats;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ChatService {

    UniversalResponse createChatRoom(Long to, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    ChatRooms createGroupChat(CreateGroupChatRequest createGroupChatRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<ChatRooms>> getGroups(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Chats>> getMessages(String chatRoomTag, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Chats sendMessage(CreateChatRequest createChatRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    void test(ChatEntity chatEntity);

}