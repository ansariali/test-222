package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * ChatRooms Entity
 */

@Entity
@Table(name = "chat_rooms")
public class ChatRooms extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatRoomId;

    private String chatRoomTag;
    private String name;
    private String info;
    private String status;
    private Boolean groupChat;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private Users users;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userOne")
    private Users userOne;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userTwo")
    private Users userTwo;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "chatRooms")
    private Set<ChatRoomMembers> members = new HashSet<>();

    public Long getChatRoomId() {
        return chatRoomId;
    }

    public void setChatRoomId(Long chatRoomId) {
        this.chatRoomId = chatRoomId;
    }

    public String getChatRoomTag() {
        return chatRoomTag;
    }

    public void setChatRoomTag(String chatRoomTag) {
        this.chatRoomTag = chatRoomTag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Boolean getGroupChat() {
        return groupChat;
    }

    public void setGroupChat(Boolean groupChat) {
        this.groupChat = groupChat;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Users getUserOne() {
        return userOne;
    }

    public void setUserOne(Users userOne) {
        this.userOne = userOne;
    }

    public Users getUserTwo() {
        return userTwo;
    }

    public void setUserTwo(Users userTwo) {
        this.userTwo = userTwo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Set<ChatRoomMembers> getMembers() {
        return members;
    }

    public void setMembers(Set<ChatRoomMembers> members) {
        this.members = members;
    }
}
