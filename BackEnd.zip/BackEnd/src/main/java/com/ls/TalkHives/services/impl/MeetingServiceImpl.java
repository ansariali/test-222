package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.common.MeetingMembersEntity;
import com.ls.TalkHives.dto.common.MeetingPointsEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.meetingController.CreateMeetingRequest;
import com.ls.TalkHives.dto.meetingController.UpdateMeetingRequest;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.MeetingService;
import com.ls.TalkHives.services.impl.handler.MeetingServiceImplHandler;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.GlobalTag;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class MeetingServiceImpl extends MeetingServiceImplHandler implements MeetingService {

    private static final String TAG = MeetingServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreateMeetingRequest createMeetingRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(3, users);

        Meetings meetings = new Meetings();
        meetings.setTitle(createMeetingRequest.getTitle());
        meetings.setInfo(createMeetingRequest.getInfo());

        checkNullDate(createMeetingRequest.getTiming(), ExceptionStatus.MEETING_TIMING_MISSING);
        Date timing = getUTCTime(createMeetingRequest.getTiming());
        meetings.setTiming(timing);

        meetings.setFrequency(iDao.find(Frequency.class, createMeetingRequest.getFrequency().getFrequencyTag()));
        meetings.setUsers(users);
        meetings.setOrganizations(users.getOrganizations());
        meetings.setCreatedAt(getCurrentTime());

        Meetings meetings_ = iDao.find(Meetings.class, iDao.persist(meetings));
        checkNullObject(meetings_, ExceptionStatus.NEW_NOT_ADDED);

        HashSet<MeetingMembers> memberList = new HashSet<>();
        for (UserInfo userInfo : createMeetingRequest.getMembers()) {
            MeetingMembers meetingMembers = new MeetingMembers();
            meetingMembers.setUsers(iDao.find(Users.class, userInfo.getUserId()));
            meetingMembers.setInvitedBy(users);
            meetingMembers.setMeetings(meetings_);
            meetingMembers.setCreatedAt(getCurrentTime());
            memberList.add(meetingMembers);
        }

        // TODO: GET Size from for loop / from table using Query
        meetings_.setMembers(memberList);
        meetings_.setTotalMember(memberList.size());

        HashSet<MeetingPoints> pointList = new HashSet<>();
        for (MeetingPointsEntity points : createMeetingRequest.getPoints()) {
            MeetingPoints meetingPoints = new MeetingPoints();
            meetingPoints.setTitle(points.getTitle());
            meetingPoints.setNotedBy(users);
            meetingPoints.setMeetings(meetings_);
            meetingPoints.setCreatedAt(getCurrentTime());
            pointList.add(meetingPoints);
        }

        // TODO: GET Size from for loop / from table using Query
        meetings_.setPoints(pointList);
        meetings_.setTotalPoints(pointList.size());

        return sendMeeting(Activity.CREATE_MEETING.getActivity(), meetings_, users, iDao);
    }

    @Override
    public Map<String, List<Meetings>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Meetings>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Meetings> list = iDao.getEntities(Meetings.class, queryManager.getAllMeetings(), hashtable, false);
        hashtable.clear();

        if (!hasAccess(3, users)) {
            List<Meetings> _list = new ArrayList<>();
            for (Meetings meetings : list) {

                hashtable.put("meetings", meetings);
                hashtable.put("users", users);
                MeetingMembers meetingMembers = iDao.getEntity(MeetingMembers.class, queryManager.getMeetingMember(), hashtable, false);
                hashtable.clear();

                if (meetingMembers == null) {
                    _list.add(meetings);
                }
            }
            list.removeAll(_list);
        }

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("meetings", list);

        return map;
    }

    @Override
    public WsResponse update(UpdateMeetingRequest updateMeetingRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateMeetingRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateMeetingRequest.getMeetingId(), ExceptionStatus.MEETING_ID_MISSING);

        // Get Login User & authorization
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(3, users);

        // Get Meeting
        Meetings meetings = iDao.find(Meetings.class, updateMeetingRequest.getMeetingId());
        checkNullObject(meetings, ExceptionStatus.MEETING_NOT_FOUND);

        // Set basic meeting info
        meetings.setTitle(updateMeetingRequest.getTitle());
        meetings.setInfo(updateMeetingRequest.getInfo());

        // Set Event true / false
        checkNullDate(updateMeetingRequest.getTiming(), ExceptionStatus.MEETING_TIMING_MISSING);
        Boolean resetEvent = false;
        if (!checkEqualDate(meetings.getTiming(), updateMeetingRequest.getTiming())) {
            // TODO:
            Date timing = getUTCTime(updateMeetingRequest.getTiming());
            meetings.setTiming(timing);
            resetEvent = true;
        }

        // HashTable initialization
        Hashtable<String, Object> hashtable = new Hashtable<>();

        // Meeting Points
        hashtable.put("meetings", meetings);
        List<MeetingPoints> pointsList = iDao.getEntities(MeetingPoints.class, queryManager.getAllMeetingPoint(), hashtable, false);
        hashtable.clear();

        // Add / Remove Points
        HashSet<MeetingPoints> newPoints = new HashSet<>();

        for (MeetingPointsEntity meetingPointsEntity : updateMeetingRequest.getPoints()) {
            hashtable.put("meetings", meetings);
            hashtable.put("title", meetingPointsEntity.getTitle());
            MeetingPoints meetingPoints = iDao.getEntity(MeetingPoints.class, queryManager.getMeetingPoint(), hashtable);
            hashtable.clear();

            if (meetingPoints == null) {
                MeetingPoints _meetingPoints = new MeetingPoints();
                _meetingPoints.setCreatedAt(getCurrentTime());
                _meetingPoints.setNotedBy(iDao.find(Users.class, users.getUserId()));
                _meetingPoints.setMeetings(meetings);
                _meetingPoints.setTitle(meetingPointsEntity.getTitle());

                newPoints.add(_meetingPoints);
            } else {
                if (meetingPoints.getDeleted()) {
                    meetingPoints.setDeleted(Boolean.FALSE);
                    meetingPoints.setDeletedBy(null);
                    meetingPoints.setDeletedAt(null);
                    meetingPoints.setUpdatedAt(getCurrentTime());
                    // meetingPoints.setUpdatedBy(users);
                }
                newPoints.add(meetingPoints);
            }
        }

        // Remove points [ Added then deleted ]
        pointsList.removeAll(newPoints);

        // Remove points from database [ Added then deleted ]
        for (MeetingPoints meetingPoints : pointsList) {
            iDao.delete(meetingPoints);
        }

        // Set Points to meeting
        meetings.setPoints(newPoints);
        meetings.setTotalMember(newPoints.size());

        // Meeting Members
        hashtable.put("meetings", meetings);
        List<MeetingMembers> list = iDao.getEntities(MeetingMembers.class, queryManager.getAllMeetingMember(), hashtable, false);
        hashtable.clear();

        // Add / Remove Members
        HashSet<MeetingMembers> _list = new HashSet<>();
        HashSet<MeetingMembers> wsList = new HashSet<>();

        for (UserInfo userInfo : updateMeetingRequest.getMembers()) {
            Users meetingMembers_ = iDao.find(Users.class, userInfo.getUserId());
            hashtable.put("meetings", meetings);
            hashtable.put("users", meetingMembers_);
            MeetingMembers meetingMembers = iDao.getEntity(MeetingMembers.class, queryManager.getMeetingMember(), hashtable);
            hashtable.clear();

            if (meetingMembers == null) {
                MeetingMembers _meetingMembers = new MeetingMembers();
                _meetingMembers.setCreatedAt(getCurrentTime());
                _meetingMembers.setUsers(meetingMembers_);
                _meetingMembers.setMeetings(meetings);
                // MeetingMembers meetingMembers_ = iDao.find(MeetingMembers.class, iDao.persist(_meetingMembers));
                // checkNullObject(meetingMembers_, ExceptionStatus.MEETING_MEMBER_NOT_ADDED);

                _list.add(_meetingMembers);
                wsList.add(_meetingMembers);
            } else {
                if (meetingMembers.getDeleted()) {
                    meetingMembers.setDeleted(Boolean.FALSE);
                    meetingMembers.setDeletedAt(null);
                    meetingMembers.setDeletedBy(null);
                    meetingMembers.setUpdatedAt(getCurrentTime());
                    // meetingMembers.setUpdatedBy(users);
                }
                _list.add(meetingMembers);
            }
        }

        // Remove members [ Added then deleted ]
        list.removeAll(_list);

        // Remove members from database [ Added then deleted ]
        meetings.setMembers(_list);
        meetings.setTotalMember(_list.size());

        // Update meeting
        meetings = iDao.update(meetings);

        return sendMeeting(resetEvent, list, wsList, meetings, users, iDao);
    }

    @Override
    public WsResponse delete(Long meetingId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(3, users);

        checkNullLongId(meetingId, ExceptionStatus.MEETING_ID_MISSING);

        Meetings meetings = iDao.find(Meetings.class, meetingId);
        checkNullObject(meetings, ExceptionStatus.MEETING_NOT_FOUND);

        iDao.delete(meetings);

        meetings = iDao.find(Meetings.class, meetingId);

        if (meetings.getDeleted()) {
            return sendMeeting(Activity.DELETE_MEETING.getActivity(), meetings, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.NEW_NOT_DELETED);
        }
    }
}

/*
* Meeting Ascii
* Meeting Type
* HasAccess() modification
* */