package com.ls.TalkHives.dto.chatController;

import com.ls.TalkHives.dto.common.ChatRoomEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllGroupChat {

    private List<ChatRoomEntity> chatRooms = new ArrayList<>();

    public List<ChatRoomEntity> getChatRooms() {
        return chatRooms;
    }

    public void setChatRooms(List<ChatRoomEntity> chatRooms) {
        this.chatRooms = chatRooms;
    }
}
