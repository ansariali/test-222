package com.ls.TalkHives.dto.common;

import java.util.Date;

public class MeetingMembersEntity {
    private Long meetingMemberId;
    private UserInfo invitedBy;
    private UserInfo users;
    private Date createdAt;

    public Long getMeetingMemberId() {
        return meetingMemberId;
    }

    public void setMeetingMemberId(Long meetingMemberId) {
        this.meetingMemberId = meetingMemberId;
    }

    public UserInfo getInvitedBy() {
        return invitedBy;
    }

    public void setInvitedBy(UserInfo invitedBy) {
        this.invitedBy = invitedBy;
    }

    public UserInfo getUsers() {
        return users;
    }

    public void setUsers(UserInfo users) {
        this.users = users;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
