package com.ls.TalkHives.dto.postController;

import com.ls.TalkHives.dto.common.BlogEntity;
import com.ls.TalkHives.dto.common.PostEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllPosts {

    private List<PostEntity> posts = new ArrayList<>();

    public List<PostEntity> getPosts() {
        return posts;
    }

    public void setPosts(List<PostEntity> posts) {
        this.posts = posts;
    }
}
