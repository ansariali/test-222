package com.ls.TalkHives.dto.clientController;

import com.ls.TalkHives.dto.common.ClientEntity;

public class UpdateClientRequest extends ClientEntity {
}
