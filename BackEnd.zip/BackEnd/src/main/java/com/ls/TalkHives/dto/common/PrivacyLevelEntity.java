package com.ls.TalkHives.dto.common;

public class PrivacyLevelEntity {
    private String privacyTag;
    private String title;
    private String info;

    public String getPrivacyTag() {
        return privacyTag;
    }

    public void setPrivacyTag(String privacyTag) {
        this.privacyTag = privacyTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
