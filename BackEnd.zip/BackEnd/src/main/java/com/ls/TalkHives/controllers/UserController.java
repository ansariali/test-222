package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.ImageEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.userController.*;
import com.ls.TalkHives.entities.Images;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.UserService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.IOException;
import java.security.Principal;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/userController")
public class UserController extends UniversalController {

    private static final String TAG = UserController.class.getSimpleName();

    @Autowired
    private UserService userService;

    @ApiOperation(value = "U1 Register User")
    @PostMapping(value = "/1/register")
    public ResponseEntity<UniversalResponse> registerUser(@RequestBody CreateUserRequest createUserRequest) throws IOException {
        logger.info(TAG, "Inside U1 Register User | /1/register");

        return new ResponseEntity<>(userService.register(createUserRequest, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "U2 Login User")
    @GetMapping(value = "/1/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LoginResponse> loginUser(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside loginUser");

        String userName = null, password = null, deviceId = null;

        for (Map.Entry<String, Object> entry : requestHeader.entrySet()) {
            String key = entry.getKey().toUpperCase();
            String value = entry.getValue().toString();

            if (key.equals("AUTHORIZATION")) {
                String[] auth = refactor.decodeToBase64(value).split(":");
                if (auth.length == 2) {
                    userName = auth[0];
                    password = auth[1];
                }
            }
        }

        return new ResponseEntity<>(userService.login(userName, password, iDao), responseHeaders, HttpStatus.OK);
    }

    /*@GetMapping("/1/login")
    @ResponseBody
    public Principal user(Principal user) {
        logger.info(TAG, "Inside U2 Login User | /1/login " + user);

        return user;
    }*/

    @ApiOperation(value = "U3 Logout User")
    @GetMapping(value = "/1/logout", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UniversalResponse> logoutUser(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside U3 Invite User | /1/invite");

        // return new ResponseEntity<>(userService.logOut(requestHeader, iDao), responseHeaders, HttpStatus.OK);
        return new ResponseEntity<>(new UniversalResponse(true, "logout!"), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "U4 Invite User")
    @GetMapping(value = "/1/rememberMe", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LoginResponse> rememberUser(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside U4 Invite User | /1/invite");

        return new ResponseEntity<>(userService.rememberMe(requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "U5 Invite User")
    @PostMapping(value = "/1/invite", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UniversalResponse> inviteUser(@RequestHeader Map<String, Object> requestHeader,
                                                        @RequestBody CreateInvitationRequest createInvitationRequest) {
        logger.info(TAG, "Inside U5 Invite User | /1/invite");

        // Users users = talkHivesService.findUserByLoginToken(requestHeader, iDao);

        return new ResponseEntity<>(userService.sendInvite(createInvitationRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "U6 Register Invited User")
    @PostMapping(value = "/1/register/invite/{token}")
    public ResponseEntity<UniversalResponse> registerUser(@RequestPart(value = "file", required = false) MultipartFile multipartFile,
                                                          MultipartHttpServletRequest multipartHttpServletRequest,
                                                          @PathVariable String token) {
//        logger.info(TAG, "Inside U6 Register Invited User | /1/register/invite/{token}");

        logger.info(TAG, "multipartHttpServletRequest : " + multipartHttpServletRequest.getParameter("info"));
        logger.info(TAG, "multipartFile : " + multipartFile);

        return new ResponseEntity<>(userService.registerByInvite(multipartFile, multipartHttpServletRequest, token, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Fetch Profile")
    @GetMapping(value = "/1/fetch/profile", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UpdateUserRequest> fetchProfile(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside U7 Fetch Profile | /1/fetch/profile");

        return new ResponseEntity<>(userService.fetchProfile(requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Update Profile")
    @PutMapping(value = "/profile/1/update/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<WsResponse> updateProfile(@PathVariable Long userId, @RequestBody UpdateUserRequest users, @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside updateProfile");

        return new ResponseEntity<>(userService.updateProfile(userId, requestHeader, users, iDao), responseHeaders, HttpStatus.OK);
    }

    
}