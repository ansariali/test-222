package com.ls.TalkHives.utils.enums;

public enum UniversalInfo {

    TalkHives("907"),
    EazeProcure_Email_Host("no-reply@easeprocure.com"),

    // For server
    TalkHives_Host("https://test.easeprocure.com/");
    // TalkHives_Host("https://www.talkhives.com/");
    // TalkHives_Host("http://testbackend.bizdesk.co/");


    // For Intellij
//     TalkHives_Host("http://192.168.1.5:907/");
//     TalkHives_Host("http://192.168.0.19:5000/");

    // For tomcat
    // TalkHives_Host("http://127.0.0.1:8083/talkhives/"),;

    private final String code;

    UniversalInfo(String code) {
        this.code = code;
    }

    public String getInfo() {
        return code;
    }
}