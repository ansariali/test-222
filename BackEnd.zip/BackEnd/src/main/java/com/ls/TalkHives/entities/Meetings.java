package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Meetings Entity
 */

@Entity
@Table(name = "meetings")
public class Meetings extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long meetingId;

    private String meetingTag;

    @NotNull
    @Size(min = 3, max = 30)
    private String title;

    private String info;
    private Date timing;

    @ColumnDefault("0")
    private Integer totalMember;

    @ColumnDefault("0")
    private Integer totalPoints;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "frequency")
    private Frequency frequency;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private Users users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizationId")
    private Organizations organizations;

    @Where(clause = "deleted = false")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "meetings")
    private Set<MeetingMembers> members = new HashSet<>();

    @Where(clause = "deleted = false")
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "meetings")
    private Set<MeetingPoints> points = new HashSet<>();

    public Set<MeetingPoints> getPoints() {
        return points;
    }

    public void setPoints(Set<MeetingPoints> points) {
        this.points = points;
    }

    public Long getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(Long meetingId) {
        this.meetingId = meetingId;
    }

    public String getMeetingTag() {
        return meetingTag;
    }

    public void setMeetingTag(String meetingTag) {
        this.meetingTag = meetingTag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public Date getTiming() {
        return timing;
    }

    public void setTiming(Date timing) {
        this.timing = timing;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Integer getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(Integer totalPoints) {
        this.totalPoints = totalPoints;
    }

    public Frequency getFrequency() {
        return frequency;
    }

    public void setFrequency(Frequency frequency) {
        this.frequency = frequency;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Organizations getOrganizations() {
        return organizations;
    }

    public void setOrganizations(Organizations organizations) {
        this.organizations = organizations;
    }

    public Set<MeetingMembers> getMembers() {
        return members;
    }

    public void setMembers(Set<MeetingMembers> members) {
        this.members = members;
    }
}



