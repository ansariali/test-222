package com.ls.TalkHives.dto.postController;

public class CreateCommentLikeRequest {
    private Long commentId;
    private Boolean liked;

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }
}
