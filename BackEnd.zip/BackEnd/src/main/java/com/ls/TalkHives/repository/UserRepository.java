package com.ls.TalkHives.repository;

import com.ls.TalkHives.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/* this the user  Repository interface  */

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    public User findOneByUserName(String userName);
}
