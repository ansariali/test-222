package com.ls.TalkHives.utils.enums;

public enum GlobalTag {

    // User Role Level
    ROLE_LEVEL1("1", 1L),
    ROLE_LEVEL2("2", 2L),
    ROLE_LEVEL3("3", 3L),
    ROLE_LEVEL4("4", 4L),
    ROLE_LEVEL5("5", 5L),
    ROLE_LEVEL6("6", 6L),
    ROLE_LEVEL7("7", 7L),
    ROLE_LEVEL8("8", 8L),
    ROLE_LEVEL9("9", 9L),

    // Privacy level
    PRIVACY_LEVEL0("0", 0L),
    PRIVACY_LEVEL1("1", 1L),
    PRIVACY_LEVEL2("2", 2L),
    PRIVACY_LEVEL3("3", 3L),
    PRIVACY_LEVEL4("4", 4L),
    PRIVACY_LEVEL5("5", 5L),
    PRIVACY_LEVEL6("6", 6L),
    PRIVACY_LEVEL7("6", 7L),
    PRIVACY_LEVEL8("8", 8L),
    PRIVACY_LEVEL9("9", 9L),
    PRIVACY_LEVEL10("10", 10L),

    // Profile Pic
    DEFAULT_PROFILE_PIC_ID("1", 1L),

    // Status
    NEW("298", 298L),
    ACTIVE("604", 604L),
    COMPLETED("925", 925L),
    PENDING("709", 709L),
    POSTPONED("956", 956L),
    DELETED("695", 695L),
    OVERDUE("730", 730L),
    REJECTED("806", 806L),
    NEED_HELP("773", 773L),
    NOT_FOND("813", 813L),
    UNDEFINED("914", 914L),

    // Priority
    URGENT("629", 629L),
    HIGH("384", 384L),
    NORMAL("617", 617L),
    LOW("306", 306L),

    // Frequencies
    ONCE("389", 389L),
    DAILY("499", 499L),
    WEEKLY("657", 657L),
    MONTHLY("747", 747L),
    ANNUALLY("836", 836L),

    // Last [ DEMO ]
    LAST("", 0L);

    private final String globalTag;
    private final Long longTag;

    GlobalTag(String globalTag, Long longTag) {
        this.globalTag = globalTag;
        this.longTag = longTag;
    }

    public String getGlobalTag() {
        return globalTag;
    }

    public Long getLongTag() {
        return longTag;
    }
}