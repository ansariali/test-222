package com.ls.TalkHives.utils.enums;

public enum FrontEnd {

    CONFIRM_INVITATION("907/#/guest/welcome/{REASON}/{TOKEN}", "/publicController/1/verify/token/{token}", "guest/register", "confirmInvitation", "https://test.easeprocure.com/907/#/login");

    private static final String TalkHives_HOST = UniversalInfo.TalkHives_Host.getInfo();

    private final String url;
    private final String serverUrl;
    private final String redirectTo;
    private final String reason;
    private final String loginPage;

    FrontEnd(String url, String serverUrl, String redirectTo, String reason, String loginPage) {
        this.url = url;
        this.serverUrl = serverUrl;
        this.redirectTo = redirectTo;
        this.reason = reason;
        this.loginPage = loginPage;
    }

    public String getTalkHivesUrl() {
        return TalkHives_HOST + url;
    }

    public String getUrl() {
        return url;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public String getRedirectTo() {
        return redirectTo;
    }

    public String getReason() {
        return reason;
    }

    public String getLoginPage() {
        return TalkHives_HOST;
    }
}