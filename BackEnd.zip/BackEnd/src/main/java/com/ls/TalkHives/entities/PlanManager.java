package com.ls.TalkHives.entities;

import com.ls.TalkHives.utils.ideal.UniversalEntity;

import javax.persistence.*;

/**
 * PlanManager Entity
 */

@Entity
@Table(name = "plan_manager")
public class PlanManager extends UniversalEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long PlanManagerId;

//    @OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "userId")
//    private Users users;

//    private String info;
//    private boolean active;
//    private Long days;

//    private Long Users;
//    private Long posts;
//    private Long blogs;
//    private Long votes;
//    private Long teams;
//    private Long projects;
//    private Long issues;

//    private Double price;
//    private Integer paymentTerm;
//    private String paymentInfo;
//    private Integer paymentDays;
//    private Integer timeSpan;

//    @OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "createdBy")
//    private Users users;

}



