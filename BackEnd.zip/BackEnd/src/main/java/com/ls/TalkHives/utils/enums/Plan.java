package com.ls.TalkHives.utils.enums;

public enum Plan {
    NONE("NONE");

    private final String planEnum;

    Plan(String planEnum) {
        this.planEnum = planEnum;
    }

    public String getPlanEnum() {
        return planEnum;
    }
}
