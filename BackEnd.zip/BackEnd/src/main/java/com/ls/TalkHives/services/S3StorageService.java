package com.ls.TalkHives.services;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

public interface S3StorageService {

    String uploadFile(String prefix, MultipartFile multipartFile) throws IOException;

    String getItem(String fileUrl) throws IOException;

    File convertMultiPartToFile(MultipartFile file) throws IOException;

    String generateFileKey(String prefix, MultipartFile multiPart);

    String copyFile(String fileNameWithPrefix, String fileUrl);

    String deleteFile(String fileUrl);

    boolean findItem(String folderName);

    void createFolder(String folderName);

    /**
     * This method first deletes all the files in given folder and than the
     * folder itself
     */
    void deleteFolder(String folderName);
}