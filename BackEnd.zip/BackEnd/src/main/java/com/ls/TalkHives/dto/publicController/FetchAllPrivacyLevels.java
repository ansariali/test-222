package com.ls.TalkHives.dto.publicController;

import com.ls.TalkHives.dto.common.PrivacyLevelEntity;
import com.ls.TalkHives.dto.common.UserInfo;

import java.util.ArrayList;
import java.util.List;

public class FetchAllPrivacyLevels {

    private List<PrivacyLevelEntity> privacyLevels = new ArrayList<>();

    public List<PrivacyLevelEntity> getPrivacyLevels() {
        return privacyLevels;
    }

    public void setPrivacyLevels(List<PrivacyLevelEntity> privacyLevels) {
        this.privacyLevels = privacyLevels;
    }
}
