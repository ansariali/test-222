package com.ls.TalkHives.dto.taskController;

import com.ls.TalkHives.dto.common.PriorityEntity;
import com.ls.TalkHives.dto.common.StatusEntity;
import com.ls.TalkHives.dto.common.UserInfo;
import com.ls.TalkHives.dto.projectController.CreateProject;
import com.ls.TalkHives.dto.projectController.CreateProjectMilestoneRequest;
import com.ls.TalkHives.dto.projectController.fetchProject;
import com.ls.TalkHives.dto.projectController.fetchProjectMilestone;

import java.util.Date;
import java.util.List;

public class CreateTaskRequest {
    private String title;
    private String info;
    private String type;
    private Date initialDate;
    private Date deadline;

    private PriorityEntity priority;
    private StatusEntity status;
    private List<UserInfo> members;
    private List<fetchProject> project;
    private List<fetchProjectMilestone> milestone;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public PriorityEntity getPriority() {
        return priority;
    }

    public void setPriority(PriorityEntity priority) {
        this.priority = priority;
    }

    public StatusEntity getStatus() {
        return status;
    }

    public void setStatus(StatusEntity status) {
        this.status = status;
    }

    public List<UserInfo> getMembers() {
        return members;
    }

    public void setMembers(List<UserInfo> members) {
        this.members = members;
    }

    public List<fetchProject> getProject() {
        return project;
    }

    public void setProject(List<fetchProject> project) {
        this.project = project;
    }

    public List<fetchProjectMilestone> getMilestone() {
        return milestone;
    }

    public void setMilestone(List<fetchProjectMilestone> milestone) {
        this.milestone = milestone;
    }
}
