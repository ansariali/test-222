package com.ls.TalkHives.services.impl.handler;

import com.ls.TalkHives.dto.common.PostEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Posts;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.Notification;
import com.ls.TalkHives.utils.ideal.UniversalService;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public abstract class PostServiceImplHandler extends UniversalService {

    private void activityAction(String activityTag, Posts posts, Users users) {
        if (activityTag.equals(Activity.CREATE_POST.getActivity())) {
            posts.setPostTag(getPostTag(users));
        }

        if (activityTag.equals(Activity.DELETE_POST.getActivity())) {
            users.setDeletedPost(users.getDeletedPost() + 1);
            users.getOrganizations().setDeletedPost(users.getOrganizations().getDeletedPost() + 1);
        }
    }

    protected void sendPost(String activityTag, Posts posts, Users users, IDao<IEntity, Serializable> iDao) {
        activityAction(activityTag, posts, users);

        PostEntity postEntity = modelMapper.map(posts, PostEntity.class);

        // TODO: Send Post [ Refactor / working ]

        // TODO: Send Notification [ Refactor / working ]

        // Send Activity
        setActivity(Boolean.TRUE, posts.getPostId(), Ascii.POST, activityTag, users, iDao);
    }
}