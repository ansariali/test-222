package com.ls.TalkHives.dto.mileStoneController;

import com.ls.TalkHives.dto.common.StatusEntity;
import com.ls.TalkHives.dto.common.TaskMembersEntity;

import java.util.Date;
import java.util.List;

public class FetchTask {
    private Long taskId;
    private String title;
    private String info;
    private String type;
    private Integer totalMember = 0;
    private Date initialDate;
    private Date deadline;
    private Date overdueDate;
    private StatusEntity status;
    private List<TaskMembersEntity> members;

    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getTotalMember() {
        return totalMember;
    }

    public void setTotalMember(Integer totalMember) {
        this.totalMember = totalMember;
    }

    public Date getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(Date initialDate) {
        this.initialDate = initialDate;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public Date getOverdueDate() {
        return overdueDate;
    }

    public void setOverdueDate(Date overdueDate) {
        this.overdueDate = overdueDate;
    }

    public StatusEntity getStatus() {
        return status;
    }

    public void setStatus(StatusEntity status) {
        this.status = status;
    }

    public List<TaskMembersEntity> getMembers() {
        return members;
    }

    public void setMembers(List<TaskMembersEntity> members) {
        this.members = members;
    }
}
