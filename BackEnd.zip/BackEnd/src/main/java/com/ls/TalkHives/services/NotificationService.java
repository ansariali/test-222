package com.ls.TalkHives.services;

import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

public interface NotificationService {

    Date clock();

    Notifications create(Long activityId, String tag, Users users, IDao<IEntity, Serializable> iDao);

    Map<String, List<Notifications>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    void sentToUser(Long activityId, String tag, Boolean self, String message, Users receiver, Users users, IDao<IEntity, Serializable> iDao);

    void sentToOrganization(Long activityId, String tag, Boolean self, String message, Users users, IDao<IEntity, Serializable> iDao);

    void sendToDesignation(Long activityId, String tag, Boolean self, String message, Users users, IDao<IEntity, Serializable> iDao);

    void postNotification(String Activity, Posts posts, Users users, IDao<IEntity, Serializable> iDao);

    void voteNotification(String Activity, Votes votes, Users users, IDao<IEntity, Serializable> iDao);
}