package com.ls.TalkHives.utils.ideal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ls.TalkHives.dto.common.UserActivityEntity;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.*;
import com.ls.TalkHives.services.EmailService;
import com.ls.TalkHives.services.EventService;
import com.ls.TalkHives.services.NotificationService;
import com.ls.TalkHives.services.S3StorageService;
import com.ls.TalkHives.utils.*;
import com.ls.TalkHives.utils.enums.*;
import com.ls.TalkHives.utils.enums.TimeZone;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public abstract class UniversalService {
    protected static final String TAG = UniversalService.class.getSimpleName();

    protected static Logger logger = Logger.getInstance(true, UniversalService.class);

    protected static Util util = Util.getInstance();

    protected static Tag tag = Tag.getInstance();

    protected static Refactor refactor = Refactor.getInstance();

    protected static Gson gson = new GsonBuilder()
            .setDateFormat("dd-MM-yyyy hh:ss a")
            .registerTypeAdapter(Date.class, refactor.serializeDate)
            .registerTypeAdapter(Date.class, refactor.deserializeDate)
            .registerTypeAdapter(Date.class, refactor.serializeCurrency)
            .registerTypeAdapter(Date.class, refactor.deserializeCurrency)
            .create();

    @Autowired
    protected ModelMapper modelMapper;

    @Autowired
    protected EmailService emailService;

    @Autowired
    protected EventService eventService;

    @Autowired
    protected S3StorageService s3StorageService;

    @Autowired
    protected NotificationService notificationService;

    @Autowired
    protected SimpMessagingTemplate simpMessagingTemplate;

    protected EmailSender emailSender = EmailSender.getInstance();

    protected QueryManager queryManager = QueryManager.getInstance();

    protected UniversalResponse universalResponse;

    protected UserActivity setActivity(Boolean selfActivity, Long activityId, Ascii activity, String activityTag, Users users, IDao<IEntity, Serializable> iDao) {
        UserActivity userActivity = new UserActivity();
        if (selfActivity) {
            userActivity.setType(Ascii.SELF.getCode());
        } else {
            userActivity.setType(Ascii.PUBLIC.getCode());
        }
        userActivity.setActivityId(activityId);
        userActivity.setActivity(activity.getCode());
        userActivity.setActivityTag(activityTag);

        userActivity.setUsers(users);
        userActivity.setOrganizations(users.getOrganizations());
        userActivity.setCreatedAt(getCurrentTime());

        String message, creator = "You";
        message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        userActivity.setMessage(message);

        switch (activity) {
            case PIN:
                userActivity.setPins(iDao.find(Pins.class, activityId));
                break;

            case BLOG:
                userActivity.setBlogs(iDao.find(Blogs.class, activityId));
                break;

            case CLIENT:
                userActivity.setClients(iDao.find(Clients.class, activityId));
                break;

            case VOTE:
                userActivity.setVotes(iDao.find(Votes.class, activityId));
                break;

            case POST:
                userActivity.setPosts(iDao.find(Posts.class, activityId));
                break;

            case TEAM:
                userActivity.setTeams(iDao.find(Teams.class, activityId));
                break;

            case MEETING:
                userActivity.setMeetings(iDao.find(Meetings.class, activityId));
                break;

            default:
                break;

        }

        // if (Ascii.PIN.getCode().equals(activity)) {
        //     userActivity.setPins(iDao.find(Pins.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // } else if (Ascii.BLOG.getCode().equals(activity)) {
        //     userActivity.setBlogs(iDao.find(Blogs.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // } else if (Ascii.CLIENT.getCode().equals(activity)) {
        //     userActivity.setClients(iDao.find(Clients.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // } else if (Ascii.VOTE.getCode().equals(activity)) {
        //     userActivity.setVotes(iDao.find(Votes.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // } else if (Ascii.POST.getCode().equals(activity)) {
        //     userActivity.setPosts(iDao.find(Posts.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // } else if (Ascii.TEAM.getCode().equals(activity)) {
        //     userActivity.setTeams(iDao.find(Teams.class, activityId));
        //     message = Activity.valueOf(activityTag).getDirectMessage().replace("{creator}", creator);
        //     userActivity.setMessage(message);
        // }

        // Save Activity
        UserActivity userActivity_ = iDao.find(UserActivity.class, iDao.persist(userActivity));
        checkNullObject(userActivity_, ExceptionStatus.ACTIVITY_NOT_ADDED);

        // Send Activity to user
        UserActivityEntity userActivityEntity = modelMapper.map(userActivity_, UserActivityEntity.class);
        simpMessagingTemplate.convertAndSend(WSApi.SEND_SELF_ACTIVITY.getSendTo()
                .replace("{userId}", users.getUserId().toString()), userActivityEntity);

        return userActivity_;
    }

    protected WsResponse sendActivity(String type, String id, Long activityId, String activity, String activityTag, Object content) {
        WsResponse wsResponse = new WsResponse();
        wsResponse.setActivityId(activityId);
        wsResponse.setActivity(activity);
        wsResponse.setActivityTag(activityTag);
        wsResponse.setContent(content);

        if (type.equals(Ascii.USER.getCode())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_USER.getSendTo()
                    .replace("{userId}", id), wsResponse);
        } else if (type.equals(Ascii.ORGANIZATION.getCode())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_ORGANIZATION.getSendTo()
                    .replace("{organizationId}", id), wsResponse);
        } else if (type.equals(Ascii.PRIVACY.getCode())) {
            simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_DESIGNATION.getSendTo()
                    .replace("{userRoleTag}", id), wsResponse);
        }

        return wsResponse;
    }

    protected WsResponse sendActivity(Ascii type, String id, Long activityId, Ascii activity, String activityTag, Object content) {
        WsResponse wsResponse = new WsResponse();
        wsResponse.setActivityId(activityId);
        wsResponse.setActivity(activity.getCode());
        wsResponse.setActivityTag(activityTag);
        wsResponse.setContent(content);

        switch (type) {
            case USER:
                simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_USER.getSendTo()
                        .replace("{userId}", "" + id), wsResponse);
                break;

            case ORGANIZATION:
                simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_ORGANIZATION.getSendTo()
                        .replace("{organizationId}", id), wsResponse);
                break;

            case PRIVACY:
                simpMessagingTemplate.convertAndSend(WSApi.SEND_ACTIVITY_TO_DESIGNATION.getSendTo()
                        .replace("{userRoleTag}", id), wsResponse);
                break;

            default:
                break;
        }

        return wsResponse;
    }

    protected void sendActivity1(Set list, Ascii s) {
        // for (Object o : list) {
        //     Boolean b = o instanceof TeamMembersEntity;
        //
        //
        //     switch (s) {
        //         case PIN:
        //             logger.info(TAG, "pin  ");
        //             break;
        //         case BLOG:
        //             logger.info(TAG, "BLOG  ");
        //             break;
        //         default:
        //             logger.info(TAG, "default  ");
        //             break;
        //     }
        //
        //     TeamMembers teamMembersEntity = (TeamMembers) o;
        //
        //
        //     logger.info(TAG, "hashtable " + b + " || " + teamMembersEntity);
        //
        //     // Hashtable<String, Object> hashtable = new Hashtable<>();
        //     // hashtable.put("vivek", o);
        //     // hashtable.get("vivek").getClass().;
        //
        //     // logger.info(TAG, "hashtable " + hashtable.get("userId"));
        // }
    }

    protected void checkNullLongId(Long id, ExceptionStatus exceptionStatus) {
        if (id == null) {
            throw new UniversalException(exceptionStatus);
        }
    }

    protected void checkNullString(String s, ExceptionStatus exceptionStatus) {
        if (s == null) {
            throw new UniversalException(exceptionStatus);
        }
    }

    protected void checkNullObject(Object object, ExceptionStatus exceptionStatus) {
        if (object == null) {
            throw new UniversalException(exceptionStatus);
        }
    }

    protected void checkNullDate(Date date, ExceptionStatus exceptionStatus) {
        if (date == null) {
            throw new UniversalException(exceptionStatus);
        }
    }

    protected void checkNullMileStone(ProjectMilestones projectMilestones, ExceptionStatus exceptionStatus) {
        if (projectMilestones == null) {
            throw new UniversalException(exceptionStatus);
        }
    }

    protected Boolean checkEqualLongId(Long l, Long comparisionId) {
        if (l.equals(comparisionId)) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    protected Boolean checkEqualDate(Date date1, Date date2) {
        if (date1 == null) {
            date1 = getCurrentTime();
        }

        if (date2 == null) {
            date2 = getCurrentTime();
        }

        if (date1.compareTo(date2) == 0) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    protected Boolean isFutureDate(Date currentDate, Date futureDate) {
        Date d;
        Date f;

        if (currentDate == null) {
            d = getCurrentTime();
        } else {
            d = currentDate;
        }

        if (futureDate == null) {
            f = getCurrentTime();
        } else {
            f = futureDate;
        }

        if (d.compareTo(f) > 0) {
            // Date1 is after Date2
            return Boolean.FALSE;
        } else if (d.compareTo(f) < 0) {
            // Date1 is before Date2
            return Boolean.TRUE;
        } else if (d.compareTo(f) == 0) {
            // Date1 is equal to Date2
            return Boolean.FALSE;
        } else {
            // How to get here!!
            return Boolean.FALSE;
        }
    }

    protected String getHashCode(Integer i) {
        Integer _i = String.valueOf(i).hashCode();
        return _i.toString();
    }

    protected String getString(Integer i) {
        return String.valueOf(i);
    }

    protected Integer getInt(String s) {
         return Integer.parseInt(s);
    }

    protected Long getLong(String s) {
        return Long.parseLong(s);
    }

    protected Date getCurrentTime() {
        return refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), util.getCurrentTime());
    }

    protected Date getUTCTime(Date date) {
        checkNullDate(date, ExceptionStatus.DATE_MISSING);
        return refactor.convertTimeBySpecificZone(util.getDefaultTimeZone(), date);
    }

    protected Date getIndianTime(Date date) {
        checkNullDate(date, ExceptionStatus.DATE_MISSING);
        return refactor.convertTimeBySpecificZone(TimeZone.INDIAN.getTimeZone(), date);
    }

    private String getLoginToken(Map<String, Object> requestHeader) {
        String loginToken = null;

        for (Map.Entry<String, Object> entry : requestHeader.entrySet()) {
            String key = entry.getKey().toUpperCase();
            String value = entry.getValue().toString();

            if (key.equals("LOGIN-TOKEN")) {
//                logger.info(TAG, "Value of sessionId: " + value);
                // loginToken = value;
                // final ServletContext context = getServletContext();
                // final HttpSession session = (HttpSession) context.getAttribute(sessionId);

                String[] token = refactor.decodeToBase64(value).split(":");
                if (token.length == 3) {
                    loginToken = token[1];
                }
            }
        }

        return loginToken;
    }

    protected List<Users> getTopLevelPeople(Users users, IDao<IEntity, Serializable> iDao) {
        return getSpecificLevelPeople(GlobalTag.ROLE_LEVEL3, users, iDao);
    }

    protected List<Users> getSpecificLevelPeople(GlobalTag globalTag, Users users, IDao<IEntity, Serializable> iDao) {
        checkNullObject(users.getOrganizations(), ExceptionStatus.ORGANIZATION_NOT_FOUND);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        hashtable.put("userRole", findUserRole(globalTag.getGlobalTag(), iDao));
        List<Users> list = iDao.getEntities(Users.class, queryManager.getUsersByUserRole(), hashtable, false);
        hashtable.clear();

        return list;
    }

    protected String setFullName(Users users) {
        return users.getFirstName() + " " + users.getLastName();
    }

    protected String findInReqHeader(Map<String, Object> requestHeader, String request) {
        String result = null;

        for (Map.Entry<String, Object> entry : requestHeader.entrySet()) {
            String key = entry.getKey().toUpperCase();
            String value = entry.getValue().toString();

            if (key.equals(request)) {
                String[] requestArray = refactor.decodeToBase64(value).split(":");
                if (requestArray.length == 3) {
                    result = requestArray[1];
                }
            }
        }

        if (result == null) {
            throw new UniversalException(ExceptionStatus.RESULT_NOT_FOUND);
        }

        return result;
    }

    protected Invitations findInvitation(String token, IDao<IEntity, Serializable> iDao) {
        checkNullString(token, ExceptionStatus.INVITATION_TOKEN_NOT_FOUND);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("inviteToken", token);
        Invitations invitations = iDao.getEntity(Invitations.class, queryManager.verifyInviteToken(), hashtable, false);
        hashtable.clear();

        checkNullObject(invitations, ExceptionStatus.INVITATION_NOT_FOUND);

        return invitations;
    }

    protected LoginUsers findLoginUser(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        String loginToken = getLoginToken(requestHeader);

        if (loginToken == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_SESSION_NOT_FOUND);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("loginToken", loginToken);
        LoginUsers loginUsers = iDao.getEntity(LoginUsers.class, queryManager.getUserByLoginToken(), hashtable, false);
        hashtable.clear();

        if (loginUsers == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }

        return loginUsers;
    }

    protected Users findUserByLoginToken(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        String loginToken = getLoginToken(requestHeader);

        if (loginToken == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_SESSION_NOT_FOUND);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("loginToken", loginToken);
        LoginUsers loginUsers = iDao.getEntity(LoginUsers.class, queryManager.getUserByLoginToken(), hashtable, false);
        hashtable.clear();

        if (loginUsers == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }

        hashtable.put("thTag", loginUsers.getThTag());
        TalkHives talkHives = iDao.getEntity(TalkHives.class, queryManager.getUserByThTag(), hashtable, false);
        hashtable.clear();

        if (talkHives == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }

        // Users users = talkHives.getUser();
        return talkHives.getUser();
    }

    protected Users findUserByLoginToken(StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao) {
        String[] token = refactor.decodeToBase64(stompHeaderAccessor.getNativeHeader("LOGIN-TOKEN").get(0)).split(":");
        String loginToken = token[1];

        if (loginToken == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_SESSION_NOT_FOUND);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("loginToken", loginToken);
        LoginUsers loginUsers = iDao.getEntity(LoginUsers.class, queryManager.getUserByLoginToken(), hashtable, false);
        hashtable.clear();

        if (loginUsers == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }

        hashtable.put("thTag", loginUsers.getThTag());
        TalkHives talkHives = iDao.getEntity(TalkHives.class, queryManager.getUserByThTag(), hashtable, false);
        hashtable.clear();

        if (talkHives == null) {
            throw new UniversalException(ExceptionStatus.LOGIN_USER_NOT_FOUND);
        }

        // Users users = talkHives.getUser();
        return talkHives.getUser();
    }

    protected UserRole findUserRole(String roleTag, IDao<IEntity, Serializable> iDao) {
        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("roleTag", roleTag);
        UserRole userRole = iDao.getEntity(UserRole.class, queryManager.getUserRole(), hashtable, false);
        hashtable.clear();

        if (userRole == null) {
            throw new UniversalException(ExceptionStatus.USER_ROLE_LEVEL_NOT_FOUND);
        }

        return userRole;
    }

    protected Organizations findOrgByUser(Long organizationId, IDao<IEntity, Serializable> iDao) {
        Organizations organizations = iDao.find(Organizations.class, organizationId);

        if (organizations == null) {
            throw new UniversalException(ExceptionStatus.ORGANIZATION_NOT_FOUND);
        }

        return organizations;
    }

    protected UniversalResponse verifyToken(String token, IDao<IEntity, Serializable> iDao) {
        if (token == null) {
            throw new UniversalException(ExceptionStatus.INVITATION_TOKEN_NOT_FOUND);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("inviteToken", token);
        Invitations invitations = iDao.getEntity(Invitations.class, queryManager.verifyInviteToken(), hashtable, false);
        hashtable.clear();

        if (invitations == null) {
            throw new UniversalException(ExceptionStatus.INVITATION_NOT_FOUND);
        }

        return new UniversalResponse(true, FrontEnd.CONFIRM_INVITATION.getReason(), FrontEnd.CONFIRM_INVITATION.getServerUrl(),
                FrontEnd.CONFIRM_INVITATION.getRedirectTo(), invitations.getEmailId());
    }

    protected void findEmailId(String emailId, IDao<IEntity, Serializable> iDao) {
        if (emailId == null) {
            throw new UniversalException(ExceptionStatus.EMAIL_ID_IS_MISSING);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("emailId", emailId);
        Users user_ = iDao.getEntity(Users.class, queryManager.getUsersByEmailId(), hashtable, false);
        hashtable.clear();

        if (user_ != null) {
            throw new UniversalException(ExceptionStatus.EMAIL_ID_ALL_READY_USED);
        }
    }

    protected void findUserName(String userName, IDao<IEntity, Serializable> iDao) {
        if (userName == null) {
            throw new UniversalException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("userName", userName);
        Users users = iDao.getEntity(Users.class, queryManager.getUsersByUserName(), hashtable, false);
        hashtable.clear();

        if (users != null) {
            throw new UniversalException(ExceptionStatus.USER_NAME_IS_TAKEN);
        }
    }

    protected PrivacyLevel findPrivacyLevel(String privacyTag, IDao<IEntity, Serializable> iDao) {
        checkNullString(privacyTag, ExceptionStatus.PRIVACY_LEVEL_NOT_FOUND);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("privacyTag", privacyTag);
        PrivacyLevel privacyLevel = iDao.getEntity(PrivacyLevel.class, queryManager.getPrivacyLevel(), hashtable, false);
        hashtable.clear();

        checkNullObject(privacyLevel, ExceptionStatus.PRIVACY_LEVEL_UNKNOWN);

        return privacyLevel;
    }

    protected ChatRooms findChatRoom(String chatRoomTag, IDao<IEntity, Serializable> iDao) {
        checkNullString(chatRoomTag, ExceptionStatus.CHAT_ROOM_NOT_FOUND);

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("chatRoomTag", chatRoomTag);
        ChatRooms chatRooms = iDao.getEntity(ChatRooms.class, queryManager.getChatRoom(), hashtable, false);
        hashtable.clear();

        checkNullObject(chatRooms, ExceptionStatus.CHAT_ROOM_NOT_FOUND);

        return chatRooms;
    }

    protected void accessDenied(Integer maxUserRoleTag, Users users) {
        if (Integer.parseInt(users.getUserRole().getRoleTag()) > maxUserRoleTag) {
            throw new UniversalException(ExceptionStatus.UNAUTHORIZED_ACCESS);
        }
    }

    protected Boolean hasAccess(Integer maxUserRoleTag, Users users) {
        return Integer.parseInt(users.getUserRole().getRoleTag()) <= maxUserRoleTag;
    }

    protected void exception(Boolean b, ExceptionStatus exceptionStatus) {
        if (!b) {
            throw new UniversalException(exceptionStatus);
        }
    }

    /**
     * Tag Generation
     */
    // UserTag
    protected String getUserTag(Long userId) {
        Integer i = getInt(userId.toString()) + getInt(Ascii.USER.getCode());
        return getHashCode(i);
    }

    // OrganizationTag
    protected String getOrganizationTag(Long organizationId) {
        Integer i = getInt(organizationId.toString()) + getInt(Ascii.ORGANIZATION.getCode());
        return getHashCode(i);
    }

    // PinTag
    protected String getPinTagPrefix(String userTag) {
        Integer i = getInt(userTag) + getInt(Ascii.PIN.getCode());
        return getString(i.hashCode());
    }

    protected String getPinTag(Users users) {
        if (users.getPinTagPrefix() == null) {
            users.setPinTagPrefix(getPinTagPrefix(users.getHashTag()));
        }

        users.setTotalPin(users.getTotalPin() + 1);
        users.getOrganizations().setTotalPin(users.getOrganizations().getTotalPin() + 1);
        return users.getPinTagPrefix() + users.getTotalPin();
    }

    // BlogTag
    protected String getBlogTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.BLOG.getCode());
        return getHashCode(i);
    }

    protected String getBlogTag(Users users) {
        if (users.getOrganizations().getBlogTagPrefix() == null) {
            users.getOrganizations().setBlogTagPrefix(getBlogTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalBlog(users.getTotalBlog() + 1);
        users.getOrganizations().setTotalBlog(users.getOrganizations().getTotalBlog() + 1);
        return users.getOrganizations().getBlogTagPrefix() + users.getOrganizations().getTotalBlog();
    }

    // ClientTag
    protected String getClientTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.CLIENT.getCode());
        return getHashCode(i);
    }

    protected String getClientTag(Users users) {
        if (users.getOrganizations().getClientTagPrefix() == null) {
            users.getOrganizations().setClientTagPrefix(getClientTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalClient(users.getTotalClient() + 1);
        users.getOrganizations().setTotalClient(users.getOrganizations().getTotalClient() + 1);
        return users.getOrganizations().getClientTagPrefix() + users.getOrganizations().getTotalClient();
    }

    // VoteTag
    protected String getVoteTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.VOTE.getCode());
        return getHashCode(i);
    }

    protected String getVoteTag(Users users) {
        if (users.getOrganizations().getVoteTagPrefix() == null) {
            users.getOrganizations().setVoteTagPrefix(getVoteTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalVote(users.getTotalVote() + 1);
        users.getOrganizations().setTotalVote(users.getOrganizations().getTotalVote() + 1);
        return users.getOrganizations().getVoteTagPrefix() + users.getOrganizations().getTotalVote();
    }

    // PostTag
    protected String getPostTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.POST.getCode());
        return getHashCode(i);
    }

    protected String getPostTag(Users users) {
        if (users.getOrganizations().getPostTagPrefix() == null) {
            users.getOrganizations().setPostTagPrefix(getPostTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalPost(users.getTotalPost() + 1);
        users.getOrganizations().setTotalPost(users.getOrganizations().getTotalPost() + 1);
        return users.getOrganizations().getPostTagPrefix() + users.getOrganizations().getTotalPost();
    }

    // TeamTag
    protected String getTeamTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.TEAM.getCode());
        return getHashCode(i);
    }

    protected String getTeamTag(Users users) {
        if (users.getOrganizations().getTeamTagPrefix() == null) {
            users.getOrganizations().setTeamTagPrefix(getTeamTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalTeam(users.getTotalTeam() + 1);
        users.getOrganizations().setTotalTeam(users.getOrganizations().getTotalTeam() + 1);
        return users.getOrganizations().getTeamTagPrefix() + users.getOrganizations().getTotalTeam();
    }

    // ProjectTag
    protected String getProjectTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.PROJECT.getCode());
        return getHashCode(i);
    }

    protected String getProjectTag(Users users) {
        if (users.getOrganizations().getProjectTagPrefix() == null) {
            users.getOrganizations().setProjectTagPrefix(getProjectTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalProject(users.getTotalProject() + 1);
        users.getOrganizations().setTotalProject(users.getOrganizations().getTotalProject() + 1);
        return users.getOrganizations().getProjectTagPrefix() + users.getOrganizations().getTotalProject();
    }

    // MeetingTag
    protected String getMeetingTagPrefix(String organizationTag) {
        Integer i = getInt(organizationTag) + getInt(Ascii.MEETING.getCode());
        return getHashCode(i);
    }

    protected String getMeetingTag(Users users) {
        if (users.getOrganizations().getMeetingTagPrefix() == null) {
            users.getOrganizations().setMeetingTagPrefix(getMeetingTagPrefix(users.getOrganizations().getHashTag()));
        }

        users.setTotalMeeting(users.getTotalMeeting() + 1);
        users.getOrganizations().setTotalMeeting(users.getOrganizations().getTotalMeeting() + 1);
        return users.getOrganizations().getMeetingTagPrefix() + users.getOrganizations().getTotalMeeting();
    }

    // TaskTag
    protected String getTaskTagPrefix(String userTag) {
        Integer i = getInt(userTag) + getInt(Ascii.TASK.getCode());
        return getString(i.hashCode());
    }

    protected String getTaskTag(Users users) {
        if (users.getTaskTagPrefix() == null) {
            users.setTaskTagPrefix(getTaskTagPrefix(users.getHashTag()));
        }

        users.setTotalTask(users.getTotalTask() + 1);
        users.getOrganizations().setTotalTask(users.getOrganizations().getTotalTask() + 1);
        return users.getTaskTagPrefix() + users.getTotalTask();
    }

    // Maintenance
    protected Maintenance getMaintenance(IDao<IEntity, Serializable> iDao) {
        return iDao.getEntity(Maintenance.class, queryManager.getMaintenance(), false);
    }

    protected Meetings getNextMeeting(IDao<IEntity, Serializable> iDao) {
        return iDao.getEntity(Meetings.class, queryManager.getNextMeeting());
    }


}