package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.clientController.ClientResponse;
import com.ls.TalkHives.dto.clientController.CreateClientRequest;
import com.ls.TalkHives.dto.clientController.FetchAllClients;
import com.ls.TalkHives.dto.clientController.UpdateClientRequest;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.services.ClientService;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/clientController")
@Controller
public class ClientController extends UniversalController {

    private static final String TAG = ClientController.class.getSimpleName();

    @Autowired
    private ClientService clientService;

    @ApiOperation(value = "C1 Create Client")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/client/1/create/{organizationId}")
    // @SendTo("/topic/client/1/create/{organizationId}")
    public ResponseEntity<WsResponse> createClient(@RequestHeader Map<String, Object> requestHeader,
                                                   @RequestBody CreateClientRequest createClientRequest) {
        logger.info(TAG, "Inside C1 | ");

        return new ResponseEntity<>(clientService.create(createClientRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C2 FetchAll Client")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllClients> fetchAllClient(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside C2 | ");

        FetchAllClients res = modelMapper.map(clientService.fetchAll(requestHeader, iDao), FetchAllClients.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C3 Update Client")
    @PutMapping(value = "/1/update")
    // @MessageMapping("/client/1/update/{organizationId}")
    // @SendTo("/topic/client/1/update/{organizationId}")
    public ResponseEntity<WsResponse> updateClient(@RequestHeader Map<String, Object> requestHeader,
                                                   @RequestBody UpdateClientRequest updateClientRequest) {
        logger.info(TAG, "Inside updateClient ");

        return new ResponseEntity<>(clientService.update(updateClientRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C4 Delete Client")
    @DeleteMapping(value = "/1/delete/{clientId}")
    // @MessageMapping("/client/1/delete/{organizationId}/{clientId}")
    // @SendTo("/topic/client/1/delete/{organizationId}")
    public ResponseEntity<WsResponse> deleteClient(@RequestHeader Map<String, Object> requestHeader,
                                                   @PathVariable Long clientId) {
        logger.info(TAG, "Inside C4 | ");

        return new ResponseEntity<>(clientService.delete(clientId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "C5 Send Client")
    @SendTo("/topic/client/1/send")
    public ClientResponse send(@RequestParam Long organizationId, @RequestParam Long userId,
                               ClientResponse clientResponse) {
        logger.info(TAG, "Inside C5");

        return clientResponse;
    }

}