package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.PostCommentEntity;
import com.ls.TalkHives.dto.common.PostEntity;
import com.ls.TalkHives.dto.postController.*;
import com.ls.TalkHives.entities.PostComments;
import com.ls.TalkHives.entities.Posts;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface PostService {
    Posts create(CreatePostRequest createPostRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<PostEntity>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    void send(Posts posts, Users users, IDao<IEntity, Serializable> iDao);

    CreatePostLikeResponse createLike(CreatePostLikeRequest createPostLikeRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    CreateCommentLikeResponse createCommentLikes(CreateCommentLikeRequest createPostLikeRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    PostCommentEntity createComment(CreatePostCommentRequest createPostCommentRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<PostCommentEntity>> fetchAllComments(Long postId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Posts share(Long postId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<PostEntity>> fetchPostByUser(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    PostEntity update(UpdatePostRequest updatePostRequest, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

    UniversalResponse delete(Long postId, StompHeaderAccessor stompHeaderAccessor, IDao<IEntity, Serializable> iDao);

}