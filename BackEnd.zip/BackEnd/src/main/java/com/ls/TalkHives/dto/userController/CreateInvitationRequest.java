package com.ls.TalkHives.dto.userController;

import com.ls.TalkHives.dto.common.InviteEntity;

public class CreateInvitationRequest extends InviteEntity {
}
