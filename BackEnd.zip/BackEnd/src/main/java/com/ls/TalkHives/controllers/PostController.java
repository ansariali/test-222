package com.ls.TalkHives.controllers;

import com.google.gson.Gson;
import com.ls.TalkHives.dto.common.PostCommentEntity;
import com.ls.TalkHives.dto.common.PostEntity;
import com.ls.TalkHives.dto.postController.*;
import com.ls.TalkHives.services.PostService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/postController")
public class PostController extends UniversalController {

    private static final String TAG = PostController.class.getSimpleName();

    @Autowired
    private PostService postService;

    @ApiOperation(value = "P1 Create Post")
    @PostMapping(value = "/1/create")
    public ResponseEntity<PostEntity> createPost(@RequestHeader Map<String, Object> requestHeader,
                                                 @RequestBody CreatePostRequest createPostRequest) {
        logger.info(TAG, "Inside createPost");

        Gson aGson = new Gson();
        System.out.println("Gson :" + aGson.toJson(createPostRequest));
        PostEntity res = modelMapper.map(postService.create(createPostRequest, requestHeader, iDao), PostEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P2 FetchAll Post")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllPosts> fetchAllPost(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllPost");

        FetchAllPosts res = modelMapper.map(postService.fetchAll(requestHeader, iDao), FetchAllPosts.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P3 SendToUser Post")
    @SendTo("/topic/post/1/create/sendToUser/{userId}")
    public PostEntity sendToUser(@PathVariable Long userId, PostEntity postEntity) {
        logger.info(TAG, "Inside P3");
        return postEntity;
    }

    @ApiOperation(value = "P4 SendToOrganization Post")
    @SendTo("/topic/post/1/create/sendToOrganization/{organizationId}")
    public PostEntity sendToOrganization(@PathVariable Long organizationId, PostEntity postEntity) {
        logger.info(TAG, "Inside P4");

        return postEntity;
    }

    @ApiOperation(value = "P5 SendToDesignation Post")
    @SendTo("/topic/post/1/create/sendToDesignation/{userRoleTag}")
    public PostEntity sendToDesignation(@PathVariable Long userRoleTag, PostEntity postEntity) {
        logger.info(TAG, "Inside P4");

        return postEntity;
    }

    @ApiOperation(value = "P5 Create Post Like")
    @MessageMapping("/post/1/like/create/{organizationId}")
    @SendTo("/topic/post/1/like/create/{organizationId}")
    public ResponseEntity<CreatePostLikeResponse> createPostLike(@RequestHeader StompHeaderAccessor stompHeaderAccessor, @PathVariable String organizationId,
                                                                 @RequestBody CreatePostLikeRequest createPostLikeRequest) {
        logger.info(TAG, "Inside createPostLike ");

        return new ResponseEntity<>(postService.createLike(createPostLikeRequest, stompHeaderAccessor, iDao), responseHeaders, HttpStatus.OK);
    }

  /*  @ApiOperation(value = "P5 Create Post Like")
    @PostMapping("/1/like/create")
    public ResponseEntity<CreatePostLikeResponse> createPostLike(@RequestHeader Map<String, Object> requestHeader, @RequestBody CreatePostLikeRequest createPostLikeRequest) {
        logger.info(TAG, "Inside createPostLike ");

        return new ResponseEntity<>(postService.createLike(createPostLikeRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }*/


    @ApiOperation(value = "Create Comment Like")
    @PostMapping(value = "/1/comment/like")
    public ResponseEntity<CreateCommentLikeResponse> createCommentLike(@RequestHeader Map<String, Object> requestHeader, @RequestBody CreateCommentLikeRequest createCommentLikeRequest) {
        logger.info(TAG, "Inside createCommentLike ");

        return new ResponseEntity<>(postService.createCommentLikes(createCommentLikeRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    /*    @ApiOperation(value = "P6 Create Post Comment")
        @MessageMapping("/post/1/comment/create/{organizationId}")
        @SendTo("/topic/post/1/comment/create/{organizationId}")
        public ResponseEntity<PostCommentEntity> createPostComment(StompHeaderAccessor stompHeaderAccessor, @PathVariable String organizationId, @PathVariable String postId, CreatePostCommentRequest createPostCommentRequest) {
            logger.info(TAG, "Inside createPostComment");
            // PostCommentEntity res = modelMapper.map(postService.createComment(createPostCommentRequest, stompHeaderAccessor, iDao), PostCommentEntity.class);
            return new ResponseEntity<>(postService.createComment(createPostCommentRequest, stompHeaderAccessor, iDao), responseHeaders, HttpStatus.OK);
        }*/

    @ApiOperation(value = "Create Post Comment")
    @PostMapping(value = "/1/comment/create")
    public ResponseEntity<PostCommentEntity> createPostComment(@RequestHeader Map<String, Object> requestHeader, @RequestBody CreatePostCommentRequest createPostCommentRequest) {
        logger.info(TAG, "Inside createPostComment");
        // PostCommentEntity res = modelMapper.map(postService.createComment(createPostCommentRequest, stompHeaderAccessor, iDao), PostCommentEntity.class);
        return new ResponseEntity<>(postService.createComment(createPostCommentRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }


    @ApiOperation(value = " FetchAll Comment")
    @GetMapping(value = "/1/fetch/all/post/comment/{postId}")
    public ResponseEntity<FetchAllPostComments> fetchAllVoteComment(@RequestHeader Map<String, Object> requestHeader,
                                                                    @PathVariable Long postId) {
        logger.info(TAG, "Inside fetchAllVoteComment ");

        FetchAllPostComments res = modelMapper.map(postService.fetchAllComments(postId, requestHeader, iDao), FetchAllPostComments.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P8 Share Post")
    @PostMapping(value = "/1/share/{postId}")
    public ResponseEntity<PostEntity> sharePost(@RequestHeader Map<String, Object> requestHeader,
                                                @PathVariable Long postId) {
        logger.info(TAG, "Inside P8");

        PostEntity res = modelMapper.map(postService.share(postId, requestHeader, iDao), PostEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P9 Send Shared Post")
    @SendTo("/topic/post/1/share/{organizationId}")
    public PostEntity sendSharedPost(@PathVariable Long organizationId, PostEntity postEntity) {
        logger.info(TAG, "Inside P9");

        return postEntity;
    }

    @ApiOperation(value = "P10 Fetch Post of user")
    @GetMapping(value = "/1/fetch/all/user/post")
    public ResponseEntity<FetchAllPosts> sharePost(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside P10");

        FetchAllPosts res = modelMapper.map(postService.fetchPostByUser(requestHeader, iDao), FetchAllPosts.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P11 Update Post")
    @MessageMapping("/post/1/update/{organizationId}")
    @SendTo("/topic/post/1/update/{organizationId}")
    public PostEntity updatePost(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                 @RequestBody UpdatePostRequest updatePostRequest,
                                 @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside P11 | ");

        // PostEntity res = modelMapper.map(postService.update(updatePostRequest, stompHeaderAccessor, iDao), PostEntity.class);

        return postService.update(updatePostRequest, stompHeaderAccessor, iDao);
    }


    @ApiOperation(value = "P12 Delete Post")
    @MessageMapping("/post/1/delete/{organizationId}/{postId}")
    @SendTo("/topic/post/1/delete/{organizationId}")
    public ResponseEntity<UniversalResponse> deletePost(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                                        @DestinationVariable String postId, @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside P12 | ");

        UniversalResponse res = modelMapper.map(postService.delete(Long.parseLong(postId), stompHeaderAccessor, iDao), UniversalResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }
}