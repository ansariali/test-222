package com.ls.TalkHives.dto.newController;

import com.ls.TalkHives.dto.newController.entity.NewEntity;

import java.util.List;

public class FetchAllNewResponse {

    List<NewEntity> newList;

    public List<NewEntity> getNewList() {
        return newList;
    }

    public void setNewList(List<NewEntity> newList) {
        this.newList = newList;
    }
}