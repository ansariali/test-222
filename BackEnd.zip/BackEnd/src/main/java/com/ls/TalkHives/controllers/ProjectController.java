package com.ls.TalkHives.controllers;

import com.ls.TalkHives.dto.common.*;
import com.ls.TalkHives.dto.mileStoneController.CreateProjectMilestone;
import com.ls.TalkHives.dto.mileStoneController.FetchAllMileStone;
import com.ls.TalkHives.dto.mileStoneController.MileStoneEntity;
import com.ls.TalkHives.dto.projectController.*;
import com.ls.TalkHives.dto.taskController.CreateTaskRequest;
import com.ls.TalkHives.dto.taskController.FetchAllTasks;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.ProjectService;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.enums.Ascii;
import com.ls.TalkHives.utils.enums.S3Storage;
import com.ls.TalkHives.utils.ideal.UniversalController;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/projectController")
@Controller
public class ProjectController extends UniversalController {

    private static final String TAG = ProjectController.class.getSimpleName();

    @Autowired
    private ProjectService projectService;

    @ApiOperation(value = "documentShared in project")
    @RequestMapping(value = "/1/upload/{projectId}", method = RequestMethod.POST)
    public ResponseEntity<UniversalResponse> uploadFile(@RequestPart("fileDetails") DocumentEntity uploadFile, @RequestHeader Map<String, Object> requestHeader, @RequestParam("file") MultipartFile[] files) throws IOException {
        logger.info(TAG, "Inside uploadFile");

        /*FileEntity fileEntity = new FileEntity();
        Long fileSize = 0L;
        for (int i = 0; i < files.length; i++) {
            String prefix = S3Storage.FOLDER_PUBLIC.getValue() + S3Storage.SUFFIX.getValue() + S3Storage.FOLDER_TRASH.getValue() + S3Storage.SUFFIX.getValue() + new Date().getTime();
            fileEntity.setFileTag(Ascii.FILE.getCode() + Ascii.TRASH.getCode());
            fileEntity.setFileUrl(s3StorageService.uploadFile(prefix, files[i]));
            fileEntity.setName(files[i].getOriginalFilename());
            fileEntity.setType(files[i].getContentType());
            System.out.println("Bytes :"+ i +"-" + files[i].getBytes());
            fileSize +=  files[i].getSize();
            System.out.println("FileSize i :"+ i +"-" + fileSize);
        }
        System.out.println("FileSize :"+ fileSize);*/

       return new ResponseEntity<>(projectService.uploadFile(uploadFile, requestHeader, files, iDao),responseHeaders, HttpStatus.OK);

//        return new ResponseEntity<>(new UniversalResponse(true, "Folder created"), responseHeaders, HttpStatus.OK);
    }



    @ApiOperation(value = "P1 Create Project")
    @PostMapping(value = "/1/create")
    // @MessageMapping("/project/1/create/{organizationId}")
    // @SendTo("/topic/project/1/create/{organizationId}")
    public ResponseEntity<ProjectEntity> createProject(@RequestHeader Map<String, Object> requestHeader,
                                                       @RequestBody CreateProjectRequest createProjectRequest) {
        logger.info(TAG, "Inside T1 | /1/create");
        ProjectEntity res = modelMapper.map(projectService.create(createProjectRequest, requestHeader, iDao), ProjectEntity.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Create MileStone")
    @PostMapping(value = "/1/create/milestone")
    public ResponseEntity<CreateProjectMilestone> createMileStone(@RequestHeader Map<String, Object> requestHeader, @RequestBody CreateProjectMilestone createProjectMilestoneRequest) {
        logger.info(TAG, "Inside createMileStone");

        CreateProjectMilestone res = modelMapper.map(projectService.createMileStone(createProjectMilestoneRequest, requestHeader, iDao), CreateProjectMilestone.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "FetchAll MileStone")
    @GetMapping(value = "/1/fetch/all/mileStone")
    public ResponseEntity<FetchAllMileStone> fetchAllMilestone(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllMilestone: ");

        FetchAllMileStone res = modelMapper.map(projectService.fetchAllMileStone(requestHeader, iDao), FetchAllMileStone.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value =" Update MileStone")
    @PutMapping(value = "/1/update/mileStone/{mileStoneId}")
    public ResponseEntity<MileStoneEntity> updateMileStone(@PathVariable Long mileStoneId, @RequestHeader Map<String, Object> requestHeader, @RequestBody MileStoneEntity mileStoneRequest) {
        logger.info(TAG, "Inside updateMileStone :");

        MileStoneEntity res = modelMapper.map(projectService.updateMileStone(mileStoneId, mileStoneRequest, requestHeader, iDao), MileStoneEntity.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Delete MileStone")
    @DeleteMapping(value = "/1/delete/mileStone/{mileStoneId}")
    public ResponseEntity<WsResponse> deleteMileStone(@PathVariable Long mileStoneId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside deleteMileStone");

        return new ResponseEntity<>(projectService.deleteMilestone(mileStoneId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P2 FetchAll Project")
    @GetMapping(value = "/1/fetch/all")
    public ResponseEntity<FetchAllProjects> fetchAllProject(@RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside fetchAllProject: ");

        FetchAllProjects res = modelMapper.map(projectService.fetchAll(requestHeader, iDao), FetchAllProjects.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P3 Create Project Comment")
    // @PostMapping(value = "/1/create/project/comment")
    @MessageMapping("/project/1/comment/create/{organizationId}/{projectId}")
    @SendTo("/topic/project/1/comment/create/{organizationId}/{projectId}")
    public ProjectCommentEntity createProjectComment(StompHeaderAccessor stompHeaderAccessor, @PathVariable String organizationId, @PathVariable String projectId,
                                                     @RequestBody CreateProjectCommentRequest createProjectCommentRequest) {
        logger.info(TAG, "Inside P3 | : ");

        ProjectCommentEntity res = modelMapper.map(projectService.createComment(createProjectCommentRequest, stompHeaderAccessor, iDao), ProjectCommentEntity.class);

        return res;
    }

    @ApiOperation(value = "P4 FetchAll Project Comment")
    @GetMapping(value = "/1/fetch/all/project/comment/{projectId}")
    public ResponseEntity<FetchAllProjectComments> fetchAllProjectComment(@RequestHeader Map<String, Object> requestHeader,
                                                                          @PathVariable Long projectId) {
        logger.info(TAG, "Inside fetchAllProjectComment");

        FetchAllProjectComments res = modelMapper.map(projectService.fetchAllComments(projectId, requestHeader, iDao), FetchAllProjectComments.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Update Project")
    @PutMapping("/project/1/update/{projectId}")
    public ResponseEntity<WsResponse> updateProject(@PathVariable Long projectId, @RequestHeader Map<String, Object> requestHeader, @RequestBody UpdateProjectRequest updateProjectRequest) {
        logger.info(TAG, "Inside updateProject :");

        return new ResponseEntity<>(projectService.updateProject(projectId, updateProjectRequest, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P5 Update Project")
    @MessageMapping("/project/1/update1/{organizationId}")
    @SendTo("/topic/project/1/update1/{organizationId}")
    public ResponseEntity<ProjectEntity> updateBlog(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                                    @RequestBody UpdateProjectRequest updateProjectRequest,
                                                    @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside P5");

        ProjectEntity res = modelMapper.map(projectService.update(updateProjectRequest, stompHeaderAccessor, iDao), ProjectEntity.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "Delete Project")
    @DeleteMapping(value = "/1/delete/project/{projectId}")
    public ResponseEntity<WsResponse> deleteProject(@PathVariable Long projectId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info(TAG, "Inside deleteProject");

        return new ResponseEntity<>(projectService.deleteProject(projectId, requestHeader, iDao), responseHeaders, HttpStatus.OK);
    }

    @ApiOperation(value = "P6 Delete Project")
    @MessageMapping("/project/1/delete/{organizationId}/{projectId}")
    @SendTo("/topic/project/1/delete/{organizationId}")
    public ResponseEntity<UniversalResponse> deleteProject(@RequestHeader StompHeaderAccessor stompHeaderAccessor,
                                                           @DestinationVariable String projectId, @DestinationVariable String organizationId) {
        logger.info(TAG, "Inside P6 | ");

        UniversalResponse res = modelMapper.map(projectService.delete(Long.parseLong(projectId), stompHeaderAccessor, iDao), UniversalResponse.class);

        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }
}