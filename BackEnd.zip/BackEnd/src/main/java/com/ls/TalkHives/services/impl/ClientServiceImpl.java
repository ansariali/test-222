package com.ls.TalkHives.services.impl;

import com.ls.TalkHives.dto.clientController.CreateClientRequest;
import com.ls.TalkHives.dto.clientController.UpdateClientRequest;
import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.entities.Clients;
import com.ls.TalkHives.entities.Users;
import com.ls.TalkHives.services.ClientService;
import com.ls.TalkHives.services.impl.handler.ClientServiceImplHandler;
import com.ls.TalkHives.utils.enums.Activity;
import com.ls.TalkHives.utils.exception.UniversalException;
import com.ls.TalkHives.utils.exception.enums.ExceptionStatus;
import com.ls.TalkHives.utils.ideal.UniversalEntity;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class ClientServiceImpl extends ClientServiceImplHandler implements ClientService {

    private static final String TAG = ClientServiceImpl.class.getSimpleName();

    @Override
    public WsResponse create(CreateClientRequest createClientRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(createClientRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        Users users = findUserByLoginToken(requestHeader, iDao);
        accessDenied(2, users);

        Clients clients = new Clients();
        clients.setName(createClientRequest.getName());
        clients.setInfo(createClientRequest.getInfo());
        clients.setEmailId(createClientRequest.getEmailId());
        clients.setCountryCode(createClientRequest.getCountryCode());
        clients.setMobileNo(createClientRequest.getMobileNo());
        clients.setUser(users);
        clients.setOrganizations(users.getOrganizations());
        clients.setCreatedAt(getCurrentTime());

        Clients clients_ = iDao.find(Clients.class, iDao.persist(clients));
        checkNullObject(clients_, ExceptionStatus.NEW_NOT_ADDED);

        // TODO: Email Advertising PROFESSIONAL before response
        return sendClient(Activity.CREATE_CLIENT.getActivity(), clients_, users, iDao);
    }

    @Override
    public Map<String, List<Clients>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);

        Map<String, List<Clients>> map = new HashMap<>();

        Hashtable<String, Object> hashtable = new Hashtable<>();

        hashtable.put("organizations", users.getOrganizations());
        List<Clients> list = iDao.getEntities(Clients.class, queryManager.getAllClients(), hashtable, false);
        hashtable.clear();

        list.sort(Comparator.comparing(UniversalEntity::getCreatedAt));

        map.put("clients", list);

        return map;
    }

    @Override
    public WsResponse update(UpdateClientRequest updateClientRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        checkNullObject(updateClientRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(updateClientRequest.getClientId(), ExceptionStatus.CLIENT_ID_MISSING);

        Users users = findUserByLoginToken(requestHeader, iDao);
        Clients clients = iDao.find(Clients.class, updateClientRequest.getClientId());

        checkNullObject(clients, ExceptionStatus.CLIENT_NOT_FOUND);

        accessDenied(2, users);

        clients.setName(updateClientRequest.getName());
        clients.setInfo(updateClientRequest.getInfo());
        clients.setEmailId(updateClientRequest.getEmailId());
        clients.setCountryCode(updateClientRequest.getCountryCode());
        clients.setMobileNo(updateClientRequest.getMobileNo());
        clients.setUser(users);
        clients.setOrganizations(users.getOrganizations());
        clients.setUpdatedAt(getCurrentTime());
//        clients.setUpdatedBy(users);
        clients = iDao.update(clients);

        return sendClient(Activity.UPDATE_CLIENT.getActivity(), clients, users, iDao);
    }

    @Override
    public WsResponse delete(Long clientId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao) {
        Users users = findUserByLoginToken(requestHeader, iDao);
        checkNullLongId(clientId, ExceptionStatus.CLIENT_ID_MISSING);

        Clients clients = iDao.find(Clients.class, clientId);
        checkNullObject(clients, ExceptionStatus.CLIENT_NOT_FOUND);

        accessDenied(2, users);

        iDao.delete(clients);

        clients = iDao.find(Clients.class, clientId);

        if (clients.getDeleted()) {
            return sendClient(Activity.DELETE_CLIENT.getActivity(), clients, users, iDao);
        } else {
            throw new UniversalException(ExceptionStatus.CLIENT_NOT_DELETED);
        }
    }
}