package com.ls.TalkHives.utils.impl;

import java.util.List;
import java.util.Map;

public interface NetworkResponse {
    void onSuccess(Integer responseCode, Map<String, List<String>> responseHeader, String responseBody);

    void onFailure(Integer responseCode, Map<String, List<String>> responseHeader, String responseBody);
}