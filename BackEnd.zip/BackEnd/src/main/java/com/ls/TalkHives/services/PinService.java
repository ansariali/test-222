package com.ls.TalkHives.services;

import com.ls.TalkHives.dto.common.WsResponse;
import com.ls.TalkHives.dto.pinController.CreatePinRequest;
import com.ls.TalkHives.dto.pinController.UpdatePinRequest;
import com.ls.TalkHives.entities.NewEntity;
import com.ls.TalkHives.entities.Pins;
import com.ls.TalkHives.utils.UniversalResponse;
import com.ls.TalkHives.utils.impl.IDao;
import com.ls.TalkHives.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface PinService {
    WsResponse create(CreatePinRequest createPinRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    Map<String, List<Pins>> fetchAll(Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse update(UpdatePinRequest updatePinRequest, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);

    WsResponse delete(Long pinId, Map<String, Object> requestHeader, IDao<IEntity, Serializable> iDao);
}