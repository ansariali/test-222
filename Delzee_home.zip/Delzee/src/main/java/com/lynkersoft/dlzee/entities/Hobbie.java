package com.lynkersoft.dlzee.entities;

import javax.persistence.*;

@Entity
@Table(name = "Hobbie")
public class Hobbie {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long hobbieId;
    private String name;
    private  String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_id")
    private Profile  profile;

    public Long getHobbieId() {
        return hobbieId;
    }

    public void setHobbieId(Long hobbieId) {
        this.hobbieId = hobbieId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
}
