package com.lynkersoft.dlzee.utils.enums;

public enum Privacy {
    PRIVATE, PUBLIC, FRIENDS,
}
