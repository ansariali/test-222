package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;
import com.lynkersoft.dlzee.utils.enums.Privacy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "profile")
public class Profile extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long profileId;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy addressPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy hobbyPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy friendPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy educationPrivacy;

   /* @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Address> address = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Education> educations = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Hobbie>  hobbies = new HashSet<>();*/

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }
}
