package com.lynkersoft.dlzee.utils.exception.enums;

public enum ExceptionStatus {
    GENERIC_FAILURE(648112506174L, ErrorType.ERR, "Generic failure is failed", "Generic Failure logged"),
    HTTP_REQUEST_BODY_NOT_VALID(648112506173L, ErrorType.ERR, "HttpRequest body not valid", "Invalid httpRequest body"),

    //User
    USER_NAME_OR_PASSWORD_MISSING(907100101L, ErrorType.ERR, "User name or password is missing","User name or password is missing"),
    USER_NAME_OR_PASSWORD_INVALID(907100101L, ErrorType.ERR, "User name or password is invalid","User name or password is invalid"),
    USER_ACCOUNT_NOT_ADDED(6481125119614L, ErrorType.ERR, "Failed to add user account", "We're Unable to add your User account."),
    USER_NOT_VALID(6481125119614L, ErrorType.ERR, "User not valid ", "User not valid"),
    USER_NAME_IS_TAKEN(9071001067L, ErrorType.ERR, "Username AllReady Available","Username AllReady Available"),
    EMAIL_ID_IS_TAKEN(9071001067L, ErrorType.ERR, "Email id AllReady Available","Email id AllReady Available"),
    EMAIL_ID_NOT_FOUND(9071001067L, ErrorType.ERR, "Email id Not Found","Email id Not Found"),
    USER_ACCOUNT_NOT_ACTIVE(9071001067L, ErrorType.ERR, "User not Active","User not Active"),
    USER_NAME_IS_MISSING(9071001067L, ErrorType.ERR, "Username is missing","Username is missing"),
    FIRST_NAME_MISSING(9071001067L, ErrorType.ERR, "First name is missing","First name is missing"),
    LAST_NAME_MISSING(9071001067L, ErrorType.ERR, "Last name is missing","Last name is missing"),
    MOBILE_NO_MISSING(9071001067L, ErrorType.ERR, "Mobile Number is missing","Mobile Number is missing"),
    PASSWORD_MISSING(9071001067L, ErrorType.ERR, "Password is missing","Password is missing"),
    ACCESS_TOKEN_MISSING(9071001067L, ErrorType.ERR, "Access Token is missing","Access Token is missing"),
    USER_SESSION_NOT_FOUND(6481125119630L, ErrorType.ERR, "User session is missing", "User session is Missing"),
    USER_ALL_READY_SIGN_OUT(6481125119631L, ErrorType.ERR, "User All Ready sign out", "The User is already signed out"),
    USER_ID_MISSING(6481125119631L, ErrorType.ERR, "User id missing", "User id missing"),

    EMAIL_ADDRESS_MISSING(648112506173L, ErrorType.ERR,"Email address is missing", "Email address is missing");

    private final Long errorCode;
    private final ErrorType errorType;
    private final String debugMessage;
    private final String productionMessage;

    ExceptionStatus(Long errorCode, ErrorType errorType, String debugMessage, String productionMessage) {
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.debugMessage = debugMessage;
        this.productionMessage = productionMessage;
    }

    public Long getErrorCode() {
        return errorCode;
    }

    public ErrorType getErrorType() {
        return errorType;
    }

    public String getDebugMessage() {
        return debugMessage;
    }

    public String getProductionMessage() {
        return productionMessage;
    }

}
