package com.lynkersoft.dlzee.utils.exception;

import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.exception.util.BaseException;

public class GenericException extends BaseException {

    public GenericException(ExceptionStatus serviceStatus) {
        super(serviceStatus);
    }

    public GenericException() {
        super(ExceptionStatus.GENERIC_FAILURE);
    }
}
