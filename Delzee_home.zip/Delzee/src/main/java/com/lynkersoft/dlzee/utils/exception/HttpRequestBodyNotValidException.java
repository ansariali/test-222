package com.lynkersoft.dlzee.utils.exception;

import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.exception.util.BaseException;

public class HttpRequestBodyNotValidException extends BaseException {

    private static final long serialVersionUID = 1L;

    public HttpRequestBodyNotValidException(ExceptionStatus exceptionStatus) {
        super(exceptionStatus);
    }

    public HttpRequestBodyNotValidException() {
        super(ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
    }
}
