package com.lynkersoft.dlzee.dto.userController.entity;

import com.lynkersoft.dlzee.utils.enums.Privacy;

import java.util.ArrayList;
import java.util.List;

public class Profile {
    private Long profileId;
    private Privacy addressPrivacy;
    private Privacy hobbyPrivacy;
    private Privacy friendPrivacy;
    private Privacy educationPrivacy;
    private List<Address> address = new ArrayList<>();
    private List<Education> educations = new ArrayList<>();
    private List<Hobbie> hobbies = new ArrayList<>();

      public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public List<Education> getEducations() {
        return educations;
    }

    public void setEducations(List<Education> educations) {
        this.educations = educations;
    }

    public List<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(List<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }
}
