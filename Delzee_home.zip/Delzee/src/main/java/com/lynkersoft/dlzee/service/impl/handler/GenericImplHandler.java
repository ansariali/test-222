package com.lynkersoft.dlzee.service.impl.handler;

import com.lynkersoft.dlzee.utils.abstracts.GenericService;

public abstract class GenericImplHandler extends GenericService {
}
