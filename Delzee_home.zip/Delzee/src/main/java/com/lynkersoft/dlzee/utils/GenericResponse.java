package com.lynkersoft.dlzee.utils;

import java.util.List;

public class GenericResponse {

    private Boolean status;
    private String subject;
    private String message;
    private Object feed;
    private List<String> descriptions;

    public GenericResponse(Boolean status) {
        this.status = status;
    }

    public GenericResponse(Boolean status, String subject) {
        this.status = status;
        this.subject = subject;
    }

    public GenericResponse(Boolean status, String subject, String message) {
        this.status = status;
        this.subject = subject;
        this.message = message;
    }

    public GenericResponse(Boolean status, String subject, String message, Object feed) {
        this.status = status;
        this.subject = subject;
        this.message = message;
        this.feed = feed;
    }

    public GenericResponse(Boolean status, String subject, String message, List<String> descriptions) {
        this.status = status;
        this.subject = subject;
        this.message = message;
        this.descriptions = descriptions;
    }

    public GenericResponse(Boolean status, String subject, String message, List<String> descriptions, Object feed) {
        this.status = status;
        this.subject = subject;
        this.message = message;
        this.descriptions = descriptions;
        this.feed = feed;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getFeed() {
        return feed;
    }

    public void setFeed(Object feed) {
        this.feed = feed;
    }

    public List<String> getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(List<String> descriptions) {
        this.descriptions = descriptions;
    }
}
