package com.lynkersoft.dlzee.service;

import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.Map;

public interface BloggingService {
    GenericResponse createBlogging(Map<String, Object> requestHeader, MultipartFile[] files, IDao<IEntity, Serializable> iDao);

}
