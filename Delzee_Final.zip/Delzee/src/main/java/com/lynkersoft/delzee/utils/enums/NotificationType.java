package com.lynkersoft.delzee.utils.enums;

public enum  NotificationType {
    POST, COMMENT, LIKE, SHARE, FRIEND_REQUEST_SEND, FRIEND_REQUEST_ACCEPTED, FRIEND_REQUEST_REJECT, BIRTH_DAY;
}
