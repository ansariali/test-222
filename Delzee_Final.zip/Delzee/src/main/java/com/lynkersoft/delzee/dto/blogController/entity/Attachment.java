package com.lynkersoft.delzee.dto.blogController.entity;

import com.lynkersoft.delzee.dto.common.Blog_;
import com.lynkersoft.delzee.utils.enums.AttachmentFor;

import java.util.Date;

public class Attachment {
    private Long attachmentId;
    private String fileName;
    private String description;
    private String fileType;
    private AttachmentFor attachmentFor;
    private String contentType;
    private String url;
    private Blog_ blog;

    public Long getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(Long attachmentId) {
        this.attachmentId = attachmentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public AttachmentFor getAttachmentFor() {
        return attachmentFor;
    }

    public void setAttachmentFor(AttachmentFor attachmentFor) {
        this.attachmentFor = attachmentFor;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Blog_ getBlog() {
        return blog;
    }

    public void setBlog(Blog_ blog) {
        this.blog = blog;
    }
}
