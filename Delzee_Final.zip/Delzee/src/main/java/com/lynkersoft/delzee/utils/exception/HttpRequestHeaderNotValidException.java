package com.lynkersoft.delzee.utils.exception;

import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.exception.util.BaseException;

public class HttpRequestHeaderNotValidException extends BaseException {
    private static final long serialVersionUID = 1L;

    public HttpRequestHeaderNotValidException(ExceptionStatus serviceStatus) {
        super(serviceStatus);
    }

    public HttpRequestHeaderNotValidException() {
        super(ExceptionStatus.HTTP_REQUEST_HEADER_NOT_VALID);
    }
}