package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "hash_tag")
public class HashTag extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long hashTagId;

    private String tag;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator")
    private UserAccount creator;

    private Date created;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "hashTag")
    private Set<HashTagMember> hashTagMembers = new HashSet<>();

    public Set<HashTagMember> getHashTagMembers() {
        return hashTagMembers;
    }

    public void setHashTagMembers(Set<HashTagMember> hashTagMembers) {
        this.hashTagMembers = hashTagMembers;
    }

    public Long getHashTagId() {
        return hashTagId;
    }

    public void setHashTagId(Long hashTagId) {
        this.hashTagId = hashTagId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public UserAccount getCreator() {
        return creator;
    }

    public void setCreator(UserAccount creator) {
        this.creator = creator;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
