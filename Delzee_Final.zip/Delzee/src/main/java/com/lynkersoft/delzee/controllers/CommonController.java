package com.lynkersoft.delzee.controllers;


import com.lynkersoft.delzee.service.CommonService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/commonController/v1/")
public class CommonController extends GenericController {
    private Logger logger = LoggerFactory.getLogger(CommonController.class);

    @Autowired
    CommonService commonService;

    @GetMapping(value = "fetchMusicList")
    public ResponseEntity<Object> fetchMusicList(@RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchMusicList :");
        return new ResponseEntity<>(commonService.fetchMusicList(iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchHasTag/{userId}")
    public ResponseEntity<Object> fetchHasTag(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam String tag, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchHasTag :");
        return new ResponseEntity<>(commonService.fetchHasTag(verifySession(userId, requestHeader), profileId, tag, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "follow/{userId}")
    public ResponseEntity<GenericResponse> createFollow(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long friendId, @RequestParam String followStatus, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside createFollow :");
        return new ResponseEntity<>(commonService.createFollow(verifySession(userId, requestHeader), profileId, friendId, followStatus, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "unFollow/{userId}")
    public ResponseEntity<GenericResponse> unFollow(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long followId, @RequestParam String followStatus, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside createFollow :");
        return new ResponseEntity<>(commonService.unFollow(verifySession(userId, requestHeader), profileId, followId, followStatus, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchWeather")
    public ResponseEntity<Object> fetchWeather(@RequestParam String cityName, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchWeather :");
        return new ResponseEntity<>(commonService.fetchWeather(cityName, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchForecast")
    public ResponseEntity<Object> fetchForecast(@RequestParam String cityName, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchForecast :");
        return new ResponseEntity<>(commonService.fetchForecast(cityName, iDao), responseHeaders, HttpStatus.OK);
    }
}
