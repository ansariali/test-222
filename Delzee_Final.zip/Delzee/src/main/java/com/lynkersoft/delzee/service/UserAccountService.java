package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.delzee.dto.userController.entity.SignUp;
import com.lynkersoft.delzee.dto.userController.entity.UpdateProfileRequestBody;
import com.lynkersoft.delzee.dto.userController.entity.User;
import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface UserAccountService {

    Map<String, List<UserAccount>> searchFriend(UserAccount userAccount, Long profileId, String searchValue, IDao<IEntity, Serializable> iDao);

    GenericResponse fetchAllBirthDate(IDao<IEntity, Serializable> iDao);

    GenericResponse saveProfileImage(UserAccount userAccount, Long userId, Long profileId, Attachment attachment, IDao<IEntity, Serializable> iDao);

    GenericResponse updateProfileImage(UserAccount userAccount, Long userId, Long profileId, Long attachmentId, Attachment attachment, IDao<IEntity, Serializable> iDao);

    GenericResponse signUp(SignUp userAccount, IDao<IEntity, Serializable> iDao);

    LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao);

    GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao);

    GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao);

    GenericResponse verifyForgotPassword(String forgotToken, String password, IDao<IEntity, Serializable> iDao);

    UserAccount fetchUserById(UserAccount userAccount, Long userId, IDao<IEntity, Serializable> iDao);

    User fetchUserByPrivacy(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    User fetchUserById(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    GenericResponse sendFriendRequest(UserAccount userAccount, FriendRequest friendRequest, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse friendRequestAccept(UserAccount userAccount, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse friendRequestCancel(UserAccount userAccount, Long profileId, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateProfile(UserAccount userAccount, UpdateProfileRequestBody updateProfile, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse createEducation(UserAccount userAccount, Education education, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateEducation(UserAccount userAccount, Education education, Long educationId, IDao<IEntity, Serializable> iDao);

    GenericResponse createHobbies(UserAccount userAccount, Hobbie hobbie, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateHobbies(UserAccount userAccount, Hobbie hobbie, Long hobbiesId, IDao<IEntity, Serializable> iDao);

    Map<String, List<FriendRequest>> fetchFriendRequest(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Object fetchFriendRequestStatus(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);

    Map<String, List<UserAccount>> searchUser(UserAccount userAccount, Long profileId, String searchValue, IDao<IEntity, Serializable> iDao);

    UserAccount fetchAllUserDetails(UserAccount userAccount, Long userId, Long profileId, IDao<IEntity, Serializable> iDao);

    UserAccount fetchUserAboutUs(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);

    UserAccount fetchUserForProfile(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);


}
