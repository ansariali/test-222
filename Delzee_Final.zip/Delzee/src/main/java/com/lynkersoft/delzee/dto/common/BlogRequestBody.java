package com.lynkersoft.delzee.dto.common;

import com.lynkersoft.delzee.dto.blogController.entity.Attachment;

import java.util.ArrayList;
import java.util.List;

public class BlogRequestBody {
    private String description;
    private List<Attachment> attachments = new ArrayList<>();

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
