package com.lynkersoft.delzee.utils.enums;

public enum EmailTemplate {
    WELCOME("Welcome to Delzee", "templates/emailTemplate/welcome.vm"),
    FORGOT_PASSWORD("Forget Password", "templates/emailTemplate/forgotPassword.vm");

    private final String emailSubject;
    private final String emailTemplate;

    EmailTemplate(String emailSubject, String emailTemplate) {
        this.emailSubject = emailSubject;
        this.emailTemplate = emailTemplate;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public String getTemplateUrl() {
        return emailTemplate;
    }
}
