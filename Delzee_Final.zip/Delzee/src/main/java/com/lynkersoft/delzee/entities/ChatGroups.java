package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "chat_group")
public class ChatGroups extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatGroupId;

    private String name;
    private String status;
    private Date created;
    private String token;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "createdBy")
    private UserAccount users;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Long getChatGroupId() {
        return chatGroupId;
    }

    public void setChatGroupId(Long chatGroupId) {
        this.chatGroupId = chatGroupId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UserAccount getUsers() {
        return users;
    }

    public void setUsers(UserAccount users) {
        this.users = users;
    }
}
