package com.lynkersoft.delzee.configuration;

import com.lynkersoft.delzee.service.UserAccountService;
import com.lynkersoft.delzee.utils.GenericController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ScheduledTasks extends GenericController {

    @Autowired
    UserAccountService userAccountService;

//    @Scheduled(fixedRate = 10000)
    @Scheduled(cron = "0 0 23 * * ?")
    public void birthDayNotification() {
        userAccountService.fetchAllBirthDate(iDao);
    }
}
