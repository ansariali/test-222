package com.lynkersoft.delzee.dto.common;

import java.util.Date;

public class Friend {
    private Long friendId;
    private Boolean friendRequestAcceptedStatus;
    private Date friendRequestAcceptedDate;
    private User_ friends;
    private _Profile profile;
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public _Profile getProfile() {
        return profile;
    }

    public void setProfile(_Profile profile) {
        this.profile = profile;
    }

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public Boolean getFriendRequestAcceptedStatus() {
        return friendRequestAcceptedStatus;
    }

    public void setFriendRequestAcceptedStatus(Boolean friendRequestAcceptedStatus) {
        this.friendRequestAcceptedStatus = friendRequestAcceptedStatus;
    }

    public Date getFriendRequestAcceptedDate() {
        return friendRequestAcceptedDate;
    }

    public void setFriendRequestAcceptedDate(Date friendRequestAcceptedDate) {
        this.friendRequestAcceptedDate = friendRequestAcceptedDate;
    }

    public User_ getFriends() {
        return friends;
    }

    public void setFriends(User_ friends) {
        this.friends = friends;
    }

}
