package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Attachment;
import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.BlogSharing;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface BlogService {

    GenericResponse createBlogByByte(UserAccount userAccount, Long profileId, Blog blog, IDao<IEntity, Serializable> iDao);

    GenericResponse createBlog(UserAccount userAccount, Long profileId, String description, MultipartFile[] files, IDao<IEntity, Serializable> iDao);

    Map<String, List<Blog>> fetchAllBlog(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

   Object fetchAllBlogPublic(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Blog>> fetchBlogByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Attachment>> fetchImageByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Attachment>> fetchVideoByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao);

    Blog fetchBlogById(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao);
    
    GenericResponse updateBlog(UserAccount userAccount, Long profileId, Long blogId, Blog blog, IDao<IEntity, Serializable> iDao);

    GenericResponse deleteBlog(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao);

    GenericResponse deleteAttachment(UserAccount userAccount, Long profileId, Long blogId, Long attachmentId, IDao<IEntity, Serializable> iDao);

    GenericResponse blogShare(UserAccount userAccount, Long profileId, Long blogId, BlogSharing blogShare, IDao<IEntity, Serializable> iDao);

}
