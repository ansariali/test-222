package com.lynkersoft.delzee.dto.userController.entity;

import com.lynkersoft.delzee.dto.blogController.entity.Attachment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Blog {

    private Long blogId;
    private String description;
    private Integer totalLikes;
    private Integer totalComments;
    private Integer totalShare;
    private Date created;
    private Date deleteBlog;

    private List<Attachment> attachments = new ArrayList<>();
    private List<BlogComments> comments = new ArrayList<>();
    private List<BlogLikes> likes = new ArrayList<>();

    public Long getBlogId() {
        return blogId;
    }

    public void setBlogId(Long blogId) {
        this.blogId = blogId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTotalLikes() {
        return totalLikes;
    }

    public void setTotalLikes(Integer totalLikes) {
        this.totalLikes = totalLikes;
    }

    public Integer getTotalComments() {
        return totalComments;
    }

    public void setTotalComments(Integer totalComments) {
        this.totalComments = totalComments;
    }

    public Integer getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Integer totalShare) {
        this.totalShare = totalShare;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getDeleteBlog() {
        return deleteBlog;
    }

    public void setDeleteBlog(Date deleteBlog) {
        this.deleteBlog = deleteBlog;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    public List<BlogComments> getComments() {
        return comments;
    }

    public void setComments(List<BlogComments> comments) {
        this.comments = comments;
    }

    public List<BlogLikes> getLikes() {
        return likes;
    }

    public void setLikes(List<BlogLikes> likes) {
        this.likes = likes;
    }
}
