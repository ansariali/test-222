package com.lynkersoft.delzee.dto.chatController.fetchAll;

import com.lynkersoft.delzee.dto.common.Friend;

import java.util.ArrayList;
import java.util.List;

public class FetchAllFriends {

    List<Friend> friends = new ArrayList<>();

    public List<Friend> getFriends() {
        return friends;
    }

    public void setFriends(List<Friend> friends) {
        this.friends = friends;
    }
}
