package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.dto.hashTagController.entity.HashTagMember;
import com.lynkersoft.delzee.entities.Follow;
import com.lynkersoft.delzee.entities.HashTag;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.CommonService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.FollowStatus;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


@Service
@Transactional
public class CommonServiceImpl extends GenericImplHandler implements CommonService {

    @Value("${spring.application.server}")
    private String serverName;

    @Override
    public Object fetchMusicList(IDao<IEntity, Serializable> iDao) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://accounts.spotify.com/api/token";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Basic OGFjYzVmNzIxMGQ2NGUyMGJhMDA3N2Y1ODBmN2ZjNjI6Yjc2NTAxYmM0MTY3NGI1ZWE1NWQyZDE1NmMwYWE4ZTY=");
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", "refresh_token");
        map.add("refresh_token", "AQBUXs60IlvU1WLwZDa_sueBXB3g9IrjzfmGVxiKD35_wNns6rwd2Kipft3gPzf2tULxr7MSz13nFG70-IEeD4679fzmiG3EmLgptgTVj-g3YLTsI5-daX6nJrhNV15CkEY");

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);
        String answer = restTemplate.postForObject(url, request, String.class);
        return  answer;

    }

    @Override
    public Object fetchHasTag(UserAccount userAccount, Long profileId, String hashTag, IDao<IEntity, Serializable> iDao) {
        String str = " ";
        checkProfile(profileId, userAccount, iDao);
        checkNullString(hashTag, ExceptionStatus.HAS_TAG_MISSING);

        mCriteria.clear();
        mCriteria.put("tag", "#" + hashTag.trim());
        HashTag hashTagsQuery = iDao.getEntity(HashTag.class, queryManager.getHasTag(), mCriteria, false);
        mCriteria.clear();
        if (hashTagsQuery == null) {
            throw new GenericException(ExceptionStatus.HAS_TAG_NOT_FOUND);
        }
        //set anchor tag
        com.lynkersoft.delzee.dto.hashTagController.entity.HashTag hashTagData = dozerBeanMapper.map(hashTagsQuery, com.lynkersoft.delzee.dto.hashTagController.entity.HashTag.class);
        for (HashTagMember hashTagMember :hashTagData.getHashTagMembers()) {
            if (hashTagMember.getBlog().isHasTagStatus()) {
                //add tag
                String space = hashTagMember.getBlog().getDescription();
                String[] strings = space.split("\\s+");
                char firstLetter = '#';
                for (String word : strings) {
                    if (word.charAt(0) != firstLetter) {
                        str = str + word + " ";
                    }
                    if (word.charAt(0) == firstLetter) {
                        int wordCount = word.length() - 1;
                        if (wordCount >= 2) {
                            str = str + "<a href=" + serverName + word.substring(1) + ">" + word + "</a> " + " ";
                        } else {
                            str = str + word + " ";
                        }
                    }
                }
                hashTagMember.getBlog().setDescription(str);
                str = " ";
            } else {
                hashTagMember.getBlog().setDescription(hashTagMember.getBlog().getDescription());
            }
        }
        return hashTagData;
    }

    @Override
    public Object fetchForecast(String forecast, IDao<IEntity, Serializable> iDao) {
//        checkProfile(profileId, userAccount, iDao);
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + forecast + "&units=metric&APPID=3a918114d428726698d1578a1780810c";
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, String.class);
    }

    @Override
    public Object fetchWeather(String cityName, IDao<IEntity, Serializable> iDao) {
//        checkProfile(profileId, userAccount, iDao);
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + cityName + "&units=metric&APPID=3a918114d428726698d1578a1780810c";
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, String.class);
    }

    @Override
    public GenericResponse createFollow(UserAccount userAccount, Long profileId, Long friendId, String followStatus, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkNullString(followStatus, ExceptionStatus.FOLLOW_STATUS);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FOLLOW_NOT_FOUND);


        Follow aFollow = new Follow();
        aFollow.setFollowStatus(FollowStatus.FOLLOW.toString());
        aFollow.setFollowBy(userAccount);
        aFollow.setFollowTo(friend);
        aFollow.setCreated(getCurrentTime());

        try {
            iDao.persist(aFollow);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FOLLOW_NOT_ADDED);
        }
        return new GenericResponse(true, " Follow SuccessFully!!");
    }

    @Override
    public GenericResponse unFollow(UserAccount userAccount, Long profileId, Long followId, String followStatus, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(followId, ExceptionStatus.FOLLOW_ID_MISSING);
        checkNullString(followStatus, ExceptionStatus.FOLLOW_STATUS);
        checkProfile(profileId, userAccount, iDao);

        Follow aFollow = iDao.find(Follow.class, followId);
        checkNullObject(aFollow, ExceptionStatus.FOLLOW_NOT_FOUND);

        if (!Objects.equals(aFollow.getFollowStatus(), FollowStatus.FOLLOW)) {
            throw new GenericException(ExceptionStatus.UN_FOLLOW_ALREADY);
        }

        aFollow.setFollowStatus(FollowStatus.UNFOLLOW.toString());
        aFollow.setUnFollowDate(getCurrentTime());
        try {
            iDao.update(aFollow);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FOLLOW_NOT_ADDED);
        }
        return new GenericResponse(true, "  UnFollow SuccessFully!!");
    }
}
