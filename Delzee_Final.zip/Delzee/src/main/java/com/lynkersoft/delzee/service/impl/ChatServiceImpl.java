package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.dto.chatController.entity.GroupChat;
import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.ChatService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ChatServiceImpl extends GenericImplHandler implements ChatService {

    @Override
    public Map<String, List<Friend>> fetchAllFriends(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FRIEND_NOT_FOUND);

        mCriteria.clear();
        mCriteria.put("friendRequestStatus", FriendRequestStatus.ACCEPTED);
        mCriteria.put("friends", friend);
        List<Friend> chatMessageList = iDao.getEntities(Friend.class, queryManager.fetchFriends(), mCriteria, false);
        mCriteria.clear();

        Map<String, List<Friend>> aMap = new HashMap<>();
        aMap.put("friends", chatMessageList);
        return aMap;
    }


    @Override
    public Map<String, List<ChatGroups>> fetchAllGroup(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("user", userAccount);
        List<ChatGroups> groupList = iDao.getEntities(ChatGroups.class, queryManager.fetchAllGroup(), mCriteria, false);
        mCriteria.clear();

        Map<String, List<ChatGroups>> aMap = new HashMap<>();
        aMap.put("groups", groupList);
        return aMap;
    }

    @Override
    public Map<String, List<Chat>> fetchAllUnSeenMessage(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("sender", userAccount);
        List<Chat> chatList = iDao.getEntities(Chat.class, queryManager.fetchAllUnSeenMessage(), mCriteria);
        mCriteria.clear();

        Map<String, List<Chat>> aMap = new HashMap<>();
        aMap.put("chats", chatList);
        return aMap;
    }

    @Override
    public GenericResponse SeenAll(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("sender", userAccount);
        mCriteria.put("date", getCurrentTime());
        mCriteria.put("seen", Boolean.TRUE);
        iDao.update(queryManager.seenAllMessage(), mCriteria, false);
        mCriteria.clear();
        return new GenericResponse(true, "Seen Message SuccessFully");

    }

    @Override
    public Map<String, List<Chat>> fetchAll(UserAccount userAccount, Long profileId, Long receiverId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        mCriteria.put("sender", userAccount);
        mCriteria.put("receiver", receiver);
        List<Chat> chatMessageList = iDao.getEntities(Chat.class, queryManager.fetchAllMessage(), mCriteria);
        mCriteria.clear();

        Map<String, List<Chat>> aMap = new HashMap<>();
        aMap.put("chats", chatMessageList);
        return aMap;
    }

    @Override
    public Map<String, List<Chat>> fetchAllGroupMessage(UserAccount userAccount, Long profileId, String token, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullString(token, ExceptionStatus.TOKEN_MISSING);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("token", token);
        List<Chat> chatMessageList = iDao.getEntities(Chat.class, queryManager.fetchAllGroupMessage(), mCriteria);
        mCriteria.clear();

        Map<String, List<Chat>> aMap = new HashMap<>();
        aMap.put("chats", chatMessageList);
        return aMap;
    }

    @Override
    public GenericResponse save(UserAccount userAccount, Long profileId, Long receiverId, String token, Chat chat, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(chat.getMessage(), ExceptionStatus.MESSAGE_MISSING);
        checkProfile(profileId, userAccount, iDao);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.RECEIVER_NOT_FOUND);

        //
        mCriteria.clear();
        mCriteria.put("token", token);
        List<Friend> friend = iDao.getEntities(Friend.class, queryManager.fetchFriendByToken(), mCriteria, false);
        mCriteria.clear();
        checkNullObject(friend, ExceptionStatus.GROUP_NOT_FOUND);

        if (userAccount == receiver) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        try {
            Chat aChat = new Chat();
            aChat.setCreated(getCurrentTime());
            aChat.setMessage(chat.getMessage());
            aChat.setReceiver(receiver);
            aChat.setSender(userAccount);
            aChat.setChatGroup(Boolean.FALSE);
            aChat = iDao.find(Chat.class, iDao.persist(aChat));

            //webSocket for Chat
            chat(friend.get(0).getToken(), aChat);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.MESSAGE_NOT_ADDED);
        }
        return new GenericResponse(true, "Message Send SuccessFully !!");
    }

    @Override
    public GenericResponse saveGroupChat(UserAccount userAccount, Long profileId, String token, Chat chat, IDao<IEntity, Serializable> iDao) {
        checkNullString(chat.getMessage(), ExceptionStatus.MESSAGE_MISSING);
        checkNullString(token, ExceptionStatus.TOKEN_MISSING);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("token", token);
        ChatGroups groupChat = iDao.getEntity(ChatGroups.class, queryManager.fetchGroupByToken(), mCriteria, false);
        mCriteria.clear();
        checkNullObject(groupChat, ExceptionStatus.GROUP_NOT_FOUND);

        //
        mCriteria.clear();
        mCriteria.put("ChatGroups", groupChat);
        mCriteria.put("user", userAccount);
        ChatGroupMember chatGroupMemberList = iDao.getEntity(ChatGroupMember.class, queryManager.fetchAllGroupMember(), mCriteria, false);
        mCriteria.clear();

        if (chatGroupMemberList == null) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        try {
            Chat aChat = new Chat();
            aChat.setCreated(getCurrentTime());
            aChat.setMessage(chat.getMessage());
            aChat.setSender(userAccount);
            aChat.setChatGroup(Boolean.TRUE);
            aChat.setChatGroups(groupChat);
            aChat.setToken(token);
            aChat = iDao.find(Chat.class, iDao.persist(aChat));

            //webSocket for Chat
            chatGroup(groupChat.getToken(), aChat);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.MESSAGE_NOT_ADDED);
        }
        return new GenericResponse(true, "Message Send SuccessFully !!");
    }

    @Override
    public GenericResponse createGroup(UserAccount userAccount, Long profileId, String groupName, List<UserAccount> userAccounts, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(groupName, ExceptionStatus.GROUP_NAME);
        checkProfile(profileId, userAccount, iDao);
        checkNullObject(userAccounts, ExceptionStatus.MEMBER_NOT_FOUND);

        //
        mCriteria.clear();
        mCriteria.put("name", groupName);
        ChatGroups chatGroupQuery = iDao.getEntity(ChatGroups.class, queryManager.fetchGroup(), mCriteria, false);
        if(chatGroupQuery != null) {
            throw new GenericException(ExceptionStatus.GROUP_ALL_READY_EXISTS);
        }

        ChatGroups chatGroup = new ChatGroups();
        chatGroup.setName(groupName);
        chatGroup.setStatus("ACTIVE");
        chatGroup.setUsers(userAccount);
        chatGroup.setToken(mUtil.getTokenNumber());
        chatGroup.setCreated(getCurrentTime());
        chatGroup = iDao.find(ChatGroups.class, iDao.persist(chatGroup));
        if (chatGroup == null) {
            throw new GenericException(ExceptionStatus.GROUP_NOT_ADDED);
        }


        for (UserAccount user : userAccounts) {
            UserAccount aUserAccount = iDao.find(UserAccount.class, user.getUserId());
            if (aUserAccount == null) {
                throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
            }
            ChatGroupMember chatGroupMember = new ChatGroupMember();
            chatGroupMember.setToken(chatGroup.getToken());
            chatGroupMember.setUser(aUserAccount);
            chatGroupMember.setChatGroups(chatGroup);
            chatGroupMember = iDao.find(ChatGroupMember.class, iDao.persist(chatGroupMember));
        }

        //
        ChatGroupMember chatGroupMembers = new ChatGroupMember();
        chatGroupMembers.setToken(chatGroup.getToken());
        chatGroupMembers.setUser(userAccount);
        chatGroupMembers.setChatGroups(chatGroup);
        chatGroupMembers = iDao.find(ChatGroupMember.class, iDao.persist(chatGroupMembers));

        return new GenericResponse(true, "Group Create SuccessFully !!");
    }
}
