package com.lynkersoft.delzee.utils;

public class QueryManager {
    private QueryManager() {}

    public static QueryManager getInstance() {
        return new QueryManager();
    }

    public String searchFriend() {
        // "SELECT o FROM UserAccount AS o WHERE (o.firstName LIKE :searchValue OR o.lastName LIKE :searchValue) AND o.userId != :userId ";
        return "SELECT o FROM Friend AS o WHERE (o.friendRequestBy = :friendRequestBy OR o.friendRequest = :friendRequestBy) AND ";
    }

    public String fetchGroup() {
        return "SELECT o FROM ChatGroups AS o WHERE o.name = :name";
    }

    public String getHasTag() {
        return "SELECT o FROM HashTag AS o WHERE o.tag = :tag";
    }

    public String fetchFriendByToken() {
        return "SELECT o FROM Friend AS o WHERE o.token = :token";
    }

    public String fetchGroupByToken() {
        return "SELECT o FROM ChatGroups AS o WHERE o.token = :token";
    }

    public String seenAllMessage() {
        return "UPDATE Chat As o SET o.seenOn = :date, o.isChatGroup = :seen WHERE o.sender != :sender";
    }

    public String fetchAllUnSeenMessage() {
        return "SELECT o FROM Chat AS o WHERE o.deleted IS NOT true AND o.sender != :sender AND o.isChatGroup IS FALSE ORDER BY o.created ASC";
    }

    public String seenAllNotification() {
        return "UPDATE Notifications o SET o.seenOn = :date, o.isSeen = :seen WHERE o.blogCreator = :blogCreator";
    }

    public String seenAllNotificationOfBirthDate() {
        return "UPDATE Notifications o SET o.seenOn = :date, o.isSeen = :seen WHERE o.notificationType = :notificationType AND o.isSeen IS FALSE";
    }

    public String getLike() {
        return "SELECT o FROM Notifications AS o WHERE o.likes.blogLikeId = :blogLikeId";
    }

    public String fetchCommentByBlog() {
        return "SELECT o FROM BlogComments AS o WHERE o.deleted IS NOT true AND o.blog = :blog ORDER BY o.created ASC";
    }

    public String fetchFriends() {
        return "SELECT o FROM Friend AS o WHERE  o.friendRequestBy = :friends AND o.friendRequestStatus = :friendRequestStatus ";
    }

    public String fetchFriendRequestStatus() {
        return "SELECT o FROM FriendRequest AS o WHERE (o.sendFriendRequestBy = :sendFriendRequestBy AND o.friendRequestTo = :friendRequestTo) OR (o.sendFriendRequestBy = :friendRequestTo AND o.friendRequestTo = :sendFriendRequestBy) ";
    }

    public String fetchAllGroup() {
        return "SELECT o.ChatGroups FROM ChatGroupMember AS o WHERE o.user = :user";
    }

    public String fetchAllGroupMember() {
        return "SELECT o FROM ChatGroupMember AS o WHERE o.ChatGroups = :ChatGroups AND o.user = :user";
    }

    public String fetchAllGroupMessage() {
        return "SELECT o FROM Chat AS o WHERE o.token = :token AND o.isChatGroup IS true ORDER BY o.created ASC";
    }

    public String fetchAllMessage() {
        return "SELECT o FROM Chat AS o WHERE (o.sender = :sender AND o.receiver = :receiver) OR (o.sender = :receiver AND o.receiver = :sender) ORDER BY o.created ASC";
    }

    public String searchUser() {
        return "SELECT o FROM UserAccount AS o WHERE (o.firstName LIKE :searchValue OR o.lastName LIKE :searchValue) AND o.userId != :userId ";
    }

    public String fetchBlogById() {
        return "SELECT o FROM BlogComments AS o WHERE o.blogId = :blogId";
    }

    public String fetchAllNotification() {
        return " SELECT o FROM Notifications AS o WHERE o.deleted IS NOT true AND o.creator != :creator AND o.blog = :blog ORDER BY o.created DESC";
    }

    public String fetchAllBirthDayNotification() {
        return " SELECT o FROM Notifications AS o WHERE o.deleted IS NOT true AND o.notificationType = :notificationType AND o.blogCreator != :blogCreator ORDER BY o.created DESC";
    }

    public String fetchAllNotificationAccept() {
        return " SELECT o FROM Notifications AS o WHERE o.deleted IS NOT true AND o.notificationType = :notificationType AND o.blogCreator = :blogCreator ORDER BY o.created DESC";
    }

    public String checkLike() {
        return "SELECT o FROM BlogLikes AS o WHERE o.creator = :creator AND o.blog = :blog";
    }

    public String fetchBlogByDESC() {
        return " SELECT o FROM Blog AS o WHERE o.deleted IS NOT true ORDER BY o.created DESC";
    }

    public String fetchImageByUserId() {
        return " SELECT o FROM Attachment AS o WHERE o.createdBy = :createdBy AND o.fileType = :fileType AND o.attachmentFor != :attachmentFor AND o.deleted IS NOT true ORDER BY o.created DESC";
    }
    public String fetchBlogByUserId() {
        return " SELECT o FROM Blog AS o WHERE o.creator = :creator AND o.deleted IS NOT true ORDER BY o.created DESC";
    }

    public String fetchAllBlog() {
        return "SELECT o FROM Blog AS o WHERE o.creator = :creator";
    }
    public String checkForgetToken() {
        return "SELECT o FROM ForgotPassword AS o WHERE o.forgotToken = :forgotToken";
    }

    public String findFriendRequest() {
        return "SELECT o FROM FriendRequest AS o WHERE o.friendRequestTo = :friendRequestTo AND o.friendRequestStatus = :friendRequestStatus";
    }
    public String getEmailAddress() {
        return "SELECT o FROM UserAccount AS o WHERE o.emailAddress = :emailAddress";
    }

    public String getUsersByUserName() {
        return "SELECT o FROM UserAccount AS o WHERE o.userName = :userName";
    }

    public String checkUserNameAndPassword() {
        return "SELECT o FROM UserAccount AS o WHERE (o.userName = :userName OR o.emailAddress = :userName) AND o.password = :password AND o.userEnabled IS TRUE";
    }
    public String getFriendRequestUser() {
        return "SELECT o FROM FriendRequest AS o WHERE o.sendFriendRequestBy.userId = :userIds AND o.friendRequestTo.userId = :friedRequestId";
    }
    public String getHobbiesTag() {
        return "SELECT o FROM Hobbie AS o WHERE o.tagName = :tagName AND o.profile = :profile";
    }
}
