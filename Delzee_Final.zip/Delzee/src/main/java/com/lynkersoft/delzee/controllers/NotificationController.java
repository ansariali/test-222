package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.dto.notificationController.FetchAllNotifications;
import com.lynkersoft.delzee.dto.notificationController.entity.Blog;
import com.lynkersoft.delzee.service.BlogService;
import com.lynkersoft.delzee.service.NotificationService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@CrossOrigin
@RestController
@RequestMapping("/notificationController/v1/")
public class NotificationController extends GenericController {
    @Autowired
    NotificationService notificationService;

    private Logger logger = LoggerFactory.getLogger(NotificationController.class);

    @GetMapping(value = "fetch/all/{userId}")
    public ResponseEntity<FetchAllNotifications> fetchAllNotification(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllNotification ");
        return new ResponseEntity<>(dozerBeanMapper.map(notificationService.fetchAll(verifySession(userId, requestHeader), profileId, iDao), FetchAllNotifications.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "blog/ById/{userId}")
    public ResponseEntity<Blog> fetchBlogById(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestParam Long NotificationId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchBlogById :");
        return new ResponseEntity<>(dozerBeanMapper.map(notificationService.fetchBlogById(verifySession(userId, requestHeader), profileId, blogId, NotificationId, iDao), Blog.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "seenAll/notification/{userId}")
    public ResponseEntity<GenericResponse> allNotificationSeen(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside allNotificationSeen ");
        return new ResponseEntity<>(notificationService.allNotificationSeen(verifySession(userId, requestHeader), profileId, iDao), responseHeaders, HttpStatus.OK);
    }
}
