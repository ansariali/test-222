package com.lynkersoft.delzee.dto.common;

public class _User {
    private Long userId;
    private String firstName;
    private String lastName;
    private Attachment_ attachment;
    private Profile_ profile;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Attachment_ getAttachment() {
        return attachment;
    }

    public void setAttachment(Attachment_ attachment) {
        this.attachment = attachment;
    }

    public Profile_ getProfile() {
        return profile;
    }

    public void setProfile(Profile_ profile) {
        this.profile = profile;
    }
}
