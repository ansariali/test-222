package com.lynkersoft.delzee.dto.common;

import com.lynkersoft.delzee.utils.enums.NotificationType;

import java.util.Date;

public class NotificationEntity {

    private Long notificationId;
    private String privacyType;
    private NotificationType notificationType;
    private String message;
    private Date created;
    private Boolean isSeen = Boolean.FALSE;
    private Date seenOn;
    private User_ creator;
//    private User_ receiver;
    private Profile_ profile;
    private Blog_ blog;

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public Long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public String getPrivacyType() {
        return privacyType;
    }

    public void setPrivacyType(String privacyType) {
        this.privacyType = privacyType;
    }

    public NotificationType getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(NotificationType notificationType) {
        this.notificationType = notificationType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Boolean getSeen() {
        return isSeen;
    }

    public void setSeen(Boolean seen) {
        isSeen = seen;
    }

    public Date getSeenOn() {
        return seenOn;
    }

    public void setSeenOn(Date seenOn) {
        this.seenOn = seenOn;
    }

    public Blog_ getBlog() {
        return blog;
    }

    public void setBlog(Blog_ blog) {
        this.blog = blog;
    }

    public Profile_ getProfile() {
        return profile;
    }

    public void setProfile(Profile_ profile) {
        this.profile = profile;
    }
}
