package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "chat")
public class Chat extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatId;

    private String message;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender")
    private UserAccount sender;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver")
    private UserAccount receiver;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "chatGroupId")
    private ChatGroups chatGroups;

    private Boolean isChatGroup;

    private Date created;

    private Date seenOn;

    private Boolean seenStatus;

    private String token;

//    private Date deletedDate;


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getSeenOn() {
        return seenOn;
    }

    public void setSeenOn(Date seenOn) {
        this.seenOn = seenOn;
    }

    public Boolean getSeenStatus() {
        return seenStatus;
    }

    public void setSeenStatus(Boolean seenStatus) {
        this.seenStatus = seenStatus;
    }

    public Boolean getChatGroup() {
        return isChatGroup;
    }

    public void setChatGroup(Boolean chatGroup) {
        isChatGroup = chatGroup;
    }

    public ChatGroups getChatGroups() {
        return chatGroups;
    }

    public void setChatGroups(ChatGroups chatGroups) {
        this.chatGroups = chatGroups;
    }

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
