package com.lynkersoft.delzee.dto.hashTagController.entity;

import com.lynkersoft.delzee.dto.notificationController.entity.Blog;

public class HashTagMember {
    private Long hashTagMemberId;
    private Blog blog;

    public Long getHashTagMemberId() {
        return hashTagMemberId;
    }

    public void setHashTagMemberId(Long hashTagMemberId) {
        this.hashTagMemberId = hashTagMemberId;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }

}
