package com.lynkersoft.delzee.dto.common;

import com.lynkersoft.delzee.dto.userController.entity.Address;
import com.lynkersoft.delzee.dto.userController.entity.Education;
import com.lynkersoft.delzee.dto.userController.entity.Hobbie;

import java.util.ArrayList;
import java.util.List;

public class Profile_ {
    private Long profileId;
    private Integer totalNotification;
    private Integer totalUnseenNotification;
    private String occupation;
    private String aboutMe;
    private List<Address> address = new ArrayList<>();
    private List<Education> educations = new ArrayList<>();
    private List<Hobbie> hobbies = new ArrayList<>();

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public List<Education> getEducations() {
        return educations;
    }

    public void setEducations(List<Education> educations) {
        this.educations = educations;
    }

    public List<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(List<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Integer getTotalNotification() {
        return totalNotification;
    }

    public void setTotalNotification(Integer totalNotification) {
        this.totalNotification = totalNotification;
    }

    public Integer getTotalUnseenNotification() {
        return totalUnseenNotification;
    }

    public void setTotalUnseenNotification(Integer totalUnseenNotification) {
        this.totalUnseenNotification = totalUnseenNotification;
    }
}
