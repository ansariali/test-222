package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;

public interface CommonService {
        Object fetchHasTag(UserAccount userAccount, Long profileId, String hashTag, IDao<IEntity, Serializable> iDao);
        GenericResponse createFollow(UserAccount userAccount, Long profileId, Long friendId, String followStatus, IDao<IEntity, Serializable> iDao);
        GenericResponse unFollow(UserAccount userAccount, Long profileId, Long followId, String followStatus, IDao<IEntity, Serializable> iDao);
        Object fetchWeather( String cityName, IDao<IEntity, Serializable> iDao);
        Object fetchForecast(String forecast, IDao<IEntity, Serializable> iDao);
        Object fetchMusicList(IDao<IEntity, Serializable> iDao);
}
