package com.lynkersoft.delzee.utils.enums;

public enum FollowStatus {
    FOLLOW, UNFOLLOW, BLOCK;
}
