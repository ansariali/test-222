package com.lynkersoft.delzee.dto.blogController.entity;

import com.lynkersoft.delzee.dto.common.User_;
import com.lynkersoft.delzee.dto.common._Profile;
import com.lynkersoft.delzee.dto.userController.entity.BlogLikes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Blog {
    private Long blogId;
    private String description;
    private Date created;
    private User_ creator;
    private _Profile profile;
    private Integer totalLikes;
    private Integer totalComments;
    private Integer totalShare;
    private boolean hasTagStatus;
    private List<Attachment> attachments = new ArrayList<>();
    private List<BlogLikes> likes = new ArrayList<>();

    public boolean isHasTagStatus() {
        return hasTagStatus;
    }

    public void setHasTagStatus(boolean hasTagStatus) {
        this.hasTagStatus = hasTagStatus;
    }

    public List<BlogLikes> getLikes() {
        return likes;
    }

    public void setLikes(List<BlogLikes> likes) {
        this.likes = likes;
    }

    public _Profile getProfile() {
        return profile;
    }

    public void setProfile(_Profile profile) {
        this.profile = profile;
    }

    public Long getBlogId() {
        return blogId;
    }

    public void setBlogId(Long blogId) {
        this.blogId = blogId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getTotalLikes() {
        return totalLikes;
    }

    public void setTotalLikes(Integer totalLikes) {
        this.totalLikes = totalLikes;
    }

    public Integer getTotalComments() {
        return totalComments;
    }

    public void setTotalComments(Integer totalComments) {
        this.totalComments = totalComments;
    }

    public Integer getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Integer totalShare) {
        this.totalShare = totalShare;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }
}
