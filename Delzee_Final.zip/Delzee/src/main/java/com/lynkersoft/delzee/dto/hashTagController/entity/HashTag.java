package com.lynkersoft.delzee.dto.hashTagController.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HashTag {
    private Long hashTagId;
    private String tag;
    private Date created;
    List<HashTagMember> hashTagMembers = new ArrayList<>();

    public Long getHashTagId() {
        return hashTagId;
    }

    public void setHashTagId(Long hashTagId) {
        this.hashTagId = hashTagId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public List<HashTagMember> getHashTagMembers() {
        return hashTagMembers;
    }

    public void setHashTagMembers(List<HashTagMember> hashTagMembers) {
        this.hashTagMembers = hashTagMembers;
    }
}
