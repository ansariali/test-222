package com.lynkersoft.delzee.utils.enums;

public enum FetchingType {
    BY_ME, BY_OTHER
}
