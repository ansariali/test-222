package com.lynkersoft.delzee.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;


public interface S3StorageService {
    String uploadFileByte(String prefix, File file, String fileName) throws IOException;

    String generateFileKeyByte(String prefix, File file, String fileName) throws IOException;

    String uploadFile(String prefix, MultipartFile multipartFile) throws IOException;

    File convertMultiPartToFile(MultipartFile file) throws IOException;

    String generateFileKey(String prefix, MultipartFile multiPart);


}
