import { LayoutComponent } from '../layout/layout.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';

export const routes = [

    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: '/login', pathMatch: 'full' },
            { path: 'user', loadChildren: './user-profile/user-profile.module#UserProfileModule' }
        ]
    },

    { path: 'login', component: LoginComponent },
    { path: 'register', component: SignupComponent },
    { path: 'forgot-password', component: ForgotPasswordComponent },
    
    // Not found
    { path: '**', redirectTo: 'login' }

];
