
const Home = {
    text: 'Home',
    link: '/home',
    icon: 'icon-home'
};

export const menu = [
    Home
];
