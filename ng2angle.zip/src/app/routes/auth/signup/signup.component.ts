import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/shared/services/auth.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ToasterService } from 'angular2-toaster';
import { EventsService } from 'src/app/shared/services/events.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signupForm: FormGroup;
  isSubmitted: boolean = false;

  constructor(
    private title: Title,
    private router: Router,
    private formBuilder: FormBuilder,
    public auth: AuthService,
    private event: EventsService,
    private toasterService: ToasterService
  ) {
    this.title.setTitle('Signup | Dalzee');
  }

  ngOnInit() {

    this.signupForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$'), Validators.minLength(2), Validators.maxLength(40)]],
      lastName: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$'), Validators.minLength(2), Validators.maxLength(40)]],
      phone: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      Email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
      Password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]]
    });
  }

  onSubmit(isValid) {
    const value = this.signupForm.value;
    this.isSubmitted = true;
    console.log('>>>FormValuessss', this.signupForm);
    if (isValid) {
      let obj = {
        first_name: value.first_name,
        last_name: value.last_name,
        email: value.email,
        password: value.password,
        mobile_no: value.phone,
      };

      this.event.broadcast('loader:show');
      this.auth.register(obj).subscribe(res => {
        this.event.broadcast('loader:hide');
        localStorage.setItem('token', res.body.token);
        this.router.navigate(['/login']);
        this.toasterService.pop('success', 'Success', '');
      }, err => {
        this.event.broadcast('loader:hide');
        console.log('>>Error', err);
        this.toasterService.pop('error', 'Error', '');
      });
    }
  }
}
