import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SettingsService } from 'src/app/core/settings/settings.service';
import { AuthService } from 'src/app/shared/services/auth.service';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { EventsService } from 'src/app/shared/services/events.service';
import { ToasterService } from 'angular2-toaster';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  valForm: FormGroup;
  isSubmitted: boolean = false;

  constructor(
    private title: Title,
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private formBuilder: FormBuilder,
    private event: EventsService,
    private toasterService: ToasterService
  ) {

    this.title.setTitle('Forgot-Password | Dalzee');
    this.valForm = fb.group({
      'email': [null, Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])]
    });
  }

  ngOnInit() {
  }

  submitForm(isValid) {
    if (isValid) {
      this.event.broadcast('loader:show');
      this.authService.forogotPassword('').subscribe(res => {
        this.event.broadcast('loader:hide');
        console.log('>>>>Res', res);
        this.toasterService.pop('success', 'Success', res.body.message);
        this.router.navigate(['/login']);
      }, err => {
        this.toasterService.pop('error', 'Error', '');
        this.event.broadcast('loader:hide');
        console.log('>>>>Err', err);
      });
    }
  }

}

