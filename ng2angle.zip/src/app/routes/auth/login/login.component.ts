import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/shared/services/auth.service';
import { ToasterService } from 'angular2-toaster';
import { EventsService } from 'src/app/shared/services/events.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    loginForm: FormGroup;
    isSubmitted: boolean = false;

    constructor(
        private title: Title,
        private router: Router,
        private formBuilder: FormBuilder,
        public auth: AuthService,
        private event: EventsService,
        private toasterService: ToasterService
    ) {
        this.title.setTitle('Login | Dalzee');
    }

    ngOnInit() {
        this.loginForm = this.formBuilder.group({
            email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
            password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(25)]]
        });

        if (localStorage.getItem('token')) {
            this.router.navigate(['/trucker-setup']);
        }
    }
    get formControls() {
        return this.loginForm.controls;
    }
    onSubmit(isValid) {
        const v = this.loginForm.value;
        this.isSubmitted = true;

        if (isValid) {
            
            let obj = {
                userName: v.email,
                password: v.password
            };
    
            this.event.broadcast('loader:show');
            this.auth.login(obj).subscribe(res => {
                this.event.broadcast('loader:hide');
                console.log('>>>>Res', res);
                localStorage.setItem('token', res.body.accessToken);
                localStorage.setItem('userInfo', JSON.stringify(res.body.user));
                localStorage.setItem('profileInfo', JSON.stringify(res.body.profile));
                this.toasterService.pop('success', 'Success', res.body.message);
                this.router.navigate(['/user']);
            }, err => {
                this.event.broadcast('loader:hide');
                console.log('>>Error', err);
                this.toasterService.pop('error', 'Error', 'Somewrong');
            });
        }
    }
}
