import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-edit',
  templateUrl: './about-edit.component.html',
  styleUrls: ['./about-edit.component.scss']
})
export class AboutEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
