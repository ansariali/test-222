import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about.component';
import { AboutAddComponent } from './about-components/about-add/about-add.component';
import { AboutEditComponent } from './about-components/about-edit/about-edit.component';

const routes: Routes = [
  { path: '', component: AboutComponent },
  { path: 'add', component: AboutAddComponent },
  { path: 'edit', component: AboutEditComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AboutRoutingModule { }
