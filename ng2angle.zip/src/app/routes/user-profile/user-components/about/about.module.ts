import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutAddComponent } from './about-components/about-add/about-add.component';
import { AboutEditComponent } from './about-components/about-edit/about-edit.component';
import { AboutRoutingModule } from './about-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { AboutComponent } from './about.component';

@NgModule({
  declarations: [AboutComponent, AboutAddComponent, AboutEditComponent],
  imports: [
    CommonModule,
    SharedModule,
    AboutRoutingModule
  ]
})
export class AboutModule { }
