import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { FriendsComponent } from './friends/friends.component';
import { PhotosComponent } from './photos/photos.component';
import { VideosComponent } from './videos/videos.component';
import { UserProfileComponent } from '../user-profile.component';

const routes: Routes = [
  { path: '', component: UserProfileComponent },
  { path: 'news-feed', component: NewsFeedComponent },
  { path: 'about', loadChildren: './about/about.module#AboutModule' },
  { path: 'friends', component: FriendsComponent },
  { path: 'photos', component: PhotosComponent },
  { path: 'videos', component: VideosComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class UserProfileRoutingModule { }
