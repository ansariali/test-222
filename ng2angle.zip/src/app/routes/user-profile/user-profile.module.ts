import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserProfileComponent } from './user-profile.component';
import { NewsFeedComponent } from './user-components/news-feed/news-feed.component';
import { FriendsComponent } from './user-components/friends/friends.component';
import { PhotosComponent } from './user-components/photos/photos.component';
import { VideosComponent } from './user-components/videos/videos.component';
import { UserProfileRoutingModule } from './user-components/user-profile-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [UserProfileComponent, NewsFeedComponent, FriendsComponent, PhotosComponent, VideosComponent],
  imports: [
    CommonModule,
    SharedModule,
    UserProfileRoutingModule
  ]
})
export class UserProfileModule { }
