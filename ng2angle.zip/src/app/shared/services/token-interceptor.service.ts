import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
// import { EventsService } from './events.service';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService {

  constructor(
    private router: Router,
    // private event: EventsService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const token = localStorage.getItem('token');

    req = req.clone({
      setHeaders: {
        'ACCESS-TOKEN': `${token}`
      }
    });

    return next.handle(req).pipe(catchError((error: any, caught: Observable<HttpEvent<any>>) => {
      if (error.status === 401) {
        this.notification(error);
        localStorage.removeItem('token');
        this.router.navigate(['/login']);
        // this.event.broadcast('loader:hide');
        return of(error);
      } else {
        this.notification(error);
      }

      throw error;
    }));
  }

  private notification(content: any) {
    // this.snackBar.open(content.error.error ? content.error.error : content.message, '', {
    //     duration: 5000,
    // });
  }
}
