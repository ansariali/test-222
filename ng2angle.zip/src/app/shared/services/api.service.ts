import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  get(path: string): Observable<any> {
    return this.http.get<any>(`${environment.baseUrl}/${path}`, { observe: 'response' })
      .pipe(map(res => res));
  }

  put(path: string, param: object): Observable<any> {
    return this.http.put<any>(`${environment.baseUrl}/${path}`, param, { observe: 'response' })
      .pipe(map(res => res));
  }

  post(path: string, param: object): Observable<any> {
    return this.http.post<any>(`${environment.baseUrl}/${path}`, param, { observe: 'response' })
      .pipe(map(res => res));
  }

  patch(path: string, param: object): Observable<any> {
    return this.http.patch<any>(`${environment.baseUrl}/${path}`, param, { observe: 'response' })
      .pipe(map(res => res));
  }

  delete(path: string): Observable<HttpResponse<any>> {
    return this.http.delete<any>(`${environment.baseUrl}/${path}`, { observe: 'response' })
      .pipe(map(res => res));
  }

  upload(url, data) {

    const formData = new FormData();

    formData.append('file', data.file);
    formData.append('trucker_document_id', data.trucker_document_id);

    return this.http.post<any>(url, formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(map((event) => {

      switch (event.type) {

        case HttpEventType.UploadProgress:
          const progress = Math.round(100 * event.loaded / event.total);
          return { status: 'progress', progress: progress };

        case HttpEventType.Response:
          return event.body;
        default:
          return `Unhandled event: ${event.type}`;
      }
    }));
  }
}
