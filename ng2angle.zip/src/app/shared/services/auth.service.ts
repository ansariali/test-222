import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = 'userController/v1/';

  constructor(private api: ApiService) { }

  register(data) {
    return this.api.post(this.url + 'sign-up', data);
  }

  login(data){
    return this.api.post(this.url + 'sign-in', data);
  }

  forogotPassword(data){
    return this.api.post(this.url + 'forgot-password', data);
  }

  logout() {
    return this.api.post(this.url + 'sign-out', {});
  }
}
