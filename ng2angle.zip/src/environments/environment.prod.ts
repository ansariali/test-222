export const environment = {
  production: true,
  baseUrl: 'https://test.easeprocure.com/'
};
