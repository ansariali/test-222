package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;

import javax.persistence.*;

@Entity
@Table(name = "Hobbies")
public class Hobbie extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long hobbiesId;
    private String name;
    private  String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_id")
    private Profile  profile;

    public Long getHobbiesId() {
        return hobbiesId;
    }

    public void setHobbiesId(Long hobbiesId) {
        this.hobbiesId = hobbiesId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
}
