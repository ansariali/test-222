package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;
import com.lynkersoft.dlzee.utils.enums.FriendRequestStatus;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "friend")
public class Friend extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long friendId;

    @NotNull(message = "friend request status must be required!")
    @Enumerated(EnumType.STRING)
    private FriendRequestStatus friendRequestStatus;

    private Boolean friendRequestAcceptedStatus;

    private Date friendRequestAcceptedDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "send_friend_Request_by")
    private UserAccount sendFriendRequestBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friend_Request_Accepted_to")
    private UserAccount friendRequestAcceptedTo;


    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public FriendRequestStatus getFriendRequestStatus() {
        return friendRequestStatus;
    }

    public void setFriendRequestStatus(FriendRequestStatus friendRequestStatus) {
        this.friendRequestStatus = friendRequestStatus;
    }

    public Boolean getFriendRequestAcceptedStatus() {
        return friendRequestAcceptedStatus;
    }

    public void setFriendRequestAcceptedStatus(Boolean friendRequestAcceptedStatus) {
        this.friendRequestAcceptedStatus = friendRequestAcceptedStatus;
    }

    public Date getFriendRequestAcceptedDate() {
        return friendRequestAcceptedDate;
    }

    public void setFriendRequestAcceptedDate(Date friendRequestAcceptedDate) {
        this.friendRequestAcceptedDate = friendRequestAcceptedDate;
    }

    public UserAccount getSendFriendRequestBy() {
        return sendFriendRequestBy;
    }

    public void setSendFriendRequestBy(UserAccount sendFriendRequestBy) {
        this.sendFriendRequestBy = sendFriendRequestBy;
    }

    public UserAccount getFriendRequestAcceptedTo() {
        return friendRequestAcceptedTo;
    }

    public void setFriendRequestAcceptedTo(UserAccount friendRequestAcceptedTo) {
        this.friendRequestAcceptedTo = friendRequestAcceptedTo;
    }
}
