package com.lynkersoft.dlzee.controllers;

import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.dto.userController.entity.Token;
import com.lynkersoft.dlzee.dto.userController.entity.User;
import com.lynkersoft.dlzee.entities.FriendRequest;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.utils.GenericController;
import com.lynkersoft.dlzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/userController")
public class UserAccountController extends GenericController {

    @Autowired
    UserAccountService userAccountService;
    private Logger logger = LoggerFactory.getLogger(UserAccountController.class);

    @PostMapping(value = "/v1/sign-up")
    public ResponseEntity<GenericResponse> signUp(@Valid @RequestBody UserAccount signUpRequest) {
        logger.info("Inside signUp :");
        return new ResponseEntity<>(userAccountService.signUp(signUpRequest, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/sign-in")
    public ResponseEntity<LoginResponseEntity> signIn(@RequestBody UserAccount signUpRequest) {
        logger.info("Inside signIn :");
        return new ResponseEntity<>(userAccountService.signIn(signUpRequest.getUserName(), signUpRequest.getPassword(), iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/sign-Out")
    public ResponseEntity<GenericResponse> signOut(@RequestBody Token token) {
        logger.info("Inside signOut :");
        return new ResponseEntity<>(userAccountService.signOut(token.getAccessToken(), iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/forgotPassword/emailAddress")
    public ResponseEntity<GenericResponse> forgotPassword(@RequestParam String emailAddress) {
        logger.info("Inside forgotPassword");
        return new ResponseEntity<>(userAccountService.forgotPassword(emailAddress, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/fetch/byId")
    public ResponseEntity<User> fetchUserByPrivacy(@RequestParam Long userId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchUserByPrivacy");
        return new ResponseEntity<>(dozerBeanMapper.map(userAccountService.fetchUserByPrivacy(verifySession(userId, requestHeader), iDao), User.class), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/send/friend-request")
    public ResponseEntity<GenericResponse> sendFriendRequest(@Valid @RequestParam Long userId, @RequestParam Long friendId, @RequestHeader Map<String, Object> requestHeader, @RequestBody FriendRequest friedRequest) {
        logger.info("Inside sendFriendRequest");
        return new ResponseEntity<>(userAccountService.sendFriendRequest(verifySession(userId, requestHeader), friedRequest, friendId, iDao), responseHeaders, HttpStatus.OK);
    }

}
