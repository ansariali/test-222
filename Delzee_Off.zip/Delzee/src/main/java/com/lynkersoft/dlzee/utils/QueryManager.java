package com.lynkersoft.dlzee.utils;

public class QueryManager {
    private QueryManager() {}

    public static QueryManager getInstance() {
        return new QueryManager();
    }

    public String getEmailAddress() {
        return "SELECT o FROM UserAccount AS o WHERE o.emailAddress = :emailAddress";
    }

    public String getUsersByUserName() {
        return "SELECT o FROM UserAccount AS o WHERE o.userName = :userName";
    }

    public String checkUserNameAndPassword() {
        return "SELECT o FROM UserAccount AS o WHERE (o.userName = :userName OR o.emailAddress = :userName) AND o.password = :password AND o.userEnabled IS TRUE";
    }

    public String getFriendRequestUser() {
        return "SELECT o FROM FriendRequest AS o WHERE o.sendFriendRequestBy = :sendFriendRequestBy AND o.friendRequestTo = :friendRequestTo";
    }


}
