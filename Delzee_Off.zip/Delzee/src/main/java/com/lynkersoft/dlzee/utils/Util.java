package com.lynkersoft.dlzee.utils;

import com.lynkersoft.dlzee.controllers.UserAccountController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Random;
import java.util.UUID;

public class Util {

    private Logger mLogger = LoggerFactory.getLogger(UserAccountController.class);

    public static Util getInstance() {
        return new Util();
    }

    public String getDefaultTimeZone() {
        return TimeZone.DEFAULT.getTimeZone();
    }

    public Date getCurrentTime() {
        return new Date();
    }


    public String getTokenNumber() {
        try {
            return UUID.randomUUID().toString();
        } catch (Exception e) {
            return null;
        }
    }

    public Integer getOtpNumber() {
        try {
            Random rnd = new Random();

            Long time = new Date().getTime();

            String a = "" + String.valueOf(time).charAt(7);
            String b = "" + String.valueOf(time).charAt(8);
            String c = "" + String.valueOf(time).charAt(9);
            String d = "" + String.valueOf(time).charAt(10);
            String e = "" + String.valueOf(time).charAt(11);
            String f = "" + String.valueOf(time).charAt(12);

            Integer newNumber = Integer.valueOf(a + b + c + d + e + f);

            return newNumber + rnd.nextInt(99999);
        } catch (Exception e) {
            mLogger.error(e.getMessage());
            return 0;
        }
    }
}
