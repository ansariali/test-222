package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;

import javax.persistence.*;

@Entity
@Table(name = "comment_likes")
public class CommentLikes extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long commentLikeId;

    private Boolean liked;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount usersId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "commentId")
    private BlogComments commentId;


    public Long getCommentLikeId() {
        return commentLikeId;
    }

    public void setCommentLikeId(Long commentLikeId) {
        this.commentLikeId = commentLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public UserAccount getUsersId() {
        return usersId;
    }

    public void setUsersId(UserAccount usersId) {
        this.usersId = usersId;
    }

    public BlogComments getCommentId() {
        return commentId;
    }

    public void setCommentId(BlogComments commentId) {
        this.commentId = commentId;
    }
}
