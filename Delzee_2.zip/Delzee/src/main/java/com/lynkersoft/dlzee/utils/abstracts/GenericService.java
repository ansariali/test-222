package com.lynkersoft.dlzee.utils.abstracts;

import com.lynkersoft.dlzee.entities.FriendRequest;
import com.lynkersoft.dlzee.entities.Session;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.EmailService;
import com.lynkersoft.dlzee.utils.QueryManager;
import com.lynkersoft.dlzee.utils.Refactor;
import com.lynkersoft.dlzee.utils.Util;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;

@Service
@Transactional
public abstract class GenericService {

    protected Hashtable<String, Object> mCriteria = new Hashtable<>();
    protected QueryManager queryManager = QueryManager.getInstance();
    protected static Util mUtil = Util.getInstance();
    protected static Refactor mRefactor = Refactor.getInstance();
    protected DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();

    @Autowired
    protected EmailService mEmailService;


    //checkFriendAvailableOrNot
    protected void checkFriendAvailableOrNot(Long friedRequestId, Long userId, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("sendFriendRequestBy", friedRequestId);
        mCriteria.put("friendRequestTo", userId);
        FriendRequest friendRequest = iDao.getEntity(FriendRequest.class, queryManager.getFriendRequestUser(), mCriteria, false);
        mCriteria.clear();
        if (friendRequest != null) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_SEND);
        }
    }

    //Check Email
    protected UserAccount checkEmailId(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_NOT_FOUND);
        }

        if(!users.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ACTIVE);
        }

        return users;
    }


    //Fetch Email
    protected void findEmailAddress(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_IS_TAKEN);
        }
    }

    //Check UserName
    protected void findUserName(String userName, IDao<IEntity, Serializable> iDao) {
        if (userName == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("userName", userName);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getUsersByUserName(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_TAKEN);
        }
    }

    //Check Login
    protected Session checkLoginSession(String accessToken, IDao<IEntity, Serializable> iDao) {
        if (accessToken == null) {
            throw new GenericException(ExceptionStatus.ACCESS_TOKEN_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("accessToken", accessToken);
        Session aSession = iDao.getEntity(Session.class, "SELECT o FROM Session AS o WHERE o.accessToken = :accessToken", mCriteria, false);
        mCriteria.clear();
        if (aSession == null) {
            throw new GenericException(ExceptionStatus.USER_SESSION_NOT_FOUND);
        }

        if (!aSession.getSignIn()) {
            throw new GenericException(ExceptionStatus.USER_ALL_READY_SIGN_OUT);
        }

        return aSession;
    }


    //CheckUserName And Password
    protected UserAccount checkUserNameAndPassword(String userName, String password, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("userName", userName);
        mCriteria.put("password", password);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.checkUserNameAndPassword(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);
        } else {
            return  users;
        }
    }


    protected void checkNullObject(Object object, ExceptionStatus exceptionStatus) {
        if (object == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullLongId(Long id, ExceptionStatus exceptionStatus) {
        if (id == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullString(String s, ExceptionStatus exceptionStatus) {
        if (s == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullDate(Date date, ExceptionStatus exceptionStatus) {
        if (date == null) {
            throw new GenericException(exceptionStatus);
        }
    }
}
