package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;
import com.lynkersoft.dlzee.utils.enums.Privacy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "profile")
public class Profile extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long profileId;

    private Integer totalSendFriendRequest;
    private Integer totalFriendRequest;
    private Integer totalFriend;
    private Integer totalImage;
    private Integer totalVideo;
    private Integer totalShare;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy addressPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy hobbyPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy friendPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy educationPrivacy;

    private String aboutMe;
    @NotNull(message = "About privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy aboutMePrivacy;

    private String mobileNumber;
    @Enumerated(EnumType.STRING)
    private Privacy mobileNumberPrivacy;

    private String birthDate;
    @Enumerated(EnumType.STRING)
    private Privacy birthDatePrivacy;

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Privacy getMobileNumberPrivacy() {
        return mobileNumberPrivacy;
    }

    public void setMobileNumberPrivacy(Privacy mobileNumberPrivacy) {
        this.mobileNumberPrivacy = mobileNumberPrivacy;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public Privacy getBirthDatePrivacy() {
        return birthDatePrivacy;
    }

    public void setBirthDatePrivacy(Privacy birthDatePrivacy) {
        this.birthDatePrivacy = birthDatePrivacy;
    }

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Address> address = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Education> educations = new HashSet<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Hobbie>  hobbies = new HashSet<>();

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public Privacy getAboutMePrivacy() {
        return aboutMePrivacy;
    }

    public void setAboutMePrivacy(Privacy aboutMePrivacy) {
        this.aboutMePrivacy = aboutMePrivacy;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }

    public Set<Address> getAddress() {
        return address;
    }

    public void setAddress(Set<Address> address) {
        this.address = address;
    }

    public Set<Education> getEducations() {
        return educations;
    }

    public void setEducations(Set<Education> educations) {
        this.educations = educations;
    }

    public Set<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(Set<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }

    public Integer getTotalSendFriendRequest() {
        return totalSendFriendRequest;
    }

    public void setTotalSendFriendRequest(Integer totalSendFriendRequest) {
        this.totalSendFriendRequest = totalSendFriendRequest;
    }

    public Integer getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Integer totalShare) {
        this.totalShare = totalShare;
    }

    public Integer getTotalFriendRequest() {
        return totalFriendRequest;
    }

    public void setTotalFriendRequest(Integer totalFriendRequest) {
        this.totalFriendRequest = totalFriendRequest;
    }

    public Integer getTotalFriend() {
        return totalFriend;
    }

    public void setTotalFriend(Integer totalFriend) {
        this.totalFriend = totalFriend;
    }

    public Integer getTotalImage() {
        return totalImage;
    }

    public void setTotalImage(Integer totalImage) {
        this.totalImage = totalImage;
    }

    public Integer getTotalVideo() {
        return totalVideo;
    }

    public void setTotalVideo(Integer totalVideo) {
        this.totalVideo = totalVideo;
    }
}
