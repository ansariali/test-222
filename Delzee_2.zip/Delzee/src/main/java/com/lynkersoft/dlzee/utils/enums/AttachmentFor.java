package com.lynkersoft.dlzee.utils.enums;

public enum AttachmentFor {
    BLOGGING, CHAT, PROFILE_PICTURE
}
