package com.lynkersoft.dlzee.service;

import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.dto.userController.entity.User;
import com.lynkersoft.dlzee.entities.FriendRequest;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;

import java.io.Serializable;

public interface UserAccountService {
    GenericResponse signUp(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao);

    GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao);

    GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao);

    UserAccount fetchUserById(UserAccount userAccount, Long userId, IDao<IEntity, Serializable> iDao);

    User fetchUserByPrivacy(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    GenericResponse sendFriendRequest(UserAccount userAccount, FriendRequest friendRequest, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse friendRequestAccept(UserAccount userAccount, Long friedRequestId, IDao<IEntity, Serializable> iDao);
}
