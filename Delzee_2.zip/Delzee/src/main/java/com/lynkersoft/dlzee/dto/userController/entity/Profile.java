package com.lynkersoft.dlzee.dto.userController.entity;

import com.lynkersoft.dlzee.utils.enums.Privacy;

import java.util.ArrayList;
import java.util.List;

public class Profile {
    private Long profileId;
    private Privacy addressPrivacy;
    private Privacy hobbyPrivacy;
    private Privacy friendPrivacy;
    private Privacy educationPrivacy;

    private String aboutMe;
    private Privacy aboutMePrivacy;

    private String mobileNumber;
    private Privacy  mobileNumberPrivacy;

    private String birthDate;
    private Privacy birthDatePrivacy;

    private List<Address> address = new ArrayList<>();
    private List<Education> educations = new ArrayList<>();
    private List<Hobbie> hobbies = new ArrayList<>();

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public Privacy getAboutMePrivacy() {
        return aboutMePrivacy;
    }

    public void setAboutMePrivacy(Privacy aboutMePrivacy) {
        this.aboutMePrivacy = aboutMePrivacy;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Privacy getMobileNumberPrivacy() {
        return mobileNumberPrivacy;
    }

    public void setMobileNumberPrivacy(Privacy mobileNumberPrivacy) {
        this.mobileNumberPrivacy = mobileNumberPrivacy;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public Privacy getBirthDatePrivacy() {
        return birthDatePrivacy;
    }

    public void setBirthDatePrivacy(Privacy birthDatePrivacy) {
        this.birthDatePrivacy = birthDatePrivacy;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public List<Education> getEducations() {
        return educations;
    }

    public void setEducations(List<Education> educations) {
        this.educations = educations;
    }

    public List<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(List<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }
}
