package com.lynkersoft.dlzee.utils.exception.enums;

public enum ErrorType {
    INFO("Information"), ERR("Error"), WARN("Warning");

    private final String type;

    ErrorType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
