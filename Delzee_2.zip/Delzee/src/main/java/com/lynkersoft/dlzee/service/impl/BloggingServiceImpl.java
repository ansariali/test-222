package com.lynkersoft.dlzee.service.impl;

import com.lynkersoft.dlzee.service.BloggingService;
import com.lynkersoft.dlzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.Map;

public class BloggingServiceImpl extends GenericImplHandler implements BloggingService {
    @Override
    public GenericResponse createBlogging(Map<String, Object> requestHeader, MultipartFile[] files, IDao<IEntity, Serializable> iDao) {
        return null;
    }
}
