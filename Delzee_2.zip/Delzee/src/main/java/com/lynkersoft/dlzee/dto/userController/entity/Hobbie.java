package com.lynkersoft.dlzee.dto.userController.entity;

public class Hobbie {

    private Long hobbiesId;
    private String name;
    private  String description;

    public Long getHobbiesId() {
        return hobbiesId;
    }

    public void setHobbiesId(Long hobbiesId) {
        this.hobbiesId = hobbiesId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
