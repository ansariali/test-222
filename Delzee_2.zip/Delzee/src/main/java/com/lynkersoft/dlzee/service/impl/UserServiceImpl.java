package com.lynkersoft.dlzee.service.impl;

import com.lynkersoft.dlzee.dto.common.UserDto;
import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.dto.userController.entity.User;
import com.lynkersoft.dlzee.entities.*;
import com.lynkersoft.dlzee.service.EmailService;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.service.impl.handler.UserServiceImplHandler;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.enums.FriendRequestStatus;
import com.lynkersoft.dlzee.utils.enums.Privacy;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.exception.util.BaseException;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public class UserServiceImpl extends UserServiceImplHandler implements UserAccountService {

    @Autowired
    EmailService emailService;

    @Autowired
    UserAccountService userAccountService;

    @Override
    public User fetchUserByPrivacy(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        UserAccount aUserAccount = iDao.find(UserAccount.class, userAccount.getUserId());
        checkNullObject(aUserAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        //
        if (aUserAccount.getProfile().getAddressPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setAddress(null);
        } else if (aUserAccount.getProfile().getAddressPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setAddress(aUserAccount.getProfile().getAddress());
        }
        //
        if (aUserAccount.getProfile().getEducationPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setEducations(null);
        } else if (aUserAccount.getProfile().getEducationPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setEducations(aUserAccount.getProfile().getEducations());
        }
        //
        if (aUserAccount.getProfile().getHobbyPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setHobbies(null);
        } else if (aUserAccount.getProfile().getHobbyPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setHobbies(aUserAccount.getProfile().getHobbies());
        }

        User data = dozerBeanMapper.map(aUserAccount, User.class);
        //
        if (aUserAccount.getProfile().getAboutMePrivacy().equals(Privacy.PRIVATE)) {
            data.getProfile().setAboutMe(null);
        } else if (aUserAccount.getProfile().getAboutMePrivacy().equals(Privacy.PUBLIC)) {
            data.getProfile().setAboutMe(aUserAccount.getProfile().getAboutMe());
        }
        //
        if (aUserAccount.getProfile().getBirthDatePrivacy().equals(Privacy.PRIVATE)) {
            data.getProfile().setBirthDate(null);
        } else if (aUserAccount.getProfile().getBirthDatePrivacy().equals(Privacy.PUBLIC)) {
            data.getProfile().setBirthDate(aUserAccount.getProfile().getBirthDate());
        }
        //
        if (aUserAccount.getProfile().getMobileNumberPrivacy().equals(Privacy.PRIVATE)) {
            data.getProfile().setMobileNumber(null);
        } else if (aUserAccount.getProfile().getMobileNumberPrivacy().equals(Privacy.PUBLIC)) {
            data.getProfile().setMobileNumber(aUserAccount.getProfile().getMobileNumber());
        }

        return data;
    }

    @Override
    public GenericResponse signUp(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        //
        checkNullObject(userAccount, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullString(userAccount.getEmailAddress(), ExceptionStatus.EMAIL_ADDRESS_MISSING);
        checkNullString(userAccount.getUserName(), ExceptionStatus.USER_NAME_IS_MISSING);
        checkNullString(userAccount.getFirstName(), ExceptionStatus.FIRST_NAME_MISSING);
        checkNullString(userAccount.getLastName(), ExceptionStatus.LAST_NAME_MISSING);
        checkNullString(userAccount.getMobileNo(), ExceptionStatus.MOBILE_NO_MISSING);
        checkNullString(userAccount.getPassword(), ExceptionStatus.PASSWORD_MISSING);

        findUserName(userAccount.getUserName(), iDao);
        findEmailAddress(userAccount.getEmailAddress(), iDao);

        //
        Profile profile = new Profile();
        profile.setTotalFriendRequest(0);
        profile.setTotalFriend(0);
        profile.setTotalSendFriendRequest(0);
        profile.setTotalImage(0);
        profile.setTotalVideo(0);
        profile.setTotalShare(0);
        profile.setAddressPrivacy(Privacy.PRIVATE);
        profile.setHobbyPrivacy(Privacy.PUBLIC);
        profile.setEducationPrivacy(Privacy.PUBLIC);
        profile.setFriendPrivacy(Privacy.PUBLIC);
        try {
            profile = iDao.find(Profile.class, iDao.persist(profile));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.PROFILE_NOT_ADDED);
        }

        //
        UserAccount user = new UserAccount();
        user.setFirstName(userAccount.getFirstName());
        user.setLastName(userAccount.getLastName());
        user.setUserName(userAccount.getUserName());
        user.setGender(userAccount.getGender());
        user.setEmailAddress(userAccount.getEmailAddress());
        user.setPassword(userAccount.getPassword());
        user.setMobileNo(userAccount.getMobileNo());
        user.setUserEnabled(Boolean.TRUE);
        user.setUserBlocked(Boolean.FALSE);
        user.setProfile(profile);

        try {
            user = iDao.find(UserAccount.class, iDao.persist(user));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ADDED);
        }

        emailService.sendEmailForRegistration(user.getEmailAddress(), user.getFirstName(), "...");
        return new GenericResponse(true, "User SuccessFully  Registration..");
    }

    @Override
    public LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao) {
        //
        if (password == null || userName == null) {
            throw new BaseException(ExceptionStatus.USER_NAME_OR_PASSWORD_MISSING);
        }

        //
        UserAccount userAccount = checkUserNameAndPassword(userName, password, iDao);
        checkNullObject(userAccount, ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);

        if (!userAccount.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }
        Session aSession = new Session();
        aSession.setUser(userAccount);
        aSession.setAccessToken(mUtil.getTokenNumber());
        aSession.setSignIn(Boolean.TRUE);
        aSession.setSignInOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession.setAttempts(1L);
        aSession.setAttemptsOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.find(Session.class, iDao.persist(aSession));
        //
        LoginResponseEntity aSignInResponse = new LoginResponseEntity();
        UserDto useDto = new UserDto();
        useDto.setUserId(aSession.getUser().getUserId());
        useDto.setFirstName(aSession.getUser().getFirstName());
        useDto.setLastName(aSession.getUser().getLastName());
        useDto.setUserName(aSession.getUser().getUserName());
        useDto.setGender(aSession.getUser().getGender());
        useDto.setEmailAddress(aSession.getUser().getEmailAddress());
        useDto.setMobileNo(aSession.getUser().getMobileNo());
        useDto.setUserEnabled(aSession.getUser().getUserEnabled());
        useDto.setUserBlocked(aSession.getUser().getUserBlocked());
        //
        aSignInResponse.setSessionStatus(Boolean.TRUE);
        aSignInResponse.setSignInOn(aSession.getSignInOn());
        aSignInResponse.setMessage("SignIn success");
        aSignInResponse.setAccessToken(aSession.getAccessToken());
        aSignInResponse.setUser(useDto);

        User user = dozerBeanMapper.map(userAccountService.fetchUserById(userAccount, userAccount.getUserId(), iDao), User.class);
        aSignInResponse.setProfile(user.getProfile());

        return aSignInResponse;
    }

    @Override
    public GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao) {
        Session aSession = checkLoginSession(accessToken, iDao);
        aSession.setSignIn(Boolean.FALSE);
        aSession.setSignOutType("MANUAL");
        aSession.setSignOutOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.update(aSession);

        if (!aSession.getSignIn()) {
            return new GenericResponse(true, "SignOut", "SignOut success");
        } else {
            return new GenericResponse(false, "SignOut", "SignOut failed");
        }
    }

    @Override
    public GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao) {

        UserAccount aUserAccount = checkEmailId(emailAddress, iDao);

        ForgotPassword aForgotPassword = new ForgotPassword();

        aForgotPassword.setEmailAddress(emailAddress);
        aForgotPassword.setForgotToken(mUtil.getTokenNumber());
        aForgotPassword.setOtpCode(mUtil.getOtpNumber().toString());
        aForgotPassword.setForgoted(Boolean.FALSE);
        aForgotPassword.setCreated(mRefactor.convertTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aForgotPassword = iDao.find(ForgotPassword.class, iDao.persist(aForgotPassword));

        // STEP:4 : .
        // 4.1: .
        if (mEmailService.forgotPassword(null, aUserAccount.getEmailAddress(), aUserAccount.getFirstName(), aForgotPassword.getOtpCode(), aForgotPassword.getForgotToken())) {
            return new GenericResponse(true, "Forgot Password Request", "We have send mail for recover your password, Plz check it.");

        } else {
            return new GenericResponse(false, "Forgot Password Request", "Failed to recover your password");
        }
    }

    @Override
    public UserAccount fetchUserById(UserAccount userAccount, Long userId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(userId, ExceptionStatus.USER_ID_MISSING);
        UserAccount aUserAccount = iDao.find(UserAccount.class, userId);

        return aUserAccount;
    }

    @Override
    public GenericResponse sendFriendRequest(UserAccount userAccount, FriendRequest friendRequest, Long friedRequestId, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkNullObject(friendRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(friedRequestId, ExceptionStatus.FRIEND_ID_MISSING);

        UserAccount sendFriendRequest = iDao.find(UserAccount.class, friedRequestId);
        checkNullObject(sendFriendRequest, ExceptionStatus.FRIEND_NOT_FOUND);

        if (sendFriendRequest.getUserId() == userAccount.getUserId()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        checkFriendAvailableOrNot(friedRequestId, userAccount.getUserId(), iDao);
      /*  FriendRequest allReadyFriendRequest = iDao.find(FriendRequest.class, friedRequestId);
        System.out.println("allReadyFriendRequest: "+ allReadyFriendRequest.getFriendRequestId());

        if(allReadyFriendRequest.getFriendRequestSendStatus() || !allReadyFriendRequest.getDeleted()) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_SEND);
        }*/

        FriendRequest aFriendRequest = new FriendRequest();
        aFriendRequest.setFriendRequestSendStatus(Boolean.TRUE);
        aFriendRequest.setFriendRequestStatus(FriendRequestStatus.PENDING);
        aFriendRequest.setFriendRequestSendOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aFriendRequest.setSendFriendRequestBy(userAccount);
        aFriendRequest.setFriendRequestTo(sendFriendRequest);

        try {
            aFriendRequest = iDao.find(FriendRequest.class, iDao.persist(aFriendRequest));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }
        if (userAccount.getProfile().getTotalSendFriendRequest() == 0) {
            userAccount.getProfile().setTotalSendFriendRequest(1);
        } else {
            userAccount.getProfile().setTotalSendFriendRequest(userAccount.getProfile().getTotalSendFriendRequest() + 1);
        }
        //
        if (sendFriendRequest.getProfile().getTotalFriendRequest() == 0) {
            sendFriendRequest.getProfile().setTotalFriendRequest(1);
        } else {
            sendFriendRequest.getProfile().setTotalFriendRequest(sendFriendRequest.getProfile().getTotalFriendRequest() + 1);
        }
        try {
            iDao.update(sendFriendRequest.getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }

        return new GenericResponse(true, "Send Friend Request Successfully", "Send Friend Request Successfully");
    }

    @Override
    public GenericResponse friendRequestAccept(UserAccount userAccount, Long friedRequestId, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkNullLongId(friedRequestId, ExceptionStatus.FRIEND_ID_MISSING);

        FriendRequest friendRequest = iDao.find(FriendRequest.class, friedRequestId);
        checkNullObject(friendRequest, ExceptionStatus.FRIEND_NOT_FOUND);

        if (friendRequest.getFriendRequestStatus().equals(FriendRequestStatus.ACCEPTED)) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_ACCEPTED);
        }

        if (friendRequest.getFriendRequestTo().getUserId() != userAccount.getUserId()) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }

        friendRequest.setFriendRequestStatus(FriendRequestStatus.ACCEPTED);
        friendRequest = iDao.update(friendRequest);
        Friend friend = new Friend();
        friend.setFriendRequestStatus(FriendRequestStatus.ACCEPTED);
        friend.setFriendRequestAcceptedStatus(Boolean.TRUE);
        friend.setFriendRequestAcceptedDate(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        friend.setSendFriendRequestBy(friendRequest.getSendFriendRequestBy());
        friend.setFriendRequestAcceptedBy(userAccount);
        try {
            friend = iDao.find(Friend.class, iDao.persist(friend));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_ACCEPTED);
        }

        userAccount.getProfile().setTotalFriend(userAccount.getProfile().getTotalFriend() + 1);
        try {
            iDao.update(userAccount.getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }
        friend.getSendFriendRequestBy().getProfile().setTotalFriend(friend.getSendFriendRequestBy().getProfile().getTotalFriend() + 1);
        try {
            iDao.update(friend.getSendFriendRequestBy().getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }
        return new GenericResponse(true, "Friend Request Successfully Accept", "Friend Request Successfully Accept");
    }
}
