package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Product;
import com.lynkersoft.delzee.entities.UserAccount;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface UserService {
    Mono<UserAccount> findId(String id);
    Mono<UserAccount> save(UserAccount user);
    Mono<Product> saveProduct(String id , Product product);
    Flux<UserAccount> fetchAllUser(String id);
    Mono<Void> delete(String id);
}
