package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.common.OperationStatus;
import com.lynkersoft.delzee.entities.Product;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.entities.WatcherEntity;
import com.lynkersoft.delzee.repository.ProductRepository;
import com.lynkersoft.delzee.repository.UserRepository;
import com.lynkersoft.delzee.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Date;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Mono<Void> delete(String id) {
       return userRepository.deleteById(id);
    }

    @Override
    public Flux<UserAccount> fetchAllUser(String id) {
        return userRepository.findAll();
    }

    @Override
    public Mono<Product> saveProduct(String id, Product product) {
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount  userAccount = mongoTemplate.findOne(query, UserAccount.class);
        if(userAccount == null) {
            System.out.println("User Account Not found !!!");
            return null;
        }
        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(userAccount.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setTableName("Project");
        product.setWatcherEntity(watcherEntity);
        product.setUserId(userAccount.getUserId());

       return productRepository.save(product);
    }

    @Override
    public Mono<UserAccount> save(UserAccount user) {
        WatcherEntity watcherEntity = new WatcherEntity();
        watcherEntity.setVersion(1L);
        watcherEntity.setCreatedDate(new Date());
        watcherEntity.setCreatedBy(user.getFirstName());
        watcherEntity.setOptionStatus(OperationStatus.CREATE);
        watcherEntity.setTableName("UserAccount");
        user.setWatcherEntity(watcherEntity);
        return userRepository.save(user);
    }

    @Override
    public Mono<UserAccount> findId(String id) {
        Mono<UserAccount> userAccountMono = userRepository.findById(id).switchIfEmpty(Mono.error(new Exception("User Not Found: ")));
        Query query = new Query();
        query.addCriteria(Criteria.where("userId").is(id));
        UserAccount  userAccount = mongoTemplate.findOne(query, UserAccount.class);
        System.out.println("Id find :" + userAccount.getMobileNo());
        return userAccountMono;
    }
}
