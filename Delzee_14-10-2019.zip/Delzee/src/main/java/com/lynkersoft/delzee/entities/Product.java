package com.lynkersoft.delzee.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "product")
public class Product {

    @Id
    private String productId;
    private String name;
    private Double price;
    private WatcherEntity watcherEntity;
    private String userId;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public WatcherEntity getWatcherEntity() {
        return watcherEntity;
    }

    public void setWatcherEntity(WatcherEntity watcherEntity) {
        this.watcherEntity = watcherEntity;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
