package com.lynkersoft.delzee.repository;

import com.lynkersoft.delzee.entities.UserAccount;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public interface UserRepository extends ReactiveMongoRepository<UserAccount, String> {

//    Mono<UserAccount> findByIdAndDeleteIsFalse(String id);
}
