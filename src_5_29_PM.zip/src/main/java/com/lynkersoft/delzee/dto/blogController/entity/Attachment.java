package com.lynkersoft.delzee.dto.blogController.entity;

import com.lynkersoft.delzee.utils.enums.AttachmentFor;

import java.util.Date;

public class Attachment {
    private Long attachmentId;
    private String fileName;
    private AttachmentFor attachmentFor;
    private String contentType;
    private String url;
    private String description;
    private Date createdAt;
    private String fileType;

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public Long getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(Long attachmentId) {
        this.attachmentId = attachmentId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public AttachmentFor getAttachmentFor() {
        return attachmentFor;
    }

    public void setAttachmentFor(AttachmentFor attachmentFor) {
        this.attachmentFor = attachmentFor;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
