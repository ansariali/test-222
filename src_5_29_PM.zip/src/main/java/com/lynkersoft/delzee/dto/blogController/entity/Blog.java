package com.lynkersoft.delzee.dto.blogController.entity;

import com.lynkersoft.delzee.dto.common.User_;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Blog {
    private Long blogId;
    private String description;
    private Date created;
    private User_ creator;
    private List<Attachment> attachments = new ArrayList<>();

    public Long getBlogId() {
        return blogId;
    }

    public void setBlogId(Long blogId) {
        this.blogId = blogId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreated() {
        return created;
    }

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }
}
