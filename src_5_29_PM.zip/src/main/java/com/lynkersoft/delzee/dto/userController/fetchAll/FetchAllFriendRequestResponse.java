package com.lynkersoft.delzee.dto.userController.fetchAll;

import com.lynkersoft.delzee.dto.userController.entity.FriendRequest;

import java.util.ArrayList;
import java.util.List;

public class FetchAllFriendRequestResponse {

    List<FriendRequest> friendRequests = new ArrayList<>();

    public List<FriendRequest> getFriendRequests() {
        return friendRequests;
    }

    public void setFriendRequests(List<FriendRequest> friendRequests) {
        this.friendRequests = friendRequests;
    }
}
