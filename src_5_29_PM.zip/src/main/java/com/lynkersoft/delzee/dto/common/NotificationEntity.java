package com.lynkersoft.delzee.dto.common;

import com.lynkersoft.delzee.dto.blogController.entity.Blog;
import com.lynkersoft.delzee.utils.enums.NotificationType;

import java.util.Date;

public class NotificationEntity {

    private Long notificationId;
    private String privacyType;
    private NotificationType notificationType;
    private String message;
    private Date created;
    private Boolean isSeen = Boolean.FALSE;
    private Date seenOn;
    private User_ sender;
    private User_ receiver;
    private Profile_ profile;
    private Blog blog;

    public Long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Long notificationId) {
        this.notificationId = notificationId;
    }

    public String getPrivacyType() {
        return privacyType;
    }

    public void setPrivacyType(String privacyType) {
        this.privacyType = privacyType;
    }

    public NotificationType getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(NotificationType notificationType) {
        this.notificationType = notificationType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Boolean getSeen() {
        return isSeen;
    }

    public void setSeen(Boolean seen) {
        isSeen = seen;
    }

    public Date getSeenOn() {
        return seenOn;
    }

    public void setSeenOn(Date seenOn) {
        this.seenOn = seenOn;
    }

    public User_ getSender() {
        return sender;
    }

    public void setSender(User_ sender) {
        this.sender = sender;
    }

    public User_ getReceiver() {
        return receiver;
    }

    public void setReceiver(User_ receiver) {
        this.receiver = receiver;
    }

    public Profile_ getProfile() {
        return profile;
    }

    public void setProfile(Profile_ profile) {
        this.profile = profile;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }
}
