package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.entities.BlogLikes;
import com.lynkersoft.delzee.service.LikeService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/likeController")
public class LikeController extends GenericController {

    @Autowired
    LikeService likeService;
    private Logger logger = LoggerFactory.getLogger(LikeController.class);

    @PostMapping("/v1/save/{userId}")
    public ResponseEntity<GenericResponse> saveLike(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogLikes like) {
        logger.info("Inside saveLike :");
        return new ResponseEntity<>(likeService.createLike(verifySession(userId, requestHeader), profileId, blogId, like, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping("/v1/update/{userId}")
    public ResponseEntity<GenericResponse> updateLike(@PathVariable Long userId, @PathVariable Long profileId, @RequestParam Long blogId, @RequestParam Long likeId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogLikes updateLike) {
        logger.info("Inside updateLike :");
        return new ResponseEntity<>(likeService.updateLike(verifySession(userId, requestHeader), profileId, blogId, likeId, updateLike, iDao), responseHeaders, HttpStatus.OK);
    }

}
