package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.entities.BlogComments;
import com.lynkersoft.delzee.service.CommentService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/commentController")
public class CommentController extends GenericController {

    @Autowired
    CommentService commentService;
    private Logger logger = LoggerFactory.getLogger(CommentController.class);

    @PostMapping("/v1/save/{userId}")
    public ResponseEntity<GenericResponse> saveComment(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogComments blogComments) {
        logger.info("Inside saveComment :");
        return new ResponseEntity<>(commentService.createComment(verifySession(userId, requestHeader), profileId, blogId, blogComments, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping("/v1/update/{userId}")
    public ResponseEntity<GenericResponse> updateComment(@PathVariable Long userId, @PathVariable Long profileId, @RequestParam Long blogId, @RequestParam Long commentId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogComments updateComments) {
        logger.info("Inside updateComment :");
        return new ResponseEntity<>(commentService.updateComment(verifySession(userId, requestHeader), profileId, blogId, commentId, updateComments, iDao), responseHeaders, HttpStatus.OK);
    }

    @DeleteMapping("/v1/delete/{userId}")
    public ResponseEntity<GenericResponse> deleteComment(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestParam Long commentId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside deleteComment :");
        return new ResponseEntity<>(commentService.deleteComment(verifySession(userId, requestHeader), profileId, blogId, commentId,  iDao), responseHeaders, HttpStatus.OK);
    }

}
