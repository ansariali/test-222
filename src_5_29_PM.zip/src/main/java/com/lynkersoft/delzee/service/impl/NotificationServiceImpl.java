package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.Notifications;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.NotificationService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationServiceImpl extends GenericImplHandler implements NotificationService {

    @Override
    public Map<String, List<Notifications>> fetchAll(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);
        List<Notifications> finalList = new ArrayList<>();

        mCriteria.clear();
        mCriteria.put("creator", userAccount);
        List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchAllBlog(), mCriteria, false);
        mCriteria.clear();

        for (Blog blog : blogList) {
            mCriteria.put("creator", userAccount);
            mCriteria.put("blog", blog);
            List<Notifications> notificationsList = iDao.getEntities(Notifications.class, queryManager.fetchAllNotification(), mCriteria);
            mCriteria.clear();
            if (notificationsList.size() != 0) {
                finalList.addAll(notificationsList);
            }
        }

        Map<String, List<Notifications>> aMap = new HashMap<>();
        aMap.put("notifications", finalList);
        return aMap;

    }
}
