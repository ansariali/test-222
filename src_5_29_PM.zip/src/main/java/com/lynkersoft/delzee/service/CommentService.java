package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.BlogComments;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;

public interface CommentService {

    GenericResponse createComment(UserAccount userAccount, Long profileId, Long blogId, BlogComments comments, IDao<IEntity, Serializable> iDao);

    GenericResponse updateComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, BlogComments comments, IDao<IEntity, Serializable> iDao);

    GenericResponse deleteComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, IDao<IEntity, Serializable> iDao);

}
