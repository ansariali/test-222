package com.lynkersoft.delzee.service;

public interface EmailService {
    Boolean sendEmailForRegistration(String to, String firstName, String token);
    Boolean forgotPassword(String from, String to, String firstName, String optCode, String token);

}
