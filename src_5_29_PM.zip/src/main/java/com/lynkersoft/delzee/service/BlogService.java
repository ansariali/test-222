package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface BlogService {
    GenericResponse createBlog(UserAccount userAccount, Long profileId, String description, String fileType, MultipartFile[] files, IDao<IEntity, Serializable> iDao);

    Map<String, List<Blog>> fetchAllBlog(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Blog>> fetchAllBlogPublic(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Blog fetchBlogById(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateBlog(UserAccount userAccount, Long profileId, Long blogId, Blog blog, IDao<IEntity, Serializable> iDao);

    GenericResponse deleteBlog(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao);

}
