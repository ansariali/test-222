package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.BlogLikes;
import com.lynkersoft.delzee.entities.Profile;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.LikeService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.NotificationType;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public class LikeServiceImpl extends GenericImplHandler implements LikeService {
    @Override
    public GenericResponse createLike(UserAccount userAccount, Long profileId, Long blogId, BlogLikes blogLike, IDao<IEntity, Serializable> iDao) {
        //
      Profile aProfile =  checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        //CheckLike
        BlogLikes value = checkLike(userAccount, aBlog);
        if (value == null) {
            try {
                BlogLikes aBlogLikes = new BlogLikes();
                aBlogLikes.setLiked(blogLike.getLiked());
                aBlogLikes.setCreated(getCurrentTime());
                aBlogLikes.setBlog(aBlog);
                aBlogLikes.setCreator(userAccount);
                iDao.persist(aBlogLikes);

                //Notification
                addNotification(aProfile, userAccount, null, aBlog.getCreator(), aBlog, userAccount.getFirstName() +" "+ userAccount.getLastName()+ " Like your Post", "PUBLIC", Boolean.TRUE,  NotificationType.LIKE);

            } catch (Exception e) {
                throw new GenericException(ExceptionStatus.LIKE_NOT_ADDED);
            }
            aBlog.setTotalLikes(aBlog.getTotalLikes() + 1);
            iDao.update(aBlog);
        } else {
            if (blogLike.getLiked()) {
                value.setLiked(Boolean.TRUE);
                value.setChanger(userAccount);
                value.setChanged(getCurrentTime());
                value.setDeleted(Boolean.FALSE);
                iDao.update(value);
                aBlog.setTotalLikes(aBlog.getTotalLikes() + 1);
                iDao.update(aBlog);

            } else if (!blogLike.getLiked()) {
                value.setLiked(Boolean.FALSE);
                value.setChanger(userAccount);
                value.setChanged(getCurrentTime());
                value.setDeleted(Boolean.TRUE);
                iDao.update(value);
                if (aBlog.getTotalLikes() == 0) {
                    aBlog.setTotalLikes(0);
                } else {
                    aBlog.setTotalLikes(aBlog.getTotalLikes() - 1);
                }
                iDao.update(aBlog);
            }
        }

        return new GenericResponse(true, "Like SuccessFully create !!");
    }

    @Override
    public GenericResponse updateLike(UserAccount userAccount, Long profileId, Long blogId, Long LikeId, BlogLikes like, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullLongId(LikeId, ExceptionStatus.LIKE_ID_MISSING);

        BlogLikes blogLikes = iDao.find(BlogLikes.class, LikeId);
        checkNullObject(blogLikes, ExceptionStatus.LIKE_NOT_FOUND);

        try {
            blogLikes.setLiked(like.getLiked());
            blogLikes.setChanged(getCurrentTime());
            blogLikes.setChanger(userAccount);

            iDao.update(blogLikes);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.LIKE_NOT_UPDATE);
        }

        return new GenericResponse(true, "Like SuccessFully Updated !!");
    }
}
