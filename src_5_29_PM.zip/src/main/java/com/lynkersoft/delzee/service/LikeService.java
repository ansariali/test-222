package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.BlogLikes;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;

public interface LikeService {

    GenericResponse createLike(UserAccount userAccount, Long profileId, Long blogId, BlogLikes blogLike, IDao<IEntity, Serializable> iDao);

    GenericResponse updateLike(UserAccount userAccount, Long profileId, Long blogId, Long LikeId, BlogLikes comments, IDao<IEntity, Serializable> iDao);

}
