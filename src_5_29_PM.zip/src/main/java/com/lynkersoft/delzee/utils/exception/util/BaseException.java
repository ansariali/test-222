package com.lynkersoft.delzee.utils.exception.util;


import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;

public class BaseException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private ExceptionStatus exceptionStatus = null;

    public BaseException(ExceptionStatus exceptionStatus) {
        super(exceptionStatus.getProductionMessage());
        this.exceptionStatus = exceptionStatus;
    }

    public ServiceError getServiceError() {
        return new ServiceError(exceptionStatus);
    }

    public ExceptionStatus getExceptionStatus() {
        return exceptionStatus;
    }
}
