package com.lynkersoft.delzee.utils;

public class QueryManager {
    private QueryManager() {}

    public static QueryManager getInstance() {
        return new QueryManager();
    }

    public String fetchAllNotification() {
        return " SELECT o FROM Notifications AS o WHERE o.deleted IS NOT true AND o.creator != :creator AND o.blog = :blog ORDER BY o.created DESC";
    }

    public String checkLike() {
        return "SELECT o FROM BlogLikes AS o WHERE o.creator = :creator AND o.blog = :blog";
    }
    public String fetchBlogByDESC() {
        return " SELECT o FROM Blog AS o WHERE o.deleted IS NOT true ORDER BY o.created DESC";
    }
    public String fetchAllBlog() {
        return "SELECT o FROM Blog AS o WHERE o.creator = :creator";
    }
    public String checkForgetToken() {
        return "SELECT o FROM ForgotPassword AS o WHERE o.forgotToken = :forgotToken";
    }
    public String findFriendRequest() {
        return "SELECT o FROM FriendRequest AS o WHERE o.friendRequestTo = :friendRequestTo";
    }
    public String getEmailAddress() {
        return "SELECT o FROM UserAccount AS o WHERE o.emailAddres  s = :emailAddress";
    }
    public String getUsersByUserName() {
        return "SELECT o FROM UserAccount AS o WHERE o.userName = :userName";
    }
    public String checkUserNameAndPassword() {
        return "SELECT o FROM UserAccount AS o WHERE (o.userName = :userName OR o.emailAddress = :userName) AND o.password = :password AND o.userEnabled IS TRUE";
    }
    public String getFriendRequestUser() {
        return "SELECT o FROM FriendRequest AS o WHERE o.sendFriendRequestBy.userId = :userIds AND o.friendRequestTo.userId = :friedRequestId";
    }
    public String getHobbiesTag() {
        return "SELECT o FROM Hobbie AS o WHERE o.tagName = :tagName AND o.profile = :profile";
    }
}
