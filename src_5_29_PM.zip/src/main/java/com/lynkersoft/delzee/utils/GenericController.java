package com.lynkersoft.delzee.utils;

import com.lynkersoft.delzee.entities.Session;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;
import java.util.Objects;

@CrossOrigin
@RestController
@RequestMapping("/userController")
public class GenericController {

    protected DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();

    protected static HttpHeaders responseHeaders = new HttpHeaders();
    static {
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
    }

    @Autowired
    protected IDao<IEntity, Serializable> iDao;
    protected Refactor mRefactor = Refactor.getInstance();

    protected UserAccount verifySession(Long userId, Map<String, Object> requestHeader) {
        Hashtable<String, Object> criteria = new Hashtable<>();

        if (userId == null) {
            throw new GenericException(ExceptionStatus.USER_ID_MISSING);
        }

        if (requestHeader == null) {
            throw new GenericException(ExceptionStatus.HTTP_REQUEST_HEADER_NOT_VALID);
        }

        String accessToken = null;

        for (Map.Entry<String, Object> entry : requestHeader.entrySet()) {
            try {
                String key = entry.getKey().toUpperCase();
                String value = entry.getValue().toString();
                if (key.equals("ACCESS-TOKEN")) {
                    accessToken = value;
                    break;
                }
            } catch (Exception e) {
                throw new GenericException();
            }
        }

        if (accessToken == null) {
            throw new GenericException(ExceptionStatus.ACCESS_TOKEN_MISSING);
        }

        criteria.clear();
        criteria.put("accessToken", accessToken);
        Session aSession = iDao.getEntity(Session.class, "SELECT o FROM Session AS o WHERE o.accessToken = :accessToken AND o.isSignIn IS true", criteria, false);
        criteria.clear();

        if (aSession == null) {
            throw new GenericException(ExceptionStatus.USER_SESSION_NOT_FOUND);
        }

        if (aSession.getUser() == null) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        }

        if (!Objects.equals(aSession.getUser().getUserId(), userId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }
        if (!aSession.getUser().getUserEnabled() || aSession.getUser().getUserBlocked()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ACTIVE);
        }

        return aSession.getUser();
    }
}
