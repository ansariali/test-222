package com.lynkersoft.delzee.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lynkersoft.delzee.utils.abstracts.GenericEntity;
import com.lynkersoft.delzee.utils.enums.AttachmentFor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity
@Table(name = "attachment")
public class Attachment extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long attachmentId;

    private String fileName;

    @Column(length = 1000)
    private String description;

    @NotNull(message = "fileType must be required!")
    private String fileType;

    @NotNull(message = "attachmentFor must be required!")
    @Enumerated(EnumType.STRING)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private AttachmentFor attachmentFor;

    @NotNull(message = "contentType must be required!")
    private String contentType;

    @Lob
    @Size(max = 1024, message = "uploadUrl must be required!")
    private String url;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blogId")
    private Blog blog;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount createdBy;

    private Date createdAt;

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(Long attachmentId) {
        this.attachmentId = attachmentId;
    }

    public AttachmentFor getAttachmentFor() {
        return attachmentFor;
    }

    public void setAttachmentFor(AttachmentFor attachmentFor) {
        this.attachmentFor = attachmentFor;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }

    public UserAccount getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UserAccount createdBy) {
        this.createdBy = createdBy;
    }
}
