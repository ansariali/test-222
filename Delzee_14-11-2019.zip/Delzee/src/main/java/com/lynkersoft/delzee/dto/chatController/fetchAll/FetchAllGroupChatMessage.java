package com.lynkersoft.delzee.dto.chatController.fetchAll;

import com.lynkersoft.delzee.dto.chatController.entity.GroupChat;

import java.util.ArrayList;
import java.util.List;

public class FetchAllGroupChatMessage {

    List<GroupChat> chats = new ArrayList<>();

    public List<GroupChat> getChats() {
        return chats;
    }

    public void setChats(List<GroupChat> chats) {
        this.chats = chats;
    }
}
