package com.lynkersoft.delzee.dto.common;

import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;

import java.util.Date;

public class FriendRequest {

    private Long friendRequestId;
    private FriendRequestStatus friendRequestStatus;
    private Boolean friendRequestSendStatus;
    private Date friendRequestSendOn;
    private User_ sendFriendRequestBy;

    public Long getFriendRequestId() {
        return friendRequestId;
    }

    public void setFriendRequestId(Long friendRequestId) {
        this.friendRequestId = friendRequestId;
    }

    public FriendRequestStatus getFriendRequestStatus() {
        return friendRequestStatus;
    }

    public void setFriendRequestStatus(FriendRequestStatus friendRequestStatus) {
        this.friendRequestStatus = friendRequestStatus;
    }

    public Boolean getFriendRequestSendStatus() {
        return friendRequestSendStatus;
    }

    public void setFriendRequestSendStatus(Boolean friendRequestSendStatus) {
        this.friendRequestSendStatus = friendRequestSendStatus;
    }

    public Date getFriendRequestSendOn() {
        return friendRequestSendOn;
    }

    public void setFriendRequestSendOn(Date friendRequestSendOn) {
        this.friendRequestSendOn = friendRequestSendOn;
    }

    public User_ getSendFriendRequestBy() {
        return sendFriendRequestBy;
    }

    public void setSendFriendRequestBy(User_ sendFriendRequestBy) {
        this.sendFriendRequestBy = sendFriendRequestBy;
    }
}
