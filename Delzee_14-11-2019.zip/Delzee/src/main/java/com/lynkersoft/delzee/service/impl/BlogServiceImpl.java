package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.BlogService;
import com.lynkersoft.delzee.service.S3StorageService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.AttachmentFor;
import com.lynkersoft.delzee.utils.enums.NotificationType;
import com.lynkersoft.delzee.utils.enums.S3Storage;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class BlogServiceImpl extends GenericImplHandler implements BlogService {

    @Autowired
    private S3StorageService s3StorageService;
    private Logger logger = LoggerFactory.getLogger(BlogServiceImpl.class);

    @Override
    public GenericResponse blogShare(UserAccount userAccount, Long profileId, Long blogId, BlogSharing blogShare, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkNullString(blogShare.getPrivacyType(), ExceptionStatus.SHARE_PRIVACY_MISSING);
        checkProfile(profileId, userAccount, iDao);

        Blog blog = iDao.find(Blog.class, blogId);
        checkNullObject(blog, ExceptionStatus.BLOG_NOT_FOUND);

        BlogSharing blogSharing = new BlogSharing();
        try {
            blogSharing.setDescription(blogShare.getDescription());
            blogSharing.setPrivacyType(blogShare.getPrivacyType());
            blogSharing.setShareBy(userAccount);
            blogSharing.setBlog(blog);
            blogSharing.setBlogCreator(blog.getCreator());
            blogSharing.setCreated(getCurrentTime());
            blogSharing = iDao.find(BlogSharing.class, iDao.persist(blogSharing));

            blog.setTotalShare(blog.getTotalShare() + 1);
            blog = iDao.update(blog);

            //Notification save
            addNotification(userAccount.getProfile(), userAccount, null, blog.getCreator(), blog, userAccount.getFirstName() + " " + userAccount.getLastName() + " shared your post.", "PUBLIC", Boolean.TRUE, NotificationType.SHARE, null);

            //webSocket Notification
            notifications(blog.getCreator(), iDao);

            ///webSocket for Likes
            refreshShare(blog);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_SHARE);
        }

        return new GenericResponse(true, "Blog Share SuccessFully !!");
    }

    @Override
    public Blog fetchBlogById(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }

        return blog;
    }


    @Override
    public GenericResponse updateBlog(UserAccount userAccount, Long profileId, Long blogId, Blog blogRequest, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }

        try {
            blog.setDescription(blogRequest.getDescription());
            blog.setChanged(getCurrentTime());
            blog.setChanger(userAccount);
            iDao.update(blog);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_UPDATE);
        }
        return new GenericResponse(true, "Blog SuccessFully Updated !!");

    }

    @Override
    public GenericResponse deleteBlog(UserAccount userAccount, Long profileId, Long blogId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }

        if (blog.getDeleted()) {
            throw new GenericException(ExceptionStatus.BLOG_ALL_READY_DELETE);
        }

        try {
            blog.setDeleted(Boolean.TRUE);
            blog.setDeleteBlog(getCurrentTime());
            iDao.update(blog);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_DELETE);
        }
        return new GenericResponse(true, "Blog SuccessFully Deleted !!");
    }

    @Override
    public GenericResponse deleteAttachment(UserAccount userAccount, Long profileId, Long blogId, Long attachmentId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }

        Attachment attachment = iDao.find(Attachment.class, attachmentId);
        if (attachment == null) {
            throw new GenericException(ExceptionStatus.ATTACHMENT_NOT_FOUND);
        }

        if (userAccount.getUserId() != blog.getCreator().getUserId()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        try {
            iDao.purge(attachment);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_DELETE);
        }

        return new GenericResponse(true, "Attachment SuccessFully Deleted !!");
    }

    @Override
    public Map<String, List<Blog>> fetchAllBlog(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        //
        checkProfile(profileId, userAccount, iDao);

        mCriteria.put("creator", userAccount);
        List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchAllBlog(), mCriteria, false);
        mCriteria.clear();

        Map<String, List<Blog>> aMap = new HashMap<>();
        aMap.put("blogs", blogList);
        return aMap;

    }

    @Override
    public Map<String, List<Blog>> fetchAllBlogPublic(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);
        mCriteria.clear();
        List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchBlogByDESC(), mCriteria);
        Map<String, List<Blog>> aMap = new HashMap<>();

        aMap.put("blogs", blogList);
        return aMap;
    }

    @Override
    public Map<String, List<Blog>> fetchBlogByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FRIEND_NOT_FOUND);

        mCriteria.clear();
        mCriteria.put("creator", friend);
        List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchBlogByUserId(), mCriteria);
        mCriteria.clear();

        Map<String, List<Blog>> aMap = new HashMap<>();
        aMap.put("blogs", blogList);
        return aMap;
    }

    @Override
    public Map<String, List<Attachment>> fetchVideoByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FRIEND_NOT_FOUND);

        mCriteria.clear();
        mCriteria.put("fileType", "Video");
        mCriteria.put("createdBy", friend);
        List<Attachment> videoList = iDao.getEntities(Attachment.class, queryManager.fetchImageByUserId(), mCriteria);
        mCriteria.clear();

        Map<String, List<Attachment>> aMap = new HashMap<>();
        aMap.put("videos", videoList);
        return aMap;
    }

    @Override
    public Map<String, List<Attachment>> fetchImageByUserId(UserAccount userAccount, Long profileId, Long friendId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FRIEND_NOT_FOUND);

        mCriteria.clear();
        mCriteria.put("fileType", "Image");
        mCriteria.put("createdBy", friend);
        List<Attachment> imageList = iDao.getEntities(Attachment.class, queryManager.fetchImageByUserId(), mCriteria);
        mCriteria.clear();

        Map<String, List<Attachment>> aMap = new HashMap<>();
        aMap.put("images", imageList);
        return aMap;
    }

    @Override
    public GenericResponse createBlog(UserAccount userAccount, Long profileId, String description, MultipartFile[] files, IDao<IEntity, Serializable> iDao) {
        //
        Profile aProfile = checkProfile(profileId, userAccount, iDao);
        Blog blog = new Blog();
        blog.setDescription(description);
        blog.setProfile(aProfile);
        blog.setCreator(userAccount);
        blog.setCreated(getCurrentTime());
        blog.setTotalComments(0);
        blog.setTotalLikes(0);
        blog.setTotalShare(0);
        Integer totalImage = 0;
        Integer totalVideo = 0;
        try {
            blog = iDao.find(Blog.class, iDao.persist(blog));
            if (blog != null) {
                for (int i = 0; i < files.length; i++) {
                    try {
                        String prefix = S3Storage.FOLDER_PROJECT.getInfo() + S3Storage.SUFFIX.getInfo() + blog.getBlogId().toString() + S3Storage.SUFFIX.getInfo();
                        Attachment attachment = new Attachment();
                        attachment.setFileName(files[i].getOriginalFilename());
                        logger.info("prefix: " + prefix);
                        String url = s3StorageService.uploadFile(prefix, files[i]);
                        attachment.setUrl(S3Storage.BUCKET_URL.getInfo() + url);
                        attachment.setContentType(files[i].getContentType());
                        attachment.setAttachmentFor(AttachmentFor.BLOG);
                        String data = files[i].getContentType();
                        String fileType1 = data.split("/")[0];
                        String fileType = fileType1.substring(0, 1).toUpperCase() + fileType1.substring(1);
                        logger.info("fileType :" + fileType);
                        attachment.setFileType(fileType);
                        attachment.setDescription(blog.getDescription());
                        attachment.setCreatedBy(userAccount);
                        attachment.setCreated(getCurrentTime());
                        attachment.setBlog(blog);
                        attachment = iDao.find(Attachment.class, iDao.persist(attachment));
                        if (fileType.equals("Image")) {
                            totalImage = totalImage + 1;
                        } else if (fileType.equals("Video")) {
                            totalVideo += totalVideo + 1;
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.info("e :" + e);
                        logger.info("e.getMessage() :" + e.getMessage());
                        logger.info("e.getStackTrace() :" + e.getStackTrace());
                        throw new GenericException(ExceptionStatus.FILE_NOT_UPLOAD);
                    }
                }

            }
        } catch (Exception e) {
            logger.info("e :" + e);
            logger.info("e.getMessage() :" + e.getMessage());
            logger.info("e.getStackTrace() :" + e.getStackTrace());
            throw new GenericException(ExceptionStatus.BLOG_NOT_ADDED);
        }


        //Notification
        addNotification(aProfile, userAccount, null, blog.getCreator(), blog, userAccount.getFirstName() + " " + userAccount.getLastName() + " added a new Post", "PUBLIC", Boolean.FALSE, NotificationType.POST, null);

        aProfile.setTotalPost(aProfile.getTotalPost() + 1);
        aProfile.setTotalImage(aProfile.getTotalImage() + totalImage);
        aProfile.setTotalVideo(aProfile.getTotalVideo() + totalVideo);
        iDao.update(aProfile);
        return new GenericResponse(true, "Blog SuccessFully create !!");
    }
}
