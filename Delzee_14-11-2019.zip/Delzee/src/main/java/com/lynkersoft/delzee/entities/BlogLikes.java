package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "blog_like")
public class BlogLikes extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long blogLikeId;

   private Boolean liked;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator")
    private UserAccount creator;

    private Date created;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blogId")
    private Blog blog;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "changer")
    private UserAccount changer;

    private Date changed;

    public Long getBlogLikeId() {
        return blogLikeId;
    }

    public void setBlogLikeId(Long blogLikeId) {
        this.blogLikeId = blogLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public UserAccount getCreator() {
        return creator;
    }

    public void setCreator(UserAccount creator) {
        this.creator = creator;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }

    public UserAccount getChanger() {
        return changer;
    }

    public void setChanger(UserAccount changer) {
        this.changer = changer;
    }

    public Date getChanged() {
        return changed;
    }

    public void setChanged(Date changed) {
        this.changed = changed;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
