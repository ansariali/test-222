package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllComment;
import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.BlogComments;
import com.lynkersoft.delzee.entities.Profile;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.CommentService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.NotificationType;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class CommentServiceImpl extends GenericImplHandler implements CommentService {

    @Override
    public GenericResponse createComment(UserAccount userAccount, Long profileId, Long blogId, BlogComments comments, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        Profile aProfile = checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullObject(comments, ExceptionStatus.COMMENT_MISSING);

        BlogComments comment = new BlogComments();
        try {
            comment.setComments(comments.getComments());
            comment.setCreator(userAccount);
            comment.setCreated(getCurrentTime());
            comment.setBlog(aBlog);
            comment = iDao.find( BlogComments.class, iDao.persist(comment));

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.COMMENT_NOT_ADDED);
        }
        aBlog.setTotalComments(aBlog.getTotalComments() + 1);
        aBlog = iDao.update(aBlog);

        //Notification save
        addNotification(aProfile, userAccount, null, aBlog.getCreator(), aBlog, userAccount.getFirstName() + " " + userAccount.getLastName() + " added a new Comment", "PUBLIC", Boolean.TRUE, NotificationType.COMMENT, null);

        //webSocket Notification
        notifications(aBlog.getCreator(), iDao);

        //webSocket for comment
        commentRefreshMy(aBlog, comment, "post");

        return new GenericResponse(true, "Comment SuccessFully create !!");
    }

    @Override
    public GenericResponse updateComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, BlogComments comments, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        Profile aProfile = checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullLongId(commentId, ExceptionStatus.COMMENT_ID_MISSING);

        BlogComments aComments = iDao.find(BlogComments.class, commentId);
        if (aComments == null) {
            checkNullObject(aComments, ExceptionStatus.COMMENT_NOT_ADDED);
        }

        try {
            aComments.setComments(comments.getComments());
            aComments.setChanged(getCurrentTime());
            aComments.setChanger(userAccount);
            aComments = iDao.update(aComments);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.COMMENT_NOT_UPDATE);
        }

        //Notification
//        addNotification(aProfile, userAccount, null, aBlog.getCreator(), aBlog, userAccount.getFirstName() + " " + userAccount.getLastName() + " added a new Comment", "PUBLIC", Boolean.TRUE, NotificationType.COMMENT);

        //webSocket for comment
        commentRefreshMy(aBlog, aComments, "update");

        return new GenericResponse(true, "Comment SuccessFully Update !!");
    }

    @Override
    public GenericResponse deleteComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);

        BlogComments aComments = iDao.find(BlogComments.class, commentId);
        if (aComments == null) {
            throw new GenericException(ExceptionStatus.COMMENT_NOT_FOUND);
        }

        try {
            iDao.purge(aComments);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_DELETE);
        }

        aBlog.setTotalComments(aBlog.getTotalComments() - 1);
        aBlog = iDao.update(aBlog);

        mCriteria.clear();
        mCriteria.put("blog", aBlog);
        List<BlogComments> aCommentsList = iDao.getEntities(BlogComments.class, queryManager.fetchCommentByBlog(), mCriteria);
        mCriteria.clear();

        Map<String, List<BlogComments>> aMap =new HashMap<>();
        aMap.put("comments", aCommentsList);

        //webSocket for deleteComment
        commentDelete(aBlog,  dozerBeanMapper.map(aMap, FetchAllComment.class));

        return new GenericResponse(true, "Blog SuccessFully Deleted !!");

    }
}
