package com.lynkersoft.delzee.dto.blogController.fetchAll;

import com.lynkersoft.delzee.dto.blogController.entity.Attachment;

import java.util.ArrayList;
import java.util.List;

public class FetchAllVideo {
    List<Attachment> videos = new ArrayList<>();

    public List<Attachment> getVideos() {
        return videos;
    }

    public void setVideos(List<Attachment> videos) {
        this.videos = videos;
    }
}
