package com.lynkersoft.delzee.utils.exception;

import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.exception.util.BaseException;

public class OperationFailedException extends BaseException {

    private static final long serialVersionUID = 1L;

    public OperationFailedException(ExceptionStatus serviceStatus) {
        super(serviceStatus);
    }

    public OperationFailedException() {
        super(ExceptionStatus.OPERATION_FAILED);
    }

}
