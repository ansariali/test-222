package com.lynkersoft.delzee.utils.enums;

public enum FriendRequestStatus {
    PENDING, ACCEPTED, REJECTED, BLOCK
}
