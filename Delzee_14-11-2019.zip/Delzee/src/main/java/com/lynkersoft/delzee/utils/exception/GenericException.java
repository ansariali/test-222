package com.lynkersoft.delzee.utils.exception;

import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.exception.util.BaseException;

public class GenericException extends BaseException {
    private static final long serialVersionUID = 1L;

    public GenericException(ExceptionStatus serviceStatus) {
        super(serviceStatus);
    }

    public GenericException() {
        super(ExceptionStatus.GENERIC_FAILURE);
    }
}
