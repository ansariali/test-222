package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.dto.chatController.fetchAll.FetchAllChat;
import com.lynkersoft.delzee.dto.chatController.fetchAll.FetchAllFriends;
import com.lynkersoft.delzee.dto.chatController.fetchAll.FetchAllGroup;
import com.lynkersoft.delzee.dto.chatController.fetchAll.FetchAllGroupChatMessage;
import com.lynkersoft.delzee.entities.Chat;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.ChatService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/chatController/v1/")
public class ChatController extends GenericController {
    @Autowired
    ChatService chatService;

    private Logger logger = LoggerFactory.getLogger(ChatController.class);


    @GetMapping("seenAll/message/{userId}")
    public ResponseEntity<GenericResponse> seenAllMessage(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside seenAllMessage :");
        return new ResponseEntity<>(chatService.SeenAll(verifySession(userId, requestHeader), profileId, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/unSeenMessage/{userId}")
    public ResponseEntity<FetchAllChat> fetchAllUnSeenMessage(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllUnSeenMessage :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAllUnSeenMessage(verifySession(userId, requestHeader), profileId, iDao), FetchAllChat.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/friends/{userId}")
    public ResponseEntity<FetchAllFriends> fetchAllFriends(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllFriends :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAllFriends(verifySession(userId, requestHeader), profileId, iDao), FetchAllFriends.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/groups/{userId}")
    public ResponseEntity<FetchAllGroup> fetchAllGroup(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllGroup :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAllGroup(verifySession(userId, requestHeader), profileId, iDao), FetchAllGroup.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/chat/{userId}")
    public ResponseEntity<FetchAllChat> fetchAllChat(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long receiverId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllChat :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAll(verifySession(userId, requestHeader), profileId, receiverId, iDao), FetchAllChat.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/groupChat/{userId}")
    public ResponseEntity<FetchAllGroupChatMessage> fetchAllGroupMessage(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long chatGroupId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllGroupMessage :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAllGroupMessage(verifySession(userId, requestHeader), profileId, chatGroupId, iDao), FetchAllGroupChatMessage.class), responseHeaders, HttpStatus.OK);
    }

    @PostMapping("save/{userId}")
    public ResponseEntity<GenericResponse> saveChat(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long receiverId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Chat chat) {
        logger.info("Inside saveChat :");
        return new ResponseEntity<>(chatService.save(verifySession(userId, requestHeader), profileId, receiverId, chat, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping("saveGroupMessage/{userId}")
    public ResponseEntity<GenericResponse> saveGroupMessage(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long chatGroupId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Chat chat) {
        logger.info("Inside saveChat :");
        return new ResponseEntity<>(chatService.saveGroupChat(verifySession(userId, requestHeader), profileId, chatGroupId, chat, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping("createGroup/{userId}")
    public ResponseEntity<GenericResponse> createGroup(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam String groupName, @RequestHeader Map<String, Object> requestHeader, @RequestBody List<UserAccount> users) {
        logger.info("Inside createGroup :");
        return new ResponseEntity<>(chatService.createGroup(verifySession(userId, requestHeader), profileId, groupName, users, iDao), responseHeaders, HttpStatus.OK);
    }
}
