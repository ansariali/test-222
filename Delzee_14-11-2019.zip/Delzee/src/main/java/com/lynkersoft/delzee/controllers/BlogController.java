package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllBlogResponse;
import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllImage;
import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllVideo;
import com.lynkersoft.delzee.dto.common.BlogRequestBody;
import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.BlogSharing;
import com.lynkersoft.delzee.service.BlogService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/blogController/v1/")
public class BlogController extends GenericController {

    @Autowired
    BlogService blogService;
    private Logger logger = LoggerFactory.getLogger(BlogController.class);

    @PostMapping("save/byte/{userId}")
    public ResponseEntity<GenericResponse> saveBlogByByte(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogRequestBody blog) throws IOException {
        logger.info("Inside saveBlogByByte :"+ blog);

        return null;
//        return new ResponseEntity<>(blogService.createBlog(verifySession(userId, requestHeader), profileId, description, files, iDao),responseHeaders, HttpStatus.OK);
    }

    @PostMapping("save/{userId}/{profileId}")
    public ResponseEntity<GenericResponse> saveBlog(@PathVariable Long userId, @PathVariable Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestParam(value = "file") MultipartFile[] files, @RequestParam("description") String description) throws IOException {
        logger.info("Inside saveBlog :");
        return new ResponseEntity<>(blogService.createBlog(verifySession(userId, requestHeader), profileId, description, files, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping("update/{userId}")
    public ResponseEntity<GenericResponse> updateBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Blog blog) {
        logger.info("Inside updateBlog :");
        return new ResponseEntity<>(blogService.updateBlog(verifySession(userId, requestHeader), profileId, blogId, blog, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping("share/{userId}")
    public ResponseEntity<GenericResponse> blogShare(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader, @RequestBody BlogSharing blogSharing) {
        logger.info("Inside blogShare :");
        return new ResponseEntity<>(blogService.blogShare(verifySession(userId, requestHeader), profileId, blogId, blogSharing, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetch/blog/byId/{userId}")
    public ResponseEntity<FetchAllBlogResponse> fetchAllBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllBlog :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchAllBlog(verifySession(userId, requestHeader), profileId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchAll/blog/{userId}")
    public ResponseEntity<FetchAllBlogResponse> fetchAllBlogPublic(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllBlogPublic :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchAllBlogPublic(verifySession(userId, requestHeader), profileId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchBlog/byUserId/{userId}")
    public ResponseEntity<FetchAllBlogResponse> fetchBlogByUserId(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long friendId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchBlogByUserId :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchBlogByUserId(verifySession(userId, requestHeader), profileId, friendId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchImage/byUserId/{userId}")
    public ResponseEntity<FetchAllImage> fetchImageByUserId(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long friendId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchImageByUserId :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchImageByUserId(verifySession(userId, requestHeader), profileId, friendId, iDao), FetchAllImage.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "fetchVideo/byUserId/{userId}")
    public ResponseEntity<FetchAllVideo> fetchVideoByUserId(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long friendId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchVideoByUserId :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchVideoByUserId(verifySession(userId, requestHeader), profileId, friendId, iDao), FetchAllVideo.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "blog/ById/{userId}")
    public ResponseEntity<com.lynkersoft.delzee.dto.notificationController.entity.Blog> fetchBlogById(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchBlogById :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchBlogById(verifySession(userId, requestHeader), profileId, blogId, iDao), com.lynkersoft.delzee.dto.notificationController.entity.Blog.class), responseHeaders, HttpStatus.OK);
    }

    @DeleteMapping("delete/{userId}")
    public ResponseEntity<GenericResponse> deleteBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside deleteBlog :");
        return new ResponseEntity<>(blogService.deleteBlog(verifySession(userId, requestHeader), profileId, blogId, iDao), responseHeaders, HttpStatus.OK);
    }

    @DeleteMapping("deleteAttachment/{userId}")
    public ResponseEntity<GenericResponse> deleteAttachment(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestParam Long attachmentId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside deleteAttachment :");
        return new ResponseEntity<>(blogService.deleteAttachment(verifySession(userId, requestHeader), profileId, blogId, attachmentId, iDao), responseHeaders, HttpStatus.OK);
    }
}
