package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;
import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "friend")
public class Friend extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long friendId;

    @NotNull(message = "friend request status must be required!")
    @Enumerated(EnumType.STRING)
    private FriendRequestStatus friendRequestStatus;

    private Boolean friendRequestAcceptedStatus;

    private Date friendRequestAcceptedDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friendsId")
    private UserAccount friends;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friendRequestBy")
    private UserAccount friendRequestBy;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friendRequestId")
    private FriendRequest friendRequest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_id")
    private Profile profile;

    public UserAccount getFriendRequestBy() {
        return friendRequestBy;
    }

    public void setFriendRequestBy(UserAccount friendRequestBy) {
        this.friendRequestBy = friendRequestBy;
    }

    public UserAccount getFriends() {
        return friends;
    }

    public void setFriends(UserAccount friends) {
        this.friends = friends;
    }

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public FriendRequestStatus getFriendRequestStatus() {
        return friendRequestStatus;
    }

    public void setFriendRequestStatus(FriendRequestStatus friendRequestStatus) {
        this.friendRequestStatus = friendRequestStatus;
    }

    public Boolean getFriendRequestAcceptedStatus() {
        return friendRequestAcceptedStatus;
    }

    public void setFriendRequestAcceptedStatus(Boolean friendRequestAcceptedStatus) {
        this.friendRequestAcceptedStatus = friendRequestAcceptedStatus;
    }

    public Date getFriendRequestAcceptedDate() {
        return friendRequestAcceptedDate;
    }

    public void setFriendRequestAcceptedDate(Date friendRequestAcceptedDate) {
        this.friendRequestAcceptedDate = friendRequestAcceptedDate;
    }

    public FriendRequest getFriendRequest() {
        return friendRequest;
    }

    public void setFriendRequest(FriendRequest friendRequest) {
        this.friendRequest = friendRequest;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
}
