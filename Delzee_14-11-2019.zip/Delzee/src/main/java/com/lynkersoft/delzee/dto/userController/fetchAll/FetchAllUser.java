package com.lynkersoft.delzee.dto.userController.fetchAll;

import com.lynkersoft.delzee.dto.common.User_;

import java.util.ArrayList;
import java.util.List;

public class FetchAllUser {

    List<User_> users = new ArrayList<>();

    public List<User_> getUsers() {
        return users;
    }

    public void setUsers(List<User_> users) {
        this.users = users;
    }
}
