package com.lynkersoft.delzee.dto.blogController.fetchAll;

import com.lynkersoft.delzee.dto.blogController.entity.Attachment;

import java.util.ArrayList;
import java.util.List;

public class FetchAllImage {
    List<Attachment> images = new ArrayList<>();

    public List<Attachment> getImages() {
        return images;
    }

    public void setImages(List<Attachment> images) {
        this.images = images;
    }
}
