package com.lynkersoft.delzee.utils.exception.util;

import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;

public class ServiceError {
    private final Long errorCode;

    private final String errorMessage;

    ServiceError(ExceptionStatus exceptionStatus) {
        this.errorCode = exceptionStatus.getErrorCode();
        this.errorMessage = exceptionStatus.getProductionMessage();
    }

    public Long getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

}
