package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.Follow;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.CommonService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.FollowStatus;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Objects;


@Service
@Transactional
public class CommonServiceImpl extends GenericImplHandler implements CommonService {

    @Override
    public GenericResponse createFollow(UserAccount userAccount, Long profileId, Long friendId, String followStatus, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(friendId, ExceptionStatus.FRIEND_ID_MISSING);
        checkNullString(followStatus, ExceptionStatus.FOLLOW_STATUS);
        checkProfile(profileId, userAccount, iDao);

        UserAccount friend = iDao.find(UserAccount.class, friendId);
        checkNullObject(friend, ExceptionStatus.FOLLOW_NOT_FOUND);


        Follow aFollow = new Follow();
        aFollow.setFollowStatus(FollowStatus.FOLLOW.toString());
        aFollow.setFollowBy(userAccount);
        aFollow.setFollowTo(friend);
        aFollow.setCreated(getCurrentTime());

        try {
            iDao.persist(aFollow);
        }catch (Exception e) {
            throw new GenericException(ExceptionStatus.FOLLOW_NOT_ADDED);
        }
        return new GenericResponse(true, " Follow SuccessFully!!");
    }

    @Override
    public GenericResponse unFollow(UserAccount userAccount, Long profileId, Long followId, String followStatus, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(followId, ExceptionStatus.FOLLOW_ID_MISSING);
        checkNullString(followStatus, ExceptionStatus.FOLLOW_STATUS);
        checkProfile(profileId, userAccount, iDao);

        Follow aFollow = iDao.find(Follow.class, followId);
        checkNullObject(aFollow, ExceptionStatus.FOLLOW_NOT_FOUND);

        if(!Objects.equals(aFollow.getFollowStatus(), FollowStatus.FOLLOW)) {
            throw new GenericException(ExceptionStatus.UN_FOLLOW_ALREADY);
        }

        aFollow.setFollowStatus(FollowStatus.UNFOLLOW.toString());
        aFollow.setUnFollowDate(getCurrentTime());
        try {
            iDao.update(aFollow);
        }catch (Exception e) {
            throw new GenericException(ExceptionStatus.FOLLOW_NOT_ADDED);
        }
        return new GenericResponse(true, "  UnFollow SuccessFully!!");
    }
}
