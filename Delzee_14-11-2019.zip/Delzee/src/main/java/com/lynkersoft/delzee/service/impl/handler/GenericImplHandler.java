package com.lynkersoft.delzee.service.impl.handler;

import com.lynkersoft.delzee.utils.abstracts.GenericService;

public abstract class GenericImplHandler extends GenericService {

}
