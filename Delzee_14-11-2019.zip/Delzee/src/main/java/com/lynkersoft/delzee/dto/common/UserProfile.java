package com.lynkersoft.delzee.dto.common;

public class UserProfile {
    private String firstName;
    private String lastName;
    private Attachment_ attachment;
    private _Profile profile;

    public _Profile getProfile() {
        return profile;
    }

    public void setProfile(_Profile profile) {
        this.profile = profile;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Attachment_ getAttachment() {
        return attachment;
    }

    public void setAttachment(Attachment_ attachment) {
        this.attachment = attachment;
    }
}
