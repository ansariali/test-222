package com.lynkersoft.delzee.dto.chatController.fetchAll;

import com.lynkersoft.delzee.dto.chatController.entity.Group;

import java.util.ArrayList;
import java.util.List;

public class FetchAllGroup {

    List<Group> groups = new ArrayList<>();

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }
}
