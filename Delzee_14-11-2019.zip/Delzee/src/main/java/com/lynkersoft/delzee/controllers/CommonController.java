package com.lynkersoft.delzee.controllers;


import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllBlogResponse;
import com.lynkersoft.delzee.service.CommonService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/commonController")
public class CommonController extends GenericController {
    private Logger logger = LoggerFactory.getLogger(CommonController.class);

    @Autowired
    CommonService commonService;

    @GetMapping(value = "/v1/follow/{userId}")
    public ResponseEntity<GenericResponse> createFollow(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long friendId, @RequestParam String followStatus, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside createFollow :");
        return new ResponseEntity<>(commonService.createFollow(verifySession(userId, requestHeader), profileId, friendId, followStatus, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/unFollow/{userId}")
    public ResponseEntity<GenericResponse> unFollow(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long followId, @RequestParam String followStatus, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside createFollow :");
        return new ResponseEntity<>(commonService.unFollow(verifySession(userId, requestHeader), profileId, followId, followStatus, iDao), responseHeaders, HttpStatus.OK);
    }
}
