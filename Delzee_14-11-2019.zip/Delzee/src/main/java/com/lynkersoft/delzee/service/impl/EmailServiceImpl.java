package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.service.EmailService;
import com.lynkersoft.delzee.utils.enums.EmailTemplate;
import com.lynkersoft.delzee.utils.enums.GenericInfo;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Component
public class EmailServiceImpl implements EmailService {

    @Autowired
    private VelocityEngine mVelocityEngine;

    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public Boolean sendEmailForRegistration(String to, String firstName, String token) {
        try {
            Map<String, Object> model = new HashMap<>();
            model.put("firstName", firstName);
            sendEmail(null, to, EmailTemplate.WELCOME.getEmailSubject(), model, EmailTemplate.WELCOME.getTemplateUrl());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Async
    public Boolean forgotPassword(String from, String to, String firstName, String optCode, String token) {
        try {
            Map<String, Object> model = new HashMap<>();

            model.put("firstName", firstName);
//            model.put("token", "https://test.easeprocure.com/#/new-password/" + token);
            model.put("token", "http://192.168.43.77:4500/#/new-password/" + token);
            sendEmail(from, to, EmailTemplate.FORGOT_PASSWORD.getEmailSubject(), model, EmailTemplate.FORGOT_PASSWORD.getTemplateUrl());

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @Async
    void sendEmail(final String from, final String to, final String subject, final Map<String, Object> model, final String template) {
        MimeMessagePreparator aMimeMessagePreparator = mimeMessage -> {
            try {
                MimeMessageHelper aMimeMessageHelper = new MimeMessageHelper(mimeMessage);

                aMimeMessageHelper.setFrom(((from != null) && (!Objects.equals(from, ""))) ? from + GenericInfo.Dlzee_Email_Host.getStatus() : "no-reply" + GenericInfo.Dlzee_Email_Host.getStatus());
                aMimeMessageHelper.setTo(to);
                aMimeMessageHelper.setSubject(subject);
                aMimeMessageHelper.setText(VelocityEngineUtils.mergeTemplateIntoString(mVelocityEngine, template, "UTF-8", model), true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        };
        javaMailSender.send(aMimeMessagePreparator);
    }

}
