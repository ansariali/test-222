package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Chat;
import com.lynkersoft.delzee.entities.ChatGroups;
import com.lynkersoft.delzee.entities.Friend;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ChatService {
    GenericResponse save(UserAccount userAccount, Long profileId, Long receiverId, Chat chat, IDao<IEntity, Serializable> iDao);

    GenericResponse saveGroupChat(UserAccount userAccount, Long profileId, Long chatGroupId, Chat chat, IDao<IEntity, Serializable> iDao);

    GenericResponse createGroup(UserAccount userAccount, Long profileId, String groupName, List<UserAccount> userAccounts, IDao<IEntity, Serializable> iDao);

    Map<String, List<Chat>> fetchAll(UserAccount userAccount, Long profileId, Long receiverId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Chat>> fetchAllGroupMessage(UserAccount userAccount, Long profileId, Long chatGroupId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Friend>> fetchAllFriends(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Map<String, List<ChatGroups>> fetchAllGroup(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Map<String, List<Chat>> fetchAllUnSeenMessage(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse SeenAll(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

}
