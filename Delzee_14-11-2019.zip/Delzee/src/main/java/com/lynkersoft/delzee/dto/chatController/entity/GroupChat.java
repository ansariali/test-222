package com.lynkersoft.delzee.dto.chatController.entity;

import com.lynkersoft.delzee.dto.common.User_;

import java.util.Date;

public class GroupChat {
    private Long chatId;
    private String message;
    private Date created;
    private User_ sender;

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public User_ getSender() {
        return sender;
    }

    public void setSender(User_ sender) {
        this.sender = sender;
    }
}
