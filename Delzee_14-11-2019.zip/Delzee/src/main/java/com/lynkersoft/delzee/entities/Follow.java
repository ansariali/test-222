package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "follows")
public class Follow extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long followId;

    private String followStatus;

    private Date created;

    private Date unFollowDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "followBy")
    private UserAccount followBy;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "followTo")
    private UserAccount followTo;


    public Date getUnFollowDate() {
        return unFollowDate;
    }

    public void setUnFollowDate(Date unFollowDate) {
        this.unFollowDate = unFollowDate;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Long getFollowId() {
        return followId;
    }

    public void setFollowId(Long followId) {
        this.followId = followId;
    }

    public String getFollowStatus() {
        return followStatus;
    }

    public void setFollowStatus(String followStatus) {
        this.followStatus = followStatus;
    }

    public UserAccount getFollowBy() {
        return followBy;
    }

    public void setFollowBy(UserAccount followBy) {
        this.followBy = followBy;
    }

    public UserAccount getFollowTo() {
        return followTo;
    }

    public void setFollowTo(UserAccount followTo) {
        this.followTo = followTo;
    }
}
