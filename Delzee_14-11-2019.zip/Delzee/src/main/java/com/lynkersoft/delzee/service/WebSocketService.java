package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllComment;
import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.Chat;
import com.lynkersoft.delzee.entities.FriendRequest;
import com.lynkersoft.delzee.entities.UserAccount;

import java.util.Map;

public interface WebSocketService {
    void refreshNotification(Long userId, Map<String, Object> payload);
    void commentRefreshMy(Blog blog, String postType,  Map<String, Object> payload);
    void commentDelete(Blog blog, FetchAllComment comments);
    void refreshLikes(Blog blog, Map<String, Object> payload);
    void refreshChat(UserAccount receiver, Map<String, Object> payload);
    void refreshGroupChat(String token, Map<String, Object> payload);
    void friendRequestSend(FriendRequest friendRequest, Map<String, Object> payload);

}
