package com.lynkersoft.delzee.dto.userController.entity;

import com.lynkersoft.delzee.utils.enums.Privacy;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Profile {

    private Long profileId;
    private String occupation;
    private String gender;
    private String status;
    private String website;
    private String religiousBeliefs;
    private String politicalIncline;

    private Privacy addressPrivacy;
    private Privacy hobbyPrivacy;
    private Privacy friendPrivacy;
    private Privacy educationPrivacy;
    private Privacy aboutMePrivacy;
    private String aboutMe;
    private Privacy birthDayPrivacy;
    private Date birthDay;
    private Privacy birthPlacePrivacy;
    private String birthPlace;
    private Privacy phoneNumberPrivacy;
    private String phoneNumber;

    private List<Address> address = new ArrayList<>();
    private List<Education> educations = new ArrayList<>();
    private List<Hobbie> hobbies = new ArrayList<>();
    private List<Friend> friends = new ArrayList<>();
    private List<Blog> blogs = new ArrayList<>();

    public List<Blog> getBlogs() {
        return blogs;
    }

    public void setBlogs(List<Blog> blogs) {
        this.blogs = blogs;
    }

    public List<Friend> getFriends() {
        return friends;
    }

    public void setFriends(List<Friend> friends) {
        this.friends = friends;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Privacy getAddressPrivacy() {
        return addressPrivacy;
    }

    public void setAddressPrivacy(Privacy addressPrivacy) {
        this.addressPrivacy = addressPrivacy;
    }

    public Privacy getHobbyPrivacy() {
        return hobbyPrivacy;
    }

    public void setHobbyPrivacy(Privacy hobbyPrivacy) {
        this.hobbyPrivacy = hobbyPrivacy;
    }

    public Privacy getFriendPrivacy() {
        return friendPrivacy;
    }

    public void setFriendPrivacy(Privacy friendPrivacy) {
        this.friendPrivacy = friendPrivacy;
    }

    public Privacy getEducationPrivacy() {
        return educationPrivacy;
    }

    public void setEducationPrivacy(Privacy educationPrivacy) {
        this.educationPrivacy = educationPrivacy;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }

    public List<Education> getEducations() {
        return educations;
    }

    public void setEducations(List<Education> educations) {
        this.educations = educations;
    }

    public List<Hobbie> getHobbies() {
        return hobbies;
    }

    public void setHobbies(List<Hobbie> hobbies) {
        this.hobbies = hobbies;
    }

    public Privacy getAboutMePrivacy() {
        return aboutMePrivacy;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public void setAboutMePrivacy(Privacy aboutMePrivacy) {
        this.aboutMePrivacy = aboutMePrivacy;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getReligiousBeliefs() {
        return religiousBeliefs;
    }

    public void setReligiousBeliefs(String religiousBeliefs) {
        this.religiousBeliefs = religiousBeliefs;
    }

    public String getPoliticalIncline() {
        return politicalIncline;
    }

    public void setPoliticalIncline(String politicalIncline) {
        this.politicalIncline = politicalIncline;
    }

    public Privacy getBirthDayPrivacy() {
        return birthDayPrivacy;
    }

    public void setBirthDayPrivacy(Privacy birthDayPrivacy) {
        this.birthDayPrivacy = birthDayPrivacy;
    }

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public Privacy getBirthPlacePrivacy() {
        return birthPlacePrivacy;
    }

    public void setBirthPlacePrivacy(Privacy birthPlacePrivacy) {
        this.birthPlacePrivacy = birthPlacePrivacy;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public Privacy getPhoneNumberPrivacy() {
        return phoneNumberPrivacy;
    }

    public void setPhoneNumberPrivacy(Privacy phoneNumberPrivacy) {
        this.phoneNumberPrivacy = phoneNumberPrivacy;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
