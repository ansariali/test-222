package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.Chat;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.ChatService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ChatServiceImpl extends GenericImplHandler implements ChatService {

    @Override
    public Map<String, List<Chat>> fetchAll(UserAccount userAccount, Long profileId, Long receiverId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        mCriteria.put("sender", userAccount);
        mCriteria.put("receiver", receiver);
        List<Chat> chatMessageList = iDao.getEntities(Chat.class, queryManager.fetchAllMessage(), mCriteria);
        mCriteria.clear();

        Map<String, List<Chat>> aMap = new HashMap<>();
        aMap.put("chats", chatMessageList);
        return aMap;
    }

    @Override
    public GenericResponse save(UserAccount userAccount, Long profileId, Long receiverId, Chat chat, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(chat.getMessage(), ExceptionStatus.MESSAGE_MISSING);
        checkProfile(profileId, userAccount, iDao);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.RECEIVER_NOT_FOUND);

        if (userAccount == receiver) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        try {
            Chat aChat = new Chat();
            aChat.setCreated(getCurrentTime());
            aChat.setMessage(chat.getMessage());
            aChat.setReceiver(receiver);
            aChat.setSender(userAccount);
           aChat = iDao.find(Chat.class, iDao.persist(aChat));

            //webSocket for Chat
            chat(receiver, aChat);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.MESSAGE_NOT_ADDED);
        }
        return new GenericResponse(true, "Message Send SuccessFully !!");
    }
}
