package com.lynkersoft.delzee.controllers;

import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllBlogResponse;
import com.lynkersoft.delzee.dto.chatController.fetchAll.FetchAllChat;
import com.lynkersoft.delzee.entities.Chat;
import com.lynkersoft.delzee.service.ChatService;
import com.lynkersoft.delzee.utils.GenericController;
import com.lynkersoft.delzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/chatController")
public class ChatController extends GenericController {
    @Autowired
    ChatService chatService;

    private Logger logger = LoggerFactory.getLogger(ChatController.class);


    @GetMapping(value = "/v1/fetchAll/chat/{userId}")
    public ResponseEntity<FetchAllChat> fetchAllChat(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long receiverId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllChat :");
        return new ResponseEntity<>(dozerBeanMapper.map(chatService.fetchAll(verifySession(userId, requestHeader), profileId, receiverId, iDao), FetchAllChat.class), responseHeaders, HttpStatus.OK);
    }

    @PostMapping("/v1/save/{userId}")
    public ResponseEntity<GenericResponse> save(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long  receiverId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Chat chat) {
        logger.info("Inside save :");
        return new ResponseEntity<>(chatService.save(verifySession(userId, requestHeader), profileId, receiverId, chat, iDao), responseHeaders, HttpStatus.OK);
    }



}
