package com.lynkersoft.delzee.dto.common;

import java.util.Date;

public class Comment_ {

    private Long blogCommentId;
    private String comments;
    private User_ creator;
    private Date created;

    public Long getBlogCommentId() {
        return blogCommentId;
    }

    public void setBlogCommentId(Long blogCommentId) {
        this.blogCommentId = blogCommentId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
