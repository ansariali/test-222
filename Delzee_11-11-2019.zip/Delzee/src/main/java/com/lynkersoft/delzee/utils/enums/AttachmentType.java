package com.lynkersoft.delzee.utils.enums;

public enum AttachmentType {
    IMAGE, VIDEO
}
