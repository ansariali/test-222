package com.lynkersoft.delzee.dto.userController.entity;

import java.util.Date;

public class BlogLikes {

    private Long blogLikeId;
    private Boolean liked;
    private Date created;

    public Long getBlogLikeId() {
        return blogLikeId;
    }

    public void setBlogLikeId(Long blogLikeId) {
        this.blogLikeId = blogLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
