package com.lynkersoft.delzee.dto.common;

public class Blog_ {
    private Long blogId;


    public Long getBlogId() {
        return blogId;
    }

    public void setBlogId(Long blogId) {
        this.blogId = blogId;
    }
}
