package com.lynkersoft.delzee.dto.chatController.entity;

import com.lynkersoft.delzee.dto.common.User_;

import java.util.Date;

public class Chat {
    private Long chatId;
    private String message;
    private User_ sender;
    private User_ receiver;
    private Date created;

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public User_ getSender() {
        return sender;
    }

    public void setSender(User_ sender) {
        this.sender = sender;
    }

    public User_ getReceiver() {
        return receiver;
    }

    public void setReceiver(User_ receiver) {
        this.receiver = receiver;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
