package com.lynkersoft.delzee.dto.chatController.fetchAll;

import com.lynkersoft.delzee.dto.chatController.entity.Chat;

import java.util.ArrayList;
import java.util.List;

public class FetchAllChat {

    List<Chat> chats = new ArrayList<>();

    public List<Chat> getChats() {
        return chats;
    }

    public void setChats(List<Chat> chats) {
        this.chats = chats;
    }
}
