package com.lynkersoft.dlzee.service.impl;

import com.lynkersoft.dlzee.entities.Blog;
import com.lynkersoft.dlzee.entities.BlogComments;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.CommentService;
import com.lynkersoft.dlzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public class CommentServiceImpl extends GenericImplHandler implements CommentService {

    @Override
    public GenericResponse createComment(UserAccount userAccount, Long profileId, Long blogId, BlogComments comments, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullObject(comments, ExceptionStatus.COMMENT_MISSING);

        try {
            BlogComments comment = new BlogComments();
            comment.setComments(comments.getComments());
            comment.setCreator(userAccount);
            comment.setCreated(getCurrentTime());
            comment.setBlog(aBlog);
            iDao.persist(comment);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.COMMENT_NOT_ADDED);
        }
        aBlog.setTotalComments(aBlog.getTotalComments() + 1);
        iDao.update(aBlog);

        return new GenericResponse(true, "Comment SuccessFully create !!");
    }

    @Override
    public GenericResponse updateComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, BlogComments comments, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullLongId(commentId, ExceptionStatus.COMMENT_ID_MISSING);

        BlogComments aComments = iDao.find(BlogComments.class, commentId);
        if(aComments == null) {
            checkNullObject(aComments, ExceptionStatus.COMMENT_NOT_ADDED);
        }

        try {
            aComments.setComments(comments.getComments());
            aComments.setChanged(getCurrentTime());
            aComments.setChanger(userAccount);
            iDao.update(aComments);
            aBlog.setTotalComments(aBlog.getTotalComments() + 1);

        }catch (Exception e) {
            throw new GenericException(ExceptionStatus.COMMENT_NOT_UPDATE);
        }
        return new GenericResponse(true, "Comment SuccessFully Update !!");
    }

    @Override
    public GenericResponse deleteComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);

        BlogComments aComments = iDao.find(BlogComments.class, commentId);
        if(aComments == null) {
            checkNullObject(aComments, ExceptionStatus.COMMENT_NOT_ADDED);
        }
        if (aComments.getDeleted()) {
            throw new GenericException(ExceptionStatus.COMMENT_ALL_READY_DELETE);
        }

        try {
            aComments.setDeleted(Boolean.TRUE);
            aComments.setDeleteComment(getCurrentTime());
            iDao.update(aComments);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_DELETE);
        }

        aBlog.setTotalComments(aBlog.getTotalComments() - 1);
        iDao.update(aBlog);

        return new GenericResponse(true, "Blog SuccessFully Deleted !!");

    }
}
