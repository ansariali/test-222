package com.lynkersoft.dlzee.service;

import com.lynkersoft.dlzee.entities.Blog;
import com.lynkersoft.dlzee.entities.BlogComments;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface CommentService {

    GenericResponse createComment(UserAccount userAccount, Long profileId, Long blogId, BlogComments comments, IDao<IEntity, Serializable> iDao);

    GenericResponse updateComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, BlogComments comments, IDao<IEntity, Serializable> iDao);

    GenericResponse deleteComment(UserAccount userAccount, Long profileId, Long blogId, Long commentId, IDao<IEntity, Serializable> iDao);

}
