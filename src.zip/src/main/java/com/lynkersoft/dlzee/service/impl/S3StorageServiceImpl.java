package com.lynkersoft.dlzee.service.impl;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.lynkersoft.dlzee.service.S3StorageService;
import com.lynkersoft.dlzee.utils.abstracts.GenericService;
import com.lynkersoft.dlzee.utils.enums.S3Storage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Component
public class S3StorageServiceImpl extends GenericService implements S3StorageService {

    @Autowired
    private AmazonS3 amazonS3;

    @Value("${jsa.s3.bucket}")
    private String bucketName;

    @Value("${jsa.s3.mainKey}")
    private String mainKey;

    @Override
    public String uploadFile(String prefix, MultipartFile multipartFile) throws IOException {
        File file = convertMultiPartToFile(multipartFile);
        String fileKey = generateFileKey(prefix, multipartFile);
        amazonS3.putObject(new PutObjectRequest(bucketName, fileKey, file));
        file.delete();
        return fileKey;
    }

    @Override
    public File convertMultiPartToFile(MultipartFile file) throws IOException {
        File _file = new File(file.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(_file);
        fos.write(file.getBytes());
        fos.close();
        return _file;
    }

    @Override
    public String generateFileKey(String prefix, MultipartFile multipartFile) {
        return mainKey + prefix + multipartFile.getOriginalFilename().replace(S3Storage.SPACE.getInfo(), S3Storage.UNDER_SCORE.getInfo());
    }

}
