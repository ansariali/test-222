package com.lynkersoft.dlzee.service;

import com.lynkersoft.dlzee.entities.BlogComments;
import com.lynkersoft.dlzee.entities.BlogLikes;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;

import java.io.Serializable;

public interface LikeService {

    GenericResponse createLike(UserAccount userAccount, Long profileId, Long blogId, BlogLikes blogLike, IDao<IEntity, Serializable> iDao);

    GenericResponse updateLike(UserAccount userAccount, Long profileId, Long blogId, Long LikeId, BlogLikes comments, IDao<IEntity, Serializable> iDao);

}
