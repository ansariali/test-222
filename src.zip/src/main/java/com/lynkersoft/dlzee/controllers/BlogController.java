package com.lynkersoft.dlzee.controllers;

import com.lynkersoft.dlzee.dto.blogController.fetchAll.FetchAllBlogResponse;
import com.lynkersoft.dlzee.dto.userController.fetchAll.FetchAllFriendRequestResponse;
import com.lynkersoft.dlzee.entities.Blog;
import com.lynkersoft.dlzee.service.BlogService;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.utils.GenericController;
import com.lynkersoft.dlzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/blogController")
public class BlogController extends GenericController {

    @Autowired
    BlogService blogService;
    private Logger logger = LoggerFactory.getLogger(BlogController.class);

    @PostMapping("/v1/save/{userId}/{profileId}")
    public ResponseEntity<GenericResponse> saveBlog(@PathVariable Long userId, @PathVariable Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestParam("file") MultipartFile[] files, @RequestParam("description") String  description, @RequestParam("fileType") String  fileType) throws IOException {
        logger.info("Inside saveBlog :");
        return new ResponseEntity<>(blogService.createBlog(verifySession(userId, requestHeader), profileId, description, fileType, files, iDao),responseHeaders, HttpStatus.OK);
    }

    @PutMapping("/v1/update/{userId}")
    public ResponseEntity<GenericResponse> updateBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Blog blog) {
        logger.info("Inside updateBlog :");
        return new ResponseEntity<>(blogService.updateBlog(verifySession(userId, requestHeader), profileId, blogId, blog, iDao),responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/fetch/blog/byId/{userId}")
    public ResponseEntity<FetchAllBlogResponse> fetchAllBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllBlog :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchAllBlog(verifySession(userId, requestHeader), profileId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/fetchAll/blog/{userId}")
    public ResponseEntity<FetchAllBlogResponse> fetchAllBlogPublic(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllBlogPublic :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchAllBlogPublic(verifySession(userId, requestHeader), profileId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/blog/ById/{userId}")
    public ResponseEntity<com.lynkersoft.dlzee.dto.blogController.entity.Blog> fetchBlogById(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchBlogById :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.fetchBlogById(verifySession(userId, requestHeader), profileId, blogId, iDao), com.lynkersoft.dlzee.dto.blogController.entity.Blog.class), responseHeaders, HttpStatus.OK);
    }


    @DeleteMapping("/v1/delete/{userId}")
    public ResponseEntity<FetchAllBlogResponse> deleteBlog(@PathVariable Long userId, @RequestParam Long profileId, @RequestParam Long blogId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside deleteBlog :");
        return new ResponseEntity<>(dozerBeanMapper.map(blogService.deleteBlog(verifySession(userId, requestHeader), profileId, blogId, iDao), FetchAllBlogResponse.class), responseHeaders, HttpStatus.OK);
    }

}
