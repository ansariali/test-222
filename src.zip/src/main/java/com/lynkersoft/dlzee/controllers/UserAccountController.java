package com.lynkersoft.dlzee.controllers;

import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.dto.userController.entity.UpdateProfileRequestBody;
import com.lynkersoft.dlzee.dto.userController.fetchAll.FetchAllFriendRequestResponse;
import com.lynkersoft.dlzee.dto.userController.entity.SignUp;
import com.lynkersoft.dlzee.dto.userController.entity.Token;
import com.lynkersoft.dlzee.dto.userController.entity.User;
import com.lynkersoft.dlzee.entities.Education;
import com.lynkersoft.dlzee.entities.FriendRequest;
import com.lynkersoft.dlzee.entities.Hobbie;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.utils.GenericController;
import com.lynkersoft.dlzee.utils.GenericResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/userController")
public class UserAccountController extends GenericController {

    @Autowired
    UserAccountService userAccountService;
    private Logger logger = LoggerFactory.getLogger(UserAccountController.class);

    @PostMapping("/v1/save/{userId}")
    public ResponseEntity<GenericResponse> saveProfilePicture(@PathVariable Long userId, @RequestParam Long profileId,  @RequestParam(required = false) Long  attachmentId, @RequestHeader Map<String, Object> requestHeader, @RequestParam("file") MultipartFile files, @RequestParam("fileType") String fileType) throws IOException {
        logger.info("Inside saveProfilePicture :");
        return new ResponseEntity<>(userAccountService.saveProfileImage(verifySession(userId, requestHeader),  userId, profileId, attachmentId, fileType, files, iDao),responseHeaders, HttpStatus.OK);
    }


    @PostMapping(value = "/v1/sign-up")
    public ResponseEntity<GenericResponse> signUp(@Valid @RequestBody SignUp signUpRequest) {
        logger.info("Inside SignUp :");
        return new ResponseEntity<>(userAccountService.signUp(signUpRequest, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/sign-in")
    public ResponseEntity<LoginResponseEntity> signIn(@RequestBody UserAccount signUpRequest) {
        logger.info("Inside signIn :");
        return new ResponseEntity<>(userAccountService.signIn(signUpRequest.getUserName(), signUpRequest.getPassword(), iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/sign-out")
    public ResponseEntity<GenericResponse> signOut(@RequestBody Token token) {
        logger.info("Inside signOut :");
        return new ResponseEntity<>(userAccountService.signOut(token.getAccessToken(), iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/forgotPassword")
    public ResponseEntity<GenericResponse> forgotPassword(@RequestParam String emailAddress) {
        logger.info("Inside forgotPassword");
        return new ResponseEntity<>(userAccountService.forgotPassword(emailAddress, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/verify/forgotPassword")
    public ResponseEntity<GenericResponse> verifyForgotPassword(@RequestParam String forgotToken) {
        logger.info("Inside verifyForgotPassword");
        return new ResponseEntity<>(userAccountService.verifyForgotPassword(forgotToken, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/fetchUser/byPrivacy")
    public ResponseEntity<User> fetchUserByPrivacy(@RequestParam Long userId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchUserByPrivacy");
        return new ResponseEntity<>(userAccountService.fetchUserByPrivacy(verifySession(userId, requestHeader), iDao), responseHeaders, HttpStatus.OK);

    }

    @GetMapping(value = "/v1/fetchUser/byId")
    public ResponseEntity<User> fetchUserById(@RequestParam Long userId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchUserById");
        return new ResponseEntity<>(userAccountService.fetchUserById(verifySession(userId, requestHeader), iDao), responseHeaders, HttpStatus.OK);

    }

    @PostMapping(value = "/v1/send/friend-request")
    public ResponseEntity<GenericResponse> sendFriendRequest(@Valid @RequestParam Long userId, @RequestParam Long friendId, @RequestHeader Map<String, Object> requestHeader, @RequestBody FriendRequest friedRequest) {
        logger.info("Inside sendFriendRequest");
        return new ResponseEntity<>(userAccountService.sendFriendRequest(verifySession(userId, requestHeader), friedRequest, friendId, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/accepted/friend-request")
    public ResponseEntity<GenericResponse> acceptedFriendRequest(@RequestParam Long userId, @RequestParam Long friedRequestId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside acceptedFriendRequest");
        return new ResponseEntity<>(userAccountService.friendRequestAccept(verifySession(userId, requestHeader), friedRequestId, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping(value = "/v1/update/profile")
    public ResponseEntity<GenericResponse> updateProfile(@RequestParam Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestBody UpdateProfileRequestBody userRequest) {
        logger.info("Inside updateProfile");
        return new ResponseEntity<>(userAccountService.updateProfile(verifySession(userId, requestHeader), userRequest, profileId, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/create/education/{userId}")
    public ResponseEntity<GenericResponse> createEducation(@Valid @PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Education educationRequest) {
        logger.info("Inside createEducation :");
        return new ResponseEntity<>(userAccountService.createEducation(verifySession(userId, requestHeader), educationRequest, profileId, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping(value = "/v1/update/education/{userId}")
    public ResponseEntity<GenericResponse> updateEducation(@Valid @PathVariable Long userId, @RequestParam Long educationId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Education educationRequest) {
        logger.info("Inside updateEducation :");
        return new ResponseEntity<>(userAccountService.updateEducation(verifySession(userId, requestHeader), educationRequest, educationId, iDao), responseHeaders, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/create/hobbies/{userId}")
    public ResponseEntity<GenericResponse> createHobbies(@Valid @PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Hobbie hobbiesRequest) {
        logger.info("Inside createHobbies :");
        return new ResponseEntity<>(userAccountService.createHobbies(verifySession(userId, requestHeader), hobbiesRequest, profileId, iDao), responseHeaders, HttpStatus.OK);
    }

    @PutMapping(value = "/v1/update/hobbies/{userId}")
    public ResponseEntity<GenericResponse> updateHobbies(@Valid @PathVariable Long userId, @RequestParam Long hobbiesId, @RequestHeader Map<String, Object> requestHeader, @RequestBody Hobbie hobbiesRequest) {
        logger.info("Inside updateHobbies :");
        return new ResponseEntity<>(userAccountService.updateHobbies(verifySession(userId, requestHeader), hobbiesRequest, hobbiesId, iDao), responseHeaders, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/fetch/all/friendRequest/{userId}")
    public ResponseEntity<FetchAllFriendRequestResponse> fetchAllFriendRequest(@PathVariable Long userId, @RequestParam Long profileId, @RequestHeader Map<String, Object> requestHeader) {
        logger.info("Inside fetchAllFriendRequest :");
        FetchAllFriendRequestResponse res = dozerBeanMapper.map(userAccountService.fetchFriendRequest(verifySession(userId, requestHeader), profileId, iDao), FetchAllFriendRequestResponse.class);
        return new ResponseEntity<>(res, responseHeaders, HttpStatus.OK);
    }
}
