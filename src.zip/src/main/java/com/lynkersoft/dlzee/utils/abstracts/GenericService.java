package com.lynkersoft.dlzee.utils.abstracts;

import com.lynkersoft.dlzee.entities.*;
import com.lynkersoft.dlzee.service.EmailService;
import com.lynkersoft.dlzee.utils.QueryManager;
import com.lynkersoft.dlzee.utils.Refactor;
import com.lynkersoft.dlzee.utils.Util;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
public abstract class GenericService {

    protected static Util mUtil = Util.getInstance();
    protected static Refactor mRefactor = Refactor.getInstance();
    @Autowired
    protected IDao<IEntity, Serializable> iDao;
    @Autowired
    protected EmailService mEmailService;
    protected Hashtable<String, Object> mCriteria = new Hashtable<>();
    protected QueryManager queryManager = QueryManager.getInstance();
    protected DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();


    //CheckLike
    protected BlogLikes checkLike(UserAccount userAccount, Blog aBlog) {
        mCriteria.clear();
        mCriteria.put("creator", userAccount);
        mCriteria.put("blog", aBlog);
        BlogLikes blogLike = iDao.getEntity(BlogLikes.class, queryManager.checkLike(), mCriteria);
        mCriteria.clear();
       return  blogLike;
    }

    //checkBlog
    protected Blog checkBlog(Long blogId) {
        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }
        return blog;
    }

    // checkProfile
    protected Profile checkProfile(Long profileId, UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }
        return aProfile;
    }


    //checkForgetToken
    protected ForgotPassword checkForgetToken(String forgotToken, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("forgotToken", forgotToken);
        ForgotPassword aForgotPassword = iDao.getEntity(ForgotPassword.class, queryManager.checkForgetToken(), mCriteria, false);
        mCriteria.clear();
        if (aForgotPassword == null) {
            throw new GenericException(ExceptionStatus.FORGOT_TOKEN_NOT_VALID);
        }

        return aForgotPassword;
    }


    //getCurrentTime
    protected Date getCurrentTime() {
        return mRefactor.convertTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime());
    }


    //fetch Friend Request
    protected List<FriendRequest> findFriendRequest(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("friendRequestTo", userAccount);
        List<FriendRequest> friendRequests = iDao.getEntities(FriendRequest.class, queryManager.findFriendRequest(), mCriteria, false);
        mCriteria.clear();
        return friendRequests;
    }

    //CheckTag
    protected void checkTagName(UserAccount userAccount, String tagName, String name, Profile profile, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("tagName", tagName);
        mCriteria.put("profile", profile);
        Hobbie hobbies = iDao.getEntity(Hobbie.class, queryManager.getHobbiesTag(), mCriteria, false);
        mCriteria.clear();

        if (hobbies == null) {
            Hobbie aHobbies = new Hobbie();
            aHobbies.setTagName(tagName);
            aHobbies.setName(name);
            aHobbies.setCreated(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
            aHobbies.setProfile(userAccount.getProfile());
            iDao.persist(aHobbies);
        } else {
            hobbies.setName(name);
            iDao.update(hobbies);
        }
    }

    //checkFriendAvailableOrNot
    protected void checkFriendAvailableOrNot(Long friedRequestId, UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("friedRequestId", friedRequestId);
        mCriteria.put("userIds", userAccount.getUserId());
        FriendRequest friendRequest = iDao.getEntity(FriendRequest.class, queryManager.getFriendRequestUser(), mCriteria, false);
        mCriteria.clear();

        if (friendRequest != null) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_SEND);
        }
    }

    //Check Email
    protected UserAccount checkEmailId(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_NOT_FOUND);
        }

        if (!users.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ACTIVE);
        }

        return users;
    }

    //Fetch Email
    protected void findEmailAddress(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_IS_TAKEN);
        }
    }

    //Check UserName
    protected void findUserName(String userName, IDao<IEntity, Serializable> iDao) {
        if (userName == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("userName", userName);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getUsersByUserName(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_TAKEN);
        }
    }

    //Check Login
    protected Session checkLoginSession(String accessToken, IDao<IEntity, Serializable> iDao) {
        if (accessToken == null) {
            throw new GenericException(ExceptionStatus.ACCESS_TOKEN_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("accessToken", accessToken);
        Session aSession = iDao.getEntity(Session.class, "SELECT o FROM Session AS o WHERE o.accessToken = :accessToken", mCriteria, false);
        mCriteria.clear();
        if (aSession == null) {
            throw new GenericException(ExceptionStatus.USER_SESSION_NOT_FOUND);
        }

        if (!aSession.getSignIn()) {
            throw new GenericException(ExceptionStatus.USER_ALL_READY_SIGN_OUT);
        }

        return aSession;
    }


    //CheckUserName And Password
    protected UserAccount checkUserNameAndPassword(String userName, String password, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("userName", userName);
        mCriteria.put("password", password);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.checkUserNameAndPassword(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);
        } else {
            return users;
        }
    }


    protected void checkNullObject(Object object, ExceptionStatus exceptionStatus) {
        if (object == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullLongId(Long id, ExceptionStatus exceptionStatus) {
        if (id == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullString(String s, ExceptionStatus exceptionStatus) {
        if (s == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullDate(Date date, ExceptionStatus exceptionStatus) {
        if (date == null) {
            throw new GenericException(exceptionStatus);
        }
    }
}
