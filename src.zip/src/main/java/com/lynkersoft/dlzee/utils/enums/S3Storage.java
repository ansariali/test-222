package com.lynkersoft.dlzee.utils.enums;
public enum S3Storage {
    FOLDER_PROJECT("Blog"),
    PROFILE_PICTURE("ProfilePicture"),
    SUFFIX("/"),
    DASH("-"),
    SPACE(" "),
    UNDER_SCORE("_"),
    BUCKET_URL("https://s3-us-west-2.amazonaws.com/lynkersoft-s3-filestorage-bucket/");

    private final String info;

    S3Storage(String info) {
        this.info = info;
    }

    public String getInfo() {
        return info;
    }
}
