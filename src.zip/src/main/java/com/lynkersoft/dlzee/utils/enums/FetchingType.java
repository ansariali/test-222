package com.lynkersoft.dlzee.utils.enums;

public enum FetchingType {
    BY_ME, BY_OTHER
}
