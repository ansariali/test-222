package com.lynkersoft.dlzee.utils.enums;

public enum OperationStatus {
    CREATE, UPDATE, DELETE;
}
