package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;

import javax.persistence.*;

@Entity
@Table(name = "blog_sharing")
public class BlogSharing extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long blogSharingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bloggingId")
    private Blog blog;

    public Long getBlogSharingId() {
        return blogSharingId;
    }

    public void setBlogSharingId(Long blogSharingId) {
        this.blogSharingId = blogSharingId;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }
}
