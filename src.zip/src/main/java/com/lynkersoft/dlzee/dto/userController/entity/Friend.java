package com.lynkersoft.dlzee.dto.userController.entity;

import com.lynkersoft.dlzee.dto.common.UserDto;

import java.util.Date;

public class Friend {
    private Long friendId;
    private Boolean friendRequestAcceptedStatus;
    private Date friendRequestAcceptedDate;
    private UserDto friends;

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public Boolean getFriendRequestAcceptedStatus() {
        return friendRequestAcceptedStatus;
    }

    public void setFriendRequestAcceptedStatus(Boolean friendRequestAcceptedStatus) {
        this.friendRequestAcceptedStatus = friendRequestAcceptedStatus;
    }

    public Date getFriendRequestAcceptedDate() {
        return friendRequestAcceptedDate;
    }

    public void setFriendRequestAcceptedDate(Date friendRequestAcceptedDate) {
        this.friendRequestAcceptedDate = friendRequestAcceptedDate;
    }

    public UserDto getFriends() {
        return friends;
    }

    public void setFriends(UserDto friends) {
        this.friends = friends;
    }
}
