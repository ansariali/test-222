package com.lynkersoft.dlzee.dto.blogController.fetchAll;

import com.lynkersoft.dlzee.dto.blogController.entity.Blog;

import java.util.ArrayList;
import java.util.List;

public class FetchAllBlogResponse {
    List<Blog> blogs = new ArrayList<>();

    public List<Blog> getBlogs() {
        return blogs;
    }

    public void setBlogs(List<Blog> blogs) {
        this.blogs = blogs;
    }
}
