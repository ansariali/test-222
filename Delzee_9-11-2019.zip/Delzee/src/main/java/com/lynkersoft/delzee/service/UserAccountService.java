package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.delzee.dto.userController.entity.SignUp;
import com.lynkersoft.delzee.dto.userController.entity.UpdateProfileRequestBody;
import com.lynkersoft.delzee.dto.userController.entity.User;
import com.lynkersoft.delzee.entities.Education;
import com.lynkersoft.delzee.entities.FriendRequest;
import com.lynkersoft.delzee.entities.Hobbie;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface UserAccountService {
    GenericResponse saveProfileImage(UserAccount userAccount, Long userId, Long profileId, String fileType, MultipartFile files, IDao<IEntity, Serializable> iDao);

    GenericResponse updateProfileImage(UserAccount userAccount, Long userId, Long profileId, Long attachmentId, String fileType, MultipartFile files, IDao<IEntity, Serializable> iDao);

    GenericResponse signUp(SignUp userAccount, IDao<IEntity, Serializable> iDao);

    LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao);

    GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao);

    GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao);

    GenericResponse verifyForgotPassword(String forgotToken, String password, IDao<IEntity, Serializable> iDao);

    UserAccount fetchUserById(UserAccount userAccount, Long userId, IDao<IEntity, Serializable> iDao);

    User fetchUserByPrivacy(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    User fetchUserById(UserAccount userAccount, IDao<IEntity, Serializable> iDao);

    GenericResponse sendFriendRequest(UserAccount userAccount, FriendRequest friendRequest, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse friendRequestAccept(UserAccount userAccount, Long friedRequestId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateProfile(UserAccount userAccount, UpdateProfileRequestBody updateProfile, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse createEducation(UserAccount userAccount, Education education, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateEducation(UserAccount userAccount, Education education, Long educationId, IDao<IEntity, Serializable> iDao);

    GenericResponse createHobbies(UserAccount userAccount, Hobbie hobbie, Long profileId, IDao<IEntity, Serializable> iDao);

    GenericResponse updateHobbies(UserAccount userAccount, Hobbie hobbie, Long hobbiesId, IDao<IEntity, Serializable> iDao);

    Map<String, List<FriendRequest>> fetchFriendRequest(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);

    Map<String, List<UserAccount>> searchUser(UserAccount userAccount, Long profileId, String searchValue, IDao<IEntity, Serializable> iDao);
}
