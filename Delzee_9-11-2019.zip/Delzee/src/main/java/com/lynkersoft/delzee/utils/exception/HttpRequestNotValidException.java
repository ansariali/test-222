package com.lynkersoft.delzee.utils.exception;

import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.exception.util.BaseException;

public class HttpRequestNotValidException extends BaseException {

    private static final long serialVersionUID = 1L;

    public HttpRequestNotValidException(ExceptionStatus serviceStatus) {
        super(serviceStatus);
    }

    public HttpRequestNotValidException() {
        super(ExceptionStatus.HTTP_REQUEST_METHOD_NOT_VALID);
    }
}