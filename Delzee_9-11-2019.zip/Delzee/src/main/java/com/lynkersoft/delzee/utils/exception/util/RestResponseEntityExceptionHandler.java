package com.lynkersoft.delzee.utils.exception.util;

import com.lynkersoft.delzee.utils.exception.*;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

    private Logger logger = LoggerFactory.getLogger(RestResponseEntityExceptionHandler.class);

    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<?> handleAnyException(Exception e) {
        e.printStackTrace();
        ServiceError serviceError = new ServiceError(ExceptionStatus.GENERIC_FAILURE);
        return new ResponseEntity<>(serviceError, HttpStatus.BAD_REQUEST);
    }

    /**
     * Generic Exceptions
     **/
    @ExceptionHandler(GenericException.class)
    public ResponseEntity<ServiceError> genericException(GenericException e) {
        logger.error("" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Operation Failed Exceptions
     **/
    @ExceptionHandler(OperationFailedException.class)
    public ResponseEntity<ServiceError> operationFailedException(OperationFailedException e) {
        logger.error("" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    /**
     * HttpRequest Exceptions
     **/
    @ExceptionHandler(HttpRequestMethodNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestMethodNotValidException(HttpRequestMethodNotValidException e) {
        logger.error("" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpRequestHeaderNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestHeaderNotValidException(HttpRequestHeaderNotValidException e) {
        logger.error( "" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpRequestBodyNotValidException.class)
    public ResponseEntity<ServiceError> httpRequestBodyNotValidException(HttpRequestBodyNotValidException e) {
        logger.error("" + e.getServiceError().getErrorMessage());
        e.printStackTrace();
        return new ResponseEntity<>(e.getServiceError(), HttpStatus.BAD_REQUEST);
    }

}
