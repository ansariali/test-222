package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.controllers.UserAccountController;
import com.lynkersoft.delzee.dto.common.UserDto;
import com.lynkersoft.delzee.dto.common.User_;
import com.lynkersoft.delzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.delzee.dto.userController.entity.SignUp;
import com.lynkersoft.delzee.dto.userController.entity.UpdateProfileRequestBody;
import com.lynkersoft.delzee.dto.userController.entity.User;
import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.EmailService;
import com.lynkersoft.delzee.service.S3StorageService;
import com.lynkersoft.delzee.service.UserAccountService;
import com.lynkersoft.delzee.service.impl.handler.UserServiceImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.AttachmentFor;
import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;
import com.lynkersoft.delzee.utils.enums.Privacy;
import com.lynkersoft.delzee.utils.enums.S3Storage;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.exception.util.BaseException;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public class UserServiceImpl extends UserServiceImplHandler implements UserAccountService {

    @Autowired
    EmailService emailService;
    @Autowired
    UserAccountService userAccountService;
    @Autowired
    private S3StorageService s3StorageService;
    private Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);


    @Override
    public Map<String, List<UserAccount>> searchUser(UserAccount userAccount, Long profileId, String searchValue, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(searchValue, ExceptionStatus.SEARCH_VALUE);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.clear();
        mCriteria.put("searchValue", "%"+searchValue+"%");
        List<UserAccount> userAccounts = iDao.getEntities(UserAccount.class, queryManager.searchUser(), mCriteria, false);
        mCriteria.clear();

        Map<String, List<UserAccount>> aMap = new HashMap<>();
        aMap.put("users", userAccounts);

        return aMap;
    }

    @Override
    public GenericResponse updateProfileImage(UserAccount userAccount, Long userId, Long profileId, Long attachmentId, String fileType, MultipartFile files, IDao<IEntity, Serializable> iDao) {
        //
        UserAccount profileUserAccount = iDao.find(UserAccount.class, userId);
        checkNullObject(profileUserAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkProfile(profileId, userAccount, iDao);

        Attachment attachment = iDao.find(Attachment.class, attachmentId);
        checkNullObject(attachment, ExceptionStatus.ATTACHMENT_NOT_FOUND);

        if (attachment.getCreatedBy() != userAccount) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }
        try {
            String prefix = S3Storage.PROFILE_PICTURE.getInfo() + S3Storage.SUFFIX.getInfo() + userAccount.getUserId().toString() + S3Storage.SUFFIX.getInfo();
            attachment.setFileName(files.getOriginalFilename());
            String url = s3StorageService.uploadFile(prefix, files);
            attachment.setUrl(S3Storage.BUCKET_URL.getInfo() + url);
            attachment.setContentType(files.getContentType());
            attachment.setAttachmentFor(AttachmentFor.PROFILE_PICTURE);
            attachment.setFileType(fileType);
            attachment.setDescription("Profile Picture Update");
            attachment.setChanged(getCurrentTime());
            iDao.update(attachment);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.PROFILE_PICTURE_NOT_UPDATE);
        }

        return new GenericResponse(true, "Profile Picture SuccessFully update !!");
    }

    @Override
    public GenericResponse saveProfileImage(UserAccount userAccount, Long userId, Long profileId, String fileType, MultipartFile files, IDao<IEntity, Serializable> iDao) {
        //
        UserAccount profileUserAccount = iDao.find(UserAccount.class, userId);
        checkNullObject(profileUserAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkProfile(profileId, userAccount, iDao);

        try {
            String prefix = S3Storage.PROFILE_PICTURE.getInfo() + S3Storage.SUFFIX.getInfo() + userAccount.getUserId().toString() + S3Storage.SUFFIX.getInfo();
            Attachment attachment = new Attachment();
            attachment.setFileName(files.getOriginalFilename());
            String url = s3StorageService.uploadFile(prefix, files);
            attachment.setUrl(S3Storage.BUCKET_URL.getInfo() + url);
            attachment.setContentType(files.getContentType());
            attachment.setAttachmentFor(AttachmentFor.PROFILE_PICTURE);
            attachment.setFileType(fileType);
            attachment.setDescription("Profile Picture Create");
            attachment.setCreatedBy(userAccount);
            attachment.setCreated(getCurrentTime());
            attachment = iDao.find(Attachment.class, iDao.persist(attachment));

            profileUserAccount.setAttachment(attachment);
            iDao.update(profileUserAccount);

        } catch (Exception e) {
            logger.info("e :" +e);
            logger.info("e.getMessage() :" +e.getMessage());
            logger.info("e.getStackTrace() :" +e.getStackTrace());
            throw new GenericException(ExceptionStatus.PROFILE_PICTURE_NOT_UPDATE);
        }

        return new GenericResponse(true, "Profile Picture SuccessFully update !!");
    }

    @Override
    public Map<String, List<FriendRequest>> fetchFriendRequest(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        List<FriendRequest> friendRequests = findFriendRequest(userAccount, iDao);
        Map<String, List<FriendRequest>> aMap = new HashMap<>();

        aMap.put("friendRequests", friendRequests);
        return aMap;
    }

    @Override
    public GenericResponse createHobbies(UserAccount userAccount, Hobbie hobbie, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullObject(hobbie, ExceptionStatus.HOBBIES_NOT_FOUND);

        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        checkTagName(userAccount, hobbie.getTagName(), hobbie.getName(), userAccount.getProfile(), iDao);

        return new GenericResponse(true, "Hobbies SuccessFully Add");
    }

    @Override
    public GenericResponse updateHobbies(UserAccount userAccount, Hobbie hobbie, Long hobbiesId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(hobbiesId, ExceptionStatus.HOBBIES_ID_MISSING);

        Hobbie aHobbies = iDao.find(Hobbie.class, hobbiesId);
        checkNullObject(aHobbies, ExceptionStatus.HOBBIES_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), aHobbies.getProfile().getProfileId())) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }

        aHobbies.setName(hobbie.getName());
        aHobbies.setChanged(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        try {
            iDao.update(aHobbies);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.HOBBIES_NOT_UPDATE);
        }
        return new GenericResponse(true, "User Hobbies SuccessFully Update...");
    }

    @Override
    public GenericResponse createEducation(UserAccount userAccount, Education education, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullObject(education, ExceptionStatus.EDUCATION_NOT_FOUND);

        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        Education aEducation = new Education();
        aEducation.setCollageName(education.getCollageName());
        aEducation.setFromYear(education.getFromYear());
        aEducation.setToYear(education.getToYear());
        aEducation.setCourseName(education.getCourseName());
        aEducation.setCreated(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aEducation.setProfile(userAccount.getProfile());

        try {
            iDao.persist(aEducation);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.PROFILE_NOT_ADDED);
        }
        return new GenericResponse(true, "Education SuccessFully Add");

    }

    @Override
    public GenericResponse updateEducation(UserAccount userAccount, Education education, Long educationId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(educationId, ExceptionStatus.EDUCATION_ID_MISSING);

        Education aEducation = iDao.find(Education.class, educationId);
        checkNullObject(aEducation, ExceptionStatus.EDUCATION_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), aEducation.getProfile().getProfileId())) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }
        aEducation.setCollageName(education.getCollageName());
        aEducation.setFromYear(education.getFromYear());
        aEducation.setToYear(education.getToYear());
        aEducation.setCourseName(education.getCourseName());
        aEducation.setChanged(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        try {
            iDao.update(aEducation);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.EDUCATION_NOT_UPDATE);
        }
        return new GenericResponse(true, "User Education SuccessFully Update...");
    }

    @Override
    public GenericResponse updateProfile(UserAccount userAccount, UpdateProfileRequestBody updateProfile, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);

        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        userAccount.setFirstName(updateProfile.getFirstName());
        userAccount.setLastName(updateProfile.getLastName());
        userAccount.getProfile().setBirthDay(updateProfile.getBirthDay());
        userAccount.getProfile().setAboutMe(updateProfile.getAboutMe());
        userAccount.getProfile().setBirthPlace(updateProfile.getBirthPlace());
        userAccount.getProfile().setGender(updateProfile.getGender());
        userAccount.getProfile().setOccupation(updateProfile.getOccupation());
        userAccount.getProfile().setStatus(updateProfile.getStatus());
        userAccount.getProfile().setWebsite(updateProfile.getWebsite());
        userAccount.getProfile().setReligiousBeliefs(updateProfile.getReligiousBeliefs());
        userAccount.getProfile().setPoliticalIncline(updateProfile.getPoliticalIncline());
        userAccount.setChanged(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        try {
            iDao.update(userAccount);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.PROFILE_NOT_ADDED);
        }
        return new GenericResponse(true, "User Profile SuccessFully Update...");
    }

    @Override
    public User fetchUserById(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        UserAccount aUserAccount = iDao.find(UserAccount.class, userAccount.getUserId());
        checkNullObject(aUserAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        User user = dozerBeanMapper.map(aUserAccount, User.class);
        return user;
    }

    @Override
    public User fetchUserByPrivacy(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        UserAccount aUserAccount = iDao.find(UserAccount.class, userAccount.getUserId());
        checkNullObject(aUserAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        //
        if (aUserAccount.getProfile().getAddressPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setAddress(null);
        } else if (aUserAccount.getProfile().getAddressPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setAddress(aUserAccount.getProfile().getAddress());
        }
        //
        if (aUserAccount.getProfile().getEducationPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setEducations(null);
        } else if (aUserAccount.getProfile().getEducationPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setEducations(aUserAccount.getProfile().getEducations());
        }
        //
        if (aUserAccount.getProfile().getHobbyPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setHobbies(null);
        } else if (aUserAccount.getProfile().getHobbyPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setHobbies(aUserAccount.getProfile().getHobbies());
        }
        //
        if (aUserAccount.getProfile().getFriendPrivacy().equals(Privacy.PRIVATE)) {
            aUserAccount.getProfile().setFriends(null);
        } else if (aUserAccount.getProfile().getFriendPrivacy().equals(Privacy.PUBLIC)) {
            aUserAccount.getProfile().setFriends(aUserAccount.getProfile().getFriends());
        }

        User user = dozerBeanMapper.map(aUserAccount, User.class);
        //
        if (aUserAccount.getProfile().getAboutMePrivacy().equals(Privacy.PRIVATE)) {
            user.getProfile().setAboutMe(null);
        } else if (aUserAccount.getProfile().getAboutMePrivacy().equals(Privacy.PUBLIC)) {
            user.getProfile().setAboutMe(aUserAccount.getProfile().getAboutMe());
        }
        //
        if (aUserAccount.getProfile().getBirthDayPrivacy().equals(Privacy.PRIVATE)) {
            user.getProfile().setBirthDay(null);
        } else if (aUserAccount.getProfile().getBirthDayPrivacy().equals(Privacy.PUBLIC)) {
            user.getProfile().setBirthDay(aUserAccount.getProfile().getBirthDay());
        }
        //
        if (aUserAccount.getProfile().getBirthPlacePrivacy().equals(Privacy.PRIVATE)) {
            user.getProfile().setBirthPlace(null);
        } else if (aUserAccount.getProfile().getBirthPlacePrivacy().equals(Privacy.PUBLIC)) {
            user.getProfile().setBirthPlace(aUserAccount.getProfile().getBirthPlace());
        }
        //
        if (aUserAccount.getProfile().getPhoneNumberPrivacy().equals(Privacy.PRIVATE)) {
            user.getProfile().setPhoneNumber(null);
        } else if (aUserAccount.getProfile().getPhoneNumberPrivacy().equals(Privacy.PUBLIC)) {
            user.getProfile().setPhoneNumber(aUserAccount.getProfile().getPhoneNumber());
        }

        return user;
    }


    @Override
    public GenericResponse signUp(SignUp userAccount, IDao<IEntity, Serializable> iDao) {
        //
        checkNullObject(userAccount, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullString(userAccount.getEmail(), ExceptionStatus.EMAIL_ADDRESS_MISSING);
        checkNullString(userAccount.getUserName(), ExceptionStatus.USER_NAME_IS_MISSING);
        checkNullString(userAccount.getFirstName(), ExceptionStatus.FIRST_NAME_MISSING);
        checkNullString(userAccount.getLastName(), ExceptionStatus.LAST_NAME_MISSING);
        checkNullString(userAccount.getPhoneNumber(), ExceptionStatus.MOBILE_NO_MISSING);
        checkNullString(userAccount.getPassword(), ExceptionStatus.PASSWORD_MISSING);

        findUserName(userAccount.getUserName(), iDao);
        findEmailAddress(userAccount.getEmail(), iDao);

        //
        Profile profile = new Profile();
        profile.setTotalFriendRequest(0);
        profile.setTotalFriend(0);
        profile.setTotalSendFriendRequest(0);
        profile.setTotalImage(0);
        profile.setTotalVideo(0);
        profile.setTotalShare(0);
        profile.setTotalPost(0);
        profile.setTotalNotification(0);
        profile.setTotalUnseenNotification(0);
        profile.setAddressPrivacy(Privacy.PRIVATE);
        profile.setHobbyPrivacy(Privacy.PUBLIC);
        profile.setEducationPrivacy(Privacy.PUBLIC);
        profile.setFriendPrivacy(Privacy.PUBLIC);
        profile.setAboutMePrivacy(Privacy.PUBLIC);
        profile.setPhoneNumberPrivacy(Privacy.PRIVATE);
        profile.setBirthPlacePrivacy(Privacy.PRIVATE);
        profile.setBirthDayPrivacy(Privacy.PRIVATE);
        profile.setPhoneNumber(userAccount.getPhoneNumber());

        try {
            profile = iDao.find(Profile.class, iDao.persist(profile));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.PROFILE_NOT_ADDED);
        }

        //
        UserAccount user = new UserAccount();
        user.setFirstName(userAccount.getFirstName());
        user.setLastName(userAccount.getLastName());
        user.setUserName(userAccount.getUserName());
        user.setEmailAddress(userAccount.getEmail());
        user.setPassword(userAccount.getPassword());
        user.setUserEnabled(Boolean.TRUE);
        user.setUserBlocked(Boolean.FALSE);
        user.setCreated(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        user.setProfile(profile);

        try {
            user = iDao.find(UserAccount.class, iDao.persist(user));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ADDED);
        }

        emailService.sendEmailForRegistration(user.getEmailAddress(), user.getFirstName(), "...");
        return new GenericResponse(true, "User SuccessFully  Registration..");
    }

    @Override
    public LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao) {
        //
        if (password == null || userName == null) {
            throw new BaseException(ExceptionStatus.USER_NAME_OR_PASSWORD_MISSING);
        }

        //
        UserAccount userAccount = checkUserNameAndPassword(userName, password, iDao);
        checkNullObject(userAccount, ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);

        if (!userAccount.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }
        Session aSession = new Session();
        aSession.setUser(userAccount);
        aSession.setAccessToken(mUtil.getTokenNumber());
        aSession.setSignIn(Boolean.TRUE);
        aSession.setSignInOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession.setAttempts(1L);
        aSession.setAttemptsOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.find(Session.class, iDao.persist(aSession));
        //
        LoginResponseEntity aSignInResponse = new LoginResponseEntity();
        UserDto useDto = new UserDto();
        useDto.setUserId(aSession.getUser().getUserId());
        useDto.setFirstName(aSession.getUser().getFirstName());
        useDto.setLastName(aSession.getUser().getLastName());
        useDto.setUserName(aSession.getUser().getUserName());
        useDto.setEmailAddress(aSession.getUser().getEmailAddress());
        useDto.setUserEnabled(aSession.getUser().getUserEnabled());
        useDto.setUserBlocked(aSession.getUser().getUserBlocked());
        //
        aSignInResponse.setSessionStatus(Boolean.TRUE);
        aSignInResponse.setSignInOn(aSession.getSignInOn());
        aSignInResponse.setMessage("SignIn success");
        aSignInResponse.setAccessToken(aSession.getAccessToken());
        aSignInResponse.setUser(useDto);

        User user = dozerBeanMapper.map(userAccountService.fetchUserById(userAccount, userAccount.getUserId(), iDao), User.class);
        aSignInResponse.setProfile(user.getProfile());

        return aSignInResponse;
    }

    @Override
    public GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao) {
        Session aSession = checkLoginSession(accessToken, iDao);
        aSession.setSignIn(Boolean.FALSE);
        aSession.setSignOutType("MANUAL");
        aSession.setSignOutOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.update(aSession);

        if (!aSession.getSignIn()) {
            return new GenericResponse(true, "SignOut", "SignOut success");
        } else {
            return new GenericResponse(false, "SignOut", "SignOut failed");
        }
    }

    @Override
    public GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao) {

        UserAccount aUserAccount = checkEmailId(emailAddress, iDao);

        ForgotPassword aForgotPassword = new ForgotPassword();

        aForgotPassword.setEmailAddress(emailAddress);
        aForgotPassword.setForgotToken(mUtil.getTokenNumber());
        aForgotPassword.setOtpCode(mUtil.getOtpNumber().toString());
        aForgotPassword.setForgoted(Boolean.FALSE);
        aForgotPassword.setCreated(mRefactor.convertTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aForgotPassword.setCreator(aUserAccount);
        aForgotPassword = iDao.find(ForgotPassword.class, iDao.persist(aForgotPassword));

        // STEP:4 : .
        // 4.1: .
        if (mEmailService.forgotPassword(null, aUserAccount.getEmailAddress(), aUserAccount.getFirstName(), aForgotPassword.getOtpCode(), aForgotPassword.getForgotToken())) {
            return new GenericResponse(true, "Forgot Password Request", "We have send mail for recover your password, Plz check it.");

        } else {
            return new GenericResponse(false, "Forgot Password Request", "Failed to recover your password");
        }
    }

    @Override
    public GenericResponse verifyForgotPassword(String forgotToken, String password, IDao<IEntity, Serializable> iDao) {
        checkNullString(forgotToken, ExceptionStatus.FORGET_TOKEN_MISSING);

        //
        ForgotPassword aForgotPassword = checkForgetToken(forgotToken, iDao);
        //
        UserAccount userAccount = iDao.find(UserAccount.class, aForgotPassword.getCreator().getUserId());
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        try {
            userAccount.setPassword(password);
            userAccount.setChanged(getCurrentTime());
            iDao.update(userAccount);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        Calendar aCalendar = Calendar.getInstance();
        aCalendar.setTime(aForgotPassword.getCreated());
        aCalendar.add(Calendar.MONTH, 1);
        Date aDate = aCalendar.getTime();

        Date currentTime = mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime());

        if (aDate.getTime() != currentTime.getTime() && aDate.getTime() < currentTime.getTime()) {
//            throw new GenericException(ServiceStatus.FORGOT_PASSWORD_OTP_CODE_EXPIRE);
        }

        return new GenericResponse(true, "Password SuccessFully Update", "Valid request", "Password SuccessFully Update");
    }

    @Override
    public UserAccount fetchUserById(UserAccount userAccount, Long userId, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(userId, ExceptionStatus.USER_ID_MISSING);
        UserAccount aUserAccount = iDao.find(UserAccount.class, userId);

        return aUserAccount;
    }

    @Override
    public GenericResponse sendFriendRequest(UserAccount userAccount, FriendRequest friendRequest, Long friedRequestId, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkNullObject(friendRequest, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullLongId(friedRequestId, ExceptionStatus.FRIEND_ID_MISSING);

        UserAccount sendFriendRequest = iDao.find(UserAccount.class, friedRequestId);
        checkNullObject(sendFriendRequest, ExceptionStatus.FRIEND_NOT_FOUND);

        if (sendFriendRequest.getUserId() == userAccount.getUserId()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        checkFriendAvailableOrNot(friedRequestId, userAccount, iDao);

        FriendRequest aFriendRequest = new FriendRequest();
        aFriendRequest.setFriendRequestSendStatus(Boolean.TRUE);
        aFriendRequest.setFriendRequestStatus(FriendRequestStatus.PENDING);
        aFriendRequest.setFriendRequestSendOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aFriendRequest.setSendFriendRequestBy(userAccount);
        aFriendRequest.setFriendRequestTo(sendFriendRequest);

        try {
            aFriendRequest = iDao.find(FriendRequest.class, iDao.persist(aFriendRequest));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }
        if (userAccount.getProfile().getTotalSendFriendRequest() == 0) {
            userAccount.getProfile().setTotalSendFriendRequest(1);
        } else {
            userAccount.getProfile().setTotalSendFriendRequest(userAccount.getProfile().getTotalSendFriendRequest() + 1);
        }
        //
        if (sendFriendRequest.getProfile().getTotalFriendRequest() == 0) {
            sendFriendRequest.getProfile().setTotalFriendRequest(1);
        } else {
            sendFriendRequest.getProfile().setTotalFriendRequest(sendFriendRequest.getProfile().getTotalFriendRequest() + 1);
        }
        try {
            iDao.update(sendFriendRequest.getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }

        return new GenericResponse(true, "Send Friend Request Successfully", "Send Friend Request Successfully");
    }

    @Override
    public GenericResponse friendRequestAccept(UserAccount userAccount, Long friedRequestId, IDao<IEntity, Serializable> iDao) {
        checkNullObject(userAccount, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
        checkNullLongId(friedRequestId, ExceptionStatus.FRIEND_ID_MISSING);

        FriendRequest friendRequest = iDao.find(FriendRequest.class, friedRequestId);
        checkNullObject(friendRequest, ExceptionStatus.FRIEND_NOT_FOUND);

        if (friendRequest.getFriendRequestStatus().equals(FriendRequestStatus.ACCEPTED)) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_ACCEPTED);
        }

        if (friendRequest.getFriendRequestTo().getUserId() != userAccount.getUserId()) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }

        friendRequest.setFriendRequestStatus(FriendRequestStatus.ACCEPTED);
        friendRequest = iDao.update(friendRequest);
        Friend friend = new Friend();
        friend.setFriendRequestStatus(FriendRequestStatus.ACCEPTED);
        friend.setFriendRequestAcceptedStatus(Boolean.TRUE);
        friend.setFriendRequestAcceptedDate(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        friend.setFriends(friendRequest.getFriendRequestTo());
        friend.setProfile(friendRequest.getSendFriendRequestBy().getProfile());
        friend.setFriendRequest(friendRequest);
        try {
            friend = iDao.find(Friend.class, iDao.persist(friend));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_ACCEPTED);
        }

        //
        Friend friend2 = new Friend();
        friend2.setFriendRequestStatus(FriendRequestStatus.ACCEPTED);
        friend2.setFriendRequestAcceptedStatus(Boolean.TRUE);
        friend2.setFriendRequestAcceptedDate(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        friend2.setFriends(friendRequest.getSendFriendRequestBy());
        friend2.setProfile(friendRequest.getFriendRequestTo().getProfile());
        friend2.setFriendRequest(friendRequest);
        try {
            friend = iDao.find(Friend.class, iDao.persist(friend2));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_ACCEPTED);
        }

        userAccount.getProfile().setTotalFriend(friendRequest.getFriendRequestTo().getProfile().getTotalFriend() + 1);
        try {
            iDao.update(userAccount.getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }

        friendRequest.getSendFriendRequestBy().getProfile().setTotalFriend(friendRequest.getSendFriendRequestBy().getProfile().getTotalFriend() + 1);
        try {
            iDao.update(friendRequest.getSendFriendRequestBy().getProfile());
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_NOT_SEND);
        }

        return new GenericResponse(true, "Friend Request Successfully Accept", "Friend Request Successfully Accept");
    }


}
