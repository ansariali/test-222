package com.lynkersoft.delzee.dto.common;

public class Profile_ {
    private Long profileId;
    private Integer totalNotification;
    private Integer totalUnseenNotification;

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Integer getTotalNotification() {
        return totalNotification;
    }

    public void setTotalNotification(Integer totalNotification) {
        this.totalNotification = totalNotification;
    }

    public Integer getTotalUnseenNotification() {
        return totalUnseenNotification;
    }

    public void setTotalUnseenNotification(Integer totalUnseenNotification) {
        this.totalUnseenNotification = totalUnseenNotification;
    }
}
