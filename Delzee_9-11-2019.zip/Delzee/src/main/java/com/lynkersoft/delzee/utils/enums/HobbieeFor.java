package com.lynkersoft.delzee.utils.enums;

public enum HobbieeFor {
    Hobbies, FavouriteMusic, FavouriteTVShows, FavouriteBooks, FavouriteMovies, FavouriteWriters, FavouriteGames, OtherInterests
}
