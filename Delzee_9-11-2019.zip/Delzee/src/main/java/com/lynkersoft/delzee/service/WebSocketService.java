package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Blog;

import java.util.Map;

public interface WebSocketService {
    void refreshNotification(Long userId, Map<String, Object> payload);
    void commentRefreshMy(Blog blog, String postType,  Map<String, Object> payload);
    void commentDelete(Blog blog);
    void refreshLikes(Blog blog, Map<String, Object> payload);

}
