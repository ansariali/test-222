package com.lynkersoft.delzee.dto.notificationController;

import com.lynkersoft.delzee.dto.common.NotificationEntity;

import java.util.ArrayList;
import java.util.List;

public class FetchAllNotifications {

    private List<NotificationEntity> notifications = new ArrayList<>();

    public List<NotificationEntity> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<NotificationEntity> notifications) {
        this.notifications = notifications;
    }
}
