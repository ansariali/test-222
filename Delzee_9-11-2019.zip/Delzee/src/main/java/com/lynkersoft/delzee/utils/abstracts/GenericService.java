package com.lynkersoft.delzee.utils.abstracts;

import com.lynkersoft.delzee.dto.common.Comment_;
import com.lynkersoft.delzee.dto.common.Like_;
import com.lynkersoft.delzee.dto.notificationController.FetchAllNotifications;
import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.EmailService;
import com.lynkersoft.delzee.service.WebSocketService;
import com.lynkersoft.delzee.utils.QueryManager;
import com.lynkersoft.delzee.utils.Refactor;
import com.lynkersoft.delzee.utils.Util;
import com.lynkersoft.delzee.utils.enums.NotificationType;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import com.sun.nio.sctp.Notification;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.*;

@Service
@Transactional
public abstract class GenericService {

    protected static Util mUtil = Util.getInstance();
    protected static Refactor mRefactor = Refactor.getInstance();
    @Autowired
    protected IDao<IEntity, Serializable> iDao;
    @Autowired
    protected EmailService mEmailService;
    protected Hashtable<String, Object> mCriteria = new Hashtable<>();
    protected QueryManager queryManager = QueryManager.getInstance();
    protected DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
    protected Map<String, Object> mPayload = new HashMap<>();
    @Autowired
    WebSocketService webSocketService;



    //-------------------------------Start  WebSocket--------------------------
    //commentDelete
    protected void commentDelete(Blog blog) {
        webSocketService.commentDelete(blog);
    }

    //commentRefreshMy
    protected void commentRefreshMy(Blog blog, BlogComments comments, String postType) {
        mPayload.clear();
        mPayload.put("data", dozerBeanMapper.map(comments, Comment_.class));
        webSocketService.commentRefreshMy(blog, postType, mPayload);
        mPayload.clear();
    }
    //refreshLikes
    protected void refreshLikes(Blog blog, BlogLikes likes) {
        mPayload.clear();
        mPayload.put("data", dozerBeanMapper.map(likes, Like_.class));
        webSocketService.refreshLikes(blog, mPayload);
        mPayload.clear();
    }
    //
    public void notifications(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        try {

            mCriteria.clear();
            mCriteria.put("creator", userAccount);
            List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchAllBlog(), mCriteria, false);
            mCriteria.clear();
            List<Notifications> finalList = new ArrayList<>();
            for (Blog blog : blogList) {
                mCriteria.put("creator", userAccount);
                mCriteria.put("blog", blog);
                List<Notifications> notificationsList = iDao.getEntities(Notifications.class, queryManager.fetchAllNotification(), mCriteria);
                mCriteria.clear();
                if (notificationsList.size() != 0) {
                    finalList.addAll(notificationsList);
                }
            }

            Map<String, List<Notifications>> aMap = new HashMap<>();
            aMap.put("notifications", finalList);
            mPayload.clear();
            mPayload.put("data", dozerBeanMapper.map(aMap, FetchAllNotifications.class));
            webSocketService.refreshNotification(userAccount.getUserId(), mPayload);
            mPayload.clear();
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.NOTIFICATION_NOT_ADDED);
        }
    }
    //-------------------------------End  WebSocket--------------------------

    //Notification
    protected void addNotification(Profile profile, UserAccount creator, UserAccount receiver, UserAccount blogCreator, Blog blog, String message, String privacyType, Boolean self, NotificationType notificationType) {

        Notifications notifications = new Notifications();
        notifications.setPrivacyType(privacyType);
        notifications.setNotificationType(notificationType);
        notifications.setMessage(message);
        notifications.setCreated(getCurrentTime());
        notifications.setCreator(creator);
        notifications.setReceiver(receiver);
        notifications.setProfile(profile);
        notifications.setBlog(blog);
        notifications.setBlogCreator(blogCreator);

        //total Notification
        blogCreator.getProfile().setTotalNotification(blogCreator.getProfile().getTotalNotification() + 1);

        try {
            iDao.persist(notifications);
            //
            iDao.update(blogCreator.getProfile());

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.NOTIFICATION_NOT_ADDED);
        }

    }

    //CheckLike
    protected BlogLikes checkLike(UserAccount userAccount, Blog aBlog) {
        mCriteria.clear();
        mCriteria.put("creator", userAccount);
        mCriteria.put("blog", aBlog);
        BlogLikes blogLike = iDao.getEntity(BlogLikes.class, queryManager.checkLike(), mCriteria);
        mCriteria.clear();
        return blogLike;
    }

    //checkBlog
    protected Blog checkBlog(Long blogId) {
        Blog blog = iDao.find(Blog.class, blogId);
        if (blog == null) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }
        return blog;
    }

    // checkProfile
    protected Profile checkProfile(Long profileId, UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        Profile aProfile = iDao.find(Profile.class, profileId);
        checkNullObject(aProfile, ExceptionStatus.PROFILE_NOT_FOUND);

        if (!Objects.equals(userAccount.getProfile().getProfileId(), profileId)) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }
        return aProfile;
    }


    //checkForgetToken
    protected ForgotPassword checkForgetToken(String forgotToken, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("forgotToken", forgotToken);
        ForgotPassword aForgotPassword = iDao.getEntity(ForgotPassword.class, queryManager.checkForgetToken(), mCriteria, false);
        mCriteria.clear();
        if (aForgotPassword == null) {
            throw new GenericException(ExceptionStatus.FORGOT_TOKEN_NOT_VALID);
        }

        return aForgotPassword;
    }


    //getCurrentTime
    protected Date getCurrentTime() {
        return mRefactor.convertTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime());
    }


    //fetch Friend Request
    protected List<FriendRequest> findFriendRequest(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("friendRequestTo", userAccount);
        List<FriendRequest> friendRequests = iDao.getEntities(FriendRequest.class, queryManager.findFriendRequest(), mCriteria, false);
        mCriteria.clear();
        return friendRequests;
    }

    //CheckTag
    protected void checkTagName(UserAccount userAccount, String tagName, String name, Profile profile, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("tagName", tagName);
        mCriteria.put("profile", profile);
        Hobbie hobbies = iDao.getEntity(Hobbie.class, queryManager.getHobbiesTag(), mCriteria, false);
        mCriteria.clear();

        if (hobbies == null) {
            Hobbie aHobbies = new Hobbie();
            aHobbies.setTagName(tagName);
            aHobbies.setName(name);
            aHobbies.setCreated(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
            aHobbies.setProfile(userAccount.getProfile());
            iDao.persist(aHobbies);
        } else {
            hobbies.setName(name);
            iDao.update(hobbies);
        }
    }

    //checkFriendAvailableOrNot
    protected void checkFriendAvailableOrNot(Long friedRequestId, UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("friedRequestId", friedRequestId);
        mCriteria.put("userIds", userAccount.getUserId());
        FriendRequest friendRequest = iDao.getEntity(FriendRequest.class, queryManager.getFriendRequestUser(), mCriteria, false);
        mCriteria.clear();

        if (friendRequest != null) {
            throw new GenericException(ExceptionStatus.FRIEND_REQUEST_ALL_READY_SEND);
        }
    }

    //Check Email
    protected UserAccount checkEmailId(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_NOT_FOUND);
        }

        if (!users.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ACTIVE);
        }

        return users;
    }

    //Fetch Email
    protected void findEmailAddress(String email, IDao<IEntity, Serializable> iDao) {
        if (email == null) {
            throw new GenericException(ExceptionStatus.EMAIL_ADDRESS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("emailAddress", email);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getEmailAddress(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.EMAIL_ID_IS_TAKEN);
        }
    }

    //Check UserName
    protected void findUserName(String userName, IDao<IEntity, Serializable> iDao) {
        if (userName == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("userName", userName);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.getUsersByUserName(), mCriteria, false);
        mCriteria.clear();
        if (users != null) {
            throw new GenericException(ExceptionStatus.USER_NAME_IS_TAKEN);
        }
    }

    //Check Login
    protected Session checkLoginSession(String accessToken, IDao<IEntity, Serializable> iDao) {
        if (accessToken == null) {
            throw new GenericException(ExceptionStatus.ACCESS_TOKEN_MISSING);
        }

        mCriteria.clear();
        mCriteria.put("accessToken", accessToken);
        Session aSession = iDao.getEntity(Session.class, "SELECT o FROM Session AS o WHERE o.accessToken = :accessToken", mCriteria, false);
        mCriteria.clear();
        if (aSession == null) {
            throw new GenericException(ExceptionStatus.USER_SESSION_NOT_FOUND);
        }

        if (!aSession.getSignIn()) {
            throw new GenericException(ExceptionStatus.USER_ALL_READY_SIGN_OUT);
        }

        return aSession;
    }


    //CheckUserName And Password
    protected UserAccount checkUserNameAndPassword(String userName, String password, IDao<IEntity, Serializable> iDao) {
        mCriteria.clear();
        mCriteria.put("userName", userName);
        mCriteria.put("password", password);
        UserAccount users = iDao.getEntity(UserAccount.class, queryManager.checkUserNameAndPassword(), mCriteria, false);
        mCriteria.clear();
        if (users == null) {
            throw new GenericException(ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);
        } else {
            return users;
        }
    }


    protected void checkNullObject(Object object, ExceptionStatus exceptionStatus) {
        if (object == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullLongId(Long id, ExceptionStatus exceptionStatus) {
        if (id == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullString(String s, ExceptionStatus exceptionStatus) {
        if (s == null) {
            throw new GenericException(exceptionStatus);
        }
    }

    protected void checkNullDate(Date date, ExceptionStatus exceptionStatus) {
        if (date == null) {
            throw new GenericException(exceptionStatus);
        }
    }
}
