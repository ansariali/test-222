package com.lynkersoft.delzee.utils.impl;

public interface IEntity {


//    Watcher getWatcher();
//
//    void setWatcher(Watcher watcher);
    Long getVersion();

    void setVersion(Long version);

    Boolean getDeleted();

    void setDeleted(Boolean deleted);
}
