package com.lynkersoft.delzee.utils.enums;

public enum AttachmentFor {
    BLOG, CHAT, PROFILE_PICTURE
}
