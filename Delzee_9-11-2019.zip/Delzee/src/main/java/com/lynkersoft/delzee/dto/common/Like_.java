package com.lynkersoft.delzee.dto.common;

import java.util.Date;

public class Like_ {

    private Long blogLikeId;
    private Boolean liked;
    private User_ creator;
    private Date created;

    public Long getBlogLikeId() {
        return blogLikeId;
    }

    public void setBlogLikeId(Long blogLikeId) {
        this.blogLikeId = blogLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
