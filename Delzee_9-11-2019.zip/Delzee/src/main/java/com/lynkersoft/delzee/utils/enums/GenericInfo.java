package com.lynkersoft.delzee.utils.enums;

public enum GenericInfo {

    Dlzee_Email_Host("@easeprocure.com");

    private final String status;

    GenericInfo(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
