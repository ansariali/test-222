package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.enums.OperationStatus;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "watcher")
public class Watcher /*extends GenericEntity*/ {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long watcherId;

    private Long version = 1L;

    @Enumerated(EnumType.STRING)
    private OperationStatus operationStatus;
    private Date createdDate;
    private Date updatedDate;
    private Boolean deleteStatus = Boolean.FALSE;
    private Date deleteDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private UserAccount createdBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "update_by")
    private UserAccount updatedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "delete_by")
    private UserAccount deletedBy;

    public Long getWatcherId() {
        return watcherId;
    }

    public void setWatcherId(Long watcherId) {
        this.watcherId = watcherId;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public OperationStatus getOperationStatus() {
        return operationStatus;
    }

    public void setOperationStatus(OperationStatus operationStatus) {
        this.operationStatus = operationStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Boolean getDeleteStatus() {
        return deleteStatus;
    }

    public void setDeleteStatus(Boolean deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    public Date getDeleteDate() {
        return deleteDate;
    }

    public void setDeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }

    public UserAccount getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UserAccount createdBy) {
        this.createdBy = createdBy;
    }

    public UserAccount getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(UserAccount updatedBy) {
        this.updatedBy = updatedBy;
    }

    public UserAccount getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(UserAccount deletedBy) {
        this.deletedBy = deletedBy;
    }
}
