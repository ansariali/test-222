package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "blog_sharing")
public class BlogSharing extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long blogSharingId;

    private String privacyType;

    private  String description;
    private Date created;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shareBy")
    private UserAccount shareBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "blogCreatorId")
    private UserAccount blogCreator;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bloggingId")
    private Blog blog;

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Long getBlogSharingId() {
        return blogSharingId;
    }

    public void setBlogSharingId(Long blogSharingId) {
        this.blogSharingId = blogSharingId;
    }

    public String getPrivacyType() {
        return privacyType;
    }

    public void setPrivacyType(String privacyType) {
        this.privacyType = privacyType;
    }

    public UserAccount getShareBy() {
        return shareBy;
    }

    public void setShareBy(UserAccount shareBy) {
        this.shareBy = shareBy;
    }

    public UserAccount getBlogCreator() {
        return blogCreator;
    }

    public void setBlogCreator(UserAccount blogCreator) {
        this.blogCreator = blogCreator;
    }

    public Blog getBlog() {
        return blog;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }
}
