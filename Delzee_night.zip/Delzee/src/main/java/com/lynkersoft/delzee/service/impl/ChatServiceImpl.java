package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.ChatService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class ChatServiceImpl extends GenericImplHandler implements ChatService {

    @Override
    public Map<String, List<Friend>> fetchAllFriends(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        mCriteria.put("friendRequestStatus", FriendRequestStatus.ACCEPTED);
        mCriteria.put("friends", userAccount);
        List<Friend> chatMessageList = iDao.getEntities(Friend.class, queryManager.fetchFriends(), mCriteria, false);
        mCriteria.clear();

        Map<String, List<Friend>> aMap = new HashMap<>();
        aMap.put("friends", chatMessageList);
        return aMap;
    }

    @Override
    public Map<String, List<Chat>> fetchAll(UserAccount userAccount, Long profileId, Long receiverId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(profileId, ExceptionStatus.PROFILE_ID_MISSING);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.USER_ACCOUNT_NOT_FOUND);

        mCriteria.put("sender", userAccount);
        mCriteria.put("receiver", receiver);
        List<Chat> chatMessageList = iDao.getEntities(Chat.class, queryManager.fetchAllMessage(), mCriteria);
        mCriteria.clear();

        Map<String, List<Chat>> aMap = new HashMap<>();
        aMap.put("chats", chatMessageList);
        return aMap;
    }

    @Override
    public GenericResponse save(UserAccount userAccount, Long profileId, Long receiverId, Chat chat, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(chat.getMessage(), ExceptionStatus.MESSAGE_MISSING);
        checkProfile(profileId, userAccount, iDao);
        checkNullLongId(receiverId, ExceptionStatus.RECEIVER_ID_MISSING);

        UserAccount receiver = iDao.find(UserAccount.class, receiverId);
        checkNullObject(receiver, ExceptionStatus.RECEIVER_NOT_FOUND);

        if (userAccount == receiver) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_VALID);
        }

        try {
            Chat aChat = new Chat();
            aChat.setCreated(getCurrentTime());
            aChat.setMessage(chat.getMessage());
            aChat.setReceiver(receiver);
            aChat.setSender(userAccount);
            aChat.setSeenStatus(Boolean.FALSE);
            aChat = iDao.find(Chat.class, iDao.persist(aChat));

            //webSocket for Chat
            chat(receiver, aChat);

        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.MESSAGE_NOT_ADDED);
        }
        return new GenericResponse(true, "Message Send SuccessFully !!");
    }

    @Override
    public GenericResponse createGroup(UserAccount userAccount, Long profileId, String groupName, List<UserAccount> userAccounts, IDao<IEntity, Serializable> iDao) {
        //
        checkNullString(groupName, ExceptionStatus.GROUP_NAME);
        checkProfile(profileId, userAccount, iDao);
        checkNullObject(userAccounts, ExceptionStatus.MEMBER_NOT_FOUND);

            ChatGroups chatGroup = new ChatGroups();
            chatGroup.setName(groupName);
            chatGroup.setStatus("ACTIVE");
            chatGroup.setUsers(userAccount);
            chatGroup.setToken(mUtil.getTokenNumber());
            chatGroup.setCreated(getCurrentTime());
            chatGroup = iDao.find(ChatGroups.class, iDao.persist(chatGroup));
            if (chatGroup == null) {
                throw new GenericException(ExceptionStatus.GROUP_NOT_ADDED);
            }

            for (UserAccount user : userAccounts) {
                UserAccount aUserAccount = iDao.find(UserAccount.class, user.getUserId());
                if (aUserAccount == null) {
                    throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_FOUND);
                }
                    ChatGroupMember chatGroupMember = new ChatGroupMember();
                    chatGroupMember.setToken(chatGroup.getToken());
                    chatGroupMember.setUser(aUserAccount);
                    chatGroupMember.setChatGroups(chatGroup);
                    chatGroupMember = iDao.find(ChatGroupMember.class, iDao.persist(chatGroupMember));
            }

        return new GenericResponse(true, "Group Create SuccessFully !!");
    }
}
