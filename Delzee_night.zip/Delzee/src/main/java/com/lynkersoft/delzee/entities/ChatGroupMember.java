package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;

import javax.persistence.*;

@Entity
@Table(name = "chat_group_member")
public class ChatGroupMember extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long chatGroupMemberId;

    private String token;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user")
    private UserAccount user;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ChatGroupId")
    private ChatGroups ChatGroups;

    public Long getChatGroupMemberId() {
        return chatGroupMemberId;
    }

    public void setChatGroupMemberId(Long chatGroupMemberId) {
        this.chatGroupMemberId = chatGroupMemberId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public com.lynkersoft.delzee.entities.ChatGroups getChatGroups() {
        return ChatGroups;
    }

    public void setChatGroups(com.lynkersoft.delzee.entities.ChatGroups chatGroups) {
        ChatGroups = chatGroups;
    }

}
