package com.lynkersoft.delzee.utils.enums;

public enum Privacy {
    PRIVATE, PUBLIC, FRIENDS,
}
