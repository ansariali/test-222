package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;

public interface CommonService {
        GenericResponse createFollow(UserAccount userAccount, Long profileId, Long friendId, String followStatus, IDao<IEntity, Serializable> iDao);
        GenericResponse unFollow(UserAccount userAccount, Long profileId, Long followId, String followStatus, IDao<IEntity, Serializable> iDao);
}
