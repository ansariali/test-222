package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.dto.blogController.fetchAll.FetchAllComment;
import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.FriendRequest;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.WebSocketService;
import com.lynkersoft.delzee.utils.enums.WebSocketType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class WebSocketServiceImpl implements WebSocketService {

    private Logger logger = LoggerFactory.getLogger(WebSocketServiceImpl.class);

    @Autowired
    private SimpMessagingTemplate mSimpMessagingTemplate;


    @Override
    public void friendRequestSend(FriendRequest friendRequest, Map<String, Object> payload) {
        try {
            logger.info("Inside: friendRequestSend");
            payload.put("refreshType", WebSocketType.SEND_FRIEND_REQUEST);
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/friendRequestSend/" + friendRequest.getFriendRequestTo().getUserId(), payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void refreshChat(UserAccount receiver, Map<String, Object> payload) {
        try {
            logger.info("Inside: refreshChat");
            payload.put("refreshType", WebSocketType.CHAT);
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/refreshChat/" + receiver.getUserId(), payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void commentDelete(Blog blog, FetchAllComment comments) {
        try {
            Map<String, Object> payload = new HashMap<>();
            logger.info("Inside: commentDelete");
            payload.put("refreshType", WebSocketType.DELETE);
            payload.put("totalComments", blog.getTotalComments());
            payload.put("totalLikes", blog.getTotalLikes());
            payload.put("totalShare", blog.getTotalShare());
            payload.put("data", comments);
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/deleteComment/" + blog.getBlogId(), payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void refreshNotification(Long userId, Map<String, Object> payload) {
        try {
            logger.info("Inside: refreshNotification");
            payload.put("refreshType", WebSocketType.NOTIFICATION);
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/notification/" + userId, payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void commentRefreshMy(Blog blog, String postType, Map<String, Object> payload) {
        try {
            logger.info("Inside: commentRefreshMy");
            payload.put("refreshType", WebSocketType.COMMENT);
            payload.put("totalComments", blog.getTotalComments());
            payload.put("totalLikes", blog.getTotalLikes());
            payload.put("totalShare", blog.getTotalShare());
            payload.put("postType", postType);
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/myComment/" + blog.getBlogId(), payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void refreshLikes(Blog blog, Map<String, Object> payload) {
        try {
            logger.info("Inside: refreshLikes");
            payload.put("refreshType", WebSocketType.LIKE);
            payload.put("blogId", blog.getBlogId());
            payload.put("totalComments", blog.getTotalComments());
            payload.put("totalLikes", blog.getTotalLikes());
            payload.put("totalShare", blog.getTotalShare());
            mSimpMessagingTemplate.convertAndSend("/websocket/v1/refreshLikes/" + blog.getBlogId(), payload);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }
}