package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.Notifications;
import com.lynkersoft.delzee.entities.Profile;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.service.NotificationService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.*;

@Component
public class NotificationServiceImpl extends GenericImplHandler implements NotificationService {

    @Override
    public Map<String, List<Notifications>> fetchAll(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao) {
        checkProfile(profileId, userAccount, iDao);
        List<Notifications> finalList = new ArrayList<>();

        mCriteria.clear();
        mCriteria.put("creator", userAccount);
        List<Blog> blogList = iDao.getEntities(Blog.class, queryManager.fetchAllBlog(), mCriteria, false);
        mCriteria.clear();

        for (Blog blog : blogList) {
            mCriteria.put("creator", userAccount);
            mCriteria.put("blog", blog);
            List<Notifications> notificationsList = iDao.getEntities(Notifications.class, queryManager.fetchAllNotification(), mCriteria);
            mCriteria.clear();
            if (notificationsList.size() != 0) {
                finalList.addAll(notificationsList);
            }
        }
        finalList.sort(Comparator.comparing(Notifications::getCreated).reversed());
        Map<String, List<Notifications>> aMap = new HashMap<>();
        aMap.put("notifications", finalList);
        return aMap;

    }

    @Override
    public Blog fetchBlogById(UserAccount userAccount, Long profileId, Long blogId, Long notificationId, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkNullLongId(notificationId, ExceptionStatus.NOTIFICATION_ID_MISSING);
        Profile aProfile = checkProfile(profileId, userAccount, iDao);

        Notifications notifications = iDao.find(Notifications.class, notificationId);
        checkNullObject(notifications, ExceptionStatus.NOTIFICATION_NOT_FOUND);

        Blog blog = iDao.find(Blog.class, blogId);
        checkNullObject(blog, ExceptionStatus.NOTIFICATION_NOT_FOUND);

        try {
            if (!notifications.getSeen()) {
                notifications.setSeen(Boolean.TRUE);
                notifications.setSeenOn(getCurrentTime());
                iDao.update(notifications);
                //
                if (aProfile.getTotalNotification() != 0) {
                    aProfile.setTotalUnseenNotification(aProfile.getTotalNotification() - 1);
                    iDao.update(aProfile);
                }
            }
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.BLOG_NOT_FOUND);
        }

        return blog;
    }
}
