package com.lynkersoft.delzee.service;

import com.lynkersoft.delzee.entities.Blog;
import com.lynkersoft.delzee.entities.Notifications;
import com.lynkersoft.delzee.entities.UserAccount;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface NotificationService {
    Map<String, List<Notifications>> fetchAll(UserAccount userAccount, Long profileId, IDao<IEntity, Serializable> iDao);
    Blog fetchBlogById(UserAccount userAccount, Long profileId, Long blogId, Long notificationId, IDao<IEntity, Serializable> iDao);


}
