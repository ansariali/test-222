package com.lynkersoft.delzee.dto.userController.entity;

import com.lynkersoft.delzee.dto.common.User_;

import java.util.Date;

public class BlogLikes {

    private Long blogLikeId;
    private Boolean liked;
    private Date created;
    private User_ creator;

    public User_ getCreator() {
        return creator;
    }

    public void setCreator(User_ creator) {
        this.creator = creator;
    }

    public Long getBlogLikeId() {
        return blogLikeId;
    }

    public void setBlogLikeId(Long blogLikeId) {
        this.blogLikeId = blogLikeId;
    }

    public Boolean getLiked() {
        return liked;
    }

    public void setLiked(Boolean liked) {
        this.liked = liked;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }
}
