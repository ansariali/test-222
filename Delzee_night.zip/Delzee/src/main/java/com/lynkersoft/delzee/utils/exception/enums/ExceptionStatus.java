package com.lynkersoft.delzee.utils.exception.enums;

public enum ExceptionStatus {
    GENERIC_FAILURE(648112506174L, ErrorType.ERR, "Generic failure is failed", "Generic Failure logged"),
    HTTP_REQUEST_BODY_NOT_VALID(648112506173L, ErrorType.ERR, "HttpRequest body not valid", "Invalid httpRequest body"),
    HTTP_REQUEST_HEADER_NOT_VALID(648112506172L, ErrorType.ERR, "HttpRequest header not valid", "Unable to validate HttpRequest header"),
    OPERATION_FAILED(648112506175L, ErrorType.ERR, "Server operation is failed", "Server operation failed"),
    HTTP_REQUEST_METHOD_NOT_VALID(648112506171L, ErrorType.ERR, "HttpRequest method not valid", "Invalid Http Request method"),

    //User
    USER_NAME_OR_PASSWORD_MISSING(907100101L, ErrorType.ERR, "User name or password is missing","User name or password is missing"),
    USER_NAME_OR_PASSWORD_INVALID(907100101L, ErrorType.ERR, "User name or password is invalid","User name or password is invalid"),
    USER_ACCOUNT_NOT_ADDED(6481125119614L, ErrorType.ERR, "Failed to add user account", "We're Unable to add your User account."),
    PROFILE_NOT_ADDED(6481125119614L, ErrorType.ERR, "Failed to add profile", "We're Unable to add your Profile"),
    HOBBIES_NOT_ADDED(6481125119614L, ErrorType.ERR, "Failed to add Hobbies", "We're Unable to add your Hobbies"),
    EDUCATION_NOT_UPDATE(6481125119614L, ErrorType.ERR, "Unable to update education", "Unable to update education"),
    HOBBIES_NOT_UPDATE(6481125119614L, ErrorType.ERR, "Unable to update Hobbies", "Unable to update Hobbies"),
    PROFILE_NOT_FOUND(6481125119614L, ErrorType.ERR, "Profile not found", "Profile not found"),
    EDUCATION_NOT_FOUND(6481125119614L, ErrorType.ERR, "Education not found", "Education not found"),
    HOBBIES_NOT_FOUND(6481125119614L, ErrorType.ERR, "Hobbies not found", "Hobbies not found"),
    PROFILE_ID_MISSING(6481125119614L, ErrorType.ERR, "Profile id missing", "Profile id missing"),
    EDUCATION_ID_MISSING(6481125119614L, ErrorType.ERR, "Education id missing", "Education id missing"),
    HOBBIES_ID_MISSING(6481125119614L, ErrorType.ERR, "Hobbies id missing", "Hobbies id missing"),
    USER_NOT_VALID(6481125119614L, ErrorType.ERR, "User not valid ", "User not valid"),
    USER_NAME_IS_TAKEN(9071001067L, ErrorType.ERR, "Username AllReady Available","Username AllReady Available"),
    EMAIL_ID_IS_TAKEN(9071001067L, ErrorType.ERR, "Email id AllReady Available","Email id AllReady Available"),
    EMAIL_ID_NOT_FOUND(9071001067L, ErrorType.ERR, "Email id Not Found","Email id Not Found"),
    USER_ACCOUNT_NOT_ACTIVE(9071001067L, ErrorType.ERR, "User not Active","User not Active"),
    USER_NAME_IS_MISSING(9071001067L, ErrorType.ERR, "Username is missing","Username is missing"),
    LAST_NAME_MISSING(9071001067L, ErrorType.ERR, "Last name is missing","Last name is missing"),
    MOBILE_NO_MISSING(9071001067L, ErrorType.ERR, "Mobile Number is missing","Mobile Number is missing"),
    PASSWORD_MISSING(9071001067L, ErrorType.ERR, "Password is missing","Password is missing"),
    ACCESS_TOKEN_MISSING(9071001067L, ErrorType.ERR, "Access Token is missing","Access Token is missing"),
    USER_SESSION_NOT_FOUND(6481125119630L, ErrorType.ERR, "User session is missing", "User session is Missing"),
    USER_ALL_READY_SIGN_OUT(6481125119631L, ErrorType.ERR, "User All Ready sign out", "The User is already signed out"),
    USER_ID_MISSING(6481125119631L, ErrorType.ERR, "User id missing", "User id missing"),
    FORGET_TOKEN_MISSING(6481125119631L, ErrorType.ERR, "forget token missing", "forget token missing"),
    FRIEND_ID_MISSING(6481125119631L, ErrorType.ERR, "Friend id missing", "Friend id missing"),
    USER_ACCOUNT_NOT_FOUND(6481125119617L, ErrorType.ERR, "User account not found", "User not found"),
    USER_ACCOUNT_NOT_VALID(6481125119619L, ErrorType.ERR, "User account is not valid", "Invalid User Account. Kindly re-verify."),
    FIRST_NAME_MISSING(9071001067L, ErrorType.ERR, "First name is missing","First name is missing"),
    PROFILE_PICTURE_NOT_UPDATE(6481125119617L, ErrorType.ERR, "Profile picture not update", "Profile picture not update"),

    //friend
    FRIEND_NOT_FOUND(6481125119631L, ErrorType.ERR, "Friend not found", "Friend not found"),
    FRIEND_REQUEST_NOT_SEND(6481125119631L, ErrorType.ERR, "Unable to send friend Request", "Unable to send friend Request"),
    FRIEND_REQUEST_ALL_READY_CANCEL(6481125119631L, ErrorType.ERR, "Friend Request all ready cancel", "Friend Request all ready cancel"),
    FRIEND_REQUEST_NOT_CANCEL(6481125119631L, ErrorType.ERR, "Unable to cancel friend Request", "Unable to cancel friend Request"),
    FRIEND_REQUEST_ALL_READY_SEND(6481125119631L, ErrorType.ERR, "Friend Request All Ready Send", "Friend Request All Ready Send"),
    FRIEND_REQUEST_ALL_READY_ACCEPTED(6481125119631L, ErrorType.ERR, "Friend Request All Ready Accept", "Friend Request All Ready Accept"),
    FRIEND_REQUEST_ID_MISSING(6481125119631L, ErrorType.ERR, "Friend Request id missing", "Friend Request id missing"),
    FRIEND_REQUEST_NOT_ACCEPTED(6481125119631L, ErrorType.ERR, "Unable to Accept Friend Request", "Unable to Accept Friend Request"),
    FORGOT_TOKEN_NOT_VALID(6481125119631L, ErrorType.ERR, "Token not valid", "Token not valid"),
    SHARE_PRIVACY_MISSING(6481125119631L, ErrorType.ERR, "Share privacy missing", "Share privacy missing"),
    //Blog
    PROJECT_DOCUMENT_NOT_ADDED(6481125119631L, ErrorType.ERR, "Document not added", "Unable to upload File"),
    BLOG_NOT_FOUND(6481125119617L, ErrorType.ERR, "Blog not found", "Blog not found"),
    BLOG_NOT_UPDATE(6481125119617L, ErrorType.ERR, "Blog not update found", "Unable to update Blog "),
    BLOG_NOT_DELETE(6481125119617L, ErrorType.ERR, "Blog not delete", "Unable to delete blog"),
    BLOG_ID_MISSING(6481125119617L, ErrorType.ERR, "Blog id missing", "Blog id missing"),
    BLOG_ALL_READY_DELETE(6481125119617L, ErrorType.ERR, "Blog all ready delete", "Blog all ready delete"),
    BLOG_NOT_ADDED(6481125119631L, ErrorType.ERR, "Blog not added", "Unable to added blog"),
    FILE_NOT_UPLOAD(6481125119631L, ErrorType.ERR, "File not upload", "Unable to upload File"),

    //Comment
    COMMENT_NOT_ADDED(6481125119631L, ErrorType.ERR, "comment not added", "Unable to added comment"),
    COMMENT_NOT_UPDATE(6481125119631L, ErrorType.ERR, "comment not update", "Unable to update comment"),
    COMMENT_NOT_FOUND(6481125119631L, ErrorType.ERR, "comment not Found", "Unable to find comment"),
    COMMENT_MISSING(6481125119631L, ErrorType.ERR, "comment missing", "Comment missing"),
    COMMENT_ID_MISSING(6481125119617L, ErrorType.ERR, "Comment id missing", "Comment id missing"),
    COMMENT_ALL_READY_DELETE(6481125119617L, ErrorType.ERR, "Comment all ready delete", "Comment all ready delete"),
    //Like
    LIKE_NOT_ADDED(6481125119631L, ErrorType.ERR, "Like not added", "Unable to added Like"),
    LIKE_ID_MISSING(6481125119617L, ErrorType.ERR, "Like id missing", "Like id missing"),
    LIKE_NOT_FOUND(6481125119617L, ErrorType.ERR, "Like not found", "Like not found"),
    LIKE_NOT_DELETE(6481125119617L, ErrorType.ERR, "Like not delete", "Like not delete"),
    LIKE_NOT_UPDATE(6481125119631L, ErrorType.ERR, "Like not update", "Like to update comment"),
    //Notification
    NOTIFICATION_NOT_ADDED(6481125119631L, ErrorType.ERR, "Notification not added", "Unable to added Notification"),
    NOTIFICATION_ID_MISSING(6481125119631L, ErrorType.ERR, "Notification id  missing", "Notification id not missing"),
    NOTIFICATION_NOT_FOUND(6481125119631L, ErrorType.ERR, "Notification not found", "Notification not found"),
    NOTIFICATION_NOT_DELETE(6481125119631L, ErrorType.ERR, "Notification not delete", "Notification not delete"),
    //Attachment not found
    ATTACHMENT_NOT_FOUND(6481125119631L, ErrorType.ERR, "Attachment not found", "Unable to find Image"),
    BLOG_NOT_SHARE(6481125119631L, ErrorType.ERR, "Blog not share", "Unable to share Blog"),
    SEARCH_VALUE(6481125119631L, ErrorType.ERR, "Please Enter Search Value", "Please Enter Search Value"),
    //Chat
    RECEIVER_ID_MISSING(6481125119631L, ErrorType.ERR, "Chat Message is missing", "Chat Message is missing"),
    MESSAGE_MISSING(6481125119631L, ErrorType.ERR, "Chat Message is missing", "Chat Message is missing"),
    MESSAGE_NOT_ADDED(6481125119631L, ErrorType.ERR, "Chat Message not added", "Chat Message not added"),
    GROUP_NOT_ADDED(6481125119631L, ErrorType.ERR, "Group not added", "Unable to create group"),
    RECEIVER_NOT_FOUND(6481125119631L, ErrorType.ERR, "Receiver not found", "Receiver not found"),
    MEMBER_NOT_FOUND(6481125119631L, ErrorType.ERR, "Member not found", "Member not found"),
    GROUP_NAME(6481125119631L, ErrorType.ERR, "Chat Message is missing", "Chat Message is missing"),
    //Common
    FOLLOW_ID_MISSING(6481125119631L, ErrorType.ERR, "Follow id missing", "Follow id missing"),
    FOLLOW_STATUS(6481125119631L, ErrorType.ERR, "Follow status missing", "Follow status missing"),
    FOLLOW_NOT_FOUND(6481125119631L, ErrorType.ERR, "Follow not found", "Unable to find Follow"),
    FOLLOW_NOT_ADDED(6481125119617L, ErrorType.ERR, "Unable to follow", "Unable to follow"),
    UN_FOLLOW(6481125119617L, ErrorType.ERR, "Unable to follow", "Unable to follow"),
    UN_FOLLOW_ALREADY(6481125119617L, ErrorType.ERR, "UnFollow All Ready", "UnFollow All Ready"),


    EMAIL_ADDRESS_MISSING(648112506173L, ErrorType.ERR,"Email address is missing", "Email address is missing");

    private final Long errorCode;
    private final ErrorType errorType;
    private final String debugMessage;
    private final String productionMessage;

    ExceptionStatus(Long errorCode, ErrorType errorType, String debugMessage, String productionMessage) {
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.debugMessage = debugMessage;
        this.productionMessage = productionMessage;
    }

    public Long getErrorCode() {
        return errorCode;
    }

    public ErrorType getErrorType() {
        return errorType;
    }

    public String getDebugMessage() {
        return debugMessage;
    }

    public String getProductionMessage() {
        return productionMessage;
    }

}
