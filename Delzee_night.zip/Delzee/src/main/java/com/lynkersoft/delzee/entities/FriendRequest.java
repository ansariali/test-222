package com.lynkersoft.delzee.entities;

import com.lynkersoft.delzee.utils.abstracts.GenericEntity;
import com.lynkersoft.delzee.utils.enums.FriendRequestStatus;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "friend_request")
public class FriendRequest extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long friendRequestId;

    @NotNull(message = "friend request status must be required!")
    @Enumerated(EnumType.STRING)
    private FriendRequestStatus friendRequestStatus;

    private Boolean friendRequestSendStatus;
    private Date friendRequestSendOn;
    private Date friendRequestAcceptedOn;
    private Date friendRequestCancel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friend_Request_by")
    private UserAccount sendFriendRequestBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "friend_Request_to")
    private UserAccount friendRequestTo;

    public Date getFriendRequestAcceptedOn() {
        return friendRequestAcceptedOn;
    }

    public void setFriendRequestAcceptedOn(Date friendRequestAcceptedOn) {
        this.friendRequestAcceptedOn = friendRequestAcceptedOn;
    }

    public Date getFriendRequestCancel() {
        return friendRequestCancel;
    }

    public void setFriendRequestCancel(Date friendRequestCancel) {
        this.friendRequestCancel = friendRequestCancel;
    }

    public Long getFriendRequestId() {
        return friendRequestId;
    }

    public void setFriendRequestId(Long friendRequestId) {
        this.friendRequestId = friendRequestId;
    }

    public FriendRequestStatus getFriendRequestStatus() {
        return friendRequestStatus;
    }

    public void setFriendRequestStatus(FriendRequestStatus friendRequestStatus) {
        this.friendRequestStatus = friendRequestStatus;
    }

    public Boolean getFriendRequestSendStatus() {
        return friendRequestSendStatus;
    }

    public void setFriendRequestSendStatus(Boolean friendRequestSendStatus) {
        this.friendRequestSendStatus = friendRequestSendStatus;
    }

    public UserAccount getSendFriendRequestBy() {
        return sendFriendRequestBy;
    }

    public void setSendFriendRequestBy(UserAccount sendFriendRequestBy) {
        this.sendFriendRequestBy = sendFriendRequestBy;
    }

    public UserAccount getFriendRequestTo() {
        return friendRequestTo;
    }

    public void setFriendRequestTo(UserAccount friendRequestTo) {
        this.friendRequestTo = friendRequestTo;
    }

    public Date getFriendRequestSendOn() {
        return friendRequestSendOn;
    }

    public void setFriendRequestSendOn(Date friendRequestSendOn) {
        this.friendRequestSendOn = friendRequestSendOn;
    }


}
