package com.lynkersoft.delzee.dto.blogController.fetchAll;

import com.lynkersoft.delzee.dto.common.Comment_;

import java.util.ArrayList;
import java.util.List;

public class FetchAllComment {

    List<Comment_> comments = new ArrayList<>();

    public List<Comment_> getComments() {
        return comments;
    }

    public void setComments(List<Comment_> comments) {
        this.comments = comments;
    }
}
