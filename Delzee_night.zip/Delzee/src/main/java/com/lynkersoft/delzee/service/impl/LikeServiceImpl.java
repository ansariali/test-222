package com.lynkersoft.delzee.service.impl;

import com.lynkersoft.delzee.entities.*;
import com.lynkersoft.delzee.service.LikeService;
import com.lynkersoft.delzee.service.impl.handler.GenericImplHandler;
import com.lynkersoft.delzee.utils.GenericResponse;
import com.lynkersoft.delzee.utils.enums.NotificationType;
import com.lynkersoft.delzee.utils.exception.GenericException;
import com.lynkersoft.delzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.delzee.utils.impl.IDao;
import com.lynkersoft.delzee.utils.impl.IEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;

@Service
@Transactional
public class LikeServiceImpl extends GenericImplHandler implements LikeService {
    @Override
    public GenericResponse createLike(UserAccount userAccount, Long profileId, Long blogId, BlogLikes blogLike, IDao<IEntity, Serializable> iDao) {
        //
        Profile aProfile = checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        //CheckLike
        BlogLikes value = checkLike(userAccount, aBlog);
        BlogLikes aBlogLikes = new BlogLikes();
        if (value == null) {
            try {
                aBlogLikes.setLiked(blogLike.getLiked());
                aBlogLikes.setCreated(getCurrentTime());
                aBlogLikes.setBlog(aBlog);
                aBlogLikes.setCreator(userAccount);
                aBlogLikes = iDao.find(BlogLikes.class, iDao.persist(aBlogLikes));

                if (userAccount.getUserId() != aBlog.getCreator().getUserId()) {
                    //Notification
                    addNotification(aProfile, userAccount, null, aBlog.getCreator(), aBlog, userAccount.getFirstName() + " " + userAccount.getLastName() + " Like your Post", "PUBLIC", Boolean.TRUE, NotificationType.LIKE, aBlogLikes);
                }

            } catch (Exception e) {
                throw new GenericException(ExceptionStatus.LIKE_NOT_ADDED);
            }
            aBlog.setTotalLikes(aBlog.getTotalLikes() + 1);
            iDao.update(aBlog);

            //webSocket for Likes
            refreshLikes(aBlog, aBlogLikes);

            if (userAccount.getUserId() != aBlog.getCreator().getUserId()) {
                //webSocket Notification
                notifications(aBlog.getCreator(), iDao);
            }

        } else {
            System.out.println("Else Call.....");
            if (userAccount.getUserId() != aBlog.getCreator().getUserId()) {
                mCriteria.clear();
                mCriteria.put("blogLikeId", value.getBlogLikeId());
                Notifications notifications = iDao.getEntity(Notifications.class, queryManager.getLike(), mCriteria, false);
                if (notifications == null) {
                    throw new GenericException(ExceptionStatus.NOTIFICATION_NOT_FOUND);
                }
                try {
                    iDao.purge(notifications);
                } catch (Exception e) {
                    throw new GenericException(ExceptionStatus.NOTIFICATION_NOT_DELETE);
                }
            }

            //
            BlogLikes like = iDao.find(BlogLikes.class, value.getBlogLikeId());
            if (like == null) {
                throw new GenericException(ExceptionStatus.LIKE_NOT_FOUND);
            }

            try {
                iDao.purge(like);
            } catch (Exception e) {
                throw new GenericException(ExceptionStatus.LIKE_NOT_FOUND);
            }
            aBlog.setTotalLikes(aBlog.getTotalLikes() - 1);
            aBlog = iDao.update(aBlog);

            //webSocket for Likes
            refreshLikesFalse(aBlog, Boolean.FALSE);
            //webSocket Notification
            notifications(aBlog.getCreator(), iDao);

           /* if (blogLike.getLiked()) {
                value.setLiked(Boolean.TRUE);
                value.setChanger(userAccount);
                value.setChanged(getCurrentTime());
                value.setDeleted(Boolean.FALSE);
                value = iDao.update(value);
                aBlog.setTotalLikes(aBlog.getTotalLikes() + 1);
                aBlog = iDao.update(aBlog);

                //webSocket for Likes
                refreshLikes(aBlog, value);

            } else if (!blogLike.getLiked()) {
                value.setLiked(Boolean.FALSE);
                value.setChanger(userAccount);
                value.setChanged(getCurrentTime());
                value.setDeleted(Boolean.TRUE);
                iDao.update(value);
                if (aBlog.getTotalLikes() == 0) {
                    aBlog.setTotalLikes(0);
                } else {
                    aBlog.setTotalLikes(aBlog.getTotalLikes() - 1);
                }
                aBlog = iDao.update(aBlog);

                //webSocket for Likes
                refreshLikes(aBlog, value);
            }*/
        }

        return new GenericResponse(true, "Like SuccessFully create !!");
    }

    @Override
    public GenericResponse updateLike(UserAccount userAccount, Long profileId, Long blogId, Long LikeId, BlogLikes like, IDao<IEntity, Serializable> iDao) {
        //
        checkNullLongId(blogId, ExceptionStatus.BLOG_ID_MISSING);
        checkProfile(profileId, userAccount, iDao);
        Blog aBlog = checkBlog(blogId);
        checkNullObject(aBlog, ExceptionStatus.BLOG_NOT_FOUND);
        checkNullLongId(LikeId, ExceptionStatus.LIKE_ID_MISSING);

        BlogLikes blogLikes = iDao.find(BlogLikes.class, LikeId);
        checkNullObject(blogLikes, ExceptionStatus.LIKE_NOT_FOUND);

        try {
            blogLikes.setLiked(like.getLiked());
            blogLikes.setChanged(getCurrentTime());
            blogLikes.setChanger(userAccount);

            iDao.update(blogLikes);
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.LIKE_NOT_UPDATE);
        }

        return new GenericResponse(true, "Like SuccessFully Updated !!");
    }
}
