package com.lynkersoft.dlzee.entities;

import javax.persistence.*;

@Entity
@Table(name = "blogging_sharing")
public class BloggingSharing {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long postSharingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bloggingId")
    private Blogging blogging;

    public Long getPostSharingId() {
        return postSharingId;
    }

    public void setPostSharingId(Long postSharingId) {
        this.postSharingId = postSharingId;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public Blogging getBlogging() {
        return blogging;
    }

    public void setBlogging(Blogging blogging) {
        this.blogging = blogging;
    }
}
