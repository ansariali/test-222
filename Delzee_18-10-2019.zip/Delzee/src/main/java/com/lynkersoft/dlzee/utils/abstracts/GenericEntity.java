package com.lynkersoft.dlzee.utils.abstracts;

import com.lynkersoft.dlzee.utils.impl.IEntity;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
public class GenericEntity implements IEntity, Serializable {

    private Long version = 1L;

    private Boolean deleted = false;

    @Override
    public Long getVersion() {
        return version;
    }

    @Override
    public void setVersion(Long version) {
        this.version = version;
    }

    @Override
    public Boolean getDeleted() {
        return deleted;
    }

    @Override
    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
