package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.enums.Privacy;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "education")
public class Education {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long educationId;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy privacy;

    private  String collageName;
    private String url;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fromYear;

    @Temporal(TemporalType.TIMESTAMP)
    private Date toYear;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_id")
    private Profile  profile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by")
    private UserAccount createdBy;

}
