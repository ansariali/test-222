package com.lynkersoft.dlzee.entities;

import javax.persistence.*;

@Entity
@Table(name = "blogging_comments")
public class BloggingComments {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long bloggingCommentId;

    private String message;
    private String info;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId")
    private UserAccount user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bloggingId")
    private Blogging blogging;


    public Long getBloggingCommentId() {
        return bloggingCommentId;
    }

    public void setBloggingCommentId(Long bloggingCommentId) {
        this.bloggingCommentId = bloggingCommentId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }

    public Blogging getBlogging() {
        return blogging;
    }

    public void setBlogging(Blogging blogging) {
        this.blogging = blogging;
    }
}
