package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "session")
public class Session extends GenericEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long sessionId;

    @NotNull(message = "accessToken must be required!")
    private String accessToken;

    @NotNull(message = "isSignIn must be required!")
    private Boolean isSignIn;

    @NotNull(message = "signInOn must be required!")
    private Date signInOn;

    private Date signOutOn;

    private String signOutType;

    @NotNull(message = "attempts must be required!")
    private Long attempts;

    @NotNull(message = "attemptsOn must be required!")
    private Date attemptsOn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user")
    private UserAccount user;

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Boolean getSignIn() {
        return isSignIn;
    }

    public void setSignIn(Boolean signIn) {
        isSignIn = signIn;
    }

    public Date getSignInOn() {
        return signInOn;
    }

    public void setSignInOn(Date signInOn) {
        this.signInOn = signInOn;
    }

    public Date getSignOutOn() {
        return signOutOn;
    }

    public void setSignOutOn(Date signOutOn) {
        this.signOutOn = signOutOn;
    }

    public String getSignOutType() {
        return signOutType;
    }

    public void setSignOutType(String signOutType) {
        this.signOutType = signOutType;
    }

    public Long getAttempts() {
        return attempts;
    }

    public void setAttempts(Long attempts) {
        this.attempts = attempts;
    }

    public Date getAttemptsOn() {
        return attemptsOn;
    }

    public void setAttemptsOn(Date attemptsOn) {
        this.attemptsOn = attemptsOn;
    }

    public UserAccount getUser() {
        return user;
    }

    public void setUser(UserAccount user) {
        this.user = user;
    }
}
