package com.lynkersoft.dlzee.entities;

import com.lynkersoft.dlzee.utils.abstracts.GenericEntity;
import com.lynkersoft.dlzee.utils.enums.Privacy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "profile")
public class Profile extends GenericEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long profileId;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy addressPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy hobbyPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy friendPrivacy;

    @NotNull(message = "privacy must be required!")
    @Enumerated(EnumType.STRING)
    private Privacy educationPrivacy;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "profile")
    private Set<Address> address = new HashSet<>();


}
