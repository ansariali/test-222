package com.lynkersoft.dlzee.utils;

import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
@CrossOrigin
@RestController
@RequestMapping("/userController")
public class GenericController {

    protected static HttpHeaders responseHeaders = new HttpHeaders();
    static {
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
    }

    @Autowired
    protected IDao<IEntity, Serializable> iDao;
    protected Refactor mRefactor = Refactor.getInstance();


}
