package com.lynkersoft.dlzee.dto.userController;

public class TokenEntity {
    private String accessToken;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
