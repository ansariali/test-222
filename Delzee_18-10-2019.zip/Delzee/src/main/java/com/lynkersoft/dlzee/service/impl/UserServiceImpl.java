package com.lynkersoft.dlzee.service.impl;

import com.lynkersoft.dlzee.dto.userController.LoginResponseEntity;
import com.lynkersoft.dlzee.dto.userController.UserEntity;
import com.lynkersoft.dlzee.entities.ForgotPassword;
import com.lynkersoft.dlzee.entities.Session;
import com.lynkersoft.dlzee.entities.UserAccount;
import com.lynkersoft.dlzee.service.EmailService;
import com.lynkersoft.dlzee.service.UserAccountService;
import com.lynkersoft.dlzee.service.impl.handler.UserServiceImplHandler;
import com.lynkersoft.dlzee.utils.GenericResponse;
import com.lynkersoft.dlzee.utils.exception.GenericException;
import com.lynkersoft.dlzee.utils.exception.enums.ExceptionStatus;
import com.lynkersoft.dlzee.utils.exception.util.BaseException;
import com.lynkersoft.dlzee.utils.impl.IDao;
import com.lynkersoft.dlzee.utils.impl.IEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Hashtable;

@Service
@Transactional
public class UserServiceImpl extends UserServiceImplHandler implements UserAccountService {

    @Autowired
    EmailService emailService;

    @Override
    public GenericResponse signUp(UserAccount userAccount, IDao<IEntity, Serializable> iDao) {
        //
        checkNullObject(userAccount, ExceptionStatus.HTTP_REQUEST_BODY_NOT_VALID);
        checkNullString(userAccount.getEmailAddress(), ExceptionStatus.EMAIL_ADDRESS_MISSING);
        checkNullString(userAccount.getUserName(), ExceptionStatus.USER_NAME_IS_MISSING);
        checkNullString(userAccount.getFirstName(), ExceptionStatus.FIRST_NAME_MISSING);
        checkNullString(userAccount.getLastName(), ExceptionStatus.LAST_NAME_MISSING);
        checkNullString(userAccount.getMobileNo(), ExceptionStatus.MOBILE_NO_MISSING);
        checkNullString(userAccount.getPassword(), ExceptionStatus.PASSWORD_MISSING);

        findUserName(userAccount.getUserName(), iDao);
        findEmailAddress(userAccount.getEmailAddress(), iDao);

        //
        UserAccount user = new UserAccount();
        user.setFirstName(userAccount.getFirstName());
        user.setLastName(userAccount.getLastName());
        user.setUserName(userAccount.getUserName());
        user.setGender(userAccount.getGender());
        user.setEmailAddress(userAccount.getEmailAddress());
        user.setPassword(userAccount.getPassword());
        user.setMobileNo(userAccount.getMobileNo());
        user.setUserEnabled(Boolean.TRUE);
        user.setUserBlocked(Boolean.FALSE);

        try {
            user = iDao.find(UserAccount.class, iDao.persist(user));
        } catch (Exception e) {
            throw new GenericException(ExceptionStatus.USER_ACCOUNT_NOT_ADDED);
        }

        emailService.sendEmailForRegistration(user.getEmailAddress(), user.getFirstName(), "...");
        return new GenericResponse(true, "User SuccessFully  Registration..");
    }

    @Override
    public LoginResponseEntity signIn(String userName, String password, IDao<IEntity, Serializable> iDao) {
        //
        if (password == null || userName == null) {
            throw new BaseException(ExceptionStatus.USER_NAME_OR_PASSWORD_MISSING);
        }

        //
        UserAccount userAccount = checkUserNameAndPassword(userName, password, iDao);
        checkNullObject(userAccount, ExceptionStatus.USER_NAME_OR_PASSWORD_INVALID);

        if (!userAccount.getUserEnabled()) {
            throw new GenericException(ExceptionStatus.USER_NOT_VALID);
        }
        Session aSession = new Session();
        aSession.setUser(userAccount);
        aSession.setAccessToken(mUtil.getTokenNumber());
        aSession.setSignIn(Boolean.TRUE);
        aSession.setSignInOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession.setAttempts(1L);
        aSession.setAttemptsOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.find(Session.class, iDao.persist(aSession));
        //
        LoginResponseEntity aSignInResponse = new LoginResponseEntity();
        UserEntity userEntity = new UserEntity();
        userEntity.setUserId(aSession.getUser().getUserId());
        userEntity.setFirstName(aSession.getUser().getFirstName());
        userEntity.setLastName(aSession.getUser().getLastName());
        userEntity.setUserName(aSession.getUser().getUserName());
        userEntity.setGender(aSession.getUser().getGender());
        userEntity.setEmailAddress(aSession.getUser().getEmailAddress());
        userEntity.setMobileNo(aSession.getUser().getMobileNo());
        userEntity.setUserEnabled(aSession.getUser().getUserEnabled());
        userEntity.setUserBlocked(aSession.getUser().getUserBlocked());
        //
        aSignInResponse.setSessionStatus(Boolean.TRUE);
        aSignInResponse.setSignInOn(aSession.getSignInOn());
        aSignInResponse.setMessage("SignIn success");
        aSignInResponse.setAccessToken(aSession.getAccessToken());
        aSignInResponse.setUser(userEntity);

        return aSignInResponse;
    }

    @Override
    public GenericResponse signOut(String accessToken, IDao<IEntity, Serializable> iDao) {
        Session aSession = checkLoginSession(accessToken, iDao);
        aSession.setSignIn(Boolean.FALSE);
        aSession.setSignOutType("MANUAL");
        aSession.setSignOutOn(mRefactor.getTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aSession = iDao.update(aSession);

        if (!aSession.getSignIn()) {
            return new GenericResponse(true, "SignOut", "SignOut success");
        } else {
            return new GenericResponse(false, "SignOut", "SignOut failed");
        }
    }

    @Override
    public GenericResponse forgotPassword(String emailAddress, IDao<IEntity, Serializable> iDao) {

     UserAccount aUserAccount = checkEmailId(emailAddress, iDao);

        ForgotPassword aForgotPassword = new ForgotPassword();

        aForgotPassword.setEmailAddress(emailAddress);
        aForgotPassword.setForgotToken(mUtil.getTokenNumber());
        aForgotPassword.setOtpCode(mUtil.getOtpNumber().toString());
        aForgotPassword.setForgoted(Boolean.FALSE);
        aForgotPassword.setCreated(mRefactor.convertTimeBySpecificZone(mUtil.getDefaultTimeZone(), mUtil.getCurrentTime()));
        aForgotPassword = iDao.find(ForgotPassword.class, iDao.persist(aForgotPassword));

        // STEP:4 : .
        // 4.1: .
        if (mEmailService.forgotPassword(null, aUserAccount.getEmailAddress(), aUserAccount.getFirstName(), aForgotPassword.getOtpCode(), aForgotPassword.getForgotToken())) {
            return new GenericResponse(true, "Forgot Password Request", "We have send mail for recover your password, Plz check it.");

        } else {
            return new GenericResponse(false, "Forgot Password Request", "Failed to recover your password");
        }
    }


}
