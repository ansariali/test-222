UserAccount:
    1:1
    Profile:
        profileId PK
        userId FK
        EducationPrivacy: Enum(PU,FR,PR)
        EducationList[]
            Education
                url
                educationId PK
                profileId FK
                clgName
                fromYear
                toYear
                passYear
        AddressPrivacy: Enum(PU,FR,PR)
        AddressList[]
            Address:
                addressId PK
                profileId   FK
                address
                city
                state
                country
         Hobbies[]
         hobPri: Enum(PU,FR,PR)
            Hob:
                Type
                url:
            
                        
        
                
            