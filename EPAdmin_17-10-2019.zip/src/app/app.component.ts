import {AfterViewInit, Component, OnInit, ViewContainerRef} from '@angular/core';
import {NavigationEnd, Router} from '@angular/router';
import * as $ from 'jquery';

import {GlobalState} from './global.state';
import {BaImageLoaderService, BaThemePreloader, BaThemeSpinner} from './theme/services';
import {BaThemeConfig} from './theme/theme.config';
import {layoutPaths} from './theme/theme.constants';
import {PathService} from './@core/service/path.service';
import {HttpService} from './@core/service/http.service';
import {SessionService} from './@core/service/session.service';
import {UrlService} from './@core/service/url.service';

/*
 * App Component
 * Top Level Component
 */
@Component({
    selector: 'app',
    styleUrls: ['./app.component.scss'],
    template: `
        <main [class.menu-collapsed]="isMenuCollapsed" baThemeRun>
            <div class="additional-bg"></div>
            <router-outlet></router-outlet>
        </main>
    `,
})

export class AppComponent implements AfterViewInit, OnInit {

    isMenuCollapsed: boolean = false;

    public config: any = {
        pageUrl: null
    };

    constructor(private _router: Router,
                private _state: GlobalState,
                private _imageLoader: BaImageLoaderService,
                private _spinner: BaThemeSpinner,
                private viewContainerRef: ViewContainerRef,
                private themeConfig: BaThemeConfig,
                private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;

        this._router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };

        this._router.events.subscribe((evt) => {
            if (evt instanceof NavigationEnd) {
                this._router.navigated = false;
                window.scrollTo(0, 0);
            }
        });

        themeConfig.config();

        this._loadImages();

        this._state.subscribe('menu.isCollapsed', (isCollapsed) => {
            this.isMenuCollapsed = isCollapsed;
        });
    }

    ngAfterViewInit(): void {
        // hide spinner once all loaders are completed
        BaThemePreloader.load().then((values) => {
            this._spinner.hide();
        });
    }

    ngOnInit  () {
    }

    private _loadImages(): void {
        // register some loaders
        BaThemePreloader.registerLoader(this._imageLoader.load('assets/img/sky-bg.jpg'));
    }

}
