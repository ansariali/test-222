import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'utcDate'
})
export class UtcDatePipe implements PipeTransform {

    transform(value: string): any {

        if (!value) {
            return '';
        }

        const time = new Date(value);
        const offset = time.getTimezoneOffset();
        const minutes = time.getMinutes();
        time.setMinutes(minutes - offset);

        return time.toLocaleString();
    }
}