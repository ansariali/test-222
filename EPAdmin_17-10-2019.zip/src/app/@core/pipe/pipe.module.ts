import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {AsciiPipe} from './ascii.pipe';
import {UtcDatePipe} from './date.pipe';
import {LimitToPipe} from './limitTo.pipe';
import {FilterPipe} from './filter.pipe';

const PIPES = [
    AsciiPipe,
    UtcDatePipe,
    LimitToPipe,
    FilterPipe
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        ...PIPES,
    ],
    exports: [
        ...PIPES
    ],
})
export class PipeModule {
}
