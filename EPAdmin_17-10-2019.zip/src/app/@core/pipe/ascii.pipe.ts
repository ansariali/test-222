import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'ascii',
})

export class AsciiPipe implements PipeTransform {

    private type: any = [
        {
            code: '1866',
            string: 'Chemicals & Polymers',
        },
        {
            code: '997',
            string: 'Mechanical',
        },
        {
            code: '2274',
            string: 'Electrical / Electronics',
        },
        {
            code: '829',
            string: 'Physical',
        },
        {
            code: '1559',
            string: 'Metal / Commodity',
        },
        {
            code: '1675',
            string: 'Software / Service',
        },
        {
            code: '629',
            string: 'Others',
        },
        {
            code: '722',
            string: 'Regular',
        },
        {
            code: '637',
            string: 'One-off',
        },
        {
            code: '298',
            string: 'New',
        },
        {
            code: '1122',
            string: 'Blacklisted',
        },
    ];


    transform(info: any, args?: any): any {

        this.type.forEach(value => {
            if (info == value.code) {
                info = value.string;
            }
        });

        return info;
    }
}
