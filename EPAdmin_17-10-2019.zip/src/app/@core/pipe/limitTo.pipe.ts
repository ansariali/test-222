import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'limitTo',
})

export class LimitToPipe implements PipeTransform {

    transform(value: any, args: any): any {
        if (value === undefined) {
            return;
        }

        if (value.length > args) {
            return value.substring(0, args) + '...';
        } else {
            return value;
        }
    }
}
