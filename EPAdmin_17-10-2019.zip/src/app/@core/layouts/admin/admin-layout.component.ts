import {Component, OnInit} from '@angular/core';
import {Routes} from '@angular/router';
import {BaMenuService} from '../../../theme/services/baMenu/baMenu.service';
import {SessionService} from '../../service/session.service';

// import {BaMenuService} from '../theme';
// import {PAGES_MENU} from './pages.menu';

@Component({
    selector: 'adminLayout',
    template: `
        <ba-sidebar></ba-sidebar>
        <ba-page-top></ba-page-top>
        <div class="al-main">
            <div class="al-content">
                <ba-content-top></ba-content-top>
                <router-outlet></router-outlet>
            </div>
        </div>
        <!--<footer class="al-footer clearfix">
          <div class="al-footer-right" translate>{{'general.created_with'}} <i class="ion-heart"></i></div>
          <div class="al-footer-main clearfix">
            <div class="al-copy">&copy; <a href="http://akveo.com" translate>{{'general.akveo'}}</a> 2016</div>
            <ul class="al-share clearfix">
              <li><i class="socicon socicon-facebook"></i></li>
              <li><i class="socicon socicon-twitter"></i></li>
              <li><i class="socicon socicon-google"></i></li>
              <li><i class="socicon socicon-github"></i></li>
            </ul>
          </div>
        </footer>-->
        <ba-back-top position="200"></ba-back-top>
    `,
})
// export class Pages {
export class AdminLayoutComponent implements OnInit {

    public fullMenu: any = [
        {
            path: '',
            children: [
                {
                    path: 'dashboard',
                    data: {
                        menu: {
                            title: 'Dashboard',
                            icon: 'ion-android-home',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'pricing',
                    data: {
                        menu: {
                            title: 'Pricing Tiers',
                            icon: 'fa fa-calculator',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'tenderDashboard',
                    data: {
                        menu: {
                            title: 'Tender List',
                            icon: 'fa fa-list',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'quote',
                    data: {
                        menu: {
                            title: 'quote',
                            hidden: true,
                            selected: false,
                            expanded: false,
                            order: 200
                        }
                    }
                },
                {
                    path: 'bid',
                    data: {
                        menu: {
                            title: 'Bid',
                            icon: 'ion-ios-people',
                            selected: false,
                            expanded: false,
                            hidden: true,
                            order: 200
                        }
                    },
                    children: [
                        {
                            path: 'select',
                            data: {
                                menu: {
                                    title: 'Select Bid',
                                    selected: true,
                                    hidden: true
                                }
                            },
                            children: [
                                {
                                    path: '1',
                                    data: {
                                        menu: {
                                            title: 'Select Bid',
                                            selected: true,
                                            hidden: true
                                        }
                                    }
                                },
                                {
                                    path: '2',
                                    data: {
                                        menu: {
                                            title: 'Select Bid',
                                            selected: true,
                                            hidden: true
                                        }
                                    }
                                },
                                {
                                    path: '3',
                                    data: {
                                        menu: {
                                            title: 'Select Bid',
                                            selected: true,
                                            hidden: true
                                        }
                                    }
                                },
                                {
                                    path: '4',
                                    data: {
                                        menu: {
                                            title: 'Select Bid',
                                            selected: true,
                                            hidden: true
                                        }
                                    }
                                }
                            ]
                        },
                    ]
                },
                {
                    path: 'download',
                    data: {
                        menu: {
                            title: 'Report',
                            icon: 'ion-pie-graph',
                            selected: false,
                            expanded: false,
                            order: 250,
                        }
                    },
                    /*children: [
                        {
                            path: 'download',
                            data: {
                                menu: {
                                    title: 'Download Report',
                                    // hidden: true,
                                    selected: false,
                                    expanded: false,
                                    order: 200
                                }
                            }
                        }
                    ]*/
                },
                {
                    path: 'register',
                    data: {
                        menu: {
                            title: 'User Register Details',
                            hidden: true,
                            selected: false,
                            expanded: false,
                            order: 200
                        }
                    }
                },
                {
                    path: 'notification',
                    data: {
                        menu: {
                            title: 'All Notification',
                            hidden: true,
                            selected: false,
                            expanded: false,
                            order: 200
                        }
                    }
                },
                {
                    path: 'test',
                    data: {
                        menu: {
                            title: 'Setting Board',
                            icon: 'fa fa-cog',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'support-user',
                    data: {
                        menu: {
                            title: 'Support Users',
                            icon: 'fa fa-user-md',
                            selected: false,
                            expanded: false,
                            order: 350
                        }
                    },
                },
                {
                    path: 'support',
                    data: {
                        menu: {
                            title: 'Support',
                            icon: 'ion-help-circled',
                            selected: false,
                            expanded: false,
                            order: 400
                        }
                    },
                },

            ]
        }
    ];
    public financialMenu: any = [
        {
            path: '',
            children: [
                {
                    path: 'dashboard',
                    data: {
                        menu: {
                            title: 'Dashboard',
                            icon: 'ion-android-home',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'pricing',
                    data: {
                        menu: {
                            title: 'Pricing Tiers',
                            icon: 'fa fa-calculator',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                /* {
                               path: 'chat',
                               data: {
                                   menu: {
                                       title: 'Chat Admin',
                                       icon: 'fa fa-comments-o',
                                       selected: false,
                                       expanded: false,
                                       order: 0
                                   }
                               }
                           },*/
                {
                    path: 'test',
                    data: {
                        menu: {
                            title: 'Setting Board',
                            icon: 'fa fa-cog',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'support-user',
                    data: {
                        menu: {
                            title: 'Support Users',
                            icon: 'fa fa-user-md',
                            selected: false,
                            expanded: false,
                            order: 350
                        }
                    },
                },
                {
                    path: 'support',
                    data: {
                        menu: {
                            title: 'Support',
                            icon: 'ion-help-circled',
                            selected: false,
                            expanded: false,
                            order: 400
                        }
                    },
                },

            ]
        }
    ];
    public techMenu: any = [
        {
            path: '',
            children: [
                {
                    path: 'dashboard',
                    data: {
                        menu: {
                            title: 'Dashboard',
                            icon: 'ion-android-home',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'pricing',
                    data: {
                        menu: {
                            title: 'Pricing Tiers',
                            icon: 'fa fa-calculator',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                /* {
                               path: 'chat',
                               data: {
                                   menu: {
                                       title: 'Chat Admin',
                                       icon: 'fa fa-comments-o',
                                       selected: false,
                                       expanded: false,
                                       order: 0
                                   }
                               }
                           },*/
                {
                    path: 'test',
                    data: {
                        menu: {
                            title: 'Setting Board',
                            icon: 'fa fa-cog',
                            selected: false,
                            expanded: false,
                            order: 0
                        }
                    }
                },
                {
                    path: 'support-user',
                    data: {
                        menu: {
                            title: 'Support Users',
                            icon: 'fa fa-user-md',
                            selected: false,
                            expanded: false,
                            order: 350
                        }
                    },
                },
                {
                    path: 'support',
                    data: {
                        menu: {
                            title: 'Support',
                            icon: 'ion-help-circled',
                            selected: false,
                            expanded: false,
                            order: 400
                        }
                    },
                },

            ]
        }
    ];
    public developerMenu: any = [
            {
                path: '',
                children: [
                    {
                        path: 'support',
                        data: {
                            menu: {
                                title: 'Support',
                                icon: 'ion-help-circled',
                                selected: false,
                                expanded: false,
                                order: 0
                            }
                        }
                    },
                ]
            }
        ];

    constructor(private _menuService: BaMenuService, private session: SessionService) {
    }

    ngOnInit() {

        const userType = this.session.getUserRole();
        if (userType === 'TECH-SUPPORT') {
            this._menuService.updateMenuByRoutes(<Routes>this.techMenu);
        } else if (userType === 'FINANCIAL-SUPPORT') {
            this._menuService.updateMenuByRoutes(<Routes>this.financialMenu);
        } else if (userType === 'DEV-SUPPORT') {
            this._menuService.updateMenuByRoutes(<Routes>this.developerMenu);
        } else {
            this._menuService.updateMenuByRoutes(<Routes>this.fullMenu);
        }

        // this._menuService.updateMenuByRoutes(<Routes>PAGES_MENU);
    }
}
