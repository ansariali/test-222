import {Component, OnInit} from '@angular/core';

declare var $: any;

@Component({
    selector: 'authLayout',
    template: `
        <router-outlet></router-outlet>
        <ba-back-top position="200"></ba-back-top>
    `,
})
// export class Pages {
export class AuthLayoutComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
        /*$('.form-control').each(function () {

            $(this).focus(function () {
                $(this).parent().addClass('focused');
            });

            $(this).focusout(function () {
                $(this).parent().removeClass('focused');
            });

            function emptyListener($this) {
                requestAnimationFrame(function () {
                    emptyListener($this);
                });

                if ($this.val() === '' || $this.val() === null) {
                    $this.parent().removeClass('is-completed');
                    $this.parent().removeClass('is-active');
                } else {
                    $this.parent().addClass('is-active is-completed');
                }
            }

            emptyListener($(this));
        });*/
    }
}
