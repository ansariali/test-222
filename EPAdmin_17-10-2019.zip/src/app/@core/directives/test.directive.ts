import {Directive, ElementRef, Renderer2} from '@angular/core';

@Directive({
    selector: '[appTest]',
})
export class TestDirective {

    constructor(element: ElementRef, renderer: Renderer2) {
        renderer.setStyle(element.nativeElement, 'box-shadow', '2px 2px 12px RED');
    }

   /* ngOnInit() {
        console.info('I\'m from Test Directive!');
    }*/
}
