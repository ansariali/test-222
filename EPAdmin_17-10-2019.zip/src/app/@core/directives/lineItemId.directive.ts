import {Directive, ElementRef, Renderer2, Input, OnInit, HostListener} from '@angular/core';


@Directive({
    selector: '[lsLineItemId]',
})

export class LineItemIdDirective implements OnInit {
    @Input() lsLineItemId: string;

    constructor(public element: ElementRef, renderer: Renderer2) {
    }

    ngOnInit() {
    }

    @HostListener('click', ['$event'])
    onClick($event) {
        localStorage.setItem('LineItemId', this.lsLineItemId);
        // console.info('I\'m from LineItemId Directive! Clicked !!', this.lsLineItemId);
    }
}
