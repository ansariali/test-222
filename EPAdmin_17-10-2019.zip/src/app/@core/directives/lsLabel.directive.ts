import {Directive, DoCheck, ElementRef, HostListener, OnChanges, OnInit, Renderer2} from '@angular/core';
import {NgControl} from '@angular/forms';

@Directive({
    selector: '[lsLabel]',
})
export class LsLabelDirective implements OnInit, OnChanges, DoCheck {
    private hasFocus: any;

    constructor(private element: ElementRef, private renderer: Renderer2, private control: NgControl) {
    }

    ngOnInit() {
    }

    ngOnChanges() {
    }

    ngDoCheck() {
        if (this.element.nativeElement.value === '' || this.element.nativeElement.value === null) {
            // TODO: focus Check
            if (!this.hasFocus) {
                this.renderer.removeClass(this.element.nativeElement.parentElement, 'focused');
            }
        } else {
            this.renderer.addClass(this.element.nativeElement.parentElement, 'focused');
        }
    }

    @HostListener('focus', ['$event'])
    onFocus($event) {
        this.hasFocus = true;
        this.renderer.addClass(this.element.nativeElement.parentElement, 'focused');
    }

    @HostListener('focusout', ['$event'])
    onFocusout($event) {
        this.hasFocus = false;
        if (this.element.nativeElement.value === '' || this.element.nativeElement.value === null) {
            this.renderer.removeClass(this.element.nativeElement.parentElement, 'focused');
        } else {
            this.renderer.addClass(this.element.nativeElement.parentElement, 'focused');
        }
    }
}
