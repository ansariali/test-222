import {Directive, ElementRef, Renderer2, Input, OnInit, HostListener} from '@angular/core';


@Directive({
    selector: '[appMaterialId]',
})

export class MaterialIdDirective implements OnInit {
    @Input() value: string;

    constructor(private element: ElementRef, renderer: Renderer2) {
    }

    ngOnInit() {
    }

    @HostListener('click', ['$event'])
    onClick($event) {
        // console.info('I\'m from Test Directive! Clicked !!', this.value);
        localStorage.setItem('MaterialId', this.value);
    }
}
