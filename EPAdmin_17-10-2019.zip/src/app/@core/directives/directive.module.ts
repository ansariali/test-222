import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';

import {TestDirective} from './test.directive';
import {MaterialIdDirective} from './materialId.directive';
import {CustomVendorIdDirective} from './customVendorId.directive';
import {ClusterIdDirective} from './clusterId.directive';
import {TenderIdDirective} from './tenderId.directive';
import {BidIdDirective} from './bidId.directive';
import {EqualValidatorDirective} from './equalValidator.directive';
import {LsLabelDirective} from './lsLabel.directive';
import {LineItemIdDirective} from './lineItemId.directive';

const DIRECTIVES = [
    TestDirective,
    MaterialIdDirective,
    CustomVendorIdDirective,
    ClusterIdDirective,
    TenderIdDirective,
    BidIdDirective,
    EqualValidatorDirective,
    LsLabelDirective,
    LineItemIdDirective
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        ...DIRECTIVES,
    ],
    exports: [
        ...DIRECTIVES
    ],
})
export class DirectiveModule {
}
