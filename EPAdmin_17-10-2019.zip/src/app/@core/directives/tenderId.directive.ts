import {Directive, ElementRef, Renderer2, Input, OnInit, HostListener} from '@angular/core';


@Directive({
    selector: '[appTenderId]',
})

export class TenderIdDirective implements OnInit {
    @Input() value: string;

    constructor(private element: ElementRef, renderer: Renderer2) {
    }

    ngOnInit() {
    }

    @HostListener('click', ['$event'])
    onClick($event) {
        localStorage.setItem('TenderId', this.value);
        // console.info('I\'m from Test Directive! Clicked !!', this.value);
    }
}
