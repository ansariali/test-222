import {Injectable} from '@angular/core';

@Injectable()
export class GuardService {
    public config: any = {
        smallLoader: false
    };

    constructor() {
    }

    sLoaderSwitch(toggle) {
        this.config.smallLoader = toggle;
    }
}
