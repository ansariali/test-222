import {Injectable} from '@angular/core';

@Injectable()
export class UrlService {
    public urls: any = {
        epCtrl: {
            signUp: '/adminController/v1/proceedTo/signUp/{userId}?notificationId={notificationId}',
            signIn: '/eazeProcureController/v1/signIn',
            signOut: '/eazeProcureController/v1/signOut',
            crossAuthentication: '/eazeProcureController/v1/crossAuthentication'
        },
        adminCtrl: {
            updateUser: '/adminController/v1/update/userProfile/{userId}?serviceId={serviceId}',
            assignPlan: '/adminController/v1/allocatePlan/toVendor/{userId}?pricingTierToken={pricingTierToken}&vendorId={vendorId}&purchased={purchased}',
            newAssignPlan: '/adminController/v1/allocatePlan/toVendor/{userId}?pricingTierToken={pricingTierToken}&vendorId={vendorId}&purchased={purchased}&totalMonth={totalMonth}&autoExtendable={autoExtendable}',
            updateVendor: '/adminController/v1/update/vendorCompanyProfile/{userId}?vendorId={vendorId}&serviceId={serviceId}',
            updateEmail: '/adminController/v1/update/user/emailAddress/{userId}?targetedUserId={targetedUserId}&emailAddress={emailAddress}',
            fetchVendor: '/adminController/v1/fetch/vendor/{userId}?vendorId={vendorId}',
            fetchUserByRole: '/adminController/v1/fetchAllUser/byRole/{userId}?userRole={userRole}',
            userSwitch: '/adminController/v1/enable/disable/{userId}/{targetedUserId}?status={status}',
            sendEmail: '/adminController/v1/send/verificationMail/{userId}/{targetedUserId}',
            addMaterial: '/adminController/v1/add/material/{userId}?materialType={materialType}',
            fetchMaterial: '/adminController/v1/fetchAll/materialTypes',
            deleteMaterial: '/adminController/v1/delete/materialType/{userId}?materialId={materialId}',
            deleteMapTruck: '/adminController/v1/removeMapping/truck/material/{userId}/{materialId}/{truckTypeId}',
            fetchAllPricingTier: '/adminController/v1/fetchAll/pricingTier/{userId}',
            fetchPricingByUser: '/adminController/v1/fetchAll/pricingTier/{userId}',
            createPricing: '/adminController/v1/create/pricingTier/{userId}',
            updatePricing: '/adminController/v1/update/pricingTier/{userId}/{pricingTierId}',
            fetchPricingByTierId: '/adminController/v1/fetchAll/pricingTier/{userId}/{pricingTierId}',
            pricingTierDeactive: '/adminController/v1/activate/deactivate/pricingTier/{userId}/{pricingTierId}?status={status}',
            fetchProfile: '/adminController/v1/fetch/adminProfile/{userId}',
            updateProfile: '/adminController/v1/update/adminProfile/{userId}',
            changePwd: '/adminController/v1/changePassword/{userId}',

            addSupportUser: '/adminController/v1/add/user/{userId}',
            fetchAllSupportUser: '/adminController/v1/fetchAll/user/{userId}',
            fetchNotification: '/adminController/v1/fetchAll/notification/{userId}',
            seenNotification: '/adminController/v1/seenAll/latest/notification/{userId}',
            fetchNotificationByCount: '/adminController/v1/fetch/notificationByNumber/{userId}?pageSize={pageSize}&pageNumber={pageNumber}',
            fetchNotificationById: '/adminController/v1/fetch/notification/byId/{userId}?notificationId={notificationId}',
            enableDisabledUser: '/adminController/v1/enableAndDisableVendor/{userId}?vendorId={vendorId}&vendorUserId={vendorUserId}&enableAndDisableStatus={enableAndDisableStatus}',
            resetPlanInfo: '/adminController/v1/reset/planInformation/{userId}?secretKey={secretKey}'
        },
        supportCtrl: {
            fetchAllRequest: '/770/v1/fetchAll/request/{userId}',
            verifyHelpToken: '/770/v1/verify/request/{userId}?helpToken={helpToken}',
            attendRequest: '/770/v1/attend/request/{userId}',
            changeRequestStatus: '/770/v1/update/requestStatus/{userId}?description={description}&status={status}',
            pinRequest: '/770/v1/pin/request/{userId}',
            unPinRequest: '/770/v1/unpin/request/{userId}'

        },
        genericCtrl: {
            currentTime: '/genericController/v1/fetch/istTime',
            validateUser: '/genericController/v1/verify/userName?userName={userName}',
            validateOnlyEmail: '/genericController/v1/verify/emailAddress?emailAddress={emailAddress}',
        },
        logBidsController: {
            scSignUp: '/scController/create',
            tspSignUp: '/tspController/create',
            signUp: '/logBidsController/v1/signUp?userType={userType}',
            signIn: '/logBidsController/v1/signIn',
            signOut: '/logBidsController/v1/signOut',
            verifyEmailForgotPassword: '/logBidsController/v1/request/forgotPassword?emailAddress={emailAddress}',
            resetPassword: '/logBidsController/v1/verify/forgotPassword?forgotToken={forgotToken}',
            crossAuthentication: '/logBidsController/v1/crossAuthentication'
        },
        tenderCtrl: {
            // fetchAllTender: '/adminController/v1/fetchAll/tender/{userId}?companyName={companyName}&fromDate={fromDate}&toDate={toDate}',
            fetchAllTender: '/adminController/v1/fetchAll/lineItems/{userId}?companyName={companyName}&fromDate={fromDate}&toDate={toDate}',
            fetchTenderById: '/adminController/v1/fetchAll/stackHolder/{userId}?tenderId={tenderId}',
            extendTender: '/adminController/v1/extend/startTimeAndExpireTime/{userId}?tenderId={tenderId}&startDate={startDate}&expiryDate={expiryDate}',
            // extendTender: '/adminController/v1/extend/tender/{userId}?tenderId={tenderId}&expiryDate={expiryDate}',
            convertToAuction: '/adminController/v1/convert/tender/rfqToAuction/{userId}?tenderId={tenderId}&deepScan=true',
            deleteTender: '/adminController/v1/delete/tender/{userId}?tenderId={tenderId}&justification={justification}&deepScan={deepScan}',
            deleteTenderLinItem: '/adminController/v1/delete/tenderLineItem/{userId}?tenderId={tenderId}&lineItemId={lineItemId}&justification={justification}&deepScan={deepScan}',
            fetch: '/adminController/v1/fetch/tender/{userId}?tenderId={tenderId}',
            createBid: '/adminController/v1/create/bid/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&deepScan=true',
            // updateBid: '/adminController/v1/update/bid/{userId}/{remarks}?tenderLineItemConductorId={tenderLineItemConductorId}&bidId={bidId}&bidAmount={bidAmount}&deepScan=true',
            updateBid: '/adminController/v1/update/bid/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&bidId={bidId}&deepScan=true',
            deleteBid: '/adminController/v1/delete/bidAmount/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&bidId={bidId}&whyDelete={whyDelete}&deepScan={deepScan}',
            exitAuction: '/adminController/v1/exits/bid/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&bidId={bidId}&whyDelete={whyDelete}&deepScan=true',
            lowestBid: '/adminController/v1/fetch/lowestBid/{userId}?tenderLineItemId={tenderLineItemId}',
            highestBid: '/adminController/v1/fetch/highestBid/{userId}?tenderLineItemId={tenderLineItemId}',
            fetchLowestRank: '/adminController/v1/fetch/lowestBidRank/{userId}?tenderLineItemConductorToken={tenderLineItemConductorToken}',
            fetchHighestRank: '/adminController/v1/fetch/highestBidRank/{userId}?tenderLineItemConductorToken={tenderLineItemConductorToken}',
            allTenderInvitation: '/adminController/v1/reSend/tenderInvitation/allVendor/{userId}?tenderId={tenderId}',
            oneTenderInvitation: '/adminController/v1/reSend/tenderInvitation/byCustomVendorId/{userId}?tenderId={tenderId}&customVendorId={customVendorId}',
            selectBid: '/adminController/v1/selectBid/{userId}?tenderId={tenderId}&lineItemId={lineItemId}&bidId={bidId}&justification={justification}',
            fetchAllVendor: '/adminController/v1/fetchAll/vendor/{userId}',
            downloadReport: '/adminController/download/tenderReport/{vendorId}/{adminUserId}?fromDate={fromDate}&toDate={toDate}&spreadType={spreadType}&downloadType={downloadType}&accessToken={accessToken}',
            deleteBidPermission: '/adminController/v1/deleteBidPermission/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&deleteBidStatus={deleteBidStatus}',
            exitBidPermission: '/adminController/v1/exitBidPermission/{userId}?tenderLineItemConductorId={tenderLineItemConductorId}&exitBidStatus={exitBidStatus}',
            refreshPage: '/adminController/v1/refresh/customVendorTender/{userId}?customVendorId={customVendorId}&&tenderConductorToken={tenderConductorToken}'

        }
    };

    constructor() {
    }
}
