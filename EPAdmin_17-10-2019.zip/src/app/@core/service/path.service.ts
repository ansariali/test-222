import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class PathService {
    public pageUrl: any = {
        Inr: '₹',
        hash: '#',
        slash: '/',
        hashSlash: '#/',
        gmail: 'https://www.google.com/gmail/',
        auth: {
            login: 'auth/login',
            register: 'auth/register',
            guest: 'auth/guest/:option1/:option2',
        },
        login: {
            default: 'login',
            slashUrl: '/login',
            hashUrl: '#/login'
        },
        register: {
            default: 'register',
            slashUrl: '/register',
            hashUrl: '#/register'
        },
        forgotPassword: {
            default: 'forgot-password',
            slashUrl: '/forgot-password',
            hashUrl: '#/forgot-password'
        },
        dashboard: {
            default: 'dashboard',
            market: 'market',
        },
        material: {
            view: 'material/view',
            create: 'material/create',
            update: 'material/update',
        },
        vendor: {
            view: 'vendor/view/1',
            viewIdx: {
                one: 'vendor/view/1',
                two: 'vendor/view/2',
                three: 'vendor/view/3',
            },
        },
        cluster: {
            view: 'cluster/view',
            create: 'cluster/create',
            update: 'cluster/update',
        },
        tender: {
            view: 'tender/view',
            create: 'tender/create',
            update: 'tender/update',
            all: 'tender/all',
        },
        bid: {
            view: 'bid/view/1',
            viewIdx: {
                one: 'bid/view/1',
                two: 'bid/view/2',
                three: 'bid/view/3',
            },
            create: 'bid/create/1',
            createIdx: {
                one: 'bid/create/1',
                two: 'bid/create/2',
                three: 'bid/create/3',
            },
            update: 'bid/update/1',
            updateIdx: {
                one: 'bid/update/1',
                two: 'bid/update/2',
                three: 'bid/update/3',
            },
            select: 'bid/select/1',
            selectIdx: {
                one: 'bid/select/1',
                two: 'bid/select/2',
                three: 'bid/select/3',
                four: 'bid/select/4',
            },
        },
        guest: {
            splitOne: 'guest',
            view: 'guest/tender/view/:token',
            viewNoToken: 'guest/tender/view/',
            badUser: 'guest/baduser',
            create: 'tender/create',
            update: 'tender/update',
            profileNoToken: 'guest/profile/',
            profile: 'guest/profile/:token',
            notInterested: 'guest/later',
        },
        profile: {
            default: 'profile',
            viewIdx: {
                one: 'profile/1',
                two: 'profile/2',
                three: 'profile/3',
            },
        },
        slashUrl: {
            auth: {
                login: '/auth/login',
                register: '/auth/register',
                guest: '/auth/guest/:option1/:option2',
            },
            dashboard: {
                default: '/dashboard',
                market: '/dashboard',
            },
            material: {
                view: '/material/view',
                create: '/material/create',
                update: '/material/update',
            },
            vendor: {
                view: '/vendor/view/1',
                viewIdx: {
                    one: '/vendor/view/1',
                    two: '/vendor/view/2',
                    three: '/vendor/view/3',
                },
                create: '/vendor/create',
                update: '/vendor/update',
            },
            cluster: {
                view: '/cluster/view',
                create: '/cluster/create',
                update: '/cluster/update',
            },
            tender: {
                view: '/tender/view',
                create: '/tender/create',
                update: '/tender/update',
                all: '/tender/all',
            },
            bid: {
                view: '/bid/view/1',
                viewIdx: {
                    one: '/bid/view/1',
                    two: '/bid/view/2',
                    three: '/bid/view/3',
                },
                create: '/bid/create/1',
                createIdx: {
                    one: '/bid/create/1',
                    two: '/bid/create/2',
                    three: '/bid/create/3',
                },
                update: '/bid/update/1',
                updateIdx: {
                    one: '/bid/update/1',
                    two: '/bid/update/2',
                    three: '/bid/update/3',
                },
                select: '/bid/select/1',
                selectIdx: {
                    one: '/bid/select/1',
                    two: '/bid/select/2',
                    three: '/bid/select/3',
                    four: '/bid/select/4',
                },
            },
            guest: {
                view: '/guest/tender/view/:token',
                viewNoToken: '/guest/tender/view/',
                badUser: '/guest/baduser',
                create: '/tender/create',
                update: '/tender/update',
                profileNoToken: '/guest/profile/',
                profile: '/guest/profile/:token',
                notInterested: '/guest/later',
            },
            profile: {
                default: '/profile',
                viewIdx: {
                    one: '/profile/1',
                    two: '/profile/2',
                    three: '/profile/3',
                },
            }
        },
        hashUrl: {
            login: '#/login',
            register: '#/register',
            auth: {
                login: '#/auth/login',
                register: '#/auth/register',
                guest: '#/auth/guest/:option1/:option2',
            },
            dashboard: {
                default: '#/dashboard',
            },
            material: {
                view: '#/material/view',
                create: '#/material/create',
                update: '#/material/update',
            },
            vendor: {
                view: '#/vendor/view',
                create: '#/vendor/create',
                update: '#/vendor/update',
            },
            cluster: {
                view: '#/cluster/view',
                create: '#/cluster/create',
                update: '#/cluster/update',
            },
            tender: {
                view: '#/tender/view',
                create: '#/tender/create',
                update: '#/tender/update',
                all: '#/tender/all',
            },
            bid: {
                view: '#/bid/view/1',
                viewIdx: {
                    one: '#/bid/view/1',
                    two: '#/bid/view/2',
                    three: '#/bid/view/3',
                },
                create: '#/bid/create/1',
                createIdx: {
                    one: '#/bid/create/1',
                    two: '#/bid/create/2',
                    three: '#/bid/create/3',
                },
                update: '#/bid/update/1',
                updateIdx: {
                    one: '#/bid/update/1',
                    two: '#/bid/update/2',
                    three: '#/bid/update/3',
                },
                select: '#/bid/select/1',
                selectIdx: {
                    one: '#/bid/select/1',
                    two: '#/bid/select/2',
                    three: '#/bid/select/3',
                    four: '#/bid/select/4',
                },
            },
            guest: {
                view: '#/guest/tender/view/:token',
                viewNoToken: '#/guest/tender/view/',
                badUser: '#/guest/baduser',
                create: '#/tender/create',
                update: '#/tender/update',
                profileNoToken: '#/guest/profile/',
                profile: '#/guest/profile/:token',
                notInterested: '#/guest/later',
            },
            profile: {
                default: '#/profile',
                viewIdx: {
                    one: '#/profile/1',
                    two: '#/profile/2',
                    three: '#/profile/3',
                },
            }
        },

    };

    constructor(private router: Router) {
    }

    routeRegister() {
        this.router.navigateByUrl(this.pageUrl.auth.register);
    }
}
