import {Injectable, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from './http.service';
import {SessionService} from './session.service';
import {PathService} from './path.service';

import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';

@Injectable()
export class WebsocketService implements OnInit {
    public serverUrl: string;
    public stompClient;

    constructor(public router: Router, public http: HttpService, public path: PathService,
                public session: SessionService) {
        this.serverUrl = this.http.wsConnectionUrl();
    }

    ngOnInit() {
    }

    client() {
        let ws = new SockJS(this.serverUrl);
        return Stomp.over(ws);
    }

    connect(_fn?: Function, _errFn?: Function) {
        let ws = new SockJS(this.serverUrl);
        this.stompClient = Stomp.over(ws);
        this.stompClient.debug = null;
        this.stompClient.connect({},
            (frame) => {
                if (_fn != undefined) {
                    _fn(this.stompClient);
                }
            },
            () => {
                if (_errFn != undefined) {
                    _errFn();
                } else {
                    // this.http.customErrorToast(9075229999)
                }
            });
    }

    _connect(stompClient, _fn?: Function, _errFn?: Function) {
        stompClient.connect({},
            (frame) => {
                if (_fn != undefined) {
                    _fn(stompClient);
                }
            },
            () => {
                if (_errFn != undefined) {
                    _errFn();
                } else {
                    // this.http.customErrorToast(9075229999);
                }
            });
    }

    subscribe(_url, _headers, _fn?: Function) {
        console.info('_url: ', _url);


        if (_fn == undefined) {
            this.stompClient.subscribe(_url, null, _headers);
        } else {
            this.stompClient.subscribe(_url, _fn, _headers);
        }
    }

    _subscribe(stompClient, _url, _headers, _fn?: Function) {

        if (_fn == undefined) {
            stompClient.subscribe(_url, null, _headers);
        } else {
            stompClient.subscribe(_url, _fn, _headers);
        }
    }

    send(_url, _headers, message, customHeaders?) {
        if (customHeaders) {
            _headers['Accept'] = 'application/json';
        } else {
            // _headers['LOGIN-TOKEN'] = this.session.getLoginToken();
            _headers['Accept'] = 'application/json';
        }

        if (this.stompClient != undefined) {
            this.stompClient.send(_url, _headers, JSON.stringify(message));
        }
    }

    disconnect() {
        // console.info('this.stompClient: ', this.stompClient);
        if (this.stompClient != undefined) {
            console.info('disconneted');
            this.stompClient.disconnect();
        }
    }

    _disconnect(stompClient) {
        if (stompClient != null && stompClient != undefined) {
            stompClient.disconnect();
        }
        return this.client();
    }

    getStompClient() {
        // console.info('this.stompClient: ', this.stompClient);
        return this.stompClient;
    }

    getBody(object) {
        return JSON.parse(object.body);
    }

}
