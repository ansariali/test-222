import {Injectable} from '@angular/core';

@Injectable()
export class ConstantService {

  public static API_ENDPOINT = 'http://192.168.10.99:50/';

  public codeA = [
    6481125119601,
    6481125119602,
    6481125119603,
    6481125119604,
    6481125119605,
    6481125119606,
    6481125119607,
    6481125119608,
    6481125000009,
    6481125119610,
    6481125119611,
    6481125119612,
    6481125119613,
    6481125119614,
    6481125119615,
    6481125119616,
    6481125119617,
    6481125119618,
    6481125119619,
    6481125058401,
    6481125058402,
    6481125059801,
    6481125059802,
    6481125059804,
    6481125059805,
    6481125059806,
    6481125059807,
    6481125059808,
    6481125059809,
    6481125148301,
    6481125148302,
    6481125148303,
    6481125148304,
    6481125148305,
    6481125148306,
    6481125148307,
    6481125148308,
    6481125148309,
    6481125148310,
    6481125148311,
    6481125148312,
    6481125148313,
    6481125071301,
    6481125202601,
    6481125081501,
    6481125081502,
    6481125081503,
    6481125081504,
    6481125081506,
    6481125081507,
    6481125081508,
    6481125081509,
    6481125081510,
    6481125081511,
    6481125081512,
    6481125081513,
    6481125180601,
    6481125180602,
    6481125180603,
    6481125180604,
    6481125161301,
    6481125161302,
    6481125161303,
    6481125161304,
    6481125132101,
    6481125132102,
    6481125132103,
    6481125132104,
    6481125132105,
    6481125132106,
    6481125132107,
    6481125132108,
    6481125132109,
    6481125132110,
    6481125132111,
    6481125132112,
    6481125132113,
    6481125132114,
    6481125132115,
    6481125132116,
    6481125132118,
    6481125132119,
    6481125132120,
    6481125132121,
    6481125132122,
    6481125132123,
    6481125073801,
    6481125073802,
    6481125073803,
    6481125073804,
    6481125073805,
    6481125073806,
    6481125073807,
    6481125073808,
    6481125073809,
    6481125073810,
    6481125073811,
    6481125140201,
    6481125140202,
    6481125140203,
    6481125140204,
    6481125140205,
    6481125061001,
    6481125061002,
    6481125061003,
    6481125061004,
    6481125061005,
    6481125061006,
    6481125061007,
    6481125061008,
    6481125061009,
    6481125061010,
    6481125061011,
    6481125061012,
    6481125061013,
    6481125061014,
    6481125061015,
    6481125061016,
    6481125061017,
    6481125061018,
    6481125061019,
    6481125061020,
    6481125061021,
    6481125061022,
    6481125061023,
    6481125000024,
    6481125061025,
    6481125061026,
    6481125061027,
    6481125061028,
    6481125061029,
    6481125061030,
    6481125061031,
    6481125061032,
    6481125061033,
    6481125061034,
    6481125061035,
    6481125061036,
    6481125061037,
    6481125061038,
    6481125061040,
    6481125061041,
    6481125061042,
    6481125061043,
    6481125061044,
    6481125061045,
    6481125061047,
    6481125061048,
    6481125061052,
    6481125061053,
    6481125061054,
    6481125061057,
    6481125061058,
    6481125061059,
    6481125061060,
    6481125061061,
    6481125061062,
    6481125061062,
    6481125061063,
    6481125061064,
    6481125061065,
    6481125027101,
    6481125027102,
    6481125027103,
    6481125027104,
    6481125027105,
    6481125027106,
    6481125027107,
    6481125027108,
    6481125126601,
    6481125126602,
    6481125126603,
    6481125126604,
    6481125126605,
    6481125126606,
    6481125126608,
    6481125126609,
    6481125126610,
    6481125126611,
    6481125148301,
    6481125148302,
    6481125148303,
    6481125148304,
    6481125148305,
    6481125148306,
    6481125148308,
    6481125148309,
    6481125148310,
    6481125148311,
    6481125148312,
    6481125148313,
    6481125125501,
    6481125125502,
    6481125125503,
    6481125125504,
    6481125125505,
    6481125125506,
    648112506171,
    648112506172,
    648112506173,
    648112506174,
    648112506175,
    648112506176,
    648112506177,
    648112506178,
    648112506179,
    6481125061710,
    6481125061711,
    6481125061712,
    6481125061713,
    6481125061714
  ];

  public messageA = [
    'Targetted User not found',
    'Custom Vendor Unspecified: The Custom Vendor is not Created by you.',
    'Failed to add Nodal Contact.',
    'Failed to remove nodal contact.',
    'Email ID is missing',
    'Company Name is Missing',
    'Company Registration Number is Missing.',
    'Username is missing',
    'Tax number is missing',
    'Pan Card Number is Missing',
    'Kindly fill in the Nature of Business field',
    'Kindly specify specific business typr',
    'Kindly Update User ID',
    'We\'re Unable to add your User account.',
    'We\'re Unable to update your User account.',
    'This User name already exists, please try with an alternate username.',
    'We\'re unable to find the desired email address. Kindly Verify.',
    'The associated user account is inactive. Kindly verify by clicking on the e-mail confirmation link.',
    'Invalid User Account. Kindly re-verify.',
    'The Username or Password is missing.',
    'Oops! Login failed. Try again later.',
    'You don\'t seem to have a Bizdesk account. Create a Bizdesk account to proceed.',
    'Failed to sign-up',
    'The Email address for Master account is missing. Kindly Update or verify.',
    'The Email address for promoter account is missing. Kindly Update or verify.',
    'Promoter Email is missing.',
    'Invalid Promoter Account.  Kindly Reverify or get in touch with our executives',
    'Specified User already exists.',
    'Invalid User Role!Kindly validate.',
    'Oops!Vendor not Found.',
    'Invalid Vendor Account',
    'Inactive Vendor account. Kindly verify by clicking on the e-mail confirmation link.',
    'This account is not linked with a buying facilitation',
    'This account is not linked with a sales facilitation',
    'Oops! We\'re unable to Update the vendor from the list',
    'Oops!Vendor not Found.',
    'Unable to track vendor details.',
    'Inactive vendor account. Kindly verify by clicking on the e-mail confirmation link.',
    'Invalid Vendor Account.',
    'We Can\'t fetch the details for the specified User. Kindly Re-verify.',
    'We\'re Unable to link the specified vendor account. Kindly Verify.',
    'Please Update a vendor account to proceed.',
    'We\'re unable to sign you out. Please try again later.',
    'Desired Results can\'t be fetched.',
    'Kindly update material name to proceed.',
    'Material Not found.',
    'Kindly Update Material Category in List.',
    'Kindly Update Specific Material Category.',
    'Unable to find material',
    'Invalid Material',
    'Failed to add material',
    'Failed to Verify Material',
    'Failed to Update Material',
    'Material is Unverified',
    'Material already exists',
    'Material is already verified',
    'Please update Material ID',
    'Unable to add preferred material',
    'Unable to find preferred material',
    'Invalid Preffered Material',
    'Preffered vendor does not exist',
    'Unable to add preferred vendor',
    'Unable to find preferred vendor',
    'Preferred vendor is invalid',
    'Kindly update Point of Contact',
    'Kindly update vendor type',
    'Invalid Vendor Type',
    'vendor category is missing',
    'Invalid vendor category',
    'Custom vendor is Missing',
    'Vendor already exists.',
    'Unable to find custom vendor for participant',
    'Kindly Update contact number',
    'unable to add custom vendor',
    'Unable to locate custom vendor id',
    'Unable to locate custom vendor ',
    'Invalid Custom Vendor',
    'Invalid Service ID',
    'Unable to update custom vendor',
    'Unable to allocate material to custom vendor.',
    'Unable to Validate Custom Vendor ID',
    'Unable to locate targetted Custom Vendor ID',
    'Unable to locate targetted Custom Vendor ',
    'Inactive targetted Custom Vendor',
    'Invalid targer custom vendor',
    'Custom vendor participant is absent. Kindly Verify.',
    'Unable to locate Cluster ID',
    'Kindly validate Cluster Name.',
    'Kindly provide cluster description.',
    'Unable to add cluster',
    'Unable to locate cluster',
    'Invalid Cluster',
    'Unable to update cluster',
    'Cluster Already exists',
    'Cluster Participant is missing',
    'cluster already exists ',
    'Please enter keywords to trace your company and identify products.',
    'Unable to locate Cluster Member ID',
    'Unable to add cluster member',
    'Unable to locate cluster member',
    'Invalid cluster member',
    'Member already exists on the cluster',
    'Kindly Update tender Material',
    'Kindly update tender title',
    'Kindly update tender type',
    'Invalid tender type',
    'Fixed tender not supported for procurement events.',
    'Fix Bid not supported for procurment events.',
    'Invalid quantity type',
    'Kindly update quantity type on form.',
    'kindly update quantity.',
    'Kindly update tender start date.',
    'kindly update tender expiry date.',
    'kindly update tender delivery date.',
    'Kindly update tender payment terms.',
    'Kindly update your freight details on the form',
    'Kindly validate pre-qualification questionaire.',
    'Kindly validate pre-qualification description.',
    'Oops! The word limit for pre-qualification criteria has been surpassed.',
    'Oops! The word limit for the description criteria has been surpassed.',
    'Kindly update Bid type',
    'Invalid bid type',
    'There seems to be a discrepancy in the bid threshold and amount.',
    'Bid amount invalid for auction.',
    'Quote is missing for RFQ.',
    'Quote should be higher than 500 for RFQ',
    'Invalid incremental bid. Kindly Verify bid increment threshold.',
    'Invalid Decremental bid. Kindly verify bid reduction threshold.',
    'Invalid Delivery date.',
    'Invalid expiry date.',
    'Unable to locate Tender Delivery address.',
    'Oops! The word limit for delivery address has been surpassed.',
    'Kindly verify pin code on form.',
    'Invalid Pin code. Kindly verify.',
    'Kindly enter delivery city',
    'Kindly verify delivery State',
    'Kindly verify country code.',
    'Tender conductor not added.',
    'Kindly update participants in tender.',
    'Bid threshold amount is mandatory for Auctions.',
    'Kindly enter fixed bid amount.',
    'Invalid fixed bid amount.',
    'Unable to add tender.',
    'Unable to locate tender ID',
    'Unable to locate tender attachment ID',
    'Unable to locate tender',
    'Invalid Tender ',
    'Quotations open in a few minutes.',
    'Non Applicable tender',
    'Unable to convert RFQ to auction',
    'Tender has already been converted to auction.',
    'Kindly verify the contractual date',
    'Kindly validate the "from" date',
    'Inavalid "from"date',
    '"Tender to" date is missing',
    'Invalid tender "to" date',
    'unable to delete tender',
    'Unable to extend tender',
    'Unable to locate tender category',
    'Kindly validate tender attachment',
    'Tender Participant ID is missing',
    'Conflicting Bids identified. Kindly Validate bid.',
    'Bid Amount is missing',
    'Unable to locate Bid ID',
    'Unable to locate bid',
    'Invalid Bid',
    'Rebid not permitted for fixed tender',
    'Unable to delete bid',
    'Bid not ready',
    'Unable to update counter offer',
    'Counter offer not found',
    'Unable to add offer',
    'Counter offer unavailable',
    'You have reached the threshold for negotiation limit.',
    'Invalid counter offer',
    'Unable to locate offer',
    'Unable to locate counter offer ID',
    'Offer ID is missing',
    'Unable to locate offer token number',
    'default address is missing',
    'Default address tag is missing',
    'Kindly validate default address',
    'Kindly validate default address pin code',
    'Kindly update default address city field',
    'kindly update  default address state field',
    'Kindly update default address country field',
    'Unable to locate default address  region',
    'Unable to add default address',
    'Unable to locate default address',
    'Unable to update default address',
    'Unable to delete default address',
    'Unable to locate notification ID',
    'Kindly validate notification Email ID',
    'Unable to locate notification status',
    'Unable to  locate vendor notification',
    'Invalid vendor notification',
    'Unable to delete notification',
    'Invalid Http Request method',
    'Unable to validate HttpRequest header',
    'Invalid httpRequest body',
    'Generic Failure logged',
    'Server operation failed',
    'Unable to locate token number',
    'Invalid token number',
    'Access ID is missing',
    'Device ID is missing',
    'Parent id is missing',
    'Service id missing',
    'Service not available',
    'Token number already verified',
    'Unable to generate report',
    'Targetted User not found',
    'Custom Vendor Unspecified: The Custom Vendor is not Created by you.',
    'Failed to add Nodal Contact.',
    'Failed to remove nodal contact.',
    'Email ID is missing',
    'Company Name is Missing',
    'Company Registration Number is Missing.',
    'Username is missing',
    'Tax number is missing',
    'Pan Card Number is Missing',
    'Kindly fill in the Nature of Business field',
    'Kindly specify specific business typr',
    'Kindly Update User ID',
    'We\'re Unable to add your User account.',
    'We\'re Unable to update your User account.',
    'This User name already exists, please try with an alternate username.',
    'We\'re unable to find the desired email address. Kindly Verify.',
    'The associated user account is inactive. Kindly verify by clicking on the e-mail confirmation link.',
    'Invalid User Account. Kindly re-verify.',
    'The Username or Password is missing.',
    'Oops! Login failed. Try again later.',
    'You don\'t seem to have a Bizdesk account. Create a Bizdesk account to proceed.',
    'Failed to sign-up',
    'The Email address for Master account is missing. Kindly Update or verify.',
    'The Email address for promoter account is missing. Kindly Update or verify.',
    'Promoter Email is missing.',
    'Invalid Promoter Account.  Kindly Reverify or get in touch with our executives',
    'Specified User already exists.',
    'Invalid User Role!Kindly validate.',
    'Oops!Vendor not Found.',
    'Invalid Vendor Account',
    'Inactive Vendor account. Kindly verify by clicking on the e-mail confirmation link.',
    'This account is not linked with a buying facilitation',
    'This account is not linked with a sales facilitation',
    'Oops! We\'re unable to Update the vendor from the list',
    'Oops!Vendor not Found.',
    'Unable to track vendor details.',
    'Inactive vendor account. Kindly verify by clicking on the e-mail confirmation link.',
    'Invalid Vendor Account.',
    'We Can\'t fetch the details for the specified User. Kindly Re-verify.',
    'We\'re Unable to link the specified vendor account. Kindly Verify.',
    'Please Update a vendor account to proceed.',
    'We\'re unable to sign you out. Please try again later.',
    'Desired Results can\'t be fetched.',
    'Kindly update material name to proceed.',
    'Material Not found.',
    'Kindly Update Material Category in List.',
    'Kindly Update Specific Material Category.',
    'Unable to find material',
    'Invalid Material',
    'Failed to add material',
    'Failed to Verify Material',
    'Failed to Update Material',
    'Material is Unverified',
    'Material already exists',
    'Material is already verified',
    'Please update Material ID',
    'Unable to add preferred material',
    'Unable to find preferred material',
    'Invalid Preffered Material',
    'Preffered vendor does not exist',
    'Unable to add preferred vendor',
    'Unable to find preferred vendor',
    'Preferred vendor is invalid',
    'Kindly update Point of Contact',
    'Kindly update vendor type',
    'Invalid Vendor Type',
    'vendor category is missing',
    'Invalid vendor category',
    'Custom vendor is Missing',
    'Vendor already exists.',
    'Unable to find custom vendor for participant',
    'Kindly Update contact number',
    'unable to add custom vendor',
    'Unable to locate custom vendor id',
    'Unable to locate custom vendor ',
    'Invalid Custom Vendor',
    'Invalid Service ID',
    'Unable to update custom vendor',
    'Unable to allocate material to custom vendor.',
    'Unable to Validate Custom Vendor ID',
    'Unable to locate targetted Custom Vendor ID',
    'Unable to locate targetted Custom Vendor ',
    'Inactive targetted Custom Vendor',
    'Invalid targer custom vendor',
    'Custom vendor participant is absent. Kindly Verify.',
    'Unable to locate Cluster ID',
    'Kindly validate Cluster Name.',
    'Kindly provide cluster description.',
    'Unable to add cluster',
    'Unable to locate cluster',
    'Invalid Cluster',
    'Unable to update cluster',
    'Cluster Already exists',
    'Cluster Participant is missing',
    'cluster already exists ',
    'Please enter keywords to trace your company and identify products.',
    'Unable to locate Cluster Member ID',
    'Unable to add cluster member',
    'Unable to locate cluster member',
    'Invalid cluster member',
    'Member already exists on the cluster',
    'Kindly Update tender Material',
    'Kindly update tender title',
    'Kindly update tender type',
    'Invalid tender type',
    'Fixed tender not supported for procurement events.',
    'Fix Bid not supported for procurment events.',
    'Invalid quantity type',
    'Kindly update quantity type on form.',
    'kindly update quantity.',
    'Kindly update tender start date.',
    'kindly update tender expiry date.',
    'kindly update tender delivery date.',
    'Kindly update tender payment terms.',
    'Kindly update your freight details on the form',
    'Kindly validate pre-qualification questionaire.',
    'Kindly validate pre-qualification description.',
    'Oops! The word limit for pre-qualification criteria has been surpassed.',
    'Oops! The word limit for the description criteria has been surpassed.',
    'Kindly update Bid type',
    'Invalid bid type',
    'There seems to be a discrepancy in the bid threshold and amount.',
    'Bid amount invalid for auction.',
    'Quote is missing for RFQ.',
    'Quote should be higher than 500 for RFQ',
    'Invalid incremental bid. Kindly Verify bid increment threshold.',
    'Invalid Decremental bid. Kindly verify bid reduction threshold.',
    'Invalid Delivery date.',
    'Invalid expiry date.',
    'Unable to locate Tender Delivery address.',
    'Oops! The word limit for delivery address has been surpassed.',
    'Kindly verify pin code on form.',
    'Invalid Pin code. Kindly verify.',
    'Kindly enter delivery city',
    'Kindly verify delivery State',
    'Kindly verify country code.',
    'Tender conductor not added.',
    'Kindly update participants in tender.',
    'Bid threshold amount is mandatory for Auctions.',
    'Kindly enter fixed bid amount.',
    'Invalid fixed bid amount.',
    'Unable to add tender.',
    'Unable to locate tender ID',
    'Unable to locate tender attachment ID',
    'Unable to locate tender',
    'Invalid Tender ',
    'Quotations open in a few minutes.',
    'Non Applicable tender',
    'Unable to convert RFQ to auction',
    'Tender has already been converted to auction.',
    'Kindly verify the contractual date',
    'Kindly validate the "from" date',
    'Inavalid "from" date',
    '"Tender to" date is missing',
    'Invalid tender "to" date',
    'unable to delete tender',
    'Unable to extend tender',
    'Unable to locate tender category',
    'Kindly validate tender attachment',
    'Tender Participant ID is missing',
    'Conflicting Bids identified. Kindly Validate bid.',
    'Bid Amount is missing',
    'Unable to locate Bid ID',
    'Unable to locate bid',
    'Invalid Bid',
    'Rebid not permitted for fixed tender',
    'Unable to delete bid',
    'Bid not ready',
    'Unable to update counter offer',
    'Counter offer not found',
    'Unable to add offer',
    'Counter offer unavailable',
    'You have reached the threshold for negotiation limit.',
    'Invalid counter offer',
    'Unable to locate offer',
    'Unable to locate counter offer ID',
    'Offer ID is missing',
    'Unable to locate offer token number',
    'default address is missing',
    'Default address tag is missing',
    'Kindly validate default address',
    'Kindly validate default address pin code',
    'Kindly update default address city field',
    'kindly update  default address state field',
    'Kindly update default address country field',
    'Unable to locate default address  region',
    'Unable to add default address',
    'Unable to locate default address',
    'Unable to update default address',
    'Unable to delete default address',
    'Unable to locate notification ID',
    'Kindly validate notification Email ID',
    'Unable to locate notification status',
    'Unable to  locate vendor notification',
    'Invalid vendor notification',
    'Unable to delete notification',
    'Invalid Http Request method',
    'Unable to validate HttpRequest header',
    'Invalid httpRequest body',
    'Generic Failure logged',
    'Server operation failed',
    'Unable to locate token number',
    'Invalid token number',
    'Access ID is missing',
    'Device ID is missing',
    'Parent id is missing',
    'Service id missing',
    'Service not available',
    'Token number already verified',
    'Unable to generate report'
  ];

  public errorArray = [
    {
      'code': 6481125119601,
      'message': 'Targetted User not found'
    },
    {
      'code': 6481125119602,
      'message': 'Custom Vendor Unspecified: The Custom Vendor is not Created by you.'
    },
    {
      'code': 6481125119603,
      'message': 'Failed to add Nodal Contact.'
    },
    {
      'code': 6481125119604,
      'message': 'Failed to remove nodal contact.'
    },
    {
      'code': 6481125119605,
      'message': 'Email ID is missing'
    },
    {
      'code': 6481125119606,
      'message': 'Company Name is Missing'
    },
    {
      'code': 6481125119607,
      'message': 'Company Registration Number is Missing.'
    },
    {
      'code': 6481125119608,
      'message': 'Username is missing'
    },
    {
      'code': 6481125000009,
      'message': 'Tax number is missing'
    },
    {
      'code': 6481125119610,
      'message': 'Pan Card Number is Missing'
    },
    {
      'code': 6481125119611,
      'message': 'Kindly fill in the Nature of Business field'
    },
    {
      'code': 6481125119612,
      'message': 'Kindly specify specific business typr'
    },
    {
      'code': 6481125119613,
      'message': 'Kindly Update User ID'
    },
    {
      'code': 6481125119614,
      'message': 'We\'re Unable to add your User account.'
    },
    {
      'code': 6481125119615,
      'message': 'We\'re Unable to update your User account.'
    },
    {
      'code': 6481125119616,
      'message': 'This User name already exists, please try with an alternate username.'
    },
    {
      'code': 6481125119617,
      'message': 'We\'re unable to find the desired email address. Kindly Verify.'
    },
    {
      'code': 6481125119618,
      'message': 'The associated user account is inactive. Kindly verify by clicking on the e-mail confirmation link.'
    },
    {
      'code': 6481125119619,
      'message': 'Invalid User Account. Kindly re-verify.'
    },
    {
      'code': 6481125058401,
      'message': 'The Username or Password is missing.'
    },
    {
      'code': 6481125058402,
      'message': 'Oops! Login failed. Try again later.'
    },
    {
      'code': 6481125059801,
      'message': 'You don\'t seem to have a Bizdesk account. Create a Bizdesk account to proceed.'
    },
    {
      'code': 6481125059802,
      'message': 'Failed to sign-up'
    },
    {
      'code': 6481125059804,
      'message': 'The Email address for Master account is missing. Kindly Update or verify.'
    },
    {
      'code': 6481125059805,
      'message': 'The Email address for promoter account is missing. Kindly Update or verify.'
    },
    {
      'code': 6481125059806,
      'message': 'Promoter Email is missing.'
    },
    {
      'code': 6481125059807,
      'message': 'Invalid Promoter Account. Kindly Reverify or get in touch with our executives'
    },
    {
      'code': 6481125059808,
      'message': 'Specified User already exists.'
    },
    {
      'code': 6481125059809,
      'message': 'Invalid User Role!Kindly validate.'
    },
    {
      'code': 6481125148301,
      'message': 'Oops!Vendor not Found.'
    },
    {
      'code': 6481125148302,
      'message': 'Invalid Vendor Account'
    },
    {
      'code': 6481125148303,
      'message': 'Inactive Vendor account. Kindly verify by clicking on the e-mail confirmation link.'
    },
    {
      'code': 6481125148304,
      'message': 'This account is not linked with a buying facilitation'
    },
    {
      'code': 6481125148305,
      'message': 'This account is not linked with a sales facilitation'
    },
    {
      'code': 6481125148306,
      'message': 'Oops! We\'re unable to Update the vendor from the list'
    },
    {
      'code': 6481125148307,
      'message': 'Oops!Vendor not Found.'
    },
    {
      'code': 6481125148308,
      'message': 'Unable to track vendor details.'
    },
    {
      'code': 6481125148309,
      'message': 'Inactive vendor account. Kindly verify by clicking on the e-mail confirmation link.'
    },
    {
      'code': 6481125148310,
      'message': 'Invalid Vendor Account.'
    },
    {
      'code': 6481125148311,
      'message': 'We Can\'t fetch the details for the specified User. Kindly Re-verify.'
    },
    {
      'code': 6481125148312,
      'message': 'We\'re Unable to link the specified vendor account. Kindly Verify.'
    },
    {
      'code': 6481125148313,
      'message': 'Please Update a vendor account to proceed.'
    },
    {
      'code': 6481125071301,
      'message': 'We\'re unable to sign you out. Please try again later.'
    },
    {
      'code': 6481125202601,
      'message': 'Desired Results can\'t be fetched.'
    },
    {
      'code': 6481125081501,
      'message': 'Kindly update material name to proceed.'
    },
    {
      'code': 6481125081502,
      'message': 'Material Not found.'
    },
    {
      'code': 6481125081503,
      'message': 'Kindly Update Material Category in List.'
    },
    {
      'code': 6481125081504,
      'message': 'Kindly Update Specific Material Category.'
    },
    {
      'code': 6481125081506,
      'message': 'Unable to find material'
    },
    {
      'code': 6481125081507,
      'message': 'Invalid Material'
    },
    {
      'code': 6481125081508,
      'message': 'Failed to add material'
    },
    {
      'code': 6481125081509,
      'message': 'Failed to Verify Material'
    },
    {
      'code': 6481125081510,
      'message': 'Failed to Update Material'
    },
    {
      'code': 6481125081511,
      'message': 'Material is Unverified'
    },
    {
      'code': 6481125081512,
      'message': 'Material already exists'
    },
    {
      'code': 6481125081513,
      'message': 'Material is already verified'
    },
    {
      'code': 6481125180601,
      'message': 'Please update Material ID'
    },
    {
      'code': 6481125180602,
      'message': 'Unable to add preferred material'
    },
    {
      'code': 6481125180603,
      'message': 'Unable to find preferred material'
    },
    {
      'code': 6481125180604,
      'message': 'Invalid Preffered Material'
    },
    {
      'code': 6481125161301,
      'message': 'Preffered vendor does not exist'
    },
    {
      'code': 6481125161302,
      'message': 'Unable to add preferred vendor'
    },
    {
      'code': 6481125161303,
      'message': 'Unable to find preferred vendor'
    },
    {
      'code': 6481125161304,
      'message': 'Preferred vendor is invalid'
    },
    {
      'code': 6481125132101,
      'message': 'Kindly update Point of Contact'
    },
    {
      'code': 6481125132102,
      'message': 'Kindly update vendor type'
    },
    {
      'code': 6481125132103,
      'message': 'Invalid Vendor Type'
    },
    {
      'code': 6481125132104,
      'message': 'vendor category is missing'
    },
    {
      'code': 6481125132105,
      'message': 'Invalid vendor category'
    },
    {
      'code': 6481125132106,
      'message': 'Custom vendor is Missing'
    },
    {
      'code': 6481125132107,
      'message': 'Vendor already exists.'
    },
    {
      'code': 6481125132108,
      'message': 'Unable to find custom vendor for participant'
    },
    {
      'code': 6481125132109,
      'message': 'Kindly Update contact number'
    },
    {
      'code': 6481125132110,
      'message': 'unable to add custom vendor'
    },
    {
      'code': 6481125132111,
      'message': 'Unable to locate custom vendor id'
    },
    {
      'code': 6481125132112,
      'message': 'Unable to locate custom vendor '
    },
    {
      'code': 6481125132113,
      'message': 'Invalid Custom Vendor'
    },
    {
      'code': 6481125132114,
      'message': 'Invalid Service ID'
    },
    {
      'code': 6481125132115,
      'message': 'Unable to update custom vendor'
    },
    {
      'code': 6481125132116,
      'message': 'Unable to allocate material to custom vendor.'
    },
    {
      'code': 6481125132118,
      'message': 'Unable to Validate Custom Vendor ID'
    },
    {
      'code': 6481125132119,
      'message': 'Unable to locate targetted Custom Vendor ID'
    },
    {
      'code': 6481125132120,
      'message': 'Unable to locate targetted Custom Vendor '
    },
    {
      'code': 6481125132121,
      'message': 'Inactive targetted Custom Vendor'
    },
    {
      'code': 6481125132122,
      'message': 'Invalid targer custom vendor'
    },
    {
      'code': 6481125132123,
      'message': 'Custom vendor participant is absent. Kindly Verify.'
    },
    {
      'code': 6481125073801,
      'message': 'Unable to locate Cluster ID'
    },
    {
      'code': 6481125073802,
      'message': 'Kindly validate Cluster Name.'
    },
    {
      'code': 6481125073803,
      'message': 'Kindly provide cluster description.'
    },
    {
      'code': 6481125073804,
      'message': 'Unable to add cluster'
    },
    {
      'code': 6481125073805,
      'message': 'Unable to locate cluster'
    },
    {
      'code': 6481125073806,
      'message': 'Invalid Cluster'
    },
    {
      'code': 6481125073807,
      'message': 'Unable to update cluster'
    },
    {
      'code': 6481125073808,
      'message': 'Cluster Already exists'
    },
    {
      'code': 6481125073809,
      'message': 'Cluster Participant is missing'
    },
    {
      'code': 6481125073810,
      'message': 'cluster already exists '
    },
    {
      'code': 6481125073811,
      'message': 'Please enter keywords to trace your company and identify products.'
    },
    {
      'code': 6481125140201,
      'message': 'Unable to locate Cluster Member ID'
    },
    {
      'code': 6481125140202,
      'message': 'Unable to add cluster member'
    },
    {
      'code': 6481125140203,
      'message': 'Unable to locate cluster member'
    },
    {
      'code': 6481125140204,
      'message': 'Invalid cluster member'
    },
    {
      'code': 6481125140205,
      'message': 'Member already exists on the cluster'
    },
    {
      'code': 6481125061001,
      'message': 'Kindly Update tender Material'
    },
    {
      'code': 6481125061002,
      'message': 'Kindly update tender title'
    },
    {
      'code': 6481125061003,
      'message': 'Kindly update tender type'
    },
    {
      'code': 6481125061004,
      'message': 'Invalid tender type'
    },
    {
      'code': 6481125061005,
      'message': 'Fixed tender not supported for procurement events.'
    },
    {
      'code': 6481125061006,
      'message': 'Fix Bid not supported for procurment events.'
    },
    {
      'code': 6481125061007,
      'message': 'Invalid quantity type'
    },
    {
      'code': 6481125061008,
      'message': 'Kindly update quantity type on form.'
    },
    {
      'code': 6481125061009,
      'message': 'kindly update quantity.'
    },
    {
      'code': 6481125061010,
      'message': 'Kindly update tender start date.'
    },
    {
      'code': 6481125061011,
      'message': 'kindly update tender expiry date.'
    },
    {
      'code': 6481125061012,
      'message': 'kindly update tender delivery date.'
    },
    {
      'code': 6481125061013,
      'message': 'Kindly update tender payment terms.'
    },
    {
      'code': 6481125061014,
      'message': 'Kindly update your freight details on the form'
    },
    {
      'code': 6481125061015,
      'message': 'Kindly validate pre-qualification questionaire.'
    },
    {
      'code': 6481125061016,
      'message': 'Kindly validate pre-qualification description.'
    },
    {
      'code': 6481125061017,
      'message': 'Oops! The word limit for pre-qualification criteria has been surpassed.'
    },
    {
      'code': 6481125061018,
      'message': 'Oops! The word limit for the description criteria has been surpassed.'
    },
    {
      'code': 6481125061019,
      'message': 'Kindly update Bid type'
    },
    {
      'code': 6481125061020,
      'message': 'Invalid bid type'
    },
    {
      'code': 6481125061021,
      'message': 'There seems to be a discrepancy in the bid threshold and amount.'
    },
    {
      'code': 6481125061022,
      'message': 'Bid amount invalid for auction.'
    },
    {
      'code': 6481125061023,
      'message': 'Quote is missing for RFQ.'
    },
    {
      'code': 6481125000024,
      'message': 'Quote should be higher than 500 for RFQ'
    },
    {
      'code': 6481125061025,
      'message': 'Invalid incremental bid. Kindly Verify bid increment threshold.'
    },
    {
      'code': 6481125061026,
      'message': 'Invalid Decremental bid. Kindly verify bid reduction threshold.'
    },
    {
      'code': 6481125061027,
      'message': 'Invalid Delivery date.'
    },
    {
      'code': 6481125061028,
      'message': 'Invalid expiry date.'
    },
    {
      'code': 6481125061029,
      'message': 'Unable to locate Tender Delivery address.'
    },
    {
      'code': 6481125061030,
      'message': 'Oops! The word limit for delivery address has been surpassed.'
    },
    {
      'code': 6481125061031,
      'message': 'Kindly verify pin code on form.'
    },
    {
      'code': 6481125061032,
      'message': 'Invalid Pin code. Kindly verify.'
    },
    {
      'code': 6481125061033,
      'message': 'Kindly enter delivery city'
    },
    {
      'code': 6481125061034,
      'message': 'Kindly verify delivery State'
    },
    {
      'code': 6481125061035,
      'message': 'Kindly verify country code.'
    },
    {
      'code': 6481125061036,
      'message': 'Tender conductor not added.'
    },
    {
      'code': 6481125061037,
      'message': 'Kindly update participants in tender.'
    },
    {
      'code': 6481125061038,
      'message': 'Bid threshold amount is mandatory for Auctions.'
    },
    {
      'code': 6481125061040,
      'message': 'Kindly enter fixed bid amount.'
    },
    {
      'code': 6481125061041,
      'message': 'Invalid fixed bid amount.'
    },
    {
      'code': 6481125061042,
      'message': 'Unable to add tender.'
    },
    {
      'code': 6481125061043,
      'message': 'Unable to locate tender ID'
    },
    {
      'code': 6481125061044,
      'message': 'Unable to locate tender attachment ID'
    },
    {
      'code': 6481125061045,
      'message': 'Unable to locate tender'
    },
    {
      'code': 6481125061047,
      'message': 'Invalid Tender '
    },
    {
      'code': 6481125061048,
      'message': 'Quotations open in a few minutes.'
    },
    {
      'code': 6481125061052,
      'message': 'Non Applicable tender'
    },
    {
      'code': 6481125061053,
      'message': 'Unable to convert RFQ to auction'
    },
    {
      'code': 6481125061054,
      'message': 'Tender has already been converted to auction.'
    },
    {
      'code': 6481125061057,
      'message': 'Kindly verify the contractual date'
    },
    {
      'code': 6481125061058,
      'message': 'Kindly validate the "from" date'
    },
    {
      'code': 6481125061059,
      'message': 'Inavalid "from"date'
    },
    {
      'code': 6481125061060,
      'message': '"Tender to" date is missing'
    },
    {
      'code': 6481125061061,
      'message': 'Invalid tender "to" date'
    },
    {
      'code': 6481125061062,
      'message': 'unable to delete tender'
    },
    {
      'code': 6481125061062,
      'message': 'Unable to extend tender'
    },
    {
      'code': 6481125061063,
      'message': 'Unable to locate tender category'
    },
    {
      'code': 6481125061064,
      'message': 'Kindly validate tender attachment'
    },
    {
      'code': 6481125061065,
      'message': 'Tender Participant ID is missing'
    },
    {
      'code': 6481125027101,
      'message': 'Conflicting Bids identified. Kindly Validate bid.'
    },
    {
      'code': 6481125027102,
      'message': 'Bid Amount is missing'
    },
    {
      'code': 6481125027103,
      'message': 'Unable to locate Bid ID'
    },
    {
      'code': 6481125027104,
      'message': 'Unable to locate bid'
    },
    {
      'code': 6481125027105,
      'message': 'Invalid Bid'
    },
    {
      'code': 6481125027106,
      'message': 'Rebid not permitted for fixed tender'
    },
    {
      'code': 6481125027107,
      'message': 'Unable to delete bid'
    },
    {
      'code': 6481125027108,
      'message': 'Bid not ready'
    },
    {
      'code': 6481125126601,
      'message': 'Unable to update counter offer'
    },
    {
      'code': 6481125126602,
      'message': 'Counter offer not found'
    },
    {
      'code': 6481125126603,
      'message': 'Unable to add offer'
    },
    {
      'code': 6481125126604,
      'message': 'Counter offer unavailable'
    },
    {
      'code': 6481125126605,
      'message': 'You have reached the threshold for negotiation limit.'
    },
    {
      'code': 6481125126606,
      'message': 'Invalid counter offer'
    },
    {
      'code': 6481125126608,
      'message': 'Unable to locate offer'
    },
    {
      'code': 6481125126609,
      'message': 'Unable to locate counter offer ID'
    },
    {
      'code': 6481125126610,
      'message': 'Offer ID is missing'
    },
    {
      'code': 6481125126611,
      'message': 'Unable to locate offer token number'
    },
    {
      'code': 6481125148301,
      'message': 'default address is missing'
    },
    {
      'code': 6481125148302,
      'message': 'Default address tag is missing'
    },
    {
      'code': 6481125148303,
      'message': 'Kindly validate default address'
    },
    {
      'code': 6481125148304,
      'message': 'Kindly validate default address pin code'
    },
    {
      'code': 6481125148305,
      'message': 'Kindly update default address city field'
    },
    {
      'code': 6481125148306,
      'message': 'kindly update default address state field'
    },
    {
      'code': 6481125148308,
      'message': 'Kindly update default address country field'
    },
    {
      'code': 6481125148309,
      'message': 'Unable to locate default address region'
    },
    {
      'code': 6481125148310,
      'message': 'Unable to add default address'
    },
    {
      'code': 6481125148311,
      'message': 'Unable to locate default address'
    },
    {
      'code': 6481125148312,
      'message': 'Unable to update default address'
    },
    {
      'code': 6481125148313,
      'message': 'Unable to delete default address'
    },
    {
      'code': 6481125125501,
      'message': 'Unable to locate notification ID'
    },
    {
      'code': 6481125125502,
      'message': 'Kindly validate notification Email ID'
    },
    {
      'code': 6481125125503,
      'message': 'Unable to locate notification status'
    },
    {
      'code': 6481125125504,
      'message': 'Unable to locate vendor notification'
    },
    {
      'code': 6481125125505,
      'message': 'Invalid vendor notification'
    },
    {
      'code': 6481125125506,
      'message': 'Unable to delete notification'
    },
    {
      'code': 648112506171,
      'message': 'Invalid Http Request method'
    },
    {
      'code': 648112506172,
      'message': 'Unable to validate HttpRequest header'
    },
    {
      'code': 648112506173,
      'message': 'Invalid httpRequest body'
    },
    {
      'code': 648112506174,
      'message': 'Generic Failure logged'
    },
    {
      'code': 648112506175,
      'message': 'Server operation failed'
    },
    {
      'code': 648112506176,
      'message': 'Unable to locate token number'
    },
    {
      'code': 648112506177,
      'message': 'Invalid token number'
    },
    {
      'code': 648112506178,
      'message': 'Access ID is missing'
    },
    {
      'code': 648112506179,
      'message': 'Device ID is missing'
    },
    {
      'code': 6481125061710,
      'message': 'Parent id is missing'
    },
    {
      'code': 6481125061711,
      'message': 'Service id missing'
    },
    {
      'code': 6481125061712,
      'message': 'Service not available'
    },
    {
      'code': 6481125061713,
      'message': 'Token number already verified'
    },
    {
      'code': 6481125061714,
      'message': 'Unable to generate report'
    }
  ];


  constructor() {
  }

}
