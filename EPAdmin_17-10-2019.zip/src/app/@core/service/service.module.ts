import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';

import {HttpService} from './http.service';
import {UrlService} from './url.service';
import {SessionService} from './session.service';

import {PathService} from './path.service';
import {GuardService} from './guard.service';
import {ConstantService} from './constant.service';
import {WebsocketService} from './websocket.service';

const SERVICES = [
    HttpService,
    UrlService,
    SessionService,
    ConstantService,
    PathService,
    GuardService,
    WebsocketService
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [],
    providers: [
        ...SERVICES,
    ],
})
export class ServiceModule {
    static forRoot(): ModuleWithProviders {
        return <ModuleWithProviders> {
            ngModule: ServiceModule,
            providers: [
                ...SERVICES,
            ],
        };
    }
}
