import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class SessionService {

    public sessionResponse: any = {};
    private session: any = {
        'eazeProcureInPurchase': null,
        'emailAddress': null,
        'firstName': null,
        'firstVisit': null,
        'lastName': null,
        'parentId': null,
        'promoterId': null,
        'session': {
            'accessId': null,
            'deviceId': null,
            'isSignIn': null,
        },
        'userActive': null,
        'userEnabled': null,
        'userId': null,
        'userAccountId': null,
        'userName': null,
        'userPromoter': null,
        'userRole': null,
        'userStatus': null,
        'userType': null,
        'vendor': null,
    };
    private backUp: any = {
        'eazeProcureInPurchase': null,
        'emailAddress': null,
        'firstName': null,
        'firstVisit': null,
        'lastName': null,
        'parentId': null,
        'promoterId': null,
        'session': {
            'accessId': null,
            'deviceId': null,
            'isSignIn': null,
        },
        'userActive': null,
        'userEnabled': null,
        'userId': null,
        'userAccountId': null,
        'userName': null,
        'userPromoter': null,
        'userRole': null,
        'userStatus': null,
        'userType': null,
        'vendor': null,
    };

    constructor(private router: Router) {
        // console.info(sessionStorage.getItem('fingerPrint'));
    }

    public fingerPrint() {
        return sessionStorage.getItem('fingerPrint');
    }

    public isSignIn() {
        // return true;
        if (localStorage.getItem('isSignIn')) {
            return localStorage.getItem('isSignIn');
        } else {
            return false;
        }
    }

    public createSession(isSignIn, session) {
        this.sessionResponse = session;

        localStorage.setItem('isSignIn', isSignIn);
        localStorage.setItem('session', JSON.stringify(session.supportUser));
        localStorage.setItem('AccessTokenAdmin', session.session.accessToken);
        localStorage.setItem('SignInOn', session.signInOn);

        localStorage.setItem('firstName', session.supportUser.firstName);
        localStorage.setItem('lastName', session.supportUser.lastName);
        // console.info('jhghjg', session.signInOn);
        const isUserValid = JSON.parse(localStorage.getItem('session'));
        // if (isUserValid.userId != null) {
        if (isUserValid.userAccountId != null) {
            if (session.supportUser.userRole == 'DEV-SUPPORT') {
                // this.router.navigateByUrl('dashboard');
                this.router.navigateByUrl('support');
            } else if (this.session.userRole == 'OWNER') {
                this.router.navigateByUrl('dashboard');
            } else {
                this.router.navigateByUrl('dashboard');
            }
        } else {
            this.router.navigateByUrl('login');
        }

        /*if (isSignIn) {
          this.session = this.backUp;
          this.session = localStorage.getItem('session');
        }*/
    }

    public clearSession() {
        localStorage.setItem('isSignIn', undefined);
        localStorage.setItem('session', undefined);
        localStorage.setItem('AccessTokenAdmin', undefined);
        localStorage.setItem('SignInOn', undefined);
        localStorage.removeItem('isSignIn');
        localStorage.removeItem('session');
        localStorage.removeItem('AccessTokenAdmin');
        localStorage.removeItem('SignInOn');

        this.router.navigateByUrl('login');
    }

    public isFirstVisit() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            return this.session.firstVisit;
        } else {
            return false;
        }
    }

    public getCreated() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            return new Date(this.session.vendor.created);
        } else {
            return null;
        }
    }

    public getAccessId() {
        if (this.isSignIn()) {
            const AccessTokenAdmin = localStorage.getItem('AccessTokenAdmin');
            return AccessTokenAdmin;
        } else {
            return null;
        }
    }

    public getSignInOn() {
        if (this.isSignIn()) {
            const signInOn = localStorage.getItem('SignInOn');
            return new Date(signInOn);
        } else {
            return null;
        }
    }

    public getUserName() {
        // console.info(JSON.parse(localStorage.getItem('session')));
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));
            return this.session.userName;
        } else {
            return null;
        }
    }

    public getEmailAddress() {
        // console.info(JSON.parse(localStorage.getItem('session')));
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));
            return this.session.emailAddress;
        } else {
            return null;
        }
    }

    public getUserId() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            // return this.session.userId;
            return this.session.userAccountId;
        } else {
            return null;
        }
    }

    public getParentId() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            return this.session.parentId;
        } else {
            return null;
        }
    }

    public getPromoterId() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            return this.session.promoterId;
        } else {
            return null;
        }
    }

    public getUserRole() {
        if (this.isSignIn()) {
            this.session = this.backUp;
            this.session = JSON.parse(localStorage.getItem('session'));

            return this.session.userRole;
        } else {
            return null;
        }
    }

    public getFirstName() {
        if (this.isSignIn()) {
            // this.session = this.backUp;
            // this.session = JSON.parse(localStorage.getItem('session'));
            // localStorage.setItem('firstName', this.session.firstName);
            // return this.session.firstName;
            return localStorage.getItem('firstName');
        } else {
            return null;
        }
    }

    public setFirstName(firstName) {
        if (this.isSignIn()) {
            this.setCustomSession('firstName', firstName);
            return true;
        } else {
            return null;
        }
    }

    public getLastName() {
        if (this.isSignIn()) {
            // this.session = this.backUp;
            // this.session = JSON.parse(localStorage.getItem('session'));
            // return this.session.lastName;
            return localStorage.getItem('lastName');
        } else {
            return null;
        }
    }

    public setLastName(lastName) {
        if (this.isSignIn()) {
            this.setCustomSession('lastName', lastName);
            return true;
        } else {
            return null;
        }
    }

    public getMaterialId() {
        if (this.isSignIn()) {
            const MaterialId = JSON.parse(localStorage.getItem('MaterialId'));
            return MaterialId;
        } else {
            return null;
        }
    }

    public removeMaterialId() {
        localStorage.removeItem('MaterialId');
    }

    public getCustomVendorId() {
        if (this.isSignIn()) {
            const CustomVendorId = JSON.parse(localStorage.getItem('CustomVendorId'));
            return CustomVendorId;
        } else {
            return null;
        }
    }

    public removeCustomVendorId() {
        localStorage.removeItem('CustomVendorId');
    }

    public getClusterId() {
        if (this.isSignIn()) {
            const ClusterId = JSON.parse(localStorage.getItem('ClusterId'));
            return ClusterId;
        } else {
            return null;
        }
    }

    public removeClusterId() {
        localStorage.removeItem('ClusterId');
    }

    public getTenderId() {
        if (this.isSignIn()) {
            const TenderId = JSON.parse(localStorage.getItem('TenderId'));
            return TenderId;
        } else {
            return null;
        }
    }

    public removeTenderId() {
        localStorage.removeItem('TenderId');
    }

    public getBidId() {
        if (this.isSignIn()) {
            const BidId = JSON.parse(localStorage.getItem('BidId'));
            return BidId;
        } else {
            return null;
        }
    }

    public removeBidId() {
        localStorage.removeItem('BidId');
    }

    public getLineItemId() {
        if (this.isSignIn()) {
            const LineItemId = JSON.parse(localStorage.getItem('LineItemId'));
            return LineItemId;
        } else {
            return null;
        }
    }

    public setToken(data) {
        localStorage.setItem('Token', data);
        return true;
    }

    public getToken() {
        const token = localStorage.getItem('Token');
        console.info(localStorage.getItem('Token'));
        return token;
    }

    public setCustomSession(key, value, local?) {
        if (local === false) {
            sessionStorage.setItem(key, value);
        }
        if (local === true || local === undefined) {
            localStorage.setItem(key, value);
        }
    }

    public getCustomSession(key, local?) {
        if (local === false) {
            const localData = sessionStorage.getItem(key);
            return localData;
        }

        if (local === true || local === undefined) {
            const sessionData = localStorage.getItem(key);
            return sessionData;
        }
    }

    public removeCustomSession(key, local?) {
        if (local === false) {
            sessionStorage.removeItem(key);
        }

        if (local === true || local === undefined) {
            localStorage.removeItem(key);
        }
    }


    // delete
    public getVendorId() {
        return null;
    }
}
