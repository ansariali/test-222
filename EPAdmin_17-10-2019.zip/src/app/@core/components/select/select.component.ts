import {
    AfterViewInit,
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
} from '@angular/core';
import {NgModel} from '@angular/forms';

@Component({
    selector: 'app-select',
    templateUrl: './select.component.html',
    styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit, AfterViewInit, OnChanges {

    @Input() array: any = [];

    @Input() lsClass: any = '';
    @Input() label: any = '';
    @Input() identifyBy: any = '';
    @Input() displayBy: any = '';

    @Input() required: boolean = true;

    @Input() _value: any;
    @Input() value: any;
    @Output() valueChange = new EventEmitter();

    @ViewChild('selectComponent') selectComponent: NgModel;
    @Output() childControl = new EventEmitter<NgModel>();

    constructor() {
    }

    ngOnInit() {}

    ngAfterViewInit() {
        setTimeout(() => this.childControl.emit(this.selectComponent));
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['value']) {
            if (changes.value.currentValue != null) {
                this._value = changes.value.currentValue[this.identifyBy] || changes.value.currentValue[this.displayBy] || changes.value.currentValue;
            } else {
                this._value = null;
            }
        }
    }

    valueChanged(e, data) {
        if (this.identifyBy == '' && this.displayBy != '') {
            this.array.forEach((value, key) => {
                if (value[this.displayBy] == data) {
                    this.valueChange.emit(value);
                }
            })
        } else {
            this.valueChange.emit(data);
        }
    }
}
