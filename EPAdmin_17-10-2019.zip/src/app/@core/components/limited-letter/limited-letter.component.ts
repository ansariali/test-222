import {Component, Input, OnInit} from '@angular/core';

@Component({
    selector: 'app-limited-letter',
    templateUrl: './limited-letter.component.html',
    styleUrls: ['./limited-letter.component.scss']
})
export class LimitedLetterComponent implements OnInit {

    @Input() public lsClass: any = '';
    @Input() public value: any = '';
    @Input() public limit: any = 10;

    constructor() {
    }

    ngOnInit() {
    }

}
