import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LimitedLetterComponent } from './limited-letter.component';

describe('LimitedLetterComponent', () => {
  let component: LimitedLetterComponent;
  let fixture: ComponentFixture<LimitedLetterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LimitedLetterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LimitedLetterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
