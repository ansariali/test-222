import {
    AfterViewInit,
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
} from '@angular/core';
import {NgModel} from '@angular/forms';

@Component({
    selector: 'ls-radio-button',
    templateUrl: './radio-button.component.html',
    styleUrls: ['./radio-button.component.scss']
})
export class RadioButtonComponent implements OnInit, AfterViewInit, OnChanges {

    @Input() array: any = [];
    @Input() condition: any = {
        'index': null,
        'ngIf': true
    };

    @Input() lsClass: any = 'p-t-15';
    @Input() label: any = '';
    @Input() identifyBy: any = '';
    @Input() displayBy: any = '';
    @Input() ngClass: any = '';

    @Input() required: boolean = true;

    @Input() _value: any;
    @Input() value: any;
    @Output() valueChange = new EventEmitter();

    @ViewChild('radioButton') radioButton: NgModel;
    @Output() childControl = new EventEmitter<NgModel>();

    constructor() {
    }

    ngOnInit() {
    }

    ngAfterViewInit() {
        // if (this.value != null) {
        //     this._value = this.value[this.displayBy] || this.value;
        // }

        // emitting the control to the parent to be picked up there and added to the main form
        setTimeout(() => {
            this.childControl.emit(this.radioButton);
            // console.info('radioo ' ,  this.radioButton);
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['value']) {
            if (changes.value.currentValue != null) {
                this._value = changes.value.currentValue[this.identifyBy] || changes.value.currentValue[this.displayBy] || changes.value.currentValue;
            }
        }
    }

    valueChanged(e, data) {
        this.valueChange.emit(data[this.identifyBy] || data);
    }
}


