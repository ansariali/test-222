import {
    AfterViewInit,
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnChanges, OnDestroy,
    OnInit,
    Output,
    SimpleChanges,
    ViewChild
} from '@angular/core';
import {DaterangePickerComponent} from 'ng2-daterangepicker';
import {isNull, isNullOrUndefined, isUndefined} from 'util';
import {NgModel} from '@angular/forms';

@Component({
    selector: 'ls-date-range-picker',
    templateUrl: './date-range-picker.component.html',
    styleUrls: ['./date-range-picker.component.scss']
})
export class DateRangePickerComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {

    @Input() ngAfterViewInitStatus: boolean = false;

    @Input() single: boolean = false;
    @Input() _options: any;

    @Input() lsClass: any = '';
    @Input() label: any = '';
    @Input() required: boolean = true;
    @Input() disabled: boolean = false;

    @Input() minDate: any;
    @Input() maxDate: any;

    @Input() invalid: boolean = false;
    @Output() invalidChange = new EventEmitter();

    @Input() starting: any;
    @Output() startingChange = new EventEmitter();

    @Input() ending: any;
    @Output() endingChange = new EventEmitter();

    @Input() timeFrame: any;
    @Output() timeFrameChange = new EventEmitter();

    @ViewChild('datePickerInput') public _datePickerInput: ElementRef;
    @ViewChild(DaterangePickerComponent) public picker: DaterangePickerComponent;

    @ViewChild('datePickerInput') datePickerInput: NgModel;
    @Output() childControl = new EventEmitter<NgModel>();

    public singleDate: any = {
        // startDate: null,
        // endDate: null,
        // minDate: new Date(),
        applyClass: 'btn-outline-success',
        cancelClass: 'btn-outline-success',
        singleDatePicker: true,
        timePicker: true,
        showDropdowns: true,
        timePickerIncrement: 1,
        locale: {
            format: 'DD/MM/YYYY h:mm A'
        }
    };

    public multipleDate: any = {
        minDate: new Date(),
        applyClass: 'btn-outline-success',
        cancelClass: 'btn-outline-success',
        timePicker: true,
        showDropdowns: true,
        timePickerIncrement: 1,
        locale: {
            format: 'DD/MM/YYYY h:mm A'
        }
    };

    constructor() {
    }

    ngOnInit() {
        if (this.single) {
            this._options = this.singleDate;
        } else {
            this._options = this.multipleDate;
        }
    }

    ngAfterViewInit(): void {
        setTimeout(() => {
            // this.childControl.emit(this.datePickerInput);
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        setTimeout(() => {
            if (changes['minDate']) {
                if (!isUndefined(this.minDate)) {
                    this._options['minDate'] = new Date(changes.minDate.currentValue);
                }
            }

            if (changes['maxDate']) {
                if (isNull(this.maxDate)) {
                    this._options['maxDate'] = new Date();
                } else if (!isUndefined(this.maxDate)) {
                    this._options['maxDate'] = new Date(this.maxDate);
                }
            }

            if (changes['starting']) {
                if (!isNullOrUndefined(this.starting)) {
                    this.picker.datePicker.setStartDate(new Date(this.starting));
                } else {
                    this.picker.datePicker.setStartDate(new Date(this.picker.datePicker.minDate));

                    if (this.single) {
                        this.picker.datePicker.setEndDate(new Date(this.picker.options.minDate));
                    }
                }

                this.startingChange.emit(Date.parse(this.picker.datePicker.startDate));

                this.getTimeFrame();
            }

            if (changes['ending']) {
                if (!this.single) {

                    if (!isNullOrUndefined(this.ending)) {
                        this.picker.datePicker.setEndDate(new Date(this.ending));
                    } else {
                        this.picker.datePicker.setEndDate(new Date(this.picker.datePicker.maxDate));
                    }

                    // this.ending = Date.parse(this.picker.datePicker.endDate);
                    this.endingChange.emit(Date.parse(this.picker.datePicker.endDate));
                }

                let endTime;
                if (this.timeFrame != undefined) {
                    if (!isNullOrUndefined(this.ending)) {
                        endTime = new Date(this.ending);
                    } else {
                        endTime = new Date(this.picker.datePicker.maxDate);
                    }
                    this.endingChange.emit(Date.parse(endTime));
                }

                this.getTimeFrame();
            }
        });
    }

    ngOnDestroy(): void {
    }

    selectedEvent(value) {
        this.starting = value.start;
        this.startingChange.emit(this.starting);

        if (!this.single) {
            this.ending = value.end;
            this.endingChange.emit(this.ending);
        }
    }

    getTimeFrame() {
        const timeDiff = Math.abs(this.starting - this.ending);

        const msPerSecond = 1000;
        const msPerMinute = msPerSecond * 60;
        const msPerHour = msPerMinute * 60;
        const msPerDay = msPerHour * 24;
        const msPerWeek = msPerDay * 7;
        const msPerMonth = msPerWeek * 5;
        const msPerYear = msPerMonth * 12;

        const second = Math.trunc((timeDiff / msPerSecond) % 60);
        const minute = Math.trunc((timeDiff / msPerMinute) % 60);
        const hour = Math.trunc((timeDiff / msPerHour) % 24);
        const day = Math.trunc((timeDiff / msPerDay) % 7);
        const week = Math.trunc((timeDiff / msPerWeek) % 5);
        const month = Math.trunc((timeDiff / msPerMonth) % 12);
        const year = Math.trunc((timeDiff / msPerYear) % 12);

        this.timeFrame = year + '𝔂 • ' + month + '𝓶 • ' + week + '𝔀 • ' + day + '𝓭 • ' + hour + '𝓱 • ' + minute + '𝓶 • ' + second + '𝓼';
        this.timeFrameChange.emit(this.timeFrame);
    }

    getLocalTime(value?, longDate?) {
        let time;
        if (value == null || value == undefined) {
            time = new Date();
        } else {
            time = new Date(value);
            // const offset = new Date().getTimezoneOffset();
            // const minutes = time.getMinutes();
            // time.setMinutes(minutes - offset);
        }

        if (longDate) {
            return time.getTime();
        } else {
            // 'numeric' or '2-digit'
            return new Date(time).toLocaleString('en-IN', {
                day: 'numeric',
                month: 'numeric',
                year: 'numeric',
                hour: 'numeric',
                minute: 'numeric',
                hour12: true
            });
        }
    }

}
