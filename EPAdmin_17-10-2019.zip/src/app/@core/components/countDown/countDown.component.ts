import {
    AfterViewInit, Component, DoCheck, ElementRef, Input, OnChanges, OnInit, SimpleChange,
    ViewChild
} from '@angular/core';
import {HttpService} from '../../service/http.service';
import {UrlService} from '../../service/url.service';

@Component({
    selector: 'ls-count-down',
    styleUrls: ['./countDown.scss'],
    template: `
        <!--{{days}} | {{hours}} | {{minutes}} | {{seconds}}-->
        <span class="style labelformat" style="border-color: rgb(41, 156, 39);"
              *ngIf="(days < 0 && hours < 0 && minutes < 0 && seconds < 0)">
            <h6 class="text-center-center p-t-5">Please wait...&nbsp;<b *ngIf="refreshSeconds > 0">{{refreshSeconds}} sec</b></h6>
            <small *ngIf="refreshSeconds < 0" class="text-center-center p-b-5">
                Failed to get Information, Click&nbsp;
                <a class="font-color-blue" (click)="http.refresh()"> here</a>
            </small>
        </span>
        <span class="style labelformat" style="border-color: rgb(41, 156, 39);"
              *ngIf="!(days < 0 && hours < 0 && minutes < 0 &&  seconds < 0)">
            <span class="timerDisplay label4">
                <span class="displaySection">
                    <span class="numberDisplay" *ngIf="days >= 0">{{days || '00'}}</span>
                    <span class="numberDisplay" *ngIf="days < 0 || days == null"> <i
                            class="fa fa-circle-o-notch fa-spin"></i></span>
                    <span class="periodDisplay">Days</span>
                </span>
                <span class="displaySection">
                    <span class="numberDisplay" *ngIf="hours >= 0">{{hours || '00'}}</span>
                    <span class="numberDisplay" *ngIf="hours < 0 || hours == null"> <i
                            class="fa fa-circle-o-notch fa-spin"></i></span>
                    <span class="periodDisplay">Hours</span>
                </span>
                <span class="displaySection">
                    <span class="numberDisplay" *ngIf="minutes >= 0">{{minutes || '00'}}</span>
                    <span class="numberDisplay" *ngIf="minutes < 0 || minutes == null"> <i
                            class="fa fa-circle-o-notch fa-spin"></i></span>
                    <span class="periodDisplay">Minutes</span>
                </span>
                <span class="displaySection">
                    <span class="numberDisplay" *ngIf="seconds >= 0">{{seconds || '00'}}</span>
                    <span class="numberDisplay" *ngIf="seconds < 0 || seconds == null"> <i
                            class="fa fa-circle-o-notch fa-spin"></i></span>
                    <span class="periodDisplay">Seconds</span>
                </span>
            </span>
        </span>
    `,
})
export class CountDownComponent implements OnInit, AfterViewInit, DoCheck, OnChanges {

    // https://codepen.io/sander/pen/yhcof

    @Input() startTime: any;
    @Input() endTime: any;
    @Input() refresh: any;
    @Input() t: any;
    @Input() diff: any;

    @ViewChild('lsCountDown') _selector: ElementRef;

    @Input() days: any;
    @Input() hours: any;
    @Input() minutes: any;
    @Input() seconds: any;
    @Input() refreshSeconds: any;
    @Input() status: any = true;
    @Input() dumpStatus: any = true;

    constructor(public http: HttpService, public url: UrlService) {
    }

    ngOnInit() {
    }

    ngAfterViewInit() {
    }

    ngDoCheck() {
        /*if (this.startTime != undefined && this.endTime != undefined) {
            // console.info('this.startTime: ', this.startTime);

            // console.info('this.dumpStatus: ', this.refresh);
            // console.info('this.dumpEnd: ', this.dumpEnd);
            // console.info('this.endTime: ', this.endTime);

            if (this.refresh || this.dumpEnd != this.endTime) {
                console.info('kya rai gayo a ????: ', this.endTime);
                this.dumpEnd = this.endTime;

                this.status = true;
                this.refresh = false;
            }

            if (this.status) {
                console.info('Before timer');
                this.timer();
                this.status = false;
            }
        }*/
    }

    ngOnChanges(changes) {
        this.timer();
    }

    timer() {
        this.http.get(this.url.urls.genericCtrl.currentTime, ({
            'Accept': 'application/json',
        })).subscribe(res => {
            let t1 = res.currentTime;
            let t2 = new Date().getTime();
            this.diff = t2 - t1;

            this.t = new Date(res.currentTime);

            let x = setInterval(() => {
                let countDownDate = new Date(this.endTime).getTime();
                let now;
                if (this.startTime == 0) {
                    now = new Date().getTime();
                } else {
                    now = new Date(this.startTime).getTime();
                }
                let gap = countDownDate - now;
                let distance = gap + this.diff;

                this.days = Math.floor(distance / (1000 * 60 * 60 * 24));
                this.hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                this.minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                this.seconds = Math.floor((distance % (1000 * 60)) / 1000);

                if (distance < 0) {
                    this.days = -1;
                    this.hours = -1;
                    this.minutes = -1;
                    this.seconds = -1;
                    clearInterval(x);
                    this.refreshTimer();
                }

            }, 1000);
        });
    }

    refreshTimer() {
        let t1 = new Date();
        let nextSixtyMin = new Date().setMinutes(t1.getMinutes() + 1);
        if (this.days < 0 && this.hours < 0 && this.minutes < 0 && this.seconds < 0) {
            let y = setInterval(() => {
                let now = new Date().getTime();
                let distance = nextSixtyMin - now;
                this.refreshSeconds = Math.floor((distance % (1000 * 60)) / 1000);
                if (distance < 0) {
                    this.refreshSeconds = -1;
                    // this.http.refresh();
                    clearInterval(y);
                }
            }, 1000);
        }
    }
}
