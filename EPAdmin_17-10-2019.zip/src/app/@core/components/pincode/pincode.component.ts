import {AfterViewInit, Component, ElementRef, Input, OnInit, Renderer2, ViewChild} from '@angular/core';

@Component({
    selector: 'app-pincode',
    templateUrl: './pincode.component.html',
    styleUrls: ['./pincode.component.scss']
})
export class PincodeComponent implements OnInit, AfterViewInit {

    @Input() required: boolean = true;

    @ViewChild('geoautocomplete') public geoAutocomplete: ElementRef;

    public userSettings: any = {
        geoCountryRestriction: ['in'],
        showCurrentLocation: false,
        showSearchButton: false,
        recentStorageName: 'componentData',
        noOfRecentSearchSave: 8,
    };

    constructor(public render: Renderer2) {
    }

    ngOnInit() {
        // this.geoAutocomplete.nativeElement
    }

    ngAfterViewInit(): void {
        console.info('kahssdkjhakhdskj : ', this.geoAutocomplete);
        console.info('kahssdkjhakhdskj : ', this.geoAutocomplete.nativeElement);
    }

    autoCompleteCallback(data: any): any {
        /*this.subPart.deliveryAddresses[0].pinCode = null;
        this.subPart.deliveryAddresses[0].city = null;
        this.subPart.deliveryAddresses[0].state = null;
        this.subPart.deliveryAddresses[0].country = null;
        this.subPart.deliveryAddresses[0].region = null;
        this.subPart.deliveryAddresses[0].longitude = null;
        this.subPart.deliveryAddresses[0].latitude = null;

        this.componentData = JSON.stringify(data);
        this.subPart.deliveryAddresses[0].pinCode = data.address_components[0].long_name;
        this.subPart.deliveryAddresses[0].city = data.address_components[1].long_name;
        this.subPart.deliveryAddresses[0].state = data.address_components[3].long_name;
        this.subPart.deliveryAddresses[0].country = data.address_components[4].long_name;
        this.subPart.deliveryAddresses[0].region = data.address_components[4].short_name + '-' + data.address_components[3].short_name;
        this.subPart.deliveryAddresses[0].longitude = data.geometry.location.lng;
        this.subPart.deliveryAddresses[0].latitude = data.geometry.location.lat;*/

        // console.info(this.info.deliveryAddresses[0]);
    }
}
