import {Component, Input, OnDestroy, OnInit} from '@angular/core';

@Component({
    selector: 'ls-time-ago',
    templateUrl: './time-ago.component.html',
    styleUrls: ['./time-ago.component.scss']
})
export class TimeAgoComponent implements OnInit, OnDestroy {

    @Input() time: any;
    @Input() outputString: any;
    public interval: any;

    constructor() {
    }

    ngOnInit() {
        const publishedAt = new Date(this.time);
        const offset = publishedAt.getTimezoneOffset();
        const minutes = publishedAt.getMinutes();
        publishedAt.setMinutes(minutes - offset);

        this.timer(publishedAt);

        this.interval = setInterval(() => {
            this.timer(publishedAt);
        }, 60000);
    }

    ngOnDestroy(): void {
        clearInterval(this.interval);
    }

    timer(publishedAt) {
        let current = new Date().getTime();

        let msPerMinute = 60 * 1000;
        let msPerHour = msPerMinute * 60;
        let msPerDay = msPerHour * 24;
        let msPerMonth = msPerDay * 30;
        let msPerYear = msPerDay * 365;

        let elapsed = current - publishedAt.getTime();

        if (elapsed < msPerMinute) {
            // this.outputString = Math.round(elapsed / 1000) + ' seconds ago';
            this.outputString = 'a few seconds ago';
            return this.outputString;
        }
        else if (elapsed < msPerHour) {
            this.outputString = Math.round(elapsed / msPerMinute) + ' minutes ago';
            return this.outputString;
        }
        else if (elapsed < msPerDay) {
            this.outputString = Math.round(elapsed / msPerHour) + ' hours ago';
            return this.outputString;
        }
        else if (elapsed < msPerMonth) {
            this.outputString = Math.round(elapsed / msPerDay) + ' days ago';
            return this.outputString;
        }
        else if (elapsed < msPerYear) {
            this.outputString = Math.round(elapsed / msPerMonth) + ' months ago';
            return this.outputString;
        }
        else {
            // this.outputString = Math.round(elapsed / msPerYear) + ' years ago';
            this.outputString = 'a while Ago';
            return this.outputString;
        }
    }
}
