import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CountDownComponent} from './countDown/countDown.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {Ng4GeoautocompleteModule} from 'ng4-geoautocomplete';
import {NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {DirectiveModule} from '../directives/directive.module';
import {ServiceModule} from '../service/service.module';
import {TableComponent} from './table/table.component';
import {DateRangePickerComponent} from './date-range-picker/date-range-picker.component';
import {RequiredFieldComponent} from './required-field/required-field.component';
import {NoDataComponent} from './no-data/no-data.component';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {TabComponent} from './tab/tab.component';
import {RadioButtonComponent} from './radio-button/radio-button.component';
import {PincodeComponent} from './pincode/pincode.component';
import {SelectComponent} from './select/select.component';
import {TimeAgoComponent} from './time-ago/time-ago.component';
import {PipeModule} from '../pipe/pipe.module';
import {RouterModule} from '@angular/router';
import { LimitedLetterComponent } from './limited-letter/limited-letter.component';
import {Daterangepicker} from 'ng2-daterangepicker';

const COMPONENTS = [
    CountDownComponent,
    DateRangePickerComponent,
    TableComponent,
    RequiredFieldComponent,
    NoDataComponent,
    TabComponent,
    RadioButtonComponent,
    PincodeComponent,
    SelectComponent,
    TimeAgoComponent,
    LimitedLetterComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule,
        ReactiveFormsModule,
        ServiceModule,
        Ng4GeoautocompleteModule.forRoot(),
        NgbTooltipModule,
        DirectiveModule,
        Ng2PaginationModule,
        Ng2SearchPipeModule,
        Ng2OrderModule,
        PipeModule,
        Daterangepicker,
    ],
    declarations: [
        ...COMPONENTS,
    ],
    exports: [
        ...COMPONENTS
    ],
    entryComponents: [
    ],
})
export class CommonComponentModule {
}
