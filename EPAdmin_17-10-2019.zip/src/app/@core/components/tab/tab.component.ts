import {
    Component, Input, OnInit, ContentChild, TemplateRef, Output,
    EventEmitter, OnChanges, SimpleChanges
} from '@angular/core';

@Component({
    selector: 'app-tab',
    templateUrl: './tab.component.html',
    styleUrls: ['./tab.component.scss']
})
export class TabComponent implements OnInit, OnChanges {

    @Input() header: any = [];

    @Input() tabNo: any = 0;
    @Output() tabNoChange = new EventEmitter();

    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

    constructor() {
    }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['tabNo']) {
            // console.info('Changes: ', changes['tabNo']);
            this.tabNo = changes['tabNo'].currentValue;
            this.tabNoChange.emit(this.tabNo);
        }
    }

    valueChanged(e, tabNo) {
        this.tabNoChange.emit(this.tabNo);
    }
}
