import {Component, Input, OnInit} from '@angular/core';

@Component({
    selector: 'ls-no-data',
    templateUrl: './no-data.component.html',
    styleUrls: ['./no-data.component.scss']
})
export class NoDataComponent implements OnInit {

    @Input() public class: string;
    @Input() public message: string = 'Data';
    @Input() public length: number = 0;
    @Input() public display: boolean = false;

    constructor() {
    }

    ngOnInit() {
    }

}
