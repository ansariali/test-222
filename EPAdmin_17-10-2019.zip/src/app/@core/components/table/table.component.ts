import {Component, ContentChild, Input, OnInit, TemplateRef} from '@angular/core';

@Component({
    selector: 'ls-table',
    templateUrl: './table.component.html',
    styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {

    @Input() title: any = null;
    @Input() data: any;
    @Input() noDataMessage: any = 'Data';
    @Input() headers: any = [];
    // @Input() filter: any = '';
    // @Input() record: any = 10;
    @Input() id: any = 1;

    // @ContentChild(TemplateRef) templateRef: TemplateRef;
    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

    public _tableSetting: any = {
        filter: '',
        record: 10,
    };
    _p: number = 1;

    constructor() {
    }

    ngOnInit() {
    }

}
