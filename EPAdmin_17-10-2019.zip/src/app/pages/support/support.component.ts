import {Component, OnInit} from '@angular/core';

import {SessionService} from '../../@core/service/session.service';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {PathService} from '../../@core/service/path.service';

declare let $: any;

@Component({
    selector: 'app-support',
    templateUrl: './support.component.html',
    styleUrls: ['./support.component.scss']
})
export class SupportComponent implements OnInit {

    public userToken: any;
    public justificationString: any = '';
    public currentStatus: any;
    public requests: any;

    public info: any = {
        firstName: null,
        lastName: null,
        userName: null,
        emailAddress: null,
        contactNumber: null,
    };

    public supportToken: any;

    public tableSetting: any = {
        totalRecord: 5,
        filter: '',
    };
    public tableFilter: any;
    p: number = 1;

    constructor(private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
    }

    ngOnInit() {
        this.fetchRequests();
    }

    fetchRequests() {
        this.http.get(this.url.urls.supportCtrl.fetchAllRequest
                .replace('{userId}', this.session.getUserId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.requests = res.requests;
                    // console.info('fetchInvitedUser Done! ', this.response);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }

    verify() {

        this.http.post(this.url.urls.supportCtrl.verifyHelpToken
                .replace('{userId}', this.session.getUserId())
                .replace('{helpToken}', this.userToken)
            , null, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    if (res.status) {
                        this.info = res.feed.user;
                        this.supportToken = res.feed.supportRequest.supportToken;

                        $('#viewUser').modal();
                    } else {
                        this.http.customErrorToast(res.message);
                    }
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );

    }

    verified() {
        this.userToken = null;
        let accessIdWithUserId = this.session.getUserId() + ':' + this.session.getAccessId();
        console.info('accessIdWithUserId: ', accessIdWithUserId);

        // window.open(location.origin + '/#/guest/welcome/admin/user-access/{token}'.replace('{token}', '123123123123123'), '_target');

        window.open(location.origin + '/1125/#/guest/welcome/{accessIdWithUserId}/user-access/{token}'
            .replace('{accessIdWithUserId}', accessIdWithUserId)
            .replace('{token}', this.supportToken), '_target');

        // window.open('http://192.168.0.31:5000/#/guest/welcome/{accessIdWithUserId}/user-access/{token}'
        //     .replace('{accessIdWithUserId}', accessIdWithUserId)
        //     .replace('{token}', this.supportToken), '_target');

    }

    beforeChangeStatus(status, supportToken) {
        // console.info('justificationString: ', status);
        // console.info('beforeChangeStatus: ', status);
        this.currentStatus = status;
        this.supportToken = supportToken;
        $('#justificationModal').modal();
    }

    changeStatus() {

        this.http.put(this.url.urls.supportCtrl.changeRequestStatus
                .replace('{userId}', this.session.getUserId())
                .replace('{description}', this.justificationString)
                .replace('{status}', this.currentStatus)
            , null, ({
                'SUPPORT-TOKEN': this.supportToken,
            }))
            .subscribe(
                res => {
                    this.http.successToast(null, 'User status successfully changed');
                    $('#justificationModal').modal('hide');
                    this.fetchRequests()
                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }

    togglePin(idx, status, supportToken) {
        // console.info('togglePin: ', status);
        console.info('supportToken: ', supportToken);

        if (status) {
            this.http.put(this.url.urls.supportCtrl.pinRequest
                    .replace('{userId}', this.session.getUserId())
                , null, ({
                    'SUPPORT-TOKEN': supportToken,
                }))
                .subscribe(
                    res => {
                        this.http.successToast(null, 'Request No.' + idx + ' has been successfully pinned');
                        this.fetchRequests()
                    },
                    err => {
                        this.http.errorToast(err);
                    },
                );


        } else {
            this.http.put(this.url.urls.supportCtrl.unPinRequest
                    .replace('{userId}', this.session.getUserId())
                , null, ({
                    'SUPPORT-TOKEN': supportToken,
                }))
                .subscribe(
                    res => {
                        this.http.successToast(null, 'Request No.' + idx + ' has been successfully unpinned');
                        this.fetchRequests()
                    },
                    err => {
                        this.http.errorToast(err);
                    },
                );
        }

    }
}
