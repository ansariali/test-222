import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {routing} from './support.routing';
import {SupportComponent} from './support.component';
import {ServiceModule} from '../../@core/service/service.module';
import {NgaModule} from '../../theme/nga.module';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {PipeModule} from '../../@core/pipe/pipe.module';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        routing,
        NgaModule,

        ServiceModule,
        DirectiveModule,
        PipeModule,
        Ng2PaginationModule,
        Ng2OrderModule,
        Ng2SearchPipeModule,
    ],
    declarations: [
        SupportComponent
    ]
})
export class SupportModule {
}
