import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {CommonModule} from '@angular/common';
import {ServiceModule} from '../../@core/service/service.module';
import {ChartsModule} from 'ng2-charts';
import {TooltipModule} from 'ng2-tooltip';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {PipeModule} from '../../@core/pipe/pipe.module';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {CommonComponentModule} from '../../@core/components/commonComponent.module';
import {DownloadReportRoutingModule} from './download-report-routing.module';
import {DownloadReportComponent} from './download-report.component';


@NgModule({
    imports: [
        CommonModule,
        DownloadReportRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        ServiceModule,
        ChartsModule,
        TooltipModule,
        DirectiveModule,
        PipeModule,
        Ng2PaginationModule,
        Ng2SearchPipeModule,
        Ng2OrderModule,
        NgbTooltipModule,
        CommonComponentModule
    ],
    declarations: [DownloadReportComponent],
    providers: [],
})
export class DownloadReportModule {
}
