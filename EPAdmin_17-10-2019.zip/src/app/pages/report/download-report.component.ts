import {Component, OnInit} from '@angular/core';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {Http, ResponseContentType} from '@angular/http';


declare let $: any;

@Component({
    selector: 'app-download-report',
    templateUrl: './download-report.component.html',
})

export class DownloadReportComponent implements OnInit {
    public btnToggle: any = false;
    public created: any = null;
    public timeFrameString: any = 'Waiting for dates...';
    public downloadType: boolean = false;
    public vendor = [];
    public companyId = null;

    public date: any = {
        test: null,
        today: new Date(),
        timeFrame: false,
        timeFrameString: 'Waiting for dates...',
        tenderDeliveryDate: null,
        tenderExpiryDate: null,
        tenderFromDate: null,
        tenderToDate: null,
        tenderStartDate: null,
        tenderEndDate: null,
        toggle: 2343,
    };

    public info: any = {
        tenderFromDate: null,
        tenderToDate: null,
        toggle: 2343
    };

    constructor(public http: HttpService, public url: UrlService, private http1: Http,
                public session: SessionService, public path: PathService) {
        this.created = new Date(1483209000000);
    }

    ngOnInit() {
        this.fetchVendor();
    }

    downloadReport() {
        let url = this.http.getUrl(this.url.urls.tenderCtrl.downloadReport
            .replace('{vendorId}', this.companyId)
            .replace('{adminUserId}', this.session.getUserId())
            .replace('{fromDate}', this.info.tenderFromDate)
            .replace('{toDate}', this.info.tenderToDate)
            .replace('{spreadType}', 2251)
            .replace('{downloadType}', this.downloadType)
            .replace('{accessToken}', this.session.getAccessId()));

        window.open(url, '_blank');

        /* this.http.get(this.url.urls.tenderCtrl.downloadReport
             .replace('{vendorId}', this.companyId)
             .replace('{adminUserId}', this.session.getUserId())
             .replace('{fromDate}', this.info.tenderFromDate)
             .replace('{toDate}', this.info.tenderToDate)
             .replace('{spreadType}', 2251)
             .replace('{downloadType}', this.downloadType), null)
             .subscribe(
                 res => {
                     this.btnToggle = false;
                     this.http.sLoaderSwitch(false);
                     // console.info('Tender Downloaded ', res);

                     let url = this.http.getUrl(this.url.urls.tenderCtrl.downloadReport.replace('{vendorId}', this.companyId).replace('{adminUserId}', this.session.getUserId())
                         .replace('{fromDate}', this.info.tenderFromDate).replace('{toDate}', this.info.tenderToDate).replace('{spreadType}',2251).replace('{downloadType}', this.downloadType));

                     window.open(url, '_blank');
                 },
                 err => {
                     this.btnToggle = false;
                     this.http.sLoaderSwitch(false);
                     // console.info('Error occurred ', err);
                 },
             );*/
    }

    fetchVendor() {
        this.http.get(this.url.urls.tenderCtrl.fetchAllVendor
                .replace('{userId}', this.session.getUserId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.vendor = res.vendor;
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }
}
