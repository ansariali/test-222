export * from './icons.component';
