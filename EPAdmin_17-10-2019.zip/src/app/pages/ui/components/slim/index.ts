export * from './slim.component';
