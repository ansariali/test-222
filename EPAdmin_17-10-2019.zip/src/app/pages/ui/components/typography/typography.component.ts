import {Component} from '@angular/core';


@Component({
  selector: 'typography',
  templateUrl: './typography.html',
})
export class Typography {

  constructor() {
  }
}
