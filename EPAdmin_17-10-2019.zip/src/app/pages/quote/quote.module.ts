import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {QuoteRoutingModule} from './quote-routing.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgbModule, NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {PipeModule} from '../../@core/pipe/pipe.module';
import {CommonComponentModule} from '../../@core/components/commonComponent.module';
import {QuoteComponent} from './quote.component';


@NgModule({
    imports: [
        CommonModule,
        QuoteRoutingModule,
        FormsModule,
        NgbTooltipModule,
        Ng2PaginationModule,
        Ng2OrderModule,
        DirectiveModule,
        PipeModule,
        CommonComponentModule,
        NgbModule,
        ReactiveFormsModule,
    ],
    declarations: [
        QuoteComponent
    ]
})
export class QuoteModule {
}
