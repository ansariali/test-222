import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {WebsocketService} from '../../@core/service/websocket.service';
import {Observable} from 'rxjs/Observable';

@Component({
    selector: 'app-quote',
    templateUrl: './quote.component.html',
    styleUrls: ['./quote.component.scss']
})
export class QuoteComponent implements OnInit {
    public hideBidHistory: any = true;

    public token: any;
    public toggle: boolean = true;
    public toggleHolder: boolean = true;
    public lineItemIdx = null;
    public lineItemConductorId = null;

    public response2: any;
    public response: any = {
        highestBidRank: null,
        lowestBidRank: null
    };

    public stackHolders: any;
    public rank: any = 0;

    public timerTime: any;

    public vendorId: 0;
    // tslint:disable
    public bidDeleted: any = 0;
    public remainingBid: any = 0;
    public startTender: any = {
        'tenderExpiryDate': null,
        'tenderStartDate': null,
        'tunnelType': null,
        'leftTime': null
    };
    public array1 = ['True', 'False'];
    public deepScanValue = true;
    public info: any = {
        vendorCategory: null,
        customVendor: {
            customVendorId: null,
            companyName: null
        },
        tender: {
            bidAmountView: null,
            remarks: '',
            tenderTitle: null,
            tenderType: null,
            tenderDeliveryDate: null,
            tenderExpiryDate: null,
            tenderFromDate: null,
            tenderToDate: null,
            tenderStartDate: null,
            tenderEndDate: null,
            forthComingAuction: false,
            timeZone: null,
            paymentTermsDays: null,
            description: null,
            bidDecrementAmount: null,
            bidIncrementAmount: null,
            bidingType: null,
            bidThreshold: null,
            tenderCategory: null,
            currencyType: null,
            specificCurrencyType: null,
            preQualificationQuestionnaireDescription: null,
            preQualificationQuestionnaireStatus: 'Yes',
            deliveryAddresses: [
                {
                    address: null,
                    city: null,
                    country: null,
                    countryCode: null,
                    latitude: 0,
                    longitude: 0,
                    pinCode: null,
                    region: null,
                    state: null,
                }],
            quantityType: null,
            specificQuantityType: null,
            quantity: null,
            material: {
                materialId: null,
                materialName: null,
            },
            freight: null,
            forthComingAuctionActive: true,
            fixedBidAmount: null,
            participants: {},
            rfqToAuctionConverted: false,
            // stackHolders: [],
        },
        lineItems: [],

    };
    public responseLowestBid: any = {
        lowestBid: null,
    };
    public responseHighestBid: any = {
        highestBid: null,
    };

    public stringData: any = {
        bidingType: null,
        tenderType: null,
        tenderCategory: null,
        justification: null,
        deleteJustification: null
    };

    public counter: any = {
        amount: 0,
        message: null,
    };

    public chat: any = {
        counterOffer: {
            counterOfferId: null,
            offers: [],
        },
    };

    public btn: any = {
        delete1: false,
        rfx: false,
        updateBtn: false,
        createBtn: false,
        validate: false,
        generatePo: false,
        sendPo: false,
        addTerm: false,
        removeTerm: false,
        addDispatch: false,
        sendDispatch: false,
        downloadPo: false,
        changePurchaseStatus: false,
        changePaymentStatus: false,
        exitAuction: false
    };

    public bid: any = {
        'agreeWithFixedAmount': true,
        'bidAmounts': [
            {
                'bidAmount': null,
            },
        ],
        'fixedBidAmount': null,
        'remarks': ''
    };
    public raceStatus: any;
    public timeDiff: any;

    public serverCurrentTime: any;
    public current: any = new Date();
    public startDate: any;
    public endDate: any;
    public refresh: any;
    public bidAmounts: any = [];
    public test: any;

    public array = [
        {
            materialName: 'Matreial1',
            deliveryDate: 150015001500,
            lowestBidAmount: 'Sr.No.',
            totalParticipant: 'Sr.No.',
        }
    ];
    public pageReady: boolean = false;

    // MatHeader
    public matTableHeader: any = [];
    public matTableHeader1: any = [];
    public bidHistory: any = [];
    public data: any = {
        tender: {
            tenderTitle: null,
            tenderType: null,
            tenderDeliveryDate: null,
            tenderExpiryDate: null,
            tenderFromDate: null,
            tenderToDate: null,
            tenderStartDate: null,
            tenderEndDate: null,
            forthComingAuction: false,
            timeZone: null,
            paymentTermsDays: null,
            description: null,
            bidDecrementAmount: null,
            bidIncrementAmount: null,
            bidingType: null,
            bidThreshold: null,
            tenderCategory: null,
            currencyType: null,
            specificCurrencyType: null,
            preQualificationQuestionnaireDescription: null,
            preQualificationQuestionnaireStatus: 'Yes',
            deliveryAddresses: [
                {
                    address: null,
                    city: null,
                    country: null,
                    countryCode: null,
                    latitude: 0,
                    longitude: 0,
                    pinCode: null,
                    region: null,
                    state: null,
                }],
            quantityType: null,
            specificQuantityType: null,
            quantity: null,
            material: {
                materialId: null,
                materialName: null,
            },
            freight: null,
            forthComingAuctionActive: true,
            fixedBidAmount: null,
            participants: {},
            rfqToAuctionConverted: false
        },
        tenderLineItem: {
            lineItemId: null,
            agentFeedback: null,
            patronFeedback: null,
            highestBidAmount: null,
            lowestBidAmount: null,
            bidSelectedOn: null,
            lineItemTitle: null,
            material: {
                materialId: null,
                materialName: null,
                hsnCode: null
            },
            deliveryAddresses: [
                {
                    deliveryAddressId: null,
                    deliveryDate: null,
                    address: null,
                    pinCode: null,
                    city: null,
                    state: null,
                    country: null,
                    countryCode: null,
                    latitude: null,
                    longitude: null
                }
            ],
            attachments: [],
            bidDecrementAmount: null,
            bidThreshold: null,
            bidIncrementAmount: null,
            fixedBidAmount: null,
            freight: null,
            quantity: null,
            quantityType: null,
            specificQuantityType: null,
            pricePerUnit: null,
            counterOffer: {
                offers: [],
            },
        }
    };
    public key = null;
    public holder = [];
    public tender: any;
    public currentBidAmountView: any = null;

    constructor(public router: Router, public http: HttpService, public ws: WebsocketService,
                public url: UrlService, public session: SessionService, public path: PathService) {
        // this.checkPo = this.router.url.split('/')[4] == 'paymentNotification';
        // this.guestPage = this.router.url.split('/')[1] == 'guest';

    }

    ngOnInit() {
        this.fetchTender();
    }

    // fetchTender
    fetchTender() {
        this.http.get(this.url.urls.tenderCtrl.fetch
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId()),
            null)
            .subscribe(
                res => {
                    this.afterFetchTender(res);
                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }

    // Function after tender fetching
    afterFetchTender(res) {
        this.info = res;

        this.startDate = new Date(this.info.tenderStartDate);
        this.endDate = new Date(this.info.tenderExpiryDate);

        // Timer
        this.time();

        // Get material table header
        this.setMatTableHeader();
        this.wsHello();

        // Calling setBidAmountView(value, key);
        this.info.lineItems.forEach((value, key) => {
            if (this.info.tenderCategory == 1 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                this.fetchHighestBid(key);
            }
            if (this.info.tenderCategory == 2 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                this.fetchLowestBid(key);
            }

            // this.setBidAmountView(value, key);
        });
        this.pageReady = true;
    }

    // Get allocatedLineItems of particular index as in SubPart
    getSubPart(key, key1) {
        return this.info.lineItems[key].stackHolders[key1];
    }

    // setBidAmountView
    setBidAmountView(key, value, key1) {
        // Both are same but just for knowledge
        if (this.getSubPart(key, key1) != null || this.info.lineItems[key].stackHolders[key1] != undefined) {
            this.info.lineItems[key].deliveryAddresses[0].deliveryDate = new Date(this.info.lineItems[key].deliveryAddresses[0].deliveryDate).toLocaleString();

            if (this.getSubPart(key, key1).createdBid != null && this.info.tenderType != 3) {
                this.getSubPart(key, key1).bidAmountView = value.createdBid.latestBidAmount.bidAmount;
                this.currentBidAmountView = value.createdBid.latestBidAmount.bidAmount;
                this.info.lineItems[key].stackHolders[key1]['currentBidAmountView'] = value.createdBid.latestBidAmount.bidAmount;
                this.getSubPart(key, key1).remarks = value.createdBid.remarks;
                this.getSubPart(key, key1)['rank'] = value.createdBid.latestBidAmount.bidRank;
                this.info.lineItems[key].stackHolders[key1]['bidDeleted'] = 0;
                value.createdBid.bidAmounts.forEach(_value => {
                    if (_value.deleted) {
                        this.info.lineItems[key].stackHolders[key1]['bidDeleted'] = this.info.lineItems[key].stackHolders[key1]['bidDeleted'] + 1;
                    }
                });
                this.info.lineItems[key].stackHolders[key1]['remainingBid'] = this.getSubPart(key, key1).createdBid.bidAmounts.length - this.info.lineItems[key].stackHolders[key1]['bidDeleted'];
            }
            if (this.info.tenderCategory == 1 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                this.getSubPart(key, key1)['bidIncrementAmount'] = this.info.lineItems[key].bidIncrementAmount;
            }
            if (this.info.tenderCategory == 2 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                this.getSubPart(key, key1)['bidDecrementAmount'] = this.info.lineItems[key].bidDecrementAmount;
            }
            if (this.info.tenderType == 3) {
                this.getSubPart(key, key1)['fixedBidAmount'] = this.info.lineItems[key].fixedBidAmount;
            }
            this.getSubPart(key, key1).bid = {
                'agreeWithFixedAmount': true,
                'bidAmounts': [
                    {
                        'bidAmount': null,
                    },
                ],
                'fixedBidAmount': null,
                'remarks': ''
            };
        }
    }

    // working
    // Timer
    time() {
        this.http.get(this.url.urls.genericCtrl.currentTime
            , ({
                'Accept': 'application/json',
            }))
            .subscribe(
                res1 => {
                    // let t = new Date(res1.currentTime).toLocaleString();
                    // this.serverCurrentTime = new Date(t);
                    // this.startDate = new Date(this.response2.tender.tenderStartDate);
                    // this.endDate = new Date(this.response2.tender.tenderExpiryDate);

                    this.serverCurrentTime =  new Date(res1.currentTime);
                    let d1 = Date.parse(this.serverCurrentTime);
                    let d2 = Date.parse(this.startDate);
                    let d3 = Date.parse(this.endDate);
                    if (d1 < d2) {
                        this.raceStatus = 0;
                        this.refresh = true;
                        this.timeDiff = Math.abs(this.current.getTime() - this.startDate.getTime());
                    }
                    else if (d2 < d3 && d3 > d1) {
                        this.raceStatus = 1;
                        this.refresh = true;
                        this.timeDiff = Math.abs(this.startDate.getTime() - this.endDate.getTime());
                    }
                    else if (d3 < d1) {
                        this.raceStatus = 2;
                        this.refresh = true;

                    }
                });
    }

    // set material table header
    setMatTableHeader() {
        // Fixed
        if (this.info.tenderType == 3) {
            // console.info('setMatTableHeader if fixed: ', this.info.tenderType);

            this.matTableHeader = ['Material', 'Fixed Bid', 'Action'];
        }
        // !Fixed
        else {
            let bidingType = this.info.bidingType;
            let value;
            if (this.info.tenderCategory == 1) {
                value = 'Highest';
            }
            if (this.info.tenderCategory == 2) {
                value = 'Lowest';
            }

            switch (bidingType) {
                // RFQ
                case 1:
                    // console.info('setMatTableHeader case 1 RFQ: ', this.info.bidingType);
                    this.matTableHeader = ['Material', 'Action'];
                    break;
                // Auction
                case 2:
                    let columnName = value + ' Bid';
                    if (this.info.rfqToAuctionConverted) {
                        columnName = 'Rank';
                        // console.info('setMatTableHeader case 2 Auction columnName: ', columnName);
                        this.matTableHeader = ['Material', 'Action'];
                    }
                    if (!this.info.rfqToAuctionConverted) {
                        // console.info('setMatTableHeader case 2 Auction columnName: ', columnName);
                        this.matTableHeader = ['Material', 'Bidding Gap', columnName, 'Action'];
                    }
                    // this.matTableHeader = ['Material', 'Last Bid', 'Bidding Gap', columnName, 'Bid', 'Action'];
                    break;
                // Ranked
                case 3:
                    // console.info('setMatTableHeader case 3 Ranked: ', this.info.bidingType);
                    this.matTableHeader = ['Material', 'Action'];
                    break;
            }
        }
    }

    setMatTableHeader1() {
        // Fixed
        if (this.info.tenderType == 3) {
            this.matTableHeader1 = ['CompanyName', 'Fixed Bid', 'Agreed', 'Action'];
        }
        // !Fixed
        else {
            let bidingType = this.info.bidingType;
            let value;
            if (this.info.tenderCategory == 1) {
                value = 'Highest';
            }
            if (this.info.tenderCategory == 2) {
                value = 'Lowest';
            }

            switch (bidingType) {
                // RFQ
                case 1:
                    this.matTableHeader1 = ['CompanyName', 'Last Bid', 'Bid', 'Action'];
                    break;
                // Auction
                case 2:
                    let columnName = value + ' Bid';
                    if (this.info.rfqToAuctionConverted) {
                        columnName = 'Rank';
                        // console.info('setMatTableHeader case 2 Auction columnName: ', columnName);
                        this.matTableHeader1 = ['CompanyName', 'Last Bid', columnName, 'Bid', 'Action'];
                    }
                    if (!this.info.rfqToAuctionConverted) {
                        // console.info('setMatTableHeader case 2 Auction columnName: ', columnName);
                        this.matTableHeader1 = ['CompanyName', 'Last Bid', 'Bidding Gap', columnName, 'Bid', 'Action'];
                    }
                    // this.matTableHeader = ['Material', 'Last Bid', 'Bidding Gap', columnName, 'Bid', 'Action'];
                    break;
                // Ranked
                case 3:
                    // console.info('setMatTableHeader case 3 Ranked: ', this.info.bidingType);
                    this.matTableHeader1 = ['CompanyName', 'Last Bid', 'Rank', 'Bid', 'Action'];
                    break;
            }
        }
    }

    showStackholder(i, idx) {
        this.toggleHolder = false;
        this.lineItemIdx = idx;
        this.setMatTableHeader1();
        // this.holder = i.stackHolders;
        this.holder = i.stackHolders;
        this.tender = i;
        i.stackHolders.forEach((value1, key1) => {
            this.setBidAmountView(idx, value1, key1);
        });
    }

    viewHistory(data, index) {
        this.bidHistory = data.createdBid;
        $('#bidHistoryModal').modal();
    }

    validator(key) {
        if (this.info.tenderCategory == 1) {
            if ((this.getSubPart(this.lineItemIdx, key).responseHighestBid.highestBid + this.info.lineItems[this.lineItemIdx].bidIncrementAmount) > this.info.lineItems[this.lineItemIdx]) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        if (this.info.tenderCategory == 2) {
            if ((this.getSubPart(this.lineItemIdx, key).responseLowestBid.lowestBid - this.info.lineItems[this.lineItemIdx].bidDecrementAmount) < this.getSubPart(this.lineItemIdx, key).bidAmountView || this.info.lineItems[this.lineItemIdx].bidDecrementAmount > this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

    validator2(key) {
        // console.info('validator dcs 2 ', this.getSubPart(this.lineItemIdx, key).responseHighestBid.lowestBid , this.getSubPart(this.lineItemIdx, key).bidAmountView);

        if (this.info.tenderCategory == 1) {
            if ((this.getSubPart(this.lineItemIdx, key).responseHighestBid.highestBid + this.info.lineItems[this.lineItemIdx].bidIncrementAmount) > this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        if (this.info.tenderCategory == 2) {
            if ((this.getSubPart(this.lineItemIdx, key).responseLowestBid.lowestBid - this.info.lineItems[this.lineItemIdx].bidDecrementAmount) < this.getSubPart(this.lineItemIdx, key).bidAmountView || this.info.lineItems[this.lineItemIdx].bidDecrementAmount > this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

    validator3(key) {
        // Sell
        if (this.info.tenderCategory == 1) {
            if (this.getSubPart(this.lineItemIdx, key).createdBid.latestBidAmount.bidAmount > this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        // Buy
        if (this.info.tenderCategory == 2) {
            if (this.getSubPart(this.lineItemIdx, key).createdBid.latestBidAmount.bidAmount < this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

    validator4(key) {
        // RFQ Rebid update
        // Sell
        if (this.info.tenderCategory == 1) {
            if (this.getSubPart(this.lineItemIdx, key).createdBid.latestBidAmount.bidAmount > this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        // Buy
        if (this.info.tenderCategory == 2) {
            if (this.getSubPart(this.lineItemIdx, key).createdBid.latestBidAmount.bidAmount < this.getSubPart(this.lineItemIdx, key).bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

    create(key1) {
        this.btn.createBtn = true;
        if (this.info.tenderType == 3 && this.bid.agreeWithFixedAmount == true) {
            this.bid = {
                agreeWithFixedAmount: true,
                bidAmounts: [
                    {
                        bidAmount: null,
                    },
                ],
                fixedBidAmount: this.getSubPart(this.lineItemIdx, key1).fixedBidAmount,
                remarks: this.getSubPart(this.lineItemIdx, key1).remarks
            };

            this.http.post(this.url.urls.tenderCtrl.createBid
                    .replace('{userId}', this.session.getUserId())
                    .replace('{tenderLineItemConductorId}', this.getSubPart(this.lineItemIdx, key1).lineItemConductorId),
                this.bid, null)
                .subscribe(
                    res => {
                        this.response = res;
                        this.btn.createBtn = false;
                        this.http.successToast(null, 'Your bid has been successfully placed');
                    },
                    err => {
                        // console.info('Error occurred ', err);
                        this.btn.createBtn = false;
                        this.http.errorToast(err);
                    },
                );
        }
        if (this.info.tenderType != 3) {
            this.bid = {
                agreeWithFixedAmount: false,
                bidAmounts: [
                    {
                        bidAmount: this.getSubPart(this.lineItemIdx, key1).bidAmountView,
                    },
                ],
                fixedBidAmount: null,
                remarks: this.getSubPart(this.lineItemIdx, key1).remarks
            };
            this.http.post(this.url.urls.tenderCtrl.createBid
                    .replace('{userId}', this.session.getUserId())
                    .replace('{tenderLineItemConductorId}', this.getSubPart(this.lineItemIdx, key1).lineItemConductorId),
                this.bid, null)
                .subscribe(
                    res => {
                        this.response = res;
                        this.http.successToast(null, 'Your bid has been successfully placed!');
                        // this.fetchTender();
                        this.btn.createBtn = false;
                    },
                    err => {
                        // console.info('Error occurred ', err);
                        this.btn.createBtn = false;
                        this.http.errorToast(err);
                    },
                );
        }
    }

    update(key1) {
        this.btn.updateBtn = true;
        this.btn.rfx = true;
        this.bid = {
            bidAmount: this.getSubPart(this.lineItemIdx, key1).bidAmountView,
            remarks: this.getSubPart(this.lineItemIdx, key1).remarks
        };
        // console.info('this.getSubPart(this.lineItemIdx, key1).remarks', this.getSubPart(this.lineItemIdx, key1).remarks);
        this.http.put(this.url.urls.tenderCtrl.updateBid
                .replace('{userId}', this.session.getUserId())
                // .replace('{remarks}', this.getSubPart(this.lineItemIdx, key1).remarks)
                .replace('{tenderLineItemConductorId}', this.getSubPart(this.lineItemIdx, key1).lineItemConductorId)
                .replace('{bidId}', this.getSubPart(this.lineItemIdx, key1).createdBid.bidId)
                // .replace('{bidAmount}', this.getSubPart(this.lineItemIdx, key1).bidAmountView)
            , this.bid, null)
            .subscribe(
                res => {
                    this.response = res;
                    this.http.successToast(null, 'Your bid has been successfully updated');
                    this.btn.updateBtn = false;
                    this.btn.rfx = false;

                    if (this.getSubPart(this.lineItemIdx, key1).createdBid != null) {
                        this.getSubPart(this.lineItemIdx, key1).createdBid.latestBidAmount.bidAmount = this.getSubPart(this.lineItemIdx, key1).bidAmountView;
                        // this.getSubPart(key).remarks = this.getSubPart(key).createdBid.remarks;
                        this.getSubPart(this.lineItemIdx, key1)['currentBidAmountView'] = this.getSubPart(this.lineItemIdx, key1).createdBid.latestBidAmount.bidAmount;
                    }

                },
                err => {
                    // console.info('Error occurred ', err);
                    this.btn.updateBtn = false;
                    this.btn.rfx = false;
                    this.http.errorToast(err);
                },
            );
    }

    // Delete Bid
    deleteBidDialog(data, index) {
        this.key = data;
        $('#deleteBidModal').modal();
    }

    deleteBid() {
        this.btn.delete1 = true;
        this.http.delete(this.url.urls.tenderCtrl.deleteBid
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemConductorId}', this.key.lineItemConductorId)
                .replace('{bidId}', this.key.createdBid.bidId)
                .replace('{whyDelete}', this.stringData.deleteJustification)
                .replace('{deepScan}', this.deepScanValue)
            , null)
            .subscribe(
                res => {
                    $('#deleteBidModal').modal('hide');
                    this.stringData.deleteJustification = null;
                    this.http.successToast(null, 'Your bid has been successfully deleted!');
                    this.btn.delete1 = false;
                },
                err => {
                    this.btn.delete1 = false;
                    this.http.errorToast(err);
                },
            );
    }

    fetchLowestBid(key) {
        this.http.get(this.url.urls.tenderCtrl.lowestBid
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemId}', this.info.lineItems[key].lineItemId),
            null)
            .subscribe(
                res => {
                    this.responseLowestBid = res;
                    this.info.lineItems[key]['responseLowestBid'] = res;
                    this.info.lineItems[key].stackHolders.forEach((value, key1) => {
                        this.getSubPart(key, key1)['responseLowestBid'] = res;
                    });
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    // fetchHighestBid
    fetchHighestBid(key) {
        this.http.get(this.url.urls.tenderCtrl.highestBid
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemId}', this.info.lineItems[key].lineItemId),
            null)
            .subscribe(
                res => {
                    this.responseHighestBid = res;
                    this.info.lineItems[key]['responseHighestBid'] = res;
                    this.info.lineItems[key].stackHolders.forEach((value, key1) => {
                        this.getSubPart(key, key1)['responseHighestBid'] = res;
                    });
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    // dump
    fetchRank(token, key, key1) {
        console.info('fetch Rank');
        if (this.info.tenderCategory == 1 && (this.info.bidingType == 3 || this.info.rfqToAuctionConverted)) {
            this.fetchHighestRank(token, key, key1);
        }
        if (this.info.tenderCategory == 2 && (this.info.bidingType == 3 || this.info.rfqToAuctionConverted)) {
            this.fetchLowestRank(token, key, key1);
        }
    }

    // dump
    fetchHighestRank(token, key, key1) {
        this.http.get(this.url.urls.tenderCtrl.fetchHighestRank
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemConductorToken}', token),
            null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.getSubPart(key, key1)['rank'] = res.highestBidRank;
                    // this.rank = res;
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    // dump
    fetchLowestRank(token, key, key1) {
        // let obj = Observable.timer(2000,1000);
        // obj.subscribe(x => console.log('kjkjdk'));
        this.http.get(this.url.urls.tenderCtrl.fetchLowestRank
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemConductorToken}', token),
            null)
            .subscribe(res => {
                    this.getSubPart(key, key1)['rank'] = res.lowestBidRank;
                    // console.info('fetchLowestRank ', this.response.lowestBidRank);
                },
                err => {
                    // console.info('Error occurred ', err);
                }
            );
    };

    wsHello() {
        this.ws.disconnect();
        this.ws.connect(this.ready);
    }

    exitAuctionBefore(id, idx) {
        this.lineItemConductorId = id;
        $('#exitAuctionModal').modal();
    }

    exitAuction() {
        if (!this.btn.exitAuction) {
            this.btn.exitAuction = true;
            this.http.delete(this.url.urls.tenderCtrl.exitAuction
                    .replace('{userId}', this.session.getUserId())
                    .replace('{tenderLineItemConductorId}', this.lineItemConductorId.lineItemConductorId)
                    .replace('{bidId}', this.lineItemConductorId.createdBid.bidId)
                    .replace('{whyDelete}', this.stringData.justification)
                , null)
                .subscribe(
                    res => {
                        this.stringData.justification = null;

                        $('#exitAuctionModal').modal('hide');
                        this.http.successToast(null, 'Auction exited by you!');
                        this.btn.exitAuction = false;
                    },
                    err => {
                        this.btn.exitAuction = false;
                        this.http.errorToast(err);
                    },
                );
        }
    }

    deletePermission(deleteBidStatus,key1){
        this.http.get(this.url.urls.tenderCtrl.deleteBidPermission
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemConductorId}', this.getSubPart(this.lineItemIdx, key1).lineItemConductorId)
                .replace('{deleteBidStatus}', deleteBidStatus)
            , null)
            .subscribe(
                res => {
                    this.http.successToast(null, res.message);
                },
                err => {
                    this.btn.exitAuction = false;
                    this.http.errorToast(err);
                },
            );
    }

    exitPermission(exitBidStatus,key1) {
        this.http.get(this.url.urls.tenderCtrl.exitBidPermission
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderLineItemConductorId}', this.getSubPart(this.lineItemIdx, key1).lineItemConductorId)
                .replace('{exitBidStatus}', exitBidStatus)
            , null)
            .subscribe(
                res => {
                    this.http.successToast(null, res.message);
                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }

    copy(token) {
        // console.info('token', token.tenderConductor.token);
        // window.open( 'http://192.168.0.31:5000/#/guest/quote/view/viewTenderStatus/{token}'
        //     .replace('{token}', token.tenderConductor.token));

        window.open( location.origin + '/1125/#/guest/quote/view/viewTenderStatus/{token}'
            .replace('{token}', token.tenderConductor.token));
    }

    refeshPage(data) {
        this.http.get(this.url.urls.tenderCtrl.refreshPage
                .replace('{userId}', this.session.getUserId())
                .replace('{customVendorId}', data.tenderConductor.customVendor.customVendorId)
                .replace('{tenderConductorToken}', data.tenderConductor.token)
            , null)
            .subscribe(
                res => {
                    this.http.successToast(null, res.message);
                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }

    ready = () => {
        this.ws.subscribe('/tunnel/v1/startTender/{tenderId}'
                .replace('{tenderId}', this.info.tenderId)
            , {}, (frame) => {
                this.time();
                // console.info('1 frame: ', frame);
            });

        this.ws.subscribe('/tunnel/v1/extendTender/{tenderId}'
                .replace('{tenderId}', this.info.tenderId)
            , {}, (frame) => {
                this.startTender = this.ws.getBody(frame);
                this.startDate = new Date(this.startTender.tenderStartDate);
                this.endDate = new Date(this.startTender.tenderExpiryDate);
                this.refresh = true;
                this.time();
            });


        this.ws.subscribe('/tunnel/v1/closedTender/{tenderId}'
                .replace('{tenderId}', this.info.tenderId)
            , {}, (frame) => {
                // console.info('5 frame: ', frame);
                this.raceStatus = 2;
            });


        this.ws.subscribe('/tunnel/v1/refresh/tender/{tenderId}'
        // this.ws.subscribe('/tunnel/v1/refreshAdmin/tender/{tenderId}'
                .replace('{tenderId}', this.info.tenderId)
            , {}, (frame) => {

                this.response2 = this.ws.getBody(frame).tender;

                this.info = this.response2;
                this.info.lineItems = this.response2.lineItems;
                // this.info.customVendor = this.info.vendor;

                this.info.tenderFromDate = new Date(this.response2.tenderFromDate).toLocaleString();
                this.info.tenderToDate = new Date(this.response2.tenderToDate).toLocaleString();
                this.info.tenderStartDate = new Date(this.response2.tenderStartDate).toLocaleString();
                this.info.tenderExpiryDate = new Date(this.response2.tenderExpiryDate).toLocaleString();

                this.timerTime = new Date(this.info.tenderExpiryDate);

                /** bidingType */
                if (this.info.bidingType == 1) {
                    this.stringData.bidingType = 'RFQ';
                }
                if (this.info.bidingType == 2) {
                    this.stringData.bidingType = 'Auction';
                }
                if (this.info.bidingType == 3) {
                    this.stringData.bidingType = 'Ranked';
                }

                /** tenderType */
                if (this.info.tenderType == 1) {
                    this.stringData.tenderType = 'Contractual';
                }
                if (this.info.tenderType == 2) {
                    this.stringData.tenderType = 'Spot';
                }
                if (this.info.tenderType == 3) {
                    this.stringData.tenderType = 'Fixed';
                }

                /** tenderCategory */
                if (this.info.tenderCategory == 1) {
                    this.stringData.tenderCategory = 'Sell';
                }
                if (this.info.tenderCategory == 2) {
                    this.stringData.tenderCategory = 'Buy';
                }

                if (this.lineItemIdx == null) {
                    this.holder = this.info.lineItems;
                }

                this.info.lineItems.forEach((value, key) => {
                    value.stackHolders.forEach((value1, key1) => {
                        if (value1.createdBid != null && this.info.tenderType != 3) {
                            this.getSubPart(key, key1).bidAmountView = value1.createdBid.latestBidAmount.bidAmount;
                            this.getSubPart(key, key1)['rank'] = value1.createdBid.latestBidAmount.bidRank;
                            this.getSubPart(key, key1)['currentBidAmountView'] = value1.createdBid.latestBidAmount.bidAmount;
                        }
                        if (this.info.tenderType == 3) {
                            this.getSubPart(key, key1)['fixedBidAmount'] = value.fixedBidAmount;
                        }
                        if (this.info.tenderCategory == 2 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                            if (value.lowestBidAmount != null) {
                                this.info.lineItems[key]['responseLowestBid'] = {
                                    lowestBid: value.lowestBidAmount.bidAmount
                                };
                                this.getSubPart(key, key1)['responseLowestBid'] = {
                                    lowestBid: value.lowestBidAmount.bidAmount
                                };
                            } else {
                                this.info.lineItems[key]['responseLowestBid'] = {
                                    lowestBid: value.bidThreshold
                                };
                                this.getSubPart(key, key1)['responseLowestBid'] = {
                                    lowestBid: value.bidThreshold
                                };
                            }
                        }
                        if (this.info.tenderCategory == 1 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                            if (value.highestBidAmount != null) {
                                this.info.lineItems[key]['responseHighestBid'] = {
                                    highestBid: value.highestBidAmount.bidAmount
                                };
                                this.getSubPart(key, key1)['responseHighestBid'] = {
                                    highestBid: value.highestBidAmount.bidAmount
                                };
                            } else {
                                this.info.lineItems[key]['responseHighestBid'] = {
                                    highestBid: value.bidThreshold
                                };
                                this.getSubPart(key, key1)['responseHighestBid'] = {
                                    highestBid: value.bidThreshold
                                };
                            }
                        }

                    });
                });

                let index;
                let index1;
                let stop = true;
                if (this.lineItemIdx != null) {
                    this.holder = this.info.lineItems[this.lineItemIdx].stackHolders;
                    this.info.lineItems[this.lineItemIdx].stackHolders.forEach((value1, key1) => {
                        // this.holder = value1;
                        if (value1.createdBid != null) {
                            if (this.info.tenderType != 3) {
                                this.getSubPart(this.lineItemIdx, key1).bidAmountView = value1.createdBid.latestBidAmount.bidAmount;
                                this.getSubPart(this.lineItemIdx, key1)['currentBidAmountView'] = value1.createdBid.latestBidAmount.bidAmount;
                                this.getSubPart(this.lineItemIdx, key1)['rank'] = value1.createdBid.latestBidAmount.bidRank;
                                this.getSubPart(this.lineItemIdx, key1).remarks = value1.createdBid.remarks;
                                this.getSubPart(this.lineItemIdx, key1)['bidAmounts'] = value1.createdBid.bidAmounts;
                                this.getSubPart(this.lineItemIdx, key1)['bidDeleted'] = 0;
                                value1.createdBid.bidAmounts.forEach(value => {
                                    if (value.deleted) {
                                        this.getSubPart(this.lineItemIdx, key1)['bidDeleted'] = this.getSubPart(this.lineItemIdx, key1)['bidDeleted'] + 1;
                                    }
                                });
                                this.getSubPart(this.lineItemIdx, key1)['remainingBid'] = value1.createdBid.bidAmounts.length - this.getSubPart(this.lineItemIdx, key1)['bidDeleted'];
                            }
                        }

                        if (this.info.tenderCategory == 2 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                            if (this.info.lineItems[this.lineItemIdx].lowestBidAmount != null) {
                                this.getSubPart(this.lineItemIdx, key1)['responseLowestBid'] = {
                                    lowestBid: this.info.lineItems[this.lineItemIdx].lowestBidAmount.bidAmount
                                };
                            }
                            else {
                                this.getSubPart(this.lineItemIdx, key1)['responseLowestBid'] = {
                                    lowestBid: this.info.lineItems[this.lineItemIdx].bidThreshold
                                };
                            }
                            this.getSubPart(this.lineItemIdx, key1)['bidDecrementAmount'] = this.info.lineItems[this.lineItemIdx].bidDecrementAmount;
                        }

                        if (this.info.tenderCategory == 1 && (this.info.bidingType == 2 && !this.info.rfqToAuctionConverted)) {
                            if (this.info.lineItems[this.lineItemIdx].highestBidAmount != null) {
                                this.getSubPart(this.lineItemIdx, key1)['responseHighestBid'] = {
                                    highestBid: this.info.lineItems[this.lineItemIdx].highestBidAmount.bidAmount
                                };
                            }
                            else {
                                this.getSubPart(this.lineItemIdx, key1)['responseHighestBid'] = {
                                    highestBid: this.info.lineItems[this.lineItemIdx].bidThreshold
                                };
                            }
                            this.getSubPart(this.lineItemIdx, key1)['bidIncrementAmount'] = this.info.lineItems[this.lineItemIdx].bidIncrementAmount;
                        }

                        // if (stop && (value.lineItemStatus != 'ACHIEVED' && value.lineItemStatus != 'LOST' && value.lineItemStatus != 'GONE' && value.lineItemStatus != 'DELETED')) {
                        if (stop) {
                            index = this.lineItemIdx;
                            index1 = key1;
                            stop = false;
                        }
                    });
                }

                if (index == undefined) {
                    if (this.info.tenderStatus != 'SUCCESS' && this.info.tenderStatus != 'HOLD' && this.info.tenderStatus != 'DELETED') {
                        this.info.tenderStatus = 'GONE';
                    }
                }
                else {
                    // if (clickedMaterial != undefined) {
                    this.getSubPart(index, index1);
                    this.setMatTableHeader();
                    // } else {
                    // this.swapMaterial(index);
                    // }
                }
            });

    };

}
