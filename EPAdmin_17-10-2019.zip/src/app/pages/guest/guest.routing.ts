import {Routes} from '@angular/router';

import {DemoComponent} from './demo/demo.component';
import {WelcomeComponent} from './welcome/welcome.component';
import {NotInterestedComponent} from './not-intrested/not-intersted.component';
import {BadUserComponent} from './bad-user/bad-user.component';
import {VendorProfileComponent} from './vender-profile/vendor-profile.component';
import {ViewTenderComponent} from './view-tender/view-tender.component';

export const GuestRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'demo',
        component: DemoComponent,
      },
      {
        path: 'welcome',
        component: WelcomeComponent,
      },
      {
        path: 'welcome/:type/:reason/:token',
        component: WelcomeComponent,
      },
      {
        path: 'later',
        component: NotInterestedComponent,
      },
      {
        path: 'profile/:token',
        component: VendorProfileComponent,
      },
      {
        path: 'tender/view/:reason/:token',
        component: ViewTenderComponent,
      },
      {
        path: 'baduser',
        component: BadUserComponent,
      },
    ],
  },
];
