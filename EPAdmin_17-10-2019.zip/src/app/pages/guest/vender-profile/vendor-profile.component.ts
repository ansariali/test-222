import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../../@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {SessionService} from '../../../@core/service/session.service';
import {PathService} from '../../../@core/service/path.service';

declare var $: any;

@Component({
  selector: 'app-vendor-profile-guest',
  templateUrl: './vendor-profile.component.html',
})

export class VendorProfileComponent implements OnInit {
  protected config: any = {
    pageUrl: null,
  };


  public btn: any = {
    updateBtn: false,
  };
  protected token: any;
  protected uvResponse: any;
  public response: any = {
    'customVendorId': null,
    'customVendorSerialNumber': null,
    'vendor': {
      'vendorId': null,
      'isUserOwner': null,
      'owner': null,
      'logBidsInAccess': null,
      'eazeProcureInAccess': null,
      'scrumsUpInAccess': null,
    },
    'companyName': null,
    'pointOfContact': null,
    'emailAddress': null,
    'contactNumber': null,
    'vendorType': null,
    'description': null,
    'address1': null,
    'pinCode': null,
    'city': null,
    'state': null,
    'countryCode': null,
    'country': null,
    'latitude': null,
    'longitude': null,
    'keyWordOfTraceCompany': null,
    'companyRegistrationNumber': null,
    'panCardNumber': null,
    'otherContactNumber': null,
    'annualRevenue': null,
    'companyWebSite': null,
    'companyDescription': null,
    'defaultEmailAddress': null,
    'rating': null,
    'ratingCount': 0,
    'bidsWon': 0,
    'bidAcceptance': 0,
    'totalQuotes': 0,
    'transactionValue': 0.0,
    'token': null,
    'verifiedOn': null,
    'invitationMailSend': true,
    'invitationMailSendOn': null,
    'invitationMailSeen': null,
    'invitationMailSeenOn': null,
    'verified': null,
  };

  public keyWords: any = [];
  public componentData: any = '';
  public userSettings: any = {
    geoCountryRestriction: ['in'],
    showCurrentLocation: false,
    showSearchButton: false,
    recentStorageName: 'componentData',
    noOfRecentSearchSave: 8,
  };

  autoCompleteCallback4(data: any): any {
    this.componentData = JSON.stringify(data);

    this.response.pinCode = data.address_components[0].long_name;
    this.response.city = data.address_components[1].long_name;
    this.response.state = data.address_components[3].long_name;
    this.response.country = data.address_components[4].long_name;
    this.response.region = data.address_components[4].short_name + '-' + data.address_components[3].short_name;
    this.response.longitude = data.geometry.location.lng;
    this.response.latitude = data.geometry.location.lat;
  }

  constructor(private router: Router, private http: HttpService, private url: UrlService, private session: SessionService, private path: PathService) {
    this.config.pageUrl = this.path.pageUrl;
  }

  ngOnInit() {
    $('.form-control').each(function () {

      $(this).focus(function () {
        $(this).parent().addClass('focused');
      });

      $(this).focusout(function () {
        $(this).parent().removeClass('focused');
      });

      function emptyListener($this) {
        requestAnimationFrame(function () {
          emptyListener($this);
        });

        if ($this.val() === '' || $this.val() === null) {
          $this.parent().removeClass('is-completed');
          $this.parent().removeClass('is-active');
        } else {
          $this.parent().addClass('is-active is-completed');
        }
      }

      emptyListener($(this));
    });

    this.token = location.hash.split('/')[3];
    this.verifyCustomVendor();
  }

  verifyCustomVendor() {
    this.http.get(this.url.urls.outSideCtrl.fetchCustomVendor, ({
      'ACCESS-TOKEN': this.token,
      'Accept': 'application/json',
    }))
      .subscribe(
        res => {
          console.info('Successfully Done! ', res);
          this.response = res;
          $('#search_places')[0].value = this.response.pinCode;
          console.info('this.cvGenericResponse: ', this.response);
        },
        err => {
          console.info('Error occurred ', err);
        },
      );
  }

  updateCustomVendor() {

    this.keyWords.forEach(value => {
      let sentence = null;

      sentence = sentence + ',' + value;
      console.info('sentence: ', sentence);
    });

    this.btn.updateBtn = true;
    this.http.put(this.url.urls.outSideCtrl.verifyCustomVendor, this.response, ({
      'ACCESS-TOKEN': this.token,
      'Accept': 'application/json',
    }))
      .subscribe(
        res => {
          console.info('Successfully Done! ', res);
          this.uvResponse = res;
          this.http.successToast(null, 'Your Profile Successfully Save');
          if (this.uvResponse.status) {
            this.router.navigateByUrl(this.path.pageUrl.guest.viewNoToken + this.token);
          } else {
            this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
          }
        },
        err => {
          console.info('Error occurred ', err);
          this.btn.updateBtn = false;
          this.http.errorToast(err);
        },
      );
  }

}
