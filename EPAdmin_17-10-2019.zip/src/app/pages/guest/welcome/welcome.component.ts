import {Component, OnInit} from '@angular/core';

import {HttpService} from '../../../@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {SessionService} from '../../../@core/service/session.service';
import {PathService} from '../../../@core/service/path.service';
import {Router} from '@angular/router';

@Component({
    selector: 'app-welcome-guest',
    templateUrl: './welcome.component.html',
    styleUrls: ['./welcome.component.sass'],
})

export class WelcomeComponent implements OnInit {
    protected config: any = {
        pageUrl: null,
    };

    protected type: any;
    protected reason: any;
    protected token: any;

    protected response: any;
    protected genericResponse: any;
    protected cvGenericResponse: any;

    constructor(private router: Router, private http: HttpService,
                private url: UrlService, private session: SessionService,
                private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
    }

    ngOnInit() {
        // tslint:disable
        console.info('location: ', location.hash);
        console.info('0: ', location.hash.split('/')[0]);
        console.info('1: ', location.hash.split('/')[1]);
        console.info('2: ', location.hash.split('/')[2]);
        console.info('3: ', location.hash.split('/')[3]);
        console.info('4: ', location.hash.split('/')[4]);

        this.type = location.hash.split('/')[3];
        this.reason = location.hash.split('/')[4];
        this.token = location.hash.split('/')[5];

        if (this.reason == 'acceptInvitation') {
            this.http.get(this.url.urls.invitationCtrl.verifyInvitation
                .replace('{invitationToken}', this.token), null)
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.response = res;
                        console.info('this.response.status: ', this.response.status);
                        if (this.response.status) {
                            this.session.setCustomSession('invitationToken', this.token);
                            this.session.setCustomSession('invitationEmail', this.response.description);
                            this.session.setCustomSession('invitation', true);

                            this.router.navigateByUrl(this.path.pageUrl.register.default);
                        } else {
                            this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
                        }
                    },
                    err => {
                        console.info('Error occurred ', err);
                    },
                );
        }

        else if (this.reason == 'acceptForgotPassword') {
            console.info('url: ', this.url.urls.userCtrl.verifyForgotPasswordRequest.repeat('{forgotToken}', this.token))
            this.http.get(this.url.urls.userCtrl.verifyForgotPasswordRequest
                .replace('{forgotToken}', this.token), null)
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.response = res;
                        console.info('this.response.status: ', this.response.status);
                        if (this.response.status) {
                            this.session.setCustomSession('ForgotPassEmail', this.response.description);
                            this.session.setCustomSession('ForgotPassStep2', true);

                            this.router.navigateByUrl(this.path.pageUrl.forgotPassword.default);
                        } else {
                            this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
                        }
                    },
                    err => {
                        console.info('Error occurred ', err);
                    },
                );
        }

        else if (this.reason == 'acceptCustomVendorInvitation') {
            this.http.get(this.url.urls.outSideCtrl.verifyInvitationOfCustomVendor, ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.genericResponse = res;
                        console.info('this.genericResponse.status: ', this.genericResponse.status);
                        if (this.genericResponse.status) {
                            this.verifyCustomVendor();
                        } else {
                            this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
                        }
                    },
                    err => {
                        console.info('Error occurred ', err);
                    },
                );
        }

        else if (this.reason == 'quoteToTender') {
            this.router.navigateByUrl(this.path.pageUrl.guest.viewNoToken + this.reason + '/' + this.token);
        }

        else if (this.reason == 'notInterestedToTender') {
            this.router.navigateByUrl(this.path.pageUrl.guest.notInterested);
        }

        else if (this.reason == 'viewTenderStatus') {
            this.router.navigateByUrl(this.path.pageUrl.guest.viewNoToken + this.reason + '/' + this.token);
        }

        else if (this.reason == 'acceptCounterAmount') {
            this.router.navigateByUrl(this.path.pageUrl.guest.viewNoToken + this.token);
        }

        else if (this.reason == 'rejectAndReCounter') {
            this.router.navigateByUrl(this.path.pageUrl.guest.viewNoToken + this.token);
        }

        else {
            this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
        }

        // console.info('type: ', this.type, ' Reason: ', this.reason, ' token: ', this.token);

        this.session.setToken(this.token);
        this.session.getToken();


    }

    verifyCustomVendor() {
        this.http.get(this.url.urls.outSideCtrl.fetchCustomVendor, ({
            'ACCESS-TOKEN': this.token,
            'Accept': 'application/json',
        }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.cvGenericResponse = res;
                    console.info('this.cvGenericResponse: ', this.cvGenericResponse);
                    if (!this.cvGenericResponse.verified) {
                        this.router.navigateByUrl(this.path.pageUrl.guest.profileNoToken + this.token);
                    }
                    else {
                        this.router.navigateByUrl(this.path.pageUrl.guest.badUser);
                    }
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }
}