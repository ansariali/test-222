import {Component, OnInit} from '@angular/core';


@Component({
    selector: 'app-not-interested-guest',
    templateUrl: './not-interested.component.html',
})

export class NotInterestedComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}
