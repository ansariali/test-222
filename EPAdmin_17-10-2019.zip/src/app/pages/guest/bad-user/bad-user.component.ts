import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-bad-user-guest',
    templateUrl: './bad-user.component.html',
})

export class BadUserComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}
