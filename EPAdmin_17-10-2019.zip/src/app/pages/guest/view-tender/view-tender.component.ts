import {Component, OnInit} from '@angular/core';

import {HttpService} from '../../../@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {SessionService} from '../../../@core/service/session.service';
import {Router} from '@angular/router';

declare var $: any;

@Component({
    selector: 'app-view-tender-guest',
    templateUrl: './view-tender.component.html',
})

export class ViewTenderComponent implements OnInit {
    public token: any;
    public reason: any;

    public response2: any;
    public response: any = {};

    public timerTime: any;

    public info: any = {
        vendorCategory: null,
        bidAmountView: null,
        customVendor: {
            customVendorId: null,
        },
        tender: {
            tenderTitle: null,
            tenderType: null,
            tenderDeliveryDate: null,
            tenderExpiryDate: null,
            tenderFromDate: null,
            tenderToDate: null,
            tenderStartDate: null,
            tenderEndDate: null,
            forthComingAuction: false,
            timeZone: null,
            paymentTermsDays: null,
            description: null,
            bidDecrementAmount: null,
            bidIncrementAmount: null,
            bidingType: null,
            bidThreshold: null,
            tenderCategory: null,
            currencyType: null,
            specificCurrencyType: null,
            preQualificationQuestionnaireDescription: null,
            preQualificationQuestionnaireStatus: 'Yes',
            deliveryAddresses: [
                {
                    address: null,
                    city: null,
                    country: null,
                    countryCode: null,
                    latitude: 0,
                    longitude: 0,
                    pinCode: null,
                    region: null,
                    state: null,
                }],
            quantityType: null,
            specificQuantityType: null,
            quantity: null,
            material: {
                materialId: null,
                materialName: null,
            },
            freight: null,
            forthComingAuctionActive: true,
            fixedBidAmount: null,
            participants: {},

        },
        bid: {
            counterOffer: {
                offers: [],
            },
        },
    };

    public info2: any = {
        bidAmountView: null,
        customVendor: {
            customVendorId: null,
        },
        tender: {
            tenderTitle: null,
            tenderType: null,
            tenderDeliveryDate: null,
            tenderExpiryDate: null,
            tenderFromDate: null,
            tenderToDate: null,
            tenderStartDate: null,
            tenderEndDate: null,
            forthComingAuction: false,
            timeZone: null,
            paymentTermsDays: null,
            description: null,
            bidDecrementAmount: null,
            bidIncrementAmount: null,
            bidingType: null,
            bidThreshold: null,
            tenderCategory: null,
            currencyType: null,
            specificCurrencyType: null,
            preQualificationQuestionnaireDescription: null,
            preQualificationQuestionnaireStatus: true,
            deliveryAddresses: [
                {
                    address: null,
                    city: null,
                    country: null,
                    countryCode: null,
                    latitude: 0,
                    longitude: 0,
                    pinCode: null,
                    region: null,
                    state: null,
                }],
            quantityType: null,
            specificQuantityType: null,
            quantity: null,
            material: {
                materialId: null,
                materialName: null,
            },
            freight: null,
            forthComingAuctionActive: true,
            fixedBidAmount: null,
            participants: {},

        },
        bid: {
            agreeWithFixedAmount: true,
            bidAmounts: [
                {
                    bidAmount: 0,
                },
            ],
            fixedBidAmount: null,
        },
    };

    public bType: any = [
        {
            code: '1',
            string: 'RFQ',
        },
        {
            code: '2',
            string: 'Auction',
        },
        {
            code: '3',
            string: 'Ranked',
        },
    ];

    public responseLowestBid: any = {
        lowestBid: null,
    };
    public responseHighestBid: any = {
        highestBid: null,
    };

    public stringData: any = {
        bidingType: null,
        tenderType: null,
        tenderCategory: null,
    };

    public counter: any = {
        amount: 0,
        message: null,
    };

    public chat: any = {
        counterOffer: {
            counterOfferId: null,
            offers: [],
        },
    };

    public btn: any = {
        updateBtn: false,
        createBtn: false,
        validate: false,
    };

    public bid: any = {
        'agreeWithFixedAmount': true,
        'bidAmounts': [
            {
                'bidAmount': null,
            },
        ],
        'fixedBidAmount': null,
    };

    constructor(private router: Router, private http: HttpService, private url: UrlService, private session: SessionService) {
    }

    ngOnInit() {

        $('.form-control').each(function () {
            function emptyListener($this) {
                requestAnimationFrame(function () {
                    emptyListener($this);
                });
                if ($this.data('oldval') != $this.val()) {
                    $this.data('oldval', $this.val);
                    $this.trigger('change');
                }
            }

            emptyListener($(this));
        });

        this.token = location.hash.split('/')[5];

        this.reason = location.hash.split('/')[4];

        this.fetchTender();
    }

    fetchTender() {
        console.info('this.token: ', this.token);
        this.http.get(this.url.urls.outSideCtrl.fetch, ({
            'ACCESS-TOKEN': this.token,
            'Accept': 'application/json',
        }))
            .subscribe(
                res => {
                    this.response2 = res;
                    console.info('response2! ', this.response2);

                    this.info.tender = this.response2.tender;
                    this.info.bid = this.response2.bid;
                    this.info.customVendor = this.response2.customVendor;
                    this.info.vendorCategory = this.response2.vendorCategory;

                    this.info.tender.tenderExpiryDate = new Date(this.response2.tender.tenderExpiryDate).toLocaleString();
                    this.info.tender.tenderStartDate = new Date(this.response2.tender.tenderStartDate).toLocaleString();
                    this.info.tender.tenderDeliveryDate = new Date(this.response2.tender.tenderDeliveryDate).toLocaleString();

                    // console.info(this.response2);

                    if (this.info.tender.preQualificationQuestionnaireStatus) {
                        this.info.tender.preQualificationQuestionnaireStatus = 'Yes';
                    } else {
                        this.info.tender.preQualificationQuestionnaireStatus = 'No';
                    }

                    if (this.response2.bid == null) {
                        // this.info.bidAmountView = this.info.bid.bidAmounts[0].bidAmount;
                    } else {
                        this.info.bidAmountView = this.response2.bid.latestBidAmount.bidAmount;
                    }

                    this.timerTime = new Date(this.info.tender.tenderExpiryDate);

                    // let day = this.info.tender.tenderExpiryDate.getDate();
                    // let day = this.info.tender.tenderExpiryDate.getDate();
                    //
                    //
                    // console.info('this.timerTime: ', this.timerTime);
                    // console.info('new Date(this.info.tender.tenderExpiryDate): ', new Date(this.info.tender.tenderExpiryDate).getDate());

                    if (this.response2.bid != null) {
                        if (this.response2.bid.bidAmounts != null) {
                            this.info.bidAmountView = this.info.bid.bidAmounts[0].bidAmount;

                        }
                    }

                    /** bidingType */
                    if (this.info.tender.bidingType == 1) {
                        this.stringData.bidingType = 'RFQ';
                    }
                    if (this.info.tender.bidingType == 2) {
                        this.stringData.bidingType = 'Auction';
                    }
                    if (this.info.tender.bidingType == 3) {
                        this.stringData.bidingType = 'Ranked';
                    }

                    /** tenderType */
                    if (this.info.tender.tenderType == 1) {
                        this.stringData.tenderType = 'Contractual';
                    }
                    if (this.info.tender.tenderType == 2) {
                        this.stringData.tenderType = 'Spot';
                    }
                    if (this.info.tender.tenderType == 3) {
                        this.stringData.tenderType = 'Fixed';
                    }

                    /** tenderCategory */
                    if (this.info.tender.tenderCategory == 1) {
                        this.stringData.tenderCategory = 'Sell';
                    }
                    if (this.info.tender.tenderCategory == 2) {
                        this.stringData.tenderCategory = 'Buy';
                    }

                    $('#future_date').countdowntimer({
                        dateAndTime: this.info.tender.tenderExpiryDate,
                        size: 'lg',
                        regexpMatchFormat: '([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2})',
                        regexpReplaceWith: '$1<sup>days</sup> / $2<sup>hours</sup> / $3<sup>minutes</sup> / $4<sup>seconds</sup>',
                    });

                    if (this.info.bid != null) {
                        this.showCounter();
                    }
                    this.fetchBid();
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchBid() {
        // tslint:disable
        if (this.info.tender.tenderCategory == 1 && this.info.tender.bidingType == 2) {
            this.fetchHighestBid();
        }
        else if (this.info.tender.tenderCategory == 2 && this.info.tender.bidingType == 2) {
            this.fetchLowestBid();
        }
        // tslint:enable
    }

    fetchLowestBid() {

        this.http.get(this.url.urls.outSideCtrl.fetchLowestAmt.replace('{customVendorId}', this.info.customVendor.customVendorId)
                .replace('{tenderId}', this.info.tender.tenderId),
            ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.responseLowestBid = res;
                    console.info('fetchLowestBid ', this.responseLowestBid.lowestBid);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchHighestBid() {

        this.http.get(this.url.urls.outSideCtrl.fetchHighestAmt.replace('{customVendorId}', this.info.customVendor.customVendorId)
                .replace('{tenderId}', this.info.tender.tenderId),
            ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.responseHighestBid = res;
                    console.info('fetchHighestBid ', this.responseHighestBid.highestBid);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchRank() {
        // tslint:disable
        if (this.info.tender.tenderCategory == 1 && this.info.tender.bidingType == 3) {
            this.fetchHighestRank();
        }
        else if (this.info.tender.tenderCategory == 2 && this.info.tender.bidingType == 3) {
            this.fetchLowestRank();
        }
        // tslint:enable
    }

    fetchHighestRank() {

        this.http.get(this.url.urls.outSideCtrl.fetchHighestRank.replace('{customVendorId}', this.info.customVendor.customVendorId)
                .replace('{tenderId}', this.info.tender.tenderId).replace('{bidAmount}', this.info.bidAmountView),
            ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.response = res;
                    console.info('fetchHighestRank ', this.response);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchLowestRank() {

        this.http.get(this.url.urls.outSideCtrl.fetchLowestRank.replace('{customVendorId}', this.info.customVendor.customVendorId)
                .replace('{tenderId}', this.info.tender.tenderId).replace('{bidAmount}', this.info.bidAmountView),
            ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.response = res;
                    console.info('fetchLowestRank ', this.response.lowestBidRank);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    create() {
        this.btn.createBtn = true;
        if (this.info.tender.tenderType == 3 && this.bid.agreeWithFixedAmount == true) {
            this.bid = {
                agreeWithFixedAmount: true,
                bidAmounts: [
                    {
                        bidAmount: null,
                    },
                ],
                fixedBidAmount: this.info.tender.fixedBidAmount,
            };
            this.http.post(this.url.urls.outSideCtrl.create.replace('{customVendorId}', this.info.customVendor.customVendorId)
                    .replace('{tenderId}', this.info.tender.tenderId).replace('{vendorCategory}', this.info.vendorCategory),
                this.bid, ({
                    'ACCESS-TOKEN': this.token,
                    'Accept': 'application/json',
                }))
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.response = res;
                        this.http.successToast(null, 'Your bids successfully places');
                    },
                    err => {
                        console.info('Error occurred ', err);
                        this.btn.createBtn = false;
                        this.http.errorToast(err);
                    },
                );
        }
        if (this.info.tender.tenderType != 3) {
            this.bid = {
                agreeWithFixedAmount: false,
                bidAmounts: [
                    {
                        bidAmount: this.info.bidAmountView,
                    },
                ],
                fixedBidAmount: null,
            };
            this.http.post(this.url.urls.outSideCtrl.create.replace('{customVendorId}', this.info.customVendor.customVendorId)
                    .replace('{tenderId}', this.info.tender.tenderId).replace('{vendorCategory}', this.info.vendorCategory),
                this.bid, ({
                    'ACCESS-TOKEN': this.token,
                    'Accept': 'application/json',
                }))
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.response = res;
                        this.http.successToast(null, 'Your bids successfully places');
                    },
                    err => {
                        console.info('Error occurred ', err);
                        this.btn.createBtn = false;
                        this.http.errorToast(err);
                    },
                );
        }

    }

    update() {
        this.btn.updateBtn = false;
        this.http.put(this.url.urls.outSideCtrl.update
            .replace('{customVendorId}', this.info.customVendor.customVendorId).replace('{tenderId}', this.info.tender.tenderId)
            .replace('{bidId}', this.info.bid.bidId).replace('{bidAmount}', this.info.bidAmountView).replace('{vendorCategory}', this.info.vendorCategory), null, ({
            'ACCESS-TOKEN': this.token,
            'Accept': 'application/json',
        }))
            .subscribe(
                res => {
                    console.info('Successfully Done! ', res);
                    this.response = res;
                    this.http.successToast(null, 'Your bids successfully updated');
                },
                err => {
                    console.info('Error occurred ', err);
                    this.btn.updateBtn = false;
                    this.http.errorToast(err);
                },
            );
    }

    createCounter() {
        // this.counter.message = 'I am giving you a offer of ' + this.counter.amount + '.';
        this.http.post(this.url.urls.outSideCtrl.createCounter.replace('{bidAmount}', this.counter.amount).replace('{message}', this.counter.message),
            null, ({
                'ACCESS-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    this.info = res;
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    acceptCounter() {
        // let offerId = this.chat.counterOffer.offers[this.chat.counterOffer.offers.length - 1].offerId;
        this.http.post(this.url.urls.outSideCtrl.acceptCounter,
            null, ({
                'ACCESS-TOKEN': this.token,
                'OFFER-TOKEN': this.token,
                'Accept': 'application/json',
            }))
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Successfully Done! ', res);
                    this.info = res;
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                },
            );
    }

    showCounter() {
        if (this.info.bid.counterOffer != null) {
            this.chat = this.info.bid;
        } else {
            this.info.bid.counterOffer.offers = [];
        }
    };

    downloadFile(content, type) {
        console.info('downloadFile content ', content);
        console.info('downloadFile type ', type);
        // var blob = new Blob([content], {type: type});
        // console.info('blob', blob);
        // var url = window.URL.createObjectURL(blob);
        let url = type + ';base64,' + content;
        console.info('url', url);
        window.open(url, '_blank');
    }

    validator() {
        if (this.info.tender.tenderCategory == 1) {
            if ((this.info.tender.bidThreshold + this.info.tender.bidIncrementAmount) > this.info.bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        if (this.info.tender.tenderCategory == 2) {
            if ((this.info.tender.bidThreshold - this.info.tender.bidDecrementAmount) < this.info.bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

    validator2() {
        if (this.info.tender.tenderCategory == 1) {
            if ((this.responseHighestBid.highestBid + this.info.tender.bidIncrementAmount) > this.info.bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
        if (this.info.tender.tenderCategory == 2) {
            if ((this.responseLowestBid.lowestBid - this.info.tender.bidDecrementAmount) < this.info.bidAmountView) {
                return this.btn.validate = true;
            } else {
                return this.btn.validate = false;
            }
        }
    }

}
