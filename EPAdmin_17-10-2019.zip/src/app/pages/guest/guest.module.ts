import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {Ng4GeoautocompleteModule} from 'ng4-geoautocomplete';

import {ServiceModule} from '../../@core/service/service.module';
import {GuestRoutes} from './guest.routing';
import {DemoComponent} from './demo/demo.component';
import {WelcomeComponent} from './welcome/welcome.component';
import {NotInterestedComponent} from './not-intrested/not-intersted.component';
import {BadUserComponent} from './bad-user/bad-user.component';
import {TagInputModule} from 'ngx-chips';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {VendorProfileComponent} from './vender-profile/vendor-profile.component';
import {NgaModule} from '../../theme/nga.module';
import {ViewTenderComponent} from './view-tender/view-tender.component';

@NgModule({
  imports: [
    CommonModule,
    NgaModule,
    RouterModule.forChild(GuestRoutes),
    FormsModule,
    ReactiveFormsModule,
    ServiceModule,
    Ng4GeoautocompleteModule.forRoot(),
    TagInputModule,
    Ng2OrderModule,
  ],
  declarations: [
    DemoComponent,
    WelcomeComponent,
    NotInterestedComponent,
    BadUserComponent,
    VendorProfileComponent,
    ViewTenderComponent,

  ],
  providers: [],
})

export class GuestModule {
}
