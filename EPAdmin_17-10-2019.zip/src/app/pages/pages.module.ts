import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {routing} from './pages.routing';
import {NgaModule} from '../theme/nga.module';
import {AppTranslationModule} from '../app.translation.module';

import {AdminLayoutComponent} from '../@core/layouts/admin/admin-layout.component';
import {AuthLayoutComponent} from '../@core/layouts/auth/auth-layout.component';
import {DirectiveModule} from '../@core/directives/directive.module';
import {NotificationComponent} from './notification/notification.component';


// import {Pages} from './pages.component';

@NgModule({
    imports: [
        CommonModule,
        AppTranslationModule,
        NgaModule,
        routing,
        DirectiveModule,
    ],
    declarations: [
        AuthLayoutComponent,
        AdminLayoutComponent,
        NotificationComponent
    ],
})
export class PagesModule {
}
