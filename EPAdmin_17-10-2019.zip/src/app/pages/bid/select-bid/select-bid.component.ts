import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../../@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {SessionService} from '../../../@core/service/session.service';
import {PathService} from '../../../@core/service/path.service';
import {WebsocketService} from '../../../@core/service/websocket.service';


declare let $: any;

@Component({
    selector: 'app-select-bid',
    templateUrl: './select-bid.component.html',
    styleUrls: ['./select-bid.component.sass', './test.scss'],
})
export class SelectBidComponent implements OnInit {
    public hideBidHistory: any = true;

    public startTender: any = {
        'tenderExpiryDate': null,
        'tenderStartDate': null,
        'tunnelType': null,
        'leftTime': null
    };


    public tab: number = 1;
    public config: any = {
        pageUrl: null,
        toggle: true,
    };

    public tableSetting: any = {
        totalRecord: 10,
        filter: '',
    };
    p: Event;

    public counter: any = {
        amount: null,
        message: '',
    };

    public info: any = {
        tenderId: null,
        lineItems: [{
            lineItemId: null,
            bids: [],
            selectedBid: null,
            bidSelector: null,
            agentFeedback: null,
            patronFeedback: null,
            highestBidAmount: null,
            lowestBidAmount: null,
            bidSelectedOn: null,
            lineItemTitle: null,
            material: {
                materialId: null,
                materialName: null,
                hsnCode: null
            },
            deliveryAddresses: [{
                deliveryAddressId: null,
                deliveryDate: null,
                address: null,
                pinCode: null,
                city: null,
                state: null,
                country: null,
                countryCode: null,
                latitude: null,
                longitude: null
            }],
            attachments: [{
                attachmentId: null,
                attachmentFor: null,
                attachmentCategory: null,
                contentType: null,
                tag: null,
                description: null,
                url: null,
                content: null,
                tenderLineItem: {
                    lineItemId: null,
                    lineItemTitle: null
                },
            }],
            participants: [{
                participantsId: null,
                tenderLineItem: {lineItemId: null, lineItemTitle: null},
                participantType: null,
                officialVendor: null,
                customVendor: {customVendorId: null, companyName: null},
                cluster: null,
            }],
            bidDecrementAmount: null,
            bidThreshold: null,
            bidIncrementAmount: null,
            fixedBidAmount: null,
            freight: null,
            quantity: null,
            quantityType: null,
            specificQuantityType: null,
            pricePerUnit: null,
        }],
        tenderTitle: null,
        tenderCategory: null,
        sTenderCategory: null,
        tenderType: null,
        sTenderType: null,
        bidingType: null,
        sBidingType: null,
        timeZone: null,
        specificTimeZone: null,
        currencyType: null,
        specificCurrencyType: null,
        paymentTermsDays: null,
        preQualificationQuestionnaireStatus: false,
        preQualificationQuestionnaireDescription: null,
        description: null,
        isRfqToAuctionConverted: false,
        rfqToAuctionConvertedBy: null,
        rfqToAuctionConvertedOn: null,
        tenderStartDate: null,
        tenderExpiryDate: null,
        tenderFromDate: null,
        tenderToDate: null,
        tenderStatus: null,
        tenderStatusApplyOn: null,
        rfqToAuctionConverted: false
    };

    public bid: any = {
        'agreeWithFixedAmount': true,
        'bidAmounts': [
            {
                'deleted': true,
                'version': 0,
            },
        ],
        'fixedBidAmount': 0,

    };

    public response: any = {};
    public bidsList: any = [];

    public chat: any = {
        counterOffer: {
            counterOfferId: null,
            offers: [],
        },
    };

    public stringData: any = {
        bidingType: null,
        tenderType: null,
        tenderCategory: null,
        justification: ''
    };

    public bidHistory: any = [];
    public auctionExitAmount: any = [];
    public data: any;
    public current: any = new Date();
    public startDate: any;
    public endDate: any;
    public refresh: any;
    public serverCurrentTime: any;
    public raceStatus: any;
    public timeDiff: any;


    constructor(public router: Router, public http: HttpService, public url: UrlService,
                public session: SessionService, public path: PathService, public ws: WebsocketService) {
        this.config.pageUrl = this.path.pageUrl;

        // tslint:disable
        // console.info(this.router.url.split('/')[3]);
        if (this.router.url.split('/')[3] != undefined) {
            if (this.router.url.split('/')[3] > '2') {
                this.tab = 2;
            } else {
                this.tab = parseInt(this.router.url.split('/')[3]);
            }
        } else {
            this.tab = 1;
        }
        // tslint:enable
    }

    ngOnInit() {
        this.fetchTender();
    }

    fetchTender() {
        // console.info('fetchTender Called!');
        this.http.get(this.url.urls.tenderCtrl.fetch
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Successfully Done! ', res);
                    this.info = res;

                    this.startDate = new Date(this.info.tenderStartDate);
                    this.endDate = new Date(this.info.tenderExpiryDate);
                    //
                    // // Timer
                    this.time();

                    this.info.tenderExpiryDate = new Date(this.info.tenderExpiryDate).toLocaleString();
                    this.info.tenderStartDate = new Date(this.info.tenderStartDate).toLocaleString();
                    this.info.tenderFromDate = new Date(this.info.tenderFromDate).toLocaleString();
                    this.info.tenderToDate = new Date(this.info.tenderToDate).toLocaleString();

                    /** bidingType */
                    if (this.info.bidingType == 1) {
                        this.stringData.bidingType = 'RFQ';
                    }
                    if (this.info.bidingType == 2) {
                        this.stringData.bidingType = 'Auction';
                    }
                    if (this.info.bidingType == 3) {
                        this.stringData.bidingType = 'Ranked';
                    }

                    /** tenderType */
                    if (this.info.tenderType == 1) {
                        this.stringData.tenderType = 'Contractual';
                    }
                    if (this.info.tenderType == 2) {
                        this.stringData.tenderType = 'Spot';
                    }
                    if (this.info.tenderType == 3) {
                        this.stringData.tenderType = 'Fixed';
                    }
                    /** tenderCategory */
                    if (this.info.tenderCategory == 1) {
                        this.stringData.tenderCategory = 'Sell';
                    }
                    if (this.info.tenderCategory == 2) {
                        this.stringData.tenderCategory = 'Buy';
                    }


                    /** Questionnaire */
                    if (this.info.preQualificationQuestionnaireStatus) {
                        this.info.preQualificationQuestionnaireStatus = 'Yes';
                    } else {
                        this.info.preQualificationQuestionnaireStatus = 'No';
                    }
                    /** advancePayment */
                    if (this.info.advancePayment) {
                        this.info.advancePayment = 'Yes';
                    } else {
                        this.info.advancePayment = 'No';
                    }

                    this.swapMaterial(0);
                    this.wsHello();


                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }

    wsHello() {
        this.ws.disconnect();
        this.ws.connect(this.ready);
    }

    ready = () => {
        window.setTimeout(() => {

            this.ws.subscribe('/tunnel/v1/extendTender/{tenderId}'
                    .replace('{tenderId}', this.session.getTenderId())
                , {}, (frame) => {
                    this.startTender = this.ws.getBody(frame);
                    this.startDate = new Date(this.startTender.tenderStartDate);
                    this.endDate = new Date(this.startTender.tenderExpiryDate);
                    this.refresh = true;
                    this.time();
                });

            this.info.lineItems.forEach((value, key) => {
                if (this.info.tenderType != 3) {
                    this.ws.subscribe('/tunnel/v1/bids/{tenderId}/{lineItemId}'
                            .replace('{tenderId}', this.info.tenderId)
                            .replace('{lineItemId}', value.lineItemId)
                        , {}, (frame) => {
                            // this.subPart.bids = this.ws.getBody(frame).bids;
                            this.info.lineItems[key]['bids'] = this.ws.getBody(frame).bids;
                            this.clickedMaterial = key;
                            if (this.info.lineItems[key].bids.length != 0) {
                                this.bidsList = this.info.lineItems[key].bids.filter(task => task.bidStatus != 'EXITED');
                                this.auctionExitAmount = this.info.lineItems[key].bids.filter(task => task.bidStatus == 'EXITED');
                                this.bidChecking();
                            }
                        });
                }

                if (this.info.tenderType == 3) {
                    this.ws.subscribe('/tunnel/v1/fix/bid/{tenderId}/{lineItemId}'
                            .replace('{tenderId}', this.info.tenderId)
                            .replace('{lineItemId}', value.lineItemId)
                        , {}, (frame) => {
                            this.info.lineItems[key]['bids'] = this.ws.getBody(frame).bids;
                            if (this.info.lineItems[key].bids.length != 0) {
                                this.bidsList = this.info.lineItems[key].bids.filter(task => task.bidStatus != 'EXITED');
                                this.auctionExitAmount = this.info.lineItems[key].bids.filter(task => task.bidStatus == 'EXITED');
                            }
                        });
                }
            });
            this.ws.subscribe('/tunnel/v1/closedTender/{tenderId}'
                    .replace('{tenderId}', this.info.tenderId)
                , {}, (frame) => {
                    // this.http.refresh();
                    this.raceStatus = 2;
                });

            this.ws.subscribe('/tunnel/v1/selectBid/refresh/tender/{tenderId}'
                    .replace('{tenderId}', this.info.tenderId)
                , {}, (frame) => {
                    this.info = this.ws.getBody(frame).tender;
                    this.info.tenderExpiryDate = new Date(this.info.tenderExpiryDate).toLocaleString();
                    this.info.tenderStartDate = new Date(this.info.tenderStartDate).toLocaleString();
                    this.info.tenderFromDate = new Date(this.info.tenderFromDate).toLocaleString();
                    this.info.tenderToDate = new Date(this.info.tenderToDate).toLocaleString();
                    /** bidingType */
                    if (this.info.bidingType == 1) {
                        this.stringData.bidingType = 'RFQ';
                    }
                    if (this.info.bidingType == 2) {
                        this.stringData.bidingType = 'Auction';
                    }
                    if (this.info.bidingType == 3) {
                        this.stringData.bidingType = 'Ranked';
                    }
                    this.swapMaterial(0);
                    this.startDate = new Date(this.info.tenderStartDate);
                    this.endDate = new Date(this.info.tenderExpiryDate);
                    // this.refresh = true;
                    this.time();
                });
        }, 500);
    };

    beforeSelectBid(status, data?) {
        // console.info('beforeSelectBid', status);
        if (status) {
            this.stringData.justification = '';
            this.selectBid(data);
        } else {
            this.data = data;
            $('#selectBidJustification').modal();
        }
    }

    selectBid(data) {
        if (data.counterOffer != null) {
            if (data.counterOffer.acceptedOffer != null) {
                let offerId = data.counterOffer.acceptedOffer.offerId;
                this.http.post(this.url.urls.counterOfferCtrl.confirmPatron
                        .replace('{vendorId}', this.session.getVendorId())
                        .replace('{userId}', this.session.getUserId())
                        .replace('{tenderId}', this.session.getTenderId())
                        .replace('{tenderLineItemId}', this.subPart.lineItemId)
                        .replace('{bidId}', this.session.getBidId())
                        .replace('{counterOfferId}', data.counterOffer.counterOfferId)
                        .replace('{offerId}', offerId),
                    null, null)
                    .subscribe(
                        res => {
                            this.http.sLoaderSwitch(false);
                            this.http.successToast('', 'Counter offer has been successfully selected');
                            $('#selectBidJustification').modal('hide');
                            this.router.navigateByUrl(this.config.pageUrl.bid.selectIdx.two);


                        },
                        err => {
                            this.http.sLoaderSwitch(false);
                            // console.info('Error occurred ', err);
                        },
                    );
            }
            else {
                this.http.areYouSure('Select Bid', () => {
                    this.http.get(this.url.urls.bidCtrl.selectBidJustification
                            .replace('{vendorId}', this.session.getVendorId())
                            .replace('{userId}', this.session.getUserId())
                            .replace('{tenderId}', this.info.tenderId)
                            .replace('{lineItemId}', this.subPart.lineItemId)
                            .replace('{bidId}', this.session.getBidId())
                            .replace('{justification}', this.stringData.justification)
                        , null)
                        .subscribe(
                            res => {
                                $('#selectBidJustification').modal('hide');
                                this.http.sLoaderSwitch(false);
                                this.http.successToast(null, 'Bid has been successfully selected!');
                                this.router.navigateByUrl(this.config.pageUrl.bid.selectIdx.two);
                            },
                            err => {
                                this.http.sLoaderSwitch(false);
                                this.http.errorToast(err);
                            },
                        );
                }, null);
            }
        }
        else {
            this.http.areYouSure('Select Bid', () => {
                this.http.get(this.url.urls.tenderCtrl.selectBid
                        .replace('{userId}', this.session.getUserId())
                        .replace('{tenderId}', this.info.tenderId)
                        .replace('{lineItemId}', this.subPart.lineItemId)
                        .replace('{bidId}', this.session.getBidId())
                        .replace('{justification}', this.stringData.justification)
                    , null)
                    .subscribe(
                        res => {
                            $('#selectBidJustification').modal('hide');
                            this.http.sLoaderSwitch(false);
                            this.http.successToast(null, 'Bid has been successfully selected!');

                            // this.tab = 2;
                            // this.http.refresh();
                            this.router.navigateByUrl(this.config.pageUrl.bid.selectIdx.two);
                        },
                        err => {
                            this.http.sLoaderSwitch(false);
                            this.http.errorToast(err);
                        },
                    );
            }, null);
        }
    }

    showCounter(index, low?) {
        if (this.bidsList[index].counterOffer != null) {
            this.chat = this.bidsList[index];
            this.chat.counterOffer['low'] = low;
            // console.info('showCounter', this.chat.counterOffer.low);
        } else {
            this.bidsList[index].counterOffer = {
                offers: []
            };
            this.chat = this.bidsList[index];
        }
    };

    createPatron() {
        // this.counter.message = 'I am giving you a offer of ' + this.counter.amount + '.';
        this.http.post(this.url.urls.counterOfferCtrl.createPatron
                .replace('{vendorId}', this.session.getVendorId())
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
                .replace('{tenderLineItemId}', this.subPart.lineItemId)
                .replace('{bidId}', this.session.getBidId())
                .replace('{bidAmount}', this.counter.amount)
                .replace('{message}', this.counter.message),
            null, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.http.successToast(null, 'Counter offer successfully created ');
                    // this.info = res;
                    $('#counterOfferModal').modal('hide');
                    this.router.navigateByUrl('bid/select');
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    acceptPatron(offerId) {
        // let offerId = this.chat.counterOffer.offers[this.chat.counterOffer.offers.length - 1].offerId;

        this.http.post(this.url.urls.counterOfferCtrl.acceptPatron
                .replace('{vendorId}', this.session.getVendorId())
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
                .replace('{tenderLineItemId}', this.subPart.lineItemId)
                .replace('{bidId}', this.session.getBidId())
                .replace('{counterOfferId}', this.chat.counterOffer.counterOfferId)
                .replace('{offerId}', offerId),
            null, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.http.successToast('', 'Counter offer has been successfully accepted');
                    this.bidChecking();
                    this.router.navigateByUrl('bid/select');
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                },
            );
    }

    confirmPatron() {
        let offerId = this.chat.counterOffer.offers[this.chat.counterOffer.offers.length - 1].offerId;
        console.info('select Bid', offerId);

        this.http.post(this.url.urls.counterOfferCtrl.confirmPatron
                .replace('{vendorId}', this.session.getVendorId())
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
                .replace('{tenderLineItemId}', this.subPart.lineItemId)
                .replace('{bidId}', this.session.getBidId())
                .replace('{counterOfferId}', this.chat.counterOffer.counterOfferId)
                .replace('{offerId}', offerId),
            null, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Successfully Done! ', res);
                    this.router.navigateByUrl('tender/success');
                    // this.info = res;

                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                },
            );
    }

    //tslint:disable

    public clickedMaterial: any = 0;
    public subPart: any = {
        'lineItemId': null,
        'bids': [],
        'selectedBid': null,
        'bidSelector': null,
        'agentFeedback': null,
        'patronFeedback': null,
        'highestBidAmount': null,
        'lowestBidAmount': null,
        'bidSelectedOn': null,
        'lineItemTitle': null,
        'material': {
            'materialId': null,
            'materialName': null,
            'hsnCode': null
        },
        'deliveryAddresses': [
            {
                'deliveryAddressId': null,
                'deliveryDate': null,
                'address': null,
                'pinCode': null,
                'city': null,
                'state': null,
                'country': null,
                'countryCode': null,
                'latitude': null,
                'longitude': null,
                'tenderLineItem': {
                    'lineItemId': null,
                    'lineItemTitle': null
                }
            }
        ],
        'attachments': [],
        'participants': [
            {
                'participantsId': null,
                'tenderLineItem': {
                    'lineItemId': null,
                    'lineItemTitle': null
                },
                'participantType': null,
                'officialVendor': null,
                'customVendor': {
                    'customVendorId': null,
                    'companyName': null
                },
                'cluster': null,
                'conducted': null,
                'conductedOn': null,
                'creator': {
                    'userAccountId': null,
                    'firstName': null,
                    'lastName': null
                },
                'created': null
            }
        ],
        'bidDecrementAmount': null,
        'bidThreshold': null,
        'bidIncrementAmount': null,
        'fixedBidAmount': null,
        'freight': null,
        'quantity': null,
        'quantityType': null,
        'specificQuantityType': null,
        'pricePerUnit': null,
        'creator': {
            'userAccountId': null,
            'firstName': null,
            'lastName': null
        },
        'created': null,
        'changer': null,
        'changed': null
    };


    swapMaterial(index) {
        this.clickedMaterial = index;
        this.subPart = this.info.lineItems[index];

        if (this.subPart.bids.length != 0) {
            this.bidsList = this.subPart.bids.filter(task => task.bidStatus != 'EXITED');
            this.auctionExitAmount = this.subPart.bids.filter(task => task.bidStatus == 'EXITED');
        }
        this.subPart.deliveryAddresses[0].deliveryDate = new Date(this.subPart.deliveryAddresses[0].deliveryDate).toLocaleString();

        if (this.info.tenderType != 3) {
            this.bidChecking();
        }
    }

    bidChecking() {
        // Sell | Max
        if (this.info.tenderCategory === 1 || this.info.tenderCategory === '1') {

            // let maximum = Math.max.apply(Math, this.info.lineItems[this.clickedMaterial].bids.map(function (item) {
            let maximum = Math.max.apply(Math, this.bidsList.map(function (item) {
                // if (item.counterOffer != null) {
                //     if (item.counterOffer.acceptedOffer != null) {
                //         return item.counterOffer.acceptedOffer.bidAmount;
                //     }
                // }
                // else {
                return item.latestBidAmount.bidAmount;
                // }
            }));

            let i = null;

            // this.subPart.bids.forEach(value => {
            // this.info.lineItems[this.clickedMaterial].bids.forEach(value => {
            this.bidsList.forEach(value => {
                // if (value.counterOffer != null) {
                //     if (value.counterOffer.acceptedOffer != null) {
                //         if(value.counterOffer.acceptedOffer.bidAmount > value.latestBidAmount.bidAmount) {
                //             value.low = value.counterOffer.acceptedOffer.bidAmount === maximum;
                //             i = i + value.counterOffer.acceptedOffer.bidAmount;
                //         }
                //     }
                // } else {
                value.low = value.latestBidAmount.bidAmount === maximum;
                i = i + value.latestBidAmount.bidAmount;
                // }
            });

            let average = Math.round.apply(Math, this.info.lineItems[this.clickedMaterial].bids.map(function (item) {
                return true;
            }));
        }
        // Buy | Min
        if (this.info.tenderCategory === 2 || this.info.tenderCategory === '2') {
            // let minimum = Math.min.apply(Math, this.info.lineItems[this.clickedMaterial].bids.map(function (item) {
            let minimum = Math.min.apply(Math, this.bidsList.map(function (item) {
                if (item.counterOffer != null) {
                    if (item.counterOffer.acceptedOffer != null) {
                        return item.counterOffer.acceptedOffer.bidAmount;
                    }
                    else {
                        return item.latestBidAmount.bidAmount;
                    }
                }
                else {
                    return item.latestBidAmount.bidAmount;
                }
            }));

            let i = null;

            // this.info.lineItems[this.clickedMaterial].bids.forEach(value => {
            this.bidsList.forEach(value => {
                if (value.counterOffer != null) {
                    if (value.counterOffer.acceptedOffer != null) {
                        if (value.counterOffer.acceptedOffer.bidAmount < value.latestBidAmount.bidAmount) {
                            value.low = value.counterOffer.acceptedOffer.bidAmount === minimum;
                            i = i + value.counterOffer.acceptedOffer.bidAmount;
                            this.chat.counterOffer['low'] = value.low;
                        }
                    }
                    else {
                        value.low = value.latestBidAmount.bidAmount === minimum;
                        i = i + value.latestBidAmount.bidAmount;
                    }
                }
                else {
                    value.low = value.latestBidAmount.bidAmount === minimum;
                    i = i + value.latestBidAmount.bidAmount;
                }
            });

            let average = Math.round.apply(Math, this.info.lineItems[this.clickedMaterial].bids.map(function (item) {
                return true;
            }));
        }
    }

    viewHistory(index) {
        this.bidHistory = this.bidsList[index];
        $('#bidHistoryModal').modal();
    }

    auctionExit() {
        $('#auctionExitModal').modal();
    }

    downloadFile(content, type) {
        // console.info('downloadFile content ', content);
        // console.info('downloadFile type ', type);
        // var blob = new Blob([content], {type: type});
        // console.info('blob', blob);
        // var url = window.URL.createObjectURL(blob);
        var url = type + ';base64,' + content;
        // console.info('url', url);
        window.open(url, '_blank');
    }

    back() {
        this.config.toggle = true;
        this.counter = {
            amount: null,
            message: '',
        };
    }

    toggleBack() {
        // this.config.toggle = true;
        this.counter = {
            amount: null,
            message: '',
        };
    }

    // Timer
    time() {
        this.http.get(this.url.urls.genericCtrl.currentTime
            , ({
                'Accept': 'application/json',
            }))
            .subscribe(
                res1 => {
                    // let t = new Date(res1.currentTime).toLocaleString();
                    // this.serverCurrentTime = new Date(t);

                    // this.startDate = new Date(this.response2.tender.tenderStartDate);
                    // this.endDate = new Date(this.response2.tender.tenderExpiryDate);
                    this.serverCurrentTime =  new Date(res1.currentTime);
                    let d1 = Date.parse(this.serverCurrentTime);
                    let d2 = Date.parse(this.startDate);
                    let d3 = Date.parse(this.endDate);
                    if (d1 < d2) {
                        this.raceStatus = 0;
                        this.refresh = true;
                        this.timeDiff = Math.abs(this.current.getTime() - this.startDate.getTime());

                    }
                    else if (d2 < d3 && d3 > d1) {
                        this.raceStatus = 1;
                        this.refresh = true;
                        this.timeDiff = Math.abs(this.startDate.getTime() - this.endDate.getTime());

                    }
                    else if (d3 < d1) {
                        this.raceStatus = 2;
                        this.refresh = true;

                    }
                });
    }

}
