import { Component } from '@angular/core';

@Component({
  selector: 'app-bid',
  template: `<router-outlet></router-outlet>`,
})
export class BidComponent {
}
