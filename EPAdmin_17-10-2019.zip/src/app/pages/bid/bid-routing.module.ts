import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {BidComponent} from './bid.component';
import {SelectBidComponent} from './select-bid/select-bid.component';

const routes: Routes = [{
    path: '',
    component: BidComponent,
    children: [
        {
            path: 'select/:id',
            component: SelectBidComponent,
        },
    ],
}];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class BidRoutingModule {
}

export const routedComponents = [
    BidComponent,
    SelectBidComponent
];
