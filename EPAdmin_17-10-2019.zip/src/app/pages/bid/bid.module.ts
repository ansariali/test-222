import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {CommonModule} from '@angular/common';
import {ServiceModule} from '../../@core/service/service.module';
import {BidRoutingModule, routedComponents} from './bid-routing.module';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2PaginationModule} from 'ng2-pagination';
import {TooltipModule} from 'ng2-tooltip';
import {AsciiPipe} from '../../@core/pipe/ascii.pipe';
import {PipeModule} from '../../@core/pipe/pipe.module';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {CommonComponentModule} from '../../@core/components/commonComponent.module';

@NgModule({
    imports: [
        CommonModule,
        BidRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        ServiceModule,
        Ng2PaginationModule,
        Ng2SearchPipeModule,
        TooltipModule,
        PipeModule,
        DirectiveModule,
        Ng2OrderModule,
        NgbTooltipModule,
        Ng2OrderModule,
        CommonComponentModule
    ],
    declarations: [
        ...routedComponents,
    ],
    providers: [],
})
export class BidModule {
}
