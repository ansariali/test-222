import {Component, OnInit} from '@angular/core';
import {HttpService} from '../../@core/service/http.service';
import {SessionService} from '../../@core/service/session.service';
import {UrlService} from '../../@core/service/url.service';
import {PathService} from '../../@core/service/path.service';

@Component({
    moduleId: module.id,
    selector: 'invite-cmp',
    templateUrl: 'invite.component.html',
})

export class InviteComponent implements OnInit {
    public config: any = {
        pageUrl: null,
        btnClicked: false
    };

    public tableSetting: any = {
        totalRecord: 10,
        filter: '',
    };
    p: Event;

    public userRole: any;

    public inviteInfo: any = {
        'emailAddress': null,
        'userRole': null,
        'personName': null,
    };

    public traveller = {
        inviteInfo: {
            'emailAddress': null,
            'userRole': null,
            'invitedProductOfIt': [
                {
                    'productMaster': {
                        'productId': 2,
                        'productName': 'EazeProcure',
                    },
                    'targetedBranchId': null,
                    'userRole': null,
                    'companyName': null,
                },
            ],
        },
        spinner: {
            userRole: [
                'SUPER-ADMIN',
                'ADMIN',
                'MANAGER',
                'EMPLOYEE',
                'WATCHER',
            ],
        },
        invitedUsers: [],
    };

    public response: any = {
        invitations: [],
    };
    public gResponse: any;

    constructor(private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
    }

    ngOnInit() {
        $('.form-control').each(function () {

            $(this).focus(function () {
                $(this).parent().addClass('focused');
            });

            $(this).focusout(function () {
                $(this).parent().removeClass('focused');
            });

            function emptyListener($this) {
                requestAnimationFrame(function () {
                    emptyListener($this);
                });

                if ($this.val() === '' || $this.val() === null) {
                    $this.parent().removeClass('is-completed');
                    $this.parent().removeClass('is-active');
                } else {
                    $this.parent().addClass('is-active is-completed');
                }
            }

            emptyListener($(this));
        });
        console.info('this.session.getUserId(): ', this.session.getUserId());
        this.userRole = this.session.getUserRole();
        // this.userRole = 'ADMIN';
        this.fetchInvitedUser();
        /*
                if (this.session.getUserRole() === 'PROMOTER') {
                    this.traveller.spinner.userRole.push(
                        'SUPER-ADMIN',
                        'ADMIN',
                        'MANAGER',
                        'EMPLOYEE',
                        'WATCHER',
                    );
                }
                else if (this.session.getUserRole() === 'SUPER-ADMIN') {
                    this.traveller.spinner.userRole.push(
                        'ADMIN',
                        'MANAGER',
                        'EMPLOYEE',
                        'WATCHER',
                    );
                }
                else if (this.session.getUserRole() === 'ADMIN') {
                    this.traveller.spinner.userRole.push(
                        'MANAGER',
                        'EMPLOYEE',
                        'WATCHER',
                    );
                }
                else if (this.session.getUserRole() === 'MANAGER') {
                    this.traveller.spinner.userRole.push(
                        'EMPLOYEE',
                        'WATCHER',
                    );
                }
                else if (this.session.getUserRole() === 'EMPLOYEE') {
                    this.traveller.spinner.userRole.push(
                        'WATCHER',
                    );
                }
                else {
                    this.traveller.spinner.userRole.push(
                        'None',
                    );
                }*/
    }

    fetchInvitedUser() {
        this.http.get(this.url.urls.invitationCtrl.fetchInvitedUser
                .replace('{vendorId}', this.session.getVendorId())
                .replace('{userId}', this.session.getUserId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.response = res;
                    console.info('fetchInvitedUser Done! ', this.response);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }

    submit() {
        this.config.btnClicked = true;

        this.http.post(this.url.urls.invitationCtrl.create
                .replace('{vendorId}', this.session.getVendorId())
                .replace('{userId}', this.session.getUserId())
                .replace('{personName}', this.inviteInfo.personName)
                .replace('{emailAddress}', this.inviteInfo.emailAddress)
                .replace('{userRole}', this.inviteInfo.userRole)
            , null, null)
            .subscribe(
                res => {
                    this.config.btnClicked = false;
                    this.http.sLoaderSwitch(false);
                    this.gResponse = res;
                    console.info('this.gResponse Done! ', this.gResponse);
                    this.fetchInvitedUser();
                },
                err => {
                    this.config.btnClicked = false;
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    /* fetchInvitedUser() {
         inviteCtrl.fetchInvitedUser()
             .then(function (response) {
                 angular.extend(this.traveller.invitedUsers, angular.fromJson(response));
             });
     }

     submit() {
         this.traveller.inviteInfo.invitedProductOfIt[0].userRole = this.traveller.inviteInfo.userRole;
         // console.log('userAccountFactory requestedData: ' + JSON.stringify(this.traveller.inviteInfo));
         inviteCtrl.create(this.traveller.inviteInfo)
             .then(function (response) {
                 fetchInvitedUser();
             });
     }*/

}
