import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {NgaModule} from '../../theme/nga.module';
import {InviteComponent} from './invite.component';
import {InviteRoutes} from './invite.routing';
import {ServiceModule} from '../../@core/service/service.module';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2OrderModule} from 'ng2-order-pipe';

@NgModule({
    imports: [
        CommonModule,
        NgaModule,
        RouterModule.forChild(InviteRoutes),
        FormsModule,
        ServiceModule,
        Ng2PaginationModule,
        Ng2SearchPipeModule,
        Ng2OrderModule,
    ],
    declarations: [InviteComponent],
})

export class InviteModule {
}
