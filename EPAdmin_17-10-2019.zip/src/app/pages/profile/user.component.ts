import {Component, state, style, animate, transition, trigger, keyframes, OnInit} from '@angular/core';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';

declare var $: any;

@Component({
    moduleId: module.id,
    selector: 'user-cmp',
    templateUrl: 'user.component.html',
    animations: [
        trigger('carduserprofile', [
            state('*', style({
                '-ms-transform': 'translate3D(0px, 0px, 0px)',
                '-webkit-transform': 'translate3D(0px, 0px, 0px)',
                '-moz-transform': 'translate3D(0px, 0px, 0px)',
                '-o-transform': 'translate3D(0px, 0px, 0px)',
                transform: 'translate3D(0px, 0px, 0px)',
                opacity: 1,
            })),
            transition('void => *', [
                style({
                    opacity: 0,
                    '-ms-transform': 'translate3D(0px, 150px, 0px)',
                    '-webkit-transform': 'translate3D(0px, 150px, 0px)',
                    '-moz-transform': 'translate3D(0px, 150px, 0px)',
                    '-o-transform': 'translate3D(0px, 150px, 0px)',
                    transform: 'translate3D(0px, 150px, 0px)',
                }),
                animate('0.3s 0s ease-out'),
            ]),
        ]),
        trigger('cardprofile', [
            state('*', style({
                '-ms-transform': 'translate3D(0px, 0px, 0px)',
                '-webkit-transform': 'translate3D(0px, 0px, 0px)',
                '-moz-transform': 'translate3D(0px, 0px, 0px)',
                '-o-transform': 'translate3D(0px, 0px, 0px)',
                transform: 'translate3D(0px, 0px, 0px)',
                opacity: 1,
            })),
            transition('void => *', [
                style({
                    opacity: 0,
                    '-ms-transform': 'translate3D(0px, 150px, 0px)',
                    '-webkit-transform': 'translate3D(0px, 150px, 0px)',
                    '-moz-transform': 'translate3D(0px, 150px, 0px)',
                    '-o-transform': 'translate3D(0px, 150px, 0px)',
                    transform: 'translate3D(0px, 150px, 0px)',
                }),
                animate('0.3s 0.25s ease-out'),
            ]),
        ]),
    ],
})

export class UserComponent implements OnInit {

    public config: any = {
        pageUrl: null,
    };

    public hasAccess: any;

    public passwordMatch: any = false;

    public info: any = {
        locals: {
            userRole: this.session.getUserRole(),
            userType: null,
            emailAddress: null,
            // userType: 'SC',
            // userRole: 'SUPER-ADMIN',
            btnToggle: null,
        },
        userInfo: {
            userProfile: {
                firstName: null,
                lastName: null,
                userName: null,
                userRole: null,
                emailAddress: null,
                mobileNo: null,
                telephoneNo: null,
                address: null,
                address2: null,
                pinCode: '',
                city: null,
                state: null,
                country: null,
                region: null,
                longitude: null,
                latitude: null,
                vendor: {
                    emailNotificationOn: false,
                    emailNotificationSendOn: null,
                },
            },
            companyProfile: {
                emailAddress: null,
                contactNumber: null,
                telephoneNo: null,
                address1: null,
                address2: null,
                pinCode: null,
                city: null,
                state: null,
                country: null,
                companyName: null,
                panCardNumber: null,
                companyRegistrationNumber: null,
                sendNotificationOn: null,
                notificationsOn: null,
                region: null,
                longitude: null,
                latitude: null,
            },
        },
        changePasswordInfo: {
            currentPassword: null,
            newPassword: null,
            confirmPassword: null,
        },
        notifyInfo: {
            emailAddress: null,
            notify: false,
        },
        moreAddress: [],
        dialog: {
            locals: {
                toggle: null,
                addressId: null,
                defaultAddressId: null,
                defaultCreated: true,
            },
            addressDetail: {
                tag: null,
                address1: null,
                address2: null,
                pinCode: null,
                city: null,
                state: null,
                country: null,
                region: null,
                countryCode: '+91',
            },
        },
    };

    public defaultAddress = {
        defaultAddresses: null,
    };

    public response: any;

    /** PinCode */
    public componentData: any = '';
    public userSettings: any = {
        geoCountryRestriction: ['in'],
        showCurrentLocation: false,
        showSearchButton: false,
        recentStorageName: 'componentData',
        noOfRecentSearchSave: 8,
    };

    autoCompleteCallback1(data: any): any {
        this.info.userInfo.userProfile.pinCode = null;
        this.info.userInfo.userProfile.city = null;
        this.info.userInfo.userProfile.state = null;
        this.info.userInfo.userProfile.country = null;
        this.info.userInfo.userProfile.region = null;
        this.info.userInfo.userProfile.longitude = 0;
        this.info.userInfo.userProfile.latitude = 0;

        this.componentData = JSON.stringify(data);
        this.info.userInfo.userProfile.pinCode = data.address_components[0].long_name;
        this.info.userInfo.userProfile.city = data.address_components[1].long_name;
        this.info.userInfo.userProfile.state = data.address_components[3].long_name;
        this.info.userInfo.userProfile.country = data.address_components[4].long_name;
        this.info.userInfo.userProfile.region = data.address_components[4].short_name + '-' + data.address_components[3].short_name;
        this.info.userInfo.userProfile.longitude = data.geometry.location.lng;
        this.info.userInfo.userProfile.latitude = data.geometry.location.lat;

        // // console.info(this.info.deliveryAddresses[0]);
    }

    autoCompleteCallback2(data: any): any {
        this.info.userInfo.companyProfile.pinCode = null;
        this.info.userInfo.companyProfile.city = null;
        this.info.userInfo.companyProfile.state = null;
        this.info.userInfo.companyProfile.country = null;
        this.info.userInfo.companyProfile.region = null;
        this.info.userInfo.companyProfile.longitude = 0;
        this.info.userInfo.companyProfile.latitude = 0;

        this.componentData = JSON.stringify(data);
        this.info.userInfo.companyProfile.pinCode = data.address_components[0].long_name;
        this.info.userInfo.companyProfile.city = data.address_components[1].long_name;
        this.info.userInfo.companyProfile.state = data.address_components[3].long_name;
        this.info.userInfo.companyProfile.country = data.address_components[4].long_name;
        this.info.userInfo.companyProfile.region = data.address_components[4].short_name + '-' + data.address_components[3].short_name;
        this.info.userInfo.companyProfile.longitude = data.geometry.location.lng;
        this.info.userInfo.companyProfile.latitude = data.geometry.location.lat;

        // // console.info(this.info.deliveryAddresses[0]);
    }

    constructor(private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
    }

    ngOnInit() {


        if (this.session.getUserRole() == 'PROMOTER' || this.session.getUserRole() == 'SUPER-ADMIN') {
            this.hasAccess = true;
        } else {
            this.hasAccess = false;
        }

        this.fetchUserProfile();
        // this.fetchCompanyProfile();


    }

    changePassword() {
        // console.info('changePassword', this.info.changePasswordInfo);
        if (this.passwordMatch) {
            let userName = this.session.getUserName();
            this.http.post(this.url.urls.adminCtrl.changePwd
                    .replace('{userId}', this.session.getUserId())
                , null, ({
                    // 'ACCESS-ID': this.session.getAccessId(),
                    'AUTHORIZATION': btoa(userName + ':' + this.info.changePasswordInfo.currentPassword + ':' + this.info.changePasswordInfo.newPassword),
                    'Accept': 'application/json',
                }))
                .subscribe(
                    res => {
                        this.http.sLoaderSwitch(false);
                        this.http.successToast(null, 'Your password successfully updated');
                        this.http.refresh();
                        // console.info('Successfully Done! ', res);
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                        // console.info('Error occurred ', err);
                        this.http.errorToast(err);
                    },
                );
        }
        else {
            this.http.customErrorToast('New password and old password must be different');
        }
    }

    updateUser() {
        this.http.put(this.url.urls.adminCtrl.updateProfile
            .replace('{userId}', this.session.getUserId()),
            this.info.userInfo.userProfile, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                        if (this.session.getFirstName() !== this.info.userInfo.userProfile.firstName) {
                            this.session.setFirstName(this.info.userInfo.userProfile.firstName);
                        }
                        if (this.session.getLastName() !== this.info.userInfo.userProfile.lastName) {
                            this.session.setLastName(this.info.userInfo.userProfile.lastName);
                        }

                    // console.info('Successfully Done! ', res);
                    this.response = res;
                    this.http.successToast(null, 'Your user profile successfully updated');
                    this.fetchUserProfile();
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                    this.http.errorToast(err);
                },
            );
    }

    fetchUserProfile() {
        this.http.get(this.url.urls.adminCtrl.fetchProfile
            .replace('{userId}', this.session.getUserId()), null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    console.info('Successfully Done! ', res);
                    this.info.userInfo.userProfile = res;

                    $('.one #search_places')[0].value = this.info.userInfo.userProfile.pinCode;

                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                },
            );
    }


    oldPassword() {
        // tslint:disable
        if (this.info.changePasswordInfo.newPassword === this.info.changePasswordInfo.currentPassword) {
            this.passwordMatch = true;
        }
        else {
            this.passwordMatch = false;
        }
        // tslint:enable
    }
}
