import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {UserComponent} from './user.component';
import {UserRoutes} from './user.routing';
import {Ng4GeoautocompleteModule} from 'ng4-geoautocomplete';
import {DirectiveModule} from '../../@core/directives/directive.module';

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(UserRoutes),
        FormsModule,
        Ng4GeoautocompleteModule.forRoot(),
        DirectiveModule
    ],
    declarations: [UserComponent],
})

export class UserModule {
}
