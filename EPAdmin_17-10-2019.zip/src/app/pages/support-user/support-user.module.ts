import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {SupportUserComponent} from './support-user.component';
import {routes} from './support-user.routing';
import {ServiceModule} from '../../@core/service/service.module';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {NgaModule} from '../../theme/nga.module';
import {RouterModule} from '@angular/router';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {Ng2SearchPipeModule} from 'ng2-search-filter';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ServiceModule,
        DirectiveModule,
        NgaModule,
        RouterModule.forChild(routes),
        Ng2PaginationModule,
        Ng2OrderModule,
        Ng2SearchPipeModule,
    ],
    declarations: [
        SupportUserComponent
    ]
})
export class SupportUserModule {
}
