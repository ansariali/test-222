import {Component, OnInit} from '@angular/core';
import {PathService} from '../../@core/service/path.service';
import {UrlService} from '../../@core/service/url.service';
import {HttpService} from '../../@core/service/http.service';
import {SessionService} from '../../@core/service/session.service';

@Component({
    selector: 'app-support-user',
    templateUrl: './support-user.component.html',
    styleUrls: ['./support-user.component.scss']
})
export class SupportUserComponent implements OnInit {

    public genericResponse: any;
    public genericResponseUsername: any;
    public toggle: boolean = false;
    public exist: boolean = false;
    public userNameExist: boolean = false;
    public userNameToggle: boolean = false;

    public btn: any = {
        createUser: false
    };

    public info: any = {
        firstName: null,
        lastName: null,
        userName: null,
        emailAddress: null,
        userRole: null,
        serviceProviderProfile: {
            serviceId: null,
            debugNotificationOn: false,
            sendDebugNotificationOn: null,
            systemNotificationOn: false,
            sendSystemNotificationOn: null,
            supportNotificationOn: false,
            sendSupportNotificationOn: null,
        }
    };

    public response: any = {
        users: []
    };

    public tableSetting: any = {
        totalRecord: 5,
        filter: '',
    };
    p: Event;

    public userRole: any;

    constructor(private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
    }

    ngOnInit() {
        this.userRole = this.session.getUserRole();
        this.fetchUser();
    }

    public validateOnlyEmail(validate) {
        if (validate != null) {
            this.toggle = false;
            this.exist = false;
        }

        if (validate == null) {
            this.http.get(this.url.urls.genericCtrl.validateOnlyEmail
                    .replace('{emailAddress}', this.info.emailAddress),
                ({
                    'Accept': 'application/json',
                }),
            )
                .subscribe(
                    res => {
                        // console.info('Successfully Done! ', res);
                        this.genericResponse = res;
                        if (!this.genericResponse.status) {
                            this.toggle = true;
                            this.exist = false;
                        }
                        if (this.genericResponse.status) {
                            this.toggle = false;
                            this.exist = true;
                        }
                    },
                    err => {
                        // console.info('Error occurred ', err);
                    },
                );
        }
    }

    public validateUserName(validate) {
        if (validate != null) {
            this.userNameToggle = false;
            this.userNameExist = false;
        }
        this.http.get(this.url.urls.genericCtrl.validateUser
                .replace('{userName}', this.info.userName),
            ({
                'Accept': 'application/json',
            }),
        )
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.genericResponseUsername = res;

                    if (!this.genericResponseUsername.status) {
                        this.userNameToggle = true;
                        this.userNameExist = false;
                    }
                    if (this.genericResponseUsername.status) {
                        this.userNameToggle = false;
                        this.userNameExist = true;
                    }
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    createUser() {
        this.btn.createUser = true;

        this.http.post(this.url.urls.adminCtrl.addSupportUser
                .replace('{userId}', this.session.getUserId())
            , this.info, null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.http.successToast(null, 'User successfully  added');
                    this.btn.createUser = true;
                    this.fetchUser();
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    fetchUser() {
        this.http.get(this.url.urls.adminCtrl.fetchAllSupportUser
                .replace('{userId}', this.session.getUserId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.response = res;
                    // console.info('fetchInvitedUser Done! ', this.response);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }

    test() {
        this.info.emailAddress = this.info.serviceProviderProfile.sendDebugNotificationOn;
        this.info.emailAddress = this.info.serviceProviderProfile.sendSupportNotificationOn;
        this.info.emailAddress = this.info.serviceProviderProfile.sendSystemNotificationOn;
    }
}
