import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {WebsocketService} from '../../@core/service/websocket.service';

@Component({
    selector: 'app-tender-dashboard',
    templateUrl: './tender-dashboard.component.html',
    styleUrls: ['./tender-dashboard.component.scss']
})
export class TenderDashboardComponent implements OnInit {

    public tenders1: any = [];
    public dashboardTenderBox: any = true;
    public dashboardTenderTable: any = true;
    public condi: any;
    public rx: any;
    public tenderStatus: any;

    public stackHolders: any = [];
    public converTender: any;

    public config: any = {
        pageUrl: null,
        toggle: 'buyer',
        st: null,
    };
    public fetchTenders: any = {
        lineItems: {
            buyLineItems: {
                expiredLineItems: [],
                successLineItems: [],
                activeLineItems: [],
                dryLineItems: [],
            },
            sellLineItems: {
                expiredLineItems: [],
                successLineItems: [],
                activeLineItems: [],
                dryLineItems: [],
            },
        },


    };

    public dateInfo: any = null;
    public tenderExtension: any = {
        date: new Date,
        dateString: null,
        tenderId: null,
        minDate: null,
        startDate: new Date,
    };
    public tenderBoxes: any = {
        buyTenders: {
            expiredTenders: [],
            successTenders: [],
            activeTenders: [],
            dryTenders: [],

        },
        sellTenders: {
            expiredTenders: [],
            successTenders: [],
            activeTenders: [],
            dryTenders: [],
        },
    };

    public selectedIndex: any = 5;
    public justificationString = '';
    public deleteValue = '';
    public deepScanValue = '';

    public info: any = {
        tenderId: null,
        // lineItems: [{
        lineItemId: null,
        bids: [],
        stackHolders: [],
        selectedBid: null,
        bidSelector: null,
        agentFeedback: null,
        patronFeedback: null,
        highestBidAmount: null,
        lowestBidAmount: null,
        bidSelectedOn: null,
        lineItemTitle: null,
        material: {
            materialId: null,
            materialName: null,
            hsnCode: null
        },
        deliveryAddresses: [{
            deliveryAddressId: null,
            deliveryDate: null,
            address: null,
            pinCode: null,
            city: null,
            state: null,
            country: null,
            countryCode: null,
            latitude: null,
            longitude: null
        }],
        attachments: [],
        participants: [],
        bidDecrementAmount: null,
        bidThreshold: null,
        bidIncrementAmount: null,
        fixedBidAmount: null,
        freight: null,
        quantity: null,
        quantityType: null,
        materialPaymentTermsDays: null,
        specificQuantityType: null,
        pricePerUnit: null,
        // }],
        tender: {
            tenderTitle: null,
            tenderCategory: null,
            sTenderCategory: null,
            tenderType: null,
            sTenderType: null,
            bidingType: null,
            sBidingType: null,
            timeZone: null,
            specificTimeZone: null,
            currencyType: null,
            specificCurrencyType: null,
            paymentTermsDays: null,
            preQualificationQuestionnaireStatus: false,
            preQualificationQuestionnaireDescription: null,
            advancePayment: false,
            advancePaymentDetail: null,
            description: null,
            isRfqToAuctionConverted: false,
            rfqToAuctionConvertedBy: null,
            rfqToAuctionConvertedOn: null,
            tenderStartDate: null,
            tenderExpiryDate: null,
            tenderFromDate: null,
            tenderToDate: null,
            tenderStatus: null,
            tenderStatusApplyOn: null,
            rfqToAuctionConverted: false

        }
    };
    public traveller: any = {
        selectedYear: new Date().getFullYear(),
        selectedQuarter: 1,
        getStartMonth: null,
        getEndMonth: null,
        getYear: null,
        getStartDate: '',
        getEndDate: '',
        startDate: '',
        endDate: '',
        yearsDropdown: [],
        currentYear: new Date().getFullYear(),
    };
    public stringData: any = {
        bidingType: null,
        tenderType: null,
        tenderCategory: null,
        startDateField: false
    };
    public array = ['Tender Delete', 'LineItem Delete'];
    public array1 = ['True', 'False'];

    public tenderDate: any = [
        {
            code: 1,
            string: 'Start Date',
        },
        {
            code: 2,
            string: 'End Date',
        },
        {
            code: 3,
            string: 'Both',
        },
    ];
    public companyName = 'ALL';
    public vendor = [];
    public tableSetting1: any = {
        totalRecord: 5,
        filter: '',
    };
    p1: Event;
    d: Event;

    constructor(public router: Router, public http: HttpService, public ws: WebsocketService,
                public url: UrlService, public session: SessionService, public path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
        /* if (new Date().getMonth() < 3) {
             this.traveller.selectedQuarter = 1;
         } else if (new Date().getMonth() > 2 && new Date().getMonth() < 6) {
             this.traveller.selectedQuarter = 2;
         } else if (new Date().getMonth() > 5 && new Date().getMonth() < 9) {
             this.traveller.selectedQuarter = 3;
         } else if (new Date().getMonth() > 8 && new Date().getMonth() < 12) {
             this.traveller.selectedQuarter = 4;
         }*/
    }

    ngOnInit() {
        this.calculateYears();
        if (new Date().getMonth() < 3) {
            this.traveller.selectedQuarter = 1;
        } else if (new Date().getMonth() > 2 && new Date().getMonth() < 6) {
            this.traveller.selectedQuarter = 2;
        } else if (new Date().getMonth() > 5 && new Date().getMonth() < 9) {
            this.traveller.selectedQuarter = 3;
        } else if (new Date().getMonth() > 8 && new Date().getMonth() < 12) {
            this.traveller.selectedQuarter = 4;
        }
        this.fetchAllTenders();
        this.fetchVendor();

        let myIndex1 = 0;
        carousel1();

        function carousel1() {
            let i;
            const x = document.getElementsByClassName('mySlides1');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex1++;
            if (myIndex1 > x.length) {
                myIndex1 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex1 - 1]).css('display', 'block');
            setTimeout(carousel1, 2000); // Change image every 2 seconds
        }

        let myIndex2 = 0;
        carousel2();

        function carousel2() {
            let i;
            const x = document.getElementsByClassName('mySlides2');

            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex2++;
            if (myIndex2 > x.length) {
                myIndex2 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex2 - 1]).css('display', 'block');
            setTimeout(carousel2, 2000); // Change image every 2 seconds
        }

        let myIndex3 = 0;
        carousel3();

        function carousel3() {
            let i;
            const x = document.getElementsByClassName('mySlides3');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex3++;
            if (myIndex3 > x.length) {
                myIndex3 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex3 - 1]).css('display', 'block');
            setTimeout(carousel3, 2000); // Change image every 2 seconds
        }

        let myIndex4 = 0;
        carousel4();

        function carousel4() {
            let i;
            const x = document.getElementsByClassName('mySlides4');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex4++;
            if (myIndex4 > x.length) {
                myIndex4 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex4 - 1]).css('display', 'block');
            setTimeout(carousel4, 2000); // Change image every 2 seconds
        }

        let myIndex5 = 0;
        carousel5();

        function carousel5() {
            let i;
            const x = document.getElementsByClassName('mySlides5');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex5++;
            if (myIndex5 > x.length) {
                myIndex5 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex5 - 1]).css('display', 'block');
            setTimeout(carousel5, 2000); // Change image every 2 seconds
        }

        let myIndex6 = 0;
        carousel6();

        function carousel6() {
            let i;
            const x = document.getElementsByClassName('mySlides6');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex6++;
            if (myIndex6 > x.length) {
                myIndex6 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex6 - 1]).css('display', 'block');
            setTimeout(carousel6, 2000); // Change image every 2 seconds
        }

        let myIndex7 = 0;
        carousel7();

        function carousel7() {
            let i;
            const x = document.getElementsByClassName('mySlides7');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex7++;
            if (myIndex7 > x.length) {
                myIndex7 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex7 - 1]).css('display', 'block');
            setTimeout(carousel7, 2000); // Change image every 2 seconds
        }

        let myIndex8 = 0;
        carousel8();

        function carousel8() {
            let i;
            const x = document.getElementsByClassName('mySlides8');
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex8++;
            if (myIndex8 > x.length) {
                myIndex8 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex8 - 1]).css('display', 'block');
            setTimeout(carousel8, 2000); // Change image every 2 seconds
        }
    }

    toggle() {
        if (this.config.toggle == 'seller') {
            this.config.toggle = 'buyer';
            this.setSelected(5);
        } else {
            this.config.toggle = 'seller';
            this.setSelected(1);
        }
    }

    setSelected(id: number) {
        this.selectedIndex = id;
        // console.info('this.selectedIndex: ', this.selectedIndex, id);
        if (id === 1) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.sellTenders.activeTenders);
            this.tenders1 = this.tenderBoxes.sellTenders.expiredTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 2) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.sellTenders.activeTenders);
            this.tenders1 = this.tenderBoxes.sellTenders.successTenders;
            // this.tenders1 = this.tenders1.reverse();

        }
        if (id === 3) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.sellLineItems.activeTenders);
            this.tenders1 = this.tenderBoxes.sellTenders.activeTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 4) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.sellLineItems.dryTenders);
            this.tenders1 = this.tenderBoxes.sellTenders.dryTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 5) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.buyTenders.activeTenders);
            this.tenders1 = this.tenderBoxes.buyTenders.expiredTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 6) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.buyTenders.activeTenders);
            this.tenders1 = this.tenderBoxes.buyTenders.successTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 7) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.buyTenders.activeTenders);
            this.tenders1 = this.tenderBoxes.buyTenders.activeTenders;
            // this.tenders1 = this.tenders1.reverse();
        }
        if (id === 8) {
            this.tenders1 = [];
            // console.info(this.fetchTenders.liveTenders.buyTenders.dryTenders);
            this.tenders1 = this.tenderBoxes.buyTenders.dryTenders;
            // this.tenders1 = this.tenders1.reverse();

        }

        this.dashboardTenderTable = false;
    }

    fetchAllTenders() {

        if (this.traveller.selectedQuarter == 1) {
            this.traveller.getStartMonth = 'January 1,';
            this.traveller.getEndMonth = 'March 31,';
        }
        else if (this.traveller.selectedQuarter == 2) {
            this.traveller.getStartMonth = 'April 1,';
            this.traveller.getEndMonth = 'June 30,';
        }
        else if (this.traveller.selectedQuarter == 3) {
            this.traveller.getStartMonth = 'July 1,';
            this.traveller.getEndMonth = 'September 31,';
        }
        else if (this.traveller.selectedQuarter == 4) {
            this.traveller.getStartMonth = 'October 1,';
            this.traveller.getEndMonth = 'December 31 11:59:00 PM';
        }
        this.traveller.getYear = this.traveller.selectedYear;
        this.traveller.getStartDate = this.traveller.getStartMonth + this.traveller.getYear;
        this.traveller.getEndDate = this.traveller.getEndMonth + this.traveller.getYear;
        this.traveller.startDate = Date.parse(this.traveller.getStartDate);
        this.traveller.endDate = Date.parse(this.traveller.getEndDate);

        this.http.get(this.url.urls.tenderCtrl.fetchAllTender
                .replace('{userId}', this.session.getUserId())
                .replace('{companyName}', this.companyName)
                .replace('{fromDate}', this.traveller.startDate)
                .replace('{toDate}', this.traveller.endDate)
            , null)
            .subscribe(
                res => {

                    this.fetchTenders = res;

                    this.tenderBoxes.buyTenders.expiredTenders = [];
                    this.tenderBoxes.buyTenders.successTenders = [];
                    this.tenderBoxes.buyTenders.activeTenders = [];
                    this.tenderBoxes.buyTenders.dryTenders = [];

                    this.tenderBoxes.sellTenders.expiredTenders = [];
                    this.tenderBoxes.sellTenders.successTenders = [];
                    this.tenderBoxes.sellTenders.activeTenders = [];
                    this.tenderBoxes.sellTenders.dryTenders = [];

                    this.tenderBoxes.buyTenders.expiredTenders = this.fetchTenders.lineItems.buyLineItems.expiredLineItems;
                    this.tenderBoxes.buyTenders.successTenders = this.fetchTenders.lineItems.buyLineItems.successLineItems;
                    this.tenderBoxes.buyTenders.activeTenders = this.fetchTenders.lineItems.buyLineItems.activeLineItems;
                    this.tenderBoxes.buyTenders.dryTenders = this.fetchTenders.lineItems.buyLineItems.dryLineItems;
                    this.tenderBoxes.sellTenders.expiredTenders = this.fetchTenders.lineItems.sellLineItems.expiredLineItems;
                    this.tenderBoxes.sellTenders.successTenders = this.fetchTenders.lineItems.sellLineItems.successLineItems;
                    this.tenderBoxes.sellTenders.activeTenders = this.fetchTenders.lineItems.sellLineItems.activeLineItems;
                    this.tenderBoxes.sellTenders.dryTenders = this.fetchTenders.lineItems.sellLineItems.dryLineItems;

                    /*    let CounteDown = 0;
                        this.fetchTenders.lineItems.buyLineItems.dryLineItems.forEach((value, key) => {
                            this.fetchTenders.lineItems.buyLineItems.activeLineItems.forEach((value1, key1) => {

                                if (value.tender.tenderId == value1.tender.tenderId) {
                                    console.info('comapre value ', value1.lineItemStatus, value1.tender.tenderId);
                                    if (value1.lineItemStatus == 'ACTIVE ') {
                                        this.count = 1;
                                        console.info('active ', this.count);
                                    }
                                } else if (value.tender.tenderId == value.tender.tenderId) {
                                    console.info('comapre dddd value ', value.tender.tenderId == value.tender.tenderId);

                                    if (value.lineItemStatus != 'DELETED') {
                                        this.count = CounteDown + 1;
                                        console.info('dry if ', this.count);

                                    } else {
                                        this.count = 0;
                                        console.info('dry else ', this.count);
                                    }
                                }
                            });
                        });*/


                    this.dashboardTenderBox = false;

                    this.setSelected(8);
                    this.http.sLoaderSwitch(false);
                    this.wsHello();
                },
                err => {
                    this.http.sLoaderSwitch(false);
                },
            );
    }

    convertToAuction(tenderId) {
        this.http.areYouSure('Auction', () => {
            this.http.get(this.url.urls.tenderCtrl.convertToAuction
                    .replace('{userId}', this.session.getUserId())
                    .replace('{tenderId}', tenderId)
                , null)
                .subscribe(
                    res => {
                        // this.http.successToast(null, 'Tender has been successfully converted to auction!', 1500);
                        this.http.sLoaderSwitch(false);
                        this.http.refresh();
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                        this.http.errorToast(err);
                    },
                );
        }, null);
    }

    openModal(tenderId, expiryDate, startDate) {
        // this.tenderExtension.dateString = new Date(this.tenderExtension.date).toLocaleString();
        // $('#tenderDate')[0].value = new Date(this.tenderExtension.date).toLocaleString();

        this.tenderExtension.tenderId = tenderId;
        this.tenderExtension.date = expiryDate;
        this.tenderExtension.startDate = startDate;

        if (new Date(this.tenderExtension.startDate) < new Date()) {
            this.stringData.startDateField = true;
            this.tenderExtension.minDate = startDate;
            if (this.tenderExtension.minDate < new Date()) {
                this.tenderExtension.dateString = new Date();
            }
        }
        else {
            this.tenderExtension.minDate = new Date();
            this.tenderExtension.dateString = new Date();
        }
    }

    extendTender() {
        this.http.areYouSure('Extend Tender', () => {
            this.http.get(this.url.urls.tenderCtrl.extendTender
                    .replace('{userId}', this.session.getUserId())
                    .replace('{tenderId}', this.tenderExtension.tenderId)
                    .replace('{startDate}', this.tenderExtension.startDate)
                    .replace('{expiryDate}', this.tenderExtension.date)
                , null)
                .subscribe(
                    res => {
                        // console.info('Tender Deleted ', res);
                        $('#myModal').modal('hide');
                        this.http.sLoaderSwitch(false);
                        this.http.refresh();
                        this.http.successToast(null, 'Tender Time has been successfully updated!');
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                        this.http.errorToast(err);
                    },
                );
        }, null);
    }

    fetchTender(data, idx) {

        this.info = data;

        this.info.tender.tenderExpiryDate = new Date(this.info.tender.tenderExpiryDate).toLocaleString();
        this.info.tender.tenderStartDate = new Date(this.info.tender.tenderStartDate).toLocaleString();
        this.info.deliveryAddresses[0].deliveryDate = new Date(this.info.deliveryAddresses[0].deliveryDate).toLocaleString();
        this.info.tender.tenderFromDate = new Date(this.info.tender.tenderFromDate).toLocaleString();
        this.info.tender.tenderToDate = new Date(this.info.tender.tenderToDate).toLocaleString();

        $('#viewTender').modal();

        /** bidingType */
        if (this.info.tender.bidingType == 1) {
            this.stringData.bidingType = 'RFQ';
        }
        if (this.info.tender.bidingType == 2) {
            this.stringData.bidingType = 'Auction';
        }
        if (this.info.tender.bidingType == 3) {
            this.stringData.bidingType = 'Ranked';
        }

        /** tenderType */
        if (this.info.tender.tenderType == 1) {
            this.stringData.tenderType = 'Contractual';
        }
        if (this.info.tender.tenderType == 2) {
            this.stringData.tenderType = 'Spot';
        }
        if (this.info.tender.tenderType == 3) {
            this.stringData.tenderType = 'Fixed';
        }
        /** tenderCategory */
        if (this.info.tender.tenderCategory == 1) {
            this.stringData.tenderCategory = 'Sell';
        }
        if (this.info.tender.tenderCategory == 2) {
            this.stringData.tenderCategory = 'Buy';
        }

        // /** Questionnaire */
        // if (this.info.tender.preQualificationQuestionnaireStatus) {
        //     this.info.tender.preQualificationQuestionnaireStatus = 'Yes';
        // } else {
        //     this.info.tender.preQualificationQuestionnaireStatus = 'No';
        // }
        //
        // /** Questionnaire */
        // if (this.info.tender.advancePayment) {
        //     this.info.tender.advancePayment = 'Yes';
        // } else {
        //     this.info.tender.advancePayment = 'No';
        // }

    }

    quoteTender() {
        this.router.navigateByUrl('/quote');
    }

    deleteModel(data) {
        this.tenderStatus = data.tender.tenderStatus;
        // this.condi = data.tender.totalLineItem - data.tender.totalDeletedLineItem;
        /*  if (this.condi > 1  && this.tenderStatus == 'ACTIVE') {
              this.rx = 0;
          }
          else if (this.condi > 1  && this.tenderStatus != 'ACTIVE') {
              this.rx = 2
          }
          else if (this.condi >= 1  && this.tenderStatus != 'ACTIVE') {
              this.rx = 1
          }
          else {
              this.rx = 2
          }*/
        // console.info('total ', this.condi, this.rx, this.condi > 1  && this.tenderStatus == 'ACTIVE', this.condi < 1  && this.tenderStatus != 'ACTIVE');
    }

    removeTender() {
        this.http.delete(this.url.urls.tenderCtrl.deleteTender
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
                .replace('{justification}', this.justificationString)
                .replace('{deepScan}', this.deepScanValue)
            , null)
            .subscribe(
                res => {
                    // console.info('Tender Deleted ', res);
                    $('#deleteTenderModal').modal('hide');
                    this.http.sLoaderSwitch(false);
                    this.http.refresh();
                    this.http.successToast('Tender has been successfully removed!');
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    removeTenderLineItem() {
        this.http.delete(this.url.urls.tenderCtrl.deleteTenderLinItem
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.session.getTenderId())
                .replace('{lineItemId}', this.session.getLineItemId())
                .replace('{justification}', this.justificationString)
                .replace('{deepScan}', this.deepScanValue)
            , null)
            .subscribe(
                res => {
                    // console.info('Tender Deleted ', res);
                    $('#deleteTenderModal').modal('hide');
                    this.http.sLoaderSwitch(false);
                    this.http.refresh();
                    this.http.successToast('Tender lineitem has been successfully removed!');
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    fetchVendor() {
        this.http.get(this.url.urls.tenderCtrl.fetchAllVendor
                .replace('{userId}', this.session.getUserId())
            , null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Successfully Done! ', res);
                    this.vendor = res.vendor;

                    // if (this.customVendor.customVendors.length != 0) {
                    //     this.traveller.vendorId = this.customVendor.customVendors[0].customVendorId;
                    //     this.fetch();
                    // }
                    // // console.info('fetchVendor ', this.customVendor);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                    // console.info('Error occurred ', err);
                },
            );
    }

    closeExtendTender() {
        this.dateInfo = '';
        this.tenderExtension = {
            date: new Date,
            dateString: null,
            tenderId: null,
            minDate: null,
            startDate: new Date,
        };
        this.stringData.startDateField = false;
    }

    cardSlide(slideName) {
        let myIndex1 = 0;
        carousel();

        function carousel() {
            // let i;
            // let x = document.getElementsByClassName(slideName);
            //
            // for (i = 0; i < x.length; i++) {
            //     x[i].style.display = "none";
            // }
            // slideIndex++;
            // if (slideIndex > x.length) {
            //     slideIndex = 1;
            // }
            // if (slideIndex <= x.length) {
            //     x[slideIndex - 1].style.display = "block";
            // }
            // setTimeout(carousel, 2000); // Change image every 2 seconds


            let i;
            const x = document.getElementsByClassName(slideName);
            for (i = 0; i < x.length; i++) {
                // x[i].style.display = "none";
                $(x[i]).css('display', 'none');
            }
            myIndex1++;
            if (myIndex1 > x.length) {
                myIndex1 = 1;
            }
            // x[myIndex-1].style.display = "block";
            $(x[myIndex1 - 1]).css('display', 'block');
            setTimeout(carousel, 2000); // Change image every 2 seconds
        }
    }

    calculateYears() {

        let scCreatedDate = new Date(1483209000000);
        let createdYear = scCreatedDate.getFullYear();

        for (let j = createdYear; j <= this.traveller.currentYear; j++) {
            this.traveller.yearsDropdown.push(j);
        }

        return this.traveller.yearsDropdown;
    }

    wsHello() {
        this.ws.disconnect();
        this.ws.connect(this.ready);
    }

    ready = () => {
        this.tenderBoxes.buyTenders.activeTenders.forEach((value, key) => {
            if (value.lineItemStatus === 'ACTIVE' && !value.tender.rfqToAuctionConverted) {
                this.ws.subscribe('/tunnel/v1/rfqToAuctionConvertStatus/{tenderId}'
                        .replace('{tenderId}', value.tender.tenderId)
                    , {}, (frame) => {
                        this.tenderBoxes.buyTenders.activeTenders[key].tender.rfqToAuctionConverted = this.ws.getBody(frame).rfqToAuctionConvertStatus;
                        this.tenders1[key].tender.rfqToAuctionConverted = this.tenderBoxes.buyTenders.activeTenders[key].tender.rfqToAuctionConverted;
                    });
            }
        });

        this.tenderBoxes.sellTenders.activeTenders.forEach((value, key) => {
            if (value.lineItemStatus === 'ACTIVE' && !value.tender.rfqToAuctionConverted) {
                this.ws.subscribe('/tunnel/v1/rfqToAuctionConvertStatus/{tenderId}'
                        .replace('{tenderId}', value.tender.tenderId)
                    , {}, (frame) => {
                        this.tenderBoxes.sellTenders.activeTenders[key].tender.rfqToAuctionConverted = this.ws.getBody(frame).rfqToAuctionConvertStatus;
                        this.tenders1[key].tender.rfqToAuctionConverted = this.tenderBoxes.sellTenders.activeTenders[key].tender.rfqToAuctionConverted;
                    });
            }
        });

        // Refers Dashboard
        /*this.tenderBoxes.sellTenders.dryTenders.forEach((value, key) => {
            // if (value.lineItemStatus === 'ASSIGNED') {
                this.ws.subscribe('/tunnel/v1/refreshAdminDashboard/tender/{tenderId}'
                        .replace('{tenderId}', value.tender.tenderId)
                    , {}, (frame) => {
                    this.http.refresh();
                    });
            // }
        });

        this.tenderBoxes.buyTenders.dryTenders.forEach((value, key) => {
            // if (value.lineItemStatus === 'ASSIGNED') {
                this.ws.subscribe('/tunnel/v1/refreshAdminDashboard/tender/{tenderId}'
                        .replace('{tenderId}', value.tender.tenderId)
                    , {}, (frame) => {
                        this.http.refresh();
                        // this.setSelected(5);
                    });
            // }
        });
*/
        this.ws.subscribe('/tunnel/v1/refreshAdminDashboard/tender'
            , {}, (frame) => {
                this.http.refresh();
            });


    };

    resendTenderInvitationBefore(tenderId, lineItemId, tender) {
        this.info.tenderId = tenderId;
        this.stackHolders = tender.stackHolders;
        this.converTender = tender.tender.rfqToAuctionConverted;

        $('#tenderInvitation').modal();
    }

    resendTenderInvitationToAll() {
        this.http.get(this.url.urls.tenderCtrl.allTenderInvitation
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.info.tenderId)
            , null)
            .subscribe(
                res => {
                    this.http.successToast(null, 'Tender invitation has been successfully sent!');
                    this.http.sLoaderSwitch(false);
                    $('#tenderInvitation').modal('hide');
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }

    resendTenderInvitationToOne(customVendorId) {
        this.http.get(this.url.urls.tenderCtrl.oneTenderInvitation
                .replace('{userId}', this.session.getUserId())
                .replace('{tenderId}', this.info.tenderId)
                .replace('{customVendorId}', customVendorId)
            , null)
            .subscribe(
                res => {
                    this.http.successToast(null, 'Tender invitation has been successfully sent!');
                    this.http.sLoaderSwitch(false);
                    $('#tenderInvitation').modal('hide');
                    this.http.refresh();
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }
}
