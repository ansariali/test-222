import {ModuleWithProviders, NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {TenderDashboardComponent} from './tender-dashboard.component';

const routes: Routes = [
    {
        path: '',
        component: TenderDashboardComponent,
    }];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class TenderDashboardRouting {
}

export const routing = RouterModule.forChild(routes);
