import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TenderDashboardComponent } from './tender-dashboard.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgbModule, NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {PipeModule} from '../../@core/pipe/pipe.module';
import {TenderDashboardRouting} from './tender-dashboard.routing';
import {CommonComponentModule} from '../../@core/components/commonComponent.module';
import {Ng2SearchPipeModule} from 'ng2-search-filter/src/ng2-filter.module';

@NgModule({
    imports: [
        CommonModule,
        // RouterModule.forChild(MarketRoutes),
        TenderDashboardRouting,
        FormsModule,
        NgbTooltipModule,
        Ng2PaginationModule,
        Ng2OrderModule,
        Ng2SearchPipeModule,
        DirectiveModule,
        PipeModule,
        CommonComponentModule,
        NgbModule,
        ReactiveFormsModule,
  ],
  declarations: [
      TenderDashboardComponent
  ]
})
export class TenderDashboardModule { }
