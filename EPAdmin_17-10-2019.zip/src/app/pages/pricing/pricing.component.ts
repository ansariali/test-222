import {Component, OnInit} from '@angular/core';
import {UrlService} from '../../@core/service/url.service';
import {HttpService} from '../../@core/service/http.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
    selector: 'app-pricing',
    templateUrl: './pricing.component.html',
    styleUrls: ['./pricing.component.scss']
})
export class PricingComponent implements OnInit {
    public selected_id: any;

    public config: any = {
        pageUrl: null,
    };
    public tableSetting: any = {
        totalRecord: 10,
        filter: '',
    };
    p: Event;

    public tableSetting1: any = {
        totalRecord: 10,
        filter: '',
    };
    p1: Event;
    public response: any = {
        pricingTiers: []
    };

    public toggle: any = null;

    public toggle2: any = null;

    public user: any = {
        scType: 'SC',
        tspType: 'TSP',
    };

    public active: any = true;

    public response2: any = {
        pricingTiers: []
    };

    // public request: any = {
    //     active: false,
    //     bidLimit: null,
    //     branchLimit: null,
    //     dedicatedClientSupport: false,
    //     description: null,
    //     emailNotificationSupport: false,
    //     pricePerMonth: null,
    //     pricePerYear: null,
    //     pricingTierFor: null,
    //     pricingTierTag: null,
    //     pricingTierType: null,
    //     rateAndReview: false,
    //     smsNotificationSupport: false,
    //     tenderLimit: null,
    //     trialAvailable: false,
    //     trialDays: null,
    //     userAccountLimit: null,
    //     qualificationQuestionnaireSupport: null,
    //     tenderRfqLimit: null,
    //     tenderAuctionLimit: null,
    //     tenderRfqToAuctionConvertLimit: null,
    //     buyerSupport: null,
    //     sellerSupport: null,
    //     bidTopUpSupport: null,
    //     tenderTopUpSupport: null,
    //     customizedReportSupport: null,
    //     downloadReportSupport: null,
    // };
    public request: any = {
        active: true,
        bidLimit: null,
        bidTopUpSupport: true,
        buyerSupport: true,
        downloadReportSupport: true,
        customizedReportSupport: true,
        dedicatedClientSupport: true,
        description: null,
        emailNotificationSupport: true,
        pricePerMonth: null,
        pricePerYear: null,
        pricingTierTag: null,
        pricingTierType: null,
        qualificationQuestionnaireSupport: true,
        sellerSupport: true,
        smsNotificationSupport: true,
        tenderAuctionLimit: null,
        tenderLimit: null,
        tenderRfqLimit: null,
        tenderRfqToAuctionConvertLimit: null,
        tenderTopUpSupport: true,
        trialAvailable: true,
        trialDays: null,
        userAccountLimit: null,
        batchId: null,
        customVendorLimit: null,
        clusterLimit: null,
        maximumAttachment: null,
        materialLimit: null,
        maximumLineItem: null,
    };

    public activeObj: any;

    public obj: any = {
        id: null,
        status: null,
    };

    // loading = false;
    // returnUrl: string;

    constructor(private http: HttpService, private url: UrlService, private session: SessionService,
                private path: PathService, private router: Router, private route: ActivatedRoute) {
        this.config.pageUrl = this.path.pageUrl;
    }

    ngOnInit() {
        // console.info('test');
        // console.info('test 1 ', this.router.url);

        this.fetchAllPricing();
        // this.returnUrl = this.router.routerState.snapshot.url;

    }

    fetchAllPricing() {

        this.http.get(this.url.urls.adminCtrl.fetchPricingByUser.replace('{userId}', this.session.getUserId())
                .replace('{userType}', this.session.getUserRole()),
            null)
            .subscribe(
                res => {
                    this.response = res;
                    // console.info('response', this.response);

                    this.response.pricingTiers.forEach(value => {
                        if (value.smsNotificationSupport) {
                            value.smsNotificationSupport = 'Yes';
                        } else {
                            value.smsNotificationSupport = 'No';
                        }

                        if (value.emailNotificationSupport) {
                            value.emailNotificationSupport = 'Yes';
                        } else {
                            value.emailNotificationSupport = 'No';
                        }

                        if (value.dedicatedClientSupport) {
                            value.dedicatedClientSupport = 'Yes';
                        } else {
                            value.dedicatedClientSupport = 'No';
                        }

                    })
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );


        this.http.get(this.url.urls.adminCtrl.fetchPricingByUser.replace('{userId}', this.session.getUserId())
                .replace('{userType}', this.user.tspType),
            null)
            .subscribe(
                res => {
                    this.response2 = res;
                    // console.info('response2', this.response2);
                    this.response2.pricingTiers.forEach(value => {
                        if (value.smsNotificationSupport) {
                            value.smsNotificationSupport = 'Yes';
                        } else {
                            value.smsNotificationSupport = 'No';
                        }

                        if (value.emailNotificationSupport) {
                            value.emailNotificationSupport = 'Yes';
                        } else {
                            value.emailNotificationSupport = 'No';
                        }

                        if (value.dedicatedClientSupport) {
                            value.dedicatedClientSupport = 'Yes';
                        } else {
                            value.dedicatedClientSupport = 'No';
                        }

                    })
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchPricingByTier(eazeProcurePricingTierId) {
        this.request = {};
        console.info('pricingTierType', eazeProcurePricingTierId);
        this.http.get(this.url.urls.adminCtrl.fetchPricingByTierId
                .replace('{userId}', this.session.getUserId())
                .replace('{pricingTierId}', eazeProcurePricingTierId),
            null)
            .subscribe(
                res => {
                    this.request = res;
                    // const tmpData = res;
                    // this.request = tmpData.pricingTiers[0];
                    console.info('response', this.request);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    create() {
        console.info('this.request: ', this.request);
        console.log('this.request: ' + JSON.stringify(this.request));
        this.http.post(this.url.urls.adminCtrl.createPricing
                .replace('{userId}', this.session.getUserId()),
            this.request, null)
            .subscribe(
                res => {
                    // this.response = res;
                    // console.info('response', this.response);
                    this.http.successToast(null, 'Pricing Tier successfully created.');
                    this.toggle = null;
                    this.request = {};
                    location.reload();
                },
                err => {
                    console.info('Error occurred ', err);
                    // this.http.errorToast(err);
                },
            );
    }

    update() {
        this.http.put(this.url.urls.adminCtrl.updatePricing.replace('{userId}', this.session.getUserId())
                .replace('{pricingTierId}', this.request.pricingTierId),
            this.request, null)
            .subscribe(
                res => {
                    this.request = res;
                    // console.info('response', this.request);
                    this.http.successToast(null, 'Pricing Tier successfully updated.');
                    this.toggle = null;
                    this.request = {};
                    location.reload();
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    back() {
        this.request = {};
    }

    activeDeActiveTier(id, status) {
        console.log(' this.obj.status', status);
        console.log(' this.obj.id', id);
        this.http.put(this.url.urls.adminCtrl.pricingTierDeactive.replace('{userId}', this.session.getUserId())
            .replace('{pricingTierId}', this.obj.id)
            .replace('{status}', this.obj.status), null, null)
            .subscribe(
                res => {
                    this.activeObj = res;
                    console.info('response', this.activeObj);
                    if (this.activeObj.status) {
                        this.http.successToast(null, this.activeObj.message);
                    }
                    this.fetchAllPricing();
                    // this.router.navigate([this.returnUrl]);

                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    openModel(idx) {
        this.obj.id = this.response.pricingTiers[idx].pricingTierId;
        this.obj.status = this.response.pricingTiers[idx].active;
    }

    refresh() {
        this.http.refresh();
    }


    /* public testing() {
         console.info('this.router1 : ', this.router.routerState._root);
         console.info('this.route  : ', this.router.routerState.snapshot.url);
         console.info('this.router3 : ', this.returnUrl);
         console.info('this.router3 : ', this.route);
         // this.router.navigate(this.fragment, { replace: true, force: true })
         this.router.navigate([this.returnUrl]);

     }*/

}
