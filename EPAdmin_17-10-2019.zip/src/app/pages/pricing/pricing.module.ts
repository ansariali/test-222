import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {routing} from './pricing.routing';
import {PricingComponent} from './pricing.component';
import {FormsModule} from '@angular/forms';
import {TooltipModule} from 'ng2-tooltip';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2PaginationModule} from 'ng2-pagination';
import {ServiceModule} from '../../@core/service/service.module';
import {NgaModule} from '../../theme/nga.module';

@NgModule({
    imports: [
        CommonModule,
        routing,
        FormsModule,
        TooltipModule,
        NgaModule,
        Ng2SearchPipeModule,
        DirectiveModule,
        Ng2OrderModule,
        Ng2PaginationModule,
        ServiceModule,
    ],
    declarations: [PricingComponent]
})
export class PricingModule {
}
