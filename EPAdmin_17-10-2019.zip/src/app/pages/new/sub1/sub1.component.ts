import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-sub1',
  templateUrl: './sub1.component.html',
  styleUrls: ['./sub1.component.scss']
})
export class Sub1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
