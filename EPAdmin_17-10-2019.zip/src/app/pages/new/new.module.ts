import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NewComponent} from './new.component';
import {routing} from './new.routing';
import {Sub1Component} from './sub1/sub1.component';

@NgModule({
  imports: [CommonModule, routing], declarations: [NewComponent, Sub1Component]
})
export class NewModule {
}
