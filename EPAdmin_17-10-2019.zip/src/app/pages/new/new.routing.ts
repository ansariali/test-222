import {Routes, RouterModule} from '@angular/router';

import {NewComponent} from './new.component';
import {Sub1Component} from './sub1/sub1.component';

const routes: Routes = [{
  path: '', component: NewComponent, children: [{path: 'sub1', component: Sub1Component}]
}];

export const routing = RouterModule.forChild(routes);
