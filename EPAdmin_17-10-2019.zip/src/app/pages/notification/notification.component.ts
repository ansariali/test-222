import {Component, OnInit, HostListener} from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from 'app/@core/service/http.service';
import {UrlService} from 'app/@core/service/url.service';
import {SessionService} from 'app/@core/service/session.service';
import {PathService} from 'app/@core/service/path.service';

@Component({
    selector: 'app-notification',
    templateUrl: './notification.component.html',
    styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {

    public pageSize = 10;
    public pageNumber = 1;
    public pageNumbers;
    public pageSizes;
    public size = false;
    public counter: number = 1;

    public allNotification: any = {
        notifications: [],
    };

    constructor(private router: Router,
                private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
    }


    ngOnInit() {
        this.fetchNotification(this.pageNumber, this.pageSize);
    }

    moreNotification() {
        this.pageSize += 10;
        this.counter += 1;
        this.fetchNotification(this.counter, this.pageSize);
    }

    fetchNotification(pageNumber, pageSize) {
        this.pageNumbers = 1;
        this.pageSizes = pageSize;

        this.http.get(this.url.urls.adminCtrl.fetchNotificationByCount
                .replace('{userId}', this.session.getUserId())
                .replace('{pageSize}', this.pageSizes)
                .replace('{pageNumber}', this.pageNumbers),
            null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.allNotification = res;

                    if (this.allNotification.notifications.length != this.pageSizes) {
                        this.size = true;
                    }

                    if (this.allNotification.notifications == null) {
                        this.allNotification.notifications = [];
                    }
                },
                err => {
                    this.http.sLoaderSwitch(false);
                },
            );
    }

    redirectPage (notificationId) {
        localStorage.setItem('notificationId', notificationId);
    }
}
