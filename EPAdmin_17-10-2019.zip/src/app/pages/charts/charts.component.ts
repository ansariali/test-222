import {Component} from '@angular/core';

@Component({
  selector: 'maps',
  template: `<router-outlet></router-outlet>`
})
export class Charts {

  constructor() {
  }

  ngOnInit() {
  }

}
