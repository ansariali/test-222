import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';

declare var $: any;

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html',
})

export class ForgotPasswordComponent implements OnInit {
    public config: any = {
        pageUrl: null,
    };

    public locals: any = {
        confirmPassword: null
    };

    public btn: any = {
        oneClicked: false,
        secondClicked: false
    };

    public traveller: any = {
        toggle: true,
        forgotPasswordInfo: {
            emailAddress: null,
            securityCode: null,
            newPassword: '',
            confirmPassword: ''
        },
        genericResponse: {
            message: null,
            status: null
        }
    };

    public toggle: any = true;
    public forgotPasswordInfo: any = {
        emailAddress: null,
        securityCode: null,
        newPassword: '',
        confirmPassword: ''
    };
    public genericResponse: any = {
        message: null,
        status: null
    };

    public response: any = {
        message: null,
        status: null
    };


    constructor(private router: Router, private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;

        if (this.session.getCustomSession('ForgotPassStep2')) {
            this.toggle = false;
            this.forgotPasswordInfo.emailAddress = this.session.getCustomSession('ForgotPassEmail');
        }
    }

    ngOnInit() {
        $('.form-control').each(function () {

            $(this).focus(function () {
                $(this).parent().addClass('focused');
            });

            $(this).focusout(function () {
                $(this).parent().removeClass('focused');
            });

            function emptyListener($this) {
                requestAnimationFrame(function () {
                    emptyListener($this);
                });

                if ($this.val() === '' || $this.val() === null) {
                    $this.parent().removeClass('is-completed');
                    $this.parent().removeClass('is-active');
                } else {
                    $this.parent().addClass('is-active is-completed');
                }
            }

            emptyListener($(this));
        });
    }

    verifyEmailId() {
        this.btn.oneClicked = true;

        this.http.get(this.url.urls.userCtrl.forgotPasswordRequest.toString()
            .replace('{emailAddress}', this.forgotPasswordInfo.emailAddress), {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
            .subscribe(
                res => {
                    // console.info('response: ', res);
                    this.btn.oneClicked = false;
                    this.genericResponse = res;
                    if (this.genericResponse.status === true) {
                        this.toggle = !this.toggle;
                        $('#step1').modal();
                    } else {
                        this.toggle = true;
                        // this.router.navigateByUrl(this.config.pageUrl.forgotPassword.default);
                        this.http.customErrorToast(this.genericResponse.subject);
                    }
                },
                err => {
                    this.btn.oneClicked = false;
                    this.http.errorToast(err);
                }
            );
    }

    stepTwo() {
        $('#step1').modal('hide');
        $('#step2').modal();
    }

    resetPassword() {
        this.btn.secondClicked = true;
        this.http.get(this.url.urls.userCtrl.resetPassword.toString()
                .replace('{otpCode}', this.forgotPasswordInfo.securityCode),
            {
                'AUTHORIZATION': btoa(this.forgotPasswordInfo.emailAddress + ':' + this.locals.confirmPassword),
                'Accept': 'application/json'
            })
            .subscribe(
                res => {
                    // console.info('response: ', res);
                    this.btn.secondClicked = false;
                    this.response = res;

                    // console.info(this.response);

                    if (this.response.status) {
                        this.session.removeCustomSession('ForgotPassEmail');
                        this.session.removeCustomSession('ForgotPassStep2');
                        this.session.removeCustomSession('forgotToken');

                        this.http.successToast(null, 'Password has been successfully changed');
                        this.router.navigateByUrl(this.config.pageUrl.login.default);
                    } else {
                        this.router.navigateByUrl(this.config.pageUrl.forgotPassword.default);
                    }
                },
                err => {
                    this.btn.secondClicked = false;
                    this.http.errorToast(err);
                }
            );
    }

    backBtn() {
        this.session.removeCustomSession('ForgotPassEmail');
        this.session.removeCustomSession('ForgotPassStep2');
        this.session.removeCustomSession('forgotToken');
    }

}


