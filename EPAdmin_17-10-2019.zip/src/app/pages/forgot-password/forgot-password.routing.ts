import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {ForgotPasswordComponent} from './forgot-password.component';

// noinspection TypeScriptValidateTypes
export const routes: Routes = [
    {
        path: '',
        component: ForgotPasswordComponent,
    },
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
