import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AppTranslationModule} from '../../app.translation.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgaModule} from '../../theme/nga.module';

import {ServiceModule} from '../../@core/service/service.module';
import {ForgotPasswordComponent} from './forgot-password.component';
import {routing} from './forgot-password.routing';
import {DirectiveModule} from '../../@core/directives/directive.module';


@NgModule({
    imports: [
        CommonModule,
        AppTranslationModule,
        ReactiveFormsModule,
        FormsModule,
        NgaModule,
        routing,
        ServiceModule,
        DirectiveModule
    ],
    declarations: [
        ForgotPasswordComponent,
    ],
})
export class ForgotPasswordModule {
}
