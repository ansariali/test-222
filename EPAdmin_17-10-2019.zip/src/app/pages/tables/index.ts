export * from './tables.component';
