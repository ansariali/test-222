import {Component} from '@angular/core';

@Component({
  selector: 'contextual-table',
  templateUrl: './contextualTable.html',
})
export class ContextualTable {

  constructor() {
  }
}
