export const PAGES_MENU = [
    {
        path: '',
        children: [
            {
                path: 'dashboard',
                data: {
                    menu: {
                        title: 'Dashboard',
                        icon: 'ion-android-home',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'pricing',
                data: {
                    menu: {
                        title: 'Pricing Tiers',
                        icon: 'fa fa-calculator',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            /* {
                           path: 'chat',
                           data: {
                               menu: {
                                   title: 'Chat Admin',
                                   icon: 'fa fa-comments-o',
                                   selected: false,
                                   expanded: false,
                                   order: 0
                               }
                           }
                       },*/
            {
                path: 'test',
                data: {
                    menu: {
                        title: 'Setting Board',
                        icon: 'fa fa-cog',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'support-user',
                data: {
                    menu: {
                        title: 'Support Users',
                        icon: 'fa fa-user-md',
                        selected: false,
                        expanded: false,
                        order: 350
                    }
                },
            },
            {
                path: 'support',
                data: {
                    menu: {
                        title: 'Support',
                        icon: 'ion-help-circled',
                        selected: false,
                        expanded: false,
                        order: 400
                    }
                },
            },

        ]
    }
];
