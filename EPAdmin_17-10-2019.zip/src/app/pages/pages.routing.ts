import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';

import {AdminLayoutComponent} from '../@core/layouts/admin/admin-layout.component';
import {AuthLayoutComponent} from '../@core/layouts/auth/auth-layout.component';
import {NotificationComponent} from './notification/notification.component';

// noinspection TypeScriptValidateTypes

// export function loadChildren(path) { return System.import(path); };

export const routes: Routes = [
    {
        path: '',
        loadChildren: () => import('app/pages/login/login.module').then(m => m.LoginModule),
    },
    {
        path: 'login',
        loadChildren: () => import('app/pages/login/login.module').then(m => m.LoginModule),
    },
    {
        path: '',
        component: AdminLayoutComponent,
        children: [
            {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
            {path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)},
            {path: 'pricing', loadChildren: () => import('./pricing/pricing.module').then(m => m.PricingModule)},
            {path: 'test', loadChildren: () => import('./test/test.module').then(m => m.TestModule)},
            {path: 'support', loadChildren: () => import('./support/support.module').then(m => m.SupportModule)},
            {path: 'support-user', loadChildren: () => import('./support-user/support-user.module').then(m => m.SupportUserModule)},
            {
                path: 'profile',
                loadChildren: () => import('./profile/user.module').then(m => m.UserModule),
            },
            {
                path: 'invitation',
                loadChildren: () => import('./invite/invite.module').then(m => m.InviteModule),
            },
            {
                path: 'tenderDashboard',
                loadChildren: () => import('./tender-dashboard/tender-dashboard.module').then(m => m.TenderDashboardModule),
            },
            {
                path: 'quote',
                loadChildren: () => import('./quote/quote.module').then(m => m.QuoteModule),
            },
            // {path: 'bid', redirectTo: 'bid/select/2', pathMatch: 'full'},
            // {path: 'bid/select', redirectTo: 'bid/select/2', pathMatch: 'full'},
            {path: 'bid', loadChildren: () => import('./bid/bid.module').then(m => m.BidModule)},
            {path: 'notification', component: NotificationComponent},
            {path: 'register', loadChildren: () => import('./register/register.module').then(m => m.RegisterModule)},
            {path: 'download', loadChildren: () => import('./report/download-report.module').then(m => m.DownloadReportModule)},
        ],
    },
    {
        path: '',
        component: AuthLayoutComponent,
        children: [
            {path: '', redirectTo: 'login', pathMatch: 'full'},
            {path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule)},
            // {path: 'register', loadChildren: './register/register.module#RegisterModule'},
        ],
    },
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
