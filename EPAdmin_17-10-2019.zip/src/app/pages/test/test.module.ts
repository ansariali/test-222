import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {TestComponent} from './test.component';
import {routing} from './test.routing';
import {FormsModule} from '@angular/forms';
import {NgaModule} from '../../theme/nga.module';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {ServiceModule} from '../../@core/service/service.module';


@NgModule({
    imports: [
        CommonModule,
        routing,
        FormsModule,
        NgaModule,
        DirectiveModule,
        ServiceModule,
    ],
    declarations: [
        TestComponent
    ]
})
export class TestModule {
}
