import {Component, OnInit} from '@angular/core';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
    selector: 'app-test',
    templateUrl: './test.component.html',
    styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {
    // EazeProcure Data
    public request: any = {
        batchId: null,
        vendorSerialNumber: null,
        createdOn: null,
        changedOn: null,
        userAccountSerialNumber: null,
        materialSerialNumber: null,
        clusterSerialNumber: null,
        customVendorSerialNumber: null,
        tenderSerialNumber: null,
        tenderLineItemSerialNumber: null,
        bidSerialNumber: null,
        appointmentRunning: null,
        appointmentIntervalTime: null,
        // autoCreateOwner: true,
        autoCreateHsnCode: false,
        autoCreateRunningBatch: false,
        autoStartAppointment: true,
        autoCreateBasicPlan: true,
        active: true,
    };
    // LogBids Data Response
    /*public request: any = {
        batch: null,
        shipperSerialNumber: null,
        transporterSerialNumber: null,
        userAccountSerialNumber: null,
        planSerialNumber: null,
        branchSerialNumber: null,
        tenderSerialNumber: null,
        domesticTenderSerialNumber: null,
        internationalTenderSerialNumber: null,
        bidSerialNumber: null,
        domesticBidSerialNumber: null,
        internationalBidSerialNumber: null,
        isAppointmentRunning: false,
        appointmentIntervalTime: null,
        autoAddLogBidsOwner: false,
        autoCreateMaterialType: false,
        autoCreateTruckType: false,
        autoMappingTruckTypesWithMaterial: false,
        autoCreateShipperPlan: false,
        autoCreateTransporterPlan: false,
        autoCreateRunningBatch: false,
        autoStartAppointmentService: false,
        createdOn: null,
        changedOn: null,
    };*/

    public secretKey = null;

    constructor(private http: HttpService, private url: UrlService, private  session: SessionService,
                private path: PathService, private router: Router, private route: ActivatedRoute) {
    }

    ngOnInit() {
    }

    resetPlanInfo() {
        this.http.get(this.url.urls.adminCtrl.resetPlanInfo
                .replace('{userId}', this.session.getUserId())
                .replace('{secretKey}', this.secretKey),
            null)
            .subscribe(
                res => {
                    this.http.successToast(null, 'Information successfully reset');
                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }

}
