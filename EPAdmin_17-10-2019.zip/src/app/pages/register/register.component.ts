import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';

@Component({
    selector: 'register',
    templateUrl: './register.html',
    styleUrls: ['./register.scss']
})
export class RegisterComponent implements OnInit {
    public status: any = false;

    public info = {
        'companyName': null,
        'companyRegistrationNumber': null,
        'contactNumber': null,
        'emailAddress': null,
        'emailNotificationOn': false,
        'emailNotificationSendOn': null,
        'gstNumber': null,
        'panCardNumber': null,
        'natureOfBusiness': null,
        'specificNatureOfBusiness': null,
    };

    public userAccount = {
        'emailAddress': null,
        'firstName': null,
        'lastName': null,
        'password': null,
        'userName': null
    };

    public locals: any = {
        confirmPassword: null,
        btnClicked: false,
        inviteBtnClicked: false
    };
    public response: any;
    public id: any = null;
    public genericResponse: any;
    public genericResponseUsername: any;
    public toggle: boolean = false;
    public exist: boolean = false;
    public userNameExist: boolean = false;
    public userNameToggle: boolean = false;

    constructor(private router: Router, private http: HttpService, private url: UrlService,
                private session: SessionService) {
    }

    ngOnInit() {
        this.fetch();
    }

    public register() {
        this.locals.btnClicked = true;

        /* this.userAccount.emailAddress = this.info.emailAddress;
         let data = {
             userAccount: this.userAccount,
             vendor: this.info
         };*/
        this.http.post(this.url.urls.epCtrl.signUp
            .replace('{userId}', this.session.getUserId())
            .replace('{notificationId}', this.id), null, null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.response = res;
                    if (this.response.status) {
                        this.http.successToast(null, 'Your account has been successfully created!');
                        // this.router.navigateByUrl('auth/login');
                        localStorage.removeItem('notificationId');
                        this.id = null;
                    }
                },
                err => {
                    this.locals.btnClicked = false;
                    this.http.errorToast(err);
                },
            );
    }

    fetch() {
        this.id = localStorage.getItem('notificationId');

        this.http.get(this.url.urls.adminCtrl.fetchNotificationById
                .replace('{userId}', this.session.getUserId())
                .replace('{notificationId}', this.id),
            null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.status = res.userRegistrationStatus;
                    this.response = JSON.parse(res.userRegistrationDetails);
                    this.info = this.response.vendor;
                    this.userAccount = this.response.userAccount;
                },
                err => {
                    this.http.sLoaderSwitch(false);
                },
            );
    }

    public validateOnlyEmail(validate) {
        if (validate != null) {
            this.toggle = false;
            this.exist = false;
        }

        if (validate == null) {
            this.http.get(this.url.urls.genericCtrl.validateOnlyEmail.replace('{emailAddress}', this.info.emailAddress),
                ({
                    'Accept': 'application/json',
                }),
            )
                .subscribe(
                    res => {
                        console.info('Successfully Done! ', res);
                        this.genericResponse = res;
                        if (!this.genericResponse.status) {
                            this.toggle = true;
                            this.exist = false;
                        }
                        if (this.genericResponse.status) {
                            this.toggle = false;
                            this.exist = true;
                        }
                    },
                    err => {
                        // console.info('Error occurred ', err);
                    },
                );
        }
    }

    public validateUserName(validate) {
        if (validate != null) {
            this.userNameToggle = false;
            this.userNameExist = false;
        }
        this.http.get(this.url.urls.genericCtrl.validateUser.replace('{userName}', this.userAccount.userName),
            ({
                'Accept': 'application/json',
            }),
        )
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.genericResponseUsername = res;

                    if (!this.genericResponseUsername.status) {
                        this.userNameToggle = true;
                        this.userNameExist = false;
                    }
                    if (this.genericResponseUsername.status) {
                        this.userNameToggle = false;
                        this.userNameExist = true;
                    }
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }
}
