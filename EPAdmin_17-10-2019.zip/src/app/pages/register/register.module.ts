import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {NgaModule} from '../../theme/nga.module';

import {RegisterComponent} from './register.component';
import {routing} from './register.routing';
import {ServiceModule} from '../../@core/service/service.module';
import {DirectiveModule} from '../../@core/directives/directive.module';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        NgaModule,
        routing,
        ServiceModule,
        DirectiveModule
    ],
    declarations: [
        RegisterComponent
    ]
})
export class RegisterModule {
}
