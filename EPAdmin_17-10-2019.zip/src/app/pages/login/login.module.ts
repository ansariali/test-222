import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AppTranslationModule} from '../../app.translation.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgaModule} from '../../theme/nga.module';

import {LoginComponent} from './login.component';
import {routing} from './login.routing';
import {ServiceModule} from '../../@core/service/service.module';
import {DirectiveModule} from '../../@core/directives/directive.module';


@NgModule({
    imports: [
        CommonModule,
        AppTranslationModule,
        ReactiveFormsModule,
        FormsModule,
        NgaModule,
        routing,
        ServiceModule,
        DirectiveModule
    ],
    declarations: [
        LoginComponent,
    ],
})
export class LoginModule {
}
