import {Component, OnInit} from '@angular/core';

import {Router} from '@angular/router';
import {HttpService} from '../../@core/service/http.service';
import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';

declare var $: any;

@Component({
    selector: 'login',
    templateUrl: './login.html',
    styleUrls: ['./login.scss'],
})
export class LoginComponent implements OnInit {
    public config: any = {
        pageUrl: null,
    };

    public info: any = {
        userName: null,
        password: null,
        // userName: 'lynkersoft.admin',
        // password: 123321,
    };
    public response: any;
    public genericResponse: any;
    public toggle: boolean = true;
    public clicked: boolean = false;

    constructor(private router: Router, private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
    }

    ngOnInit() {
    }

    public login() {
        this.clicked = true;
        this.http.post(this.url.urls.epCtrl.signIn, null, ({
            'AUTHORIZATION': btoa(this.info.userName + ':' + this.info.password),
            'Accept': 'application/json',
        }))
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.response = res;
                    // console.info('this.response! ', this.response);
                    this.session.createSession(true, res);
                    this.http.successToast('Welcome ' + this.response.supportUser.firstName + ' ' + this.response.supportUser.lastName, ' ');


                    /*if (this.response.officialVendor.userRole != 'OWNER') {
                        // console.info('this.response! 1 ', this.response.officialVendor.userRole);
                        window.open('http://www.eazeprocure.com/1125489/#/login', '_blank');
                    } else {
                        // console.info('this.response! 2 ', this.response.officialVendor.userRole);
                        this.session.createSession(true, res);

                        // if (this.session.isFirstVisit()) {
                        this.http.successToast('Welcome ' + this.response.officialVendor.firstName + ' ' + this.response.officialVendor.lastName, ' ');
                        // } else {
                        //     this.http.successToast('Welcome back ' + this.response.officialVendor.firstName + ' ' + this.response.officialVendor.lastName, ' ');
                        // }
                    }*/
                },
                err => {
                    this.clicked = false;
                    this.http.errorToast(err);
                },
            );
    }

    public validateUserName() {
        this.http.get(this.url.urls.genericCtrl.validateUser.replace('{userName}', this.info.userName),
            ({
                'Accept': 'application/json',
            }),
        )
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.genericResponse = res;
                    if (this.genericResponse.status) {
                        this.toggle = true;
                    }
                    if (!this.genericResponse.status) {
                        this.toggle = false;
                    }
                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

    clear() {
        // this.session.clearSession();

        window.sessionStorage.setItem('pagal', '123321');
        console.info('pagal: ', localStorage.getItem('pagal'));
    }

    test() {
        // console.info('session.isSignIn: ', this.session.isSignIn());
        console.info('pagal: ', window.sessionStorage.getItem('pagal'));
        // this.http.errorToast();

    }
}
