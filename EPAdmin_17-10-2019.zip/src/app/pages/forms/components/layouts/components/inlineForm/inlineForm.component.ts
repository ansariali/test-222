import {Component} from '@angular/core';

@Component({
  selector: 'inline-form',
  styleUrls: ['./inlineForm.scss'],
  templateUrl: './inlineForm.html',
})
export class InlineForm {

  constructor() {
  }

  isRemember: boolean = false;
}
