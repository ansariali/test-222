import {Component} from '@angular/core';

@Component({
  selector: 'standard-inputs',
  templateUrl: './standardInputs.html',
})
export class StandardInputs {

  constructor() {
  }
}
