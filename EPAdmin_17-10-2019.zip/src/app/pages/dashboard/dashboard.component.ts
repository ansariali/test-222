import {Component, OnInit} from '@angular/core';

import {UrlService} from '../../@core/service/url.service';
import {SessionService} from '../../@core/service/session.service';
import {PathService} from '../../@core/service/path.service';
import {HttpService} from '../../@core/service/http.service';
import {Router} from '@angular/router';

declare var $: any;

@Component({
    selector: 'dashboard',
    styleUrls: ['./dashboard.scss'],
    templateUrl: './dashboard.html',
})
export class DashboardComponent implements OnInit {
    public config: any = {
        pageUrl: null,
        toggle: 'buyer',
        st: null,
    };
    public tableSetting: any = {
        totalRecord: 5,
        filter: '',
    };
    p: Event;
    public vendorToggle: any = true;
    public response: any = {
        userAccounts: [],
    };
    public vendorResponse: any = {
        vendor: {
            emailAddress: null,
            companyName: null,
            panCardNumber: null,
            contactNumber: null,
            companyRegistrationNumber: null,
            gstNumber: null,
            'annualRevenue': 0,
            'address1': null,
            'city': null,
            'country': null,
            'countryCode': null,
            'latitude': 0,
            'longitude': 0,
            'pinCode': null,
            'state': null,
        },
        userAccount: [],
        plans: [],
        runningPlan: {}
    };

    public userType: any;

    public branchToggle: any;
    public userBranches: any = [];
    public users: any = {};
    public tableSetting1: any = {
        totalRecord: 5,
        filter: '',
    };
    p1: Event;

    public tableSetting5: any = {
        totalRecord: 5,
        filter: '',
    };
    p5: Event;

    public pricingResponse: any = {
        pricingTiers: [],
    };
    public particularUserResponse: any = {};
    public pricingTierToken: any;

    /** PinCode */
    public componentData: any = '';
    public userSettings: any = {
        geoCountryRestriction: ['in'],
        showCurrentLocation: false,
        showSearchButton: false,
        recentStorageName: 'componentData',
        noOfRecentSearchSave: 8,
    };

    public planSetting: any = {
        isPurchased: false,
        isAutoExtend: false,
        totalMonth: '',
        assign: {
            totalAmount: null,
            currencyType: null,
            paymentType: null,
            paymentStatus: null,
            whyDropped: null,
        }
    };

    public cType = ['NONE', 'INR', 'EURO', 'USD', 'GBP', 'AUD', 'HKD', 'Swiss Franc', 'yen'];
    public pStatus = ['NONE', 'PENDING', 'PAID', 'FREE'];
    public pType = ['CASH', 'CHEQUE', ' NET_BANKING', 'DEBIT_CARD', 'CREDIT_CARD', 'BHIM_UPI'];

    constructor(private router: Router, private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
    }

    autoCompleteCallback1(data: any): any {
        this.vendorResponse.vendor.pinCode = null;
        this.vendorResponse.vendor.city = null;
        this.vendorResponse.vendor.state = null;
        this.vendorResponse.vendor.country = null;
        this.vendorResponse.vendor.region = null;
        this.vendorResponse.vendor.longitude = 0;
        this.vendorResponse.vendor.latitude = 0;

        this.componentData = JSON.stringify(data);
        this.vendorResponse.vendor.pinCode = data.address_components[0].long_name;
        this.vendorResponse.vendor.city = data.address_components[1].long_name;
        this.vendorResponse.vendor.state = data.address_components[3].long_name;
        this.vendorResponse.vendor.country = data.address_components[4].long_name;
        this.vendorResponse.vendor.region = data.address_components[4].short_name + '-' + data.address_components[3].short_name;
        this.vendorResponse.vendor.longitude = data.geometry.location.lng;
        this.vendorResponse.vendor.latitude = data.geometry.location.lat;
    }

    ngOnInit() {
        this.fetchUserByRole();
    }

    fetchUserByRole() {
        this.http.get(this.url.urls.adminCtrl.fetchUserByRole
            .replace('{userId}', this.session.getUserId())
            .replace('{userRole}', 'PROMOTER'), null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.response = res;
                    // console.info('this.cvGenericResponse: ', this.response);
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    userSwitch(targetedUserId, status, firstName, lastName) {
        this.http.get(this.url.urls.adminCtrl.userSwitch
                .replace('{userId}', this.session.getUserId())
                .replace('{targetedUserId}', targetedUserId)
                .replace('{status}', status),
            null)
            .subscribe(
                res => {
                    if (status) {
                        this.http.successToast(null, '' + firstName + ' ' + lastName + ' is successfully activated!');
                        this.fetchUserByRole();
                    } else {
                        this.http.successToast(null, '' + firstName + ' ' + lastName + ' is successfully deactivated!');
                        this.fetchUserByRole();
                    }
                },
                err => {
                    this.http.errorToast(err);
                    console.info('Error occurred ', err);
                },
            );
    }

    sendEmail(targetedUserId) {
        this.http.get(this.url.urls.adminCtrl.sendEmail
                .replace('{userId}', this.session.getUserId())
                .replace('{targetedUserId}', targetedUserId),
            null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.http.successToast(null, 'Email is successfully sent!');
                    // console.info('this.cvGenericResponse: ', this.response);
                },
                err => {
                    this.http.errorToast(err);
                    console.info('Error occurred ', err);
                },
            );
    }

    fetchVendor(vendorId, index) {
        this.vendorToggle = !this.vendorToggle;
        this.http.get(this.url.urls.adminCtrl.fetchVendor
                .replace('{userId}', this.session.getUserId())
                .replace('{vendorId}', vendorId),
            null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.vendorResponse = res;
                    if (this.vendorResponse.vendor.pinCode != undefined) {
                        $('#search_places')[0].value = this.vendorResponse.vendor.pinCode;
                    } else {
                        $('#search_places')[0].value = null;
                    }

                    this.fetchPricingOfVendor();
                },
                err => {
                    // console.info('Error occurred ', err);
                    this.http.errorToast(err);
                },
            );
    }

    fetchPricingOfVendor() {
        this.http.get(this.url.urls.adminCtrl.fetchPricingByUser
                .replace('{userId}', this.session.getUserId())
                .replace('{userType}', this.userType),
            null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.pricingResponse = res;
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    updateEmail() {
        this.http.customErrorToast('awaiting for service');
    }

    updateVendor(serviceId) {
        this.http.put(this.url.urls.adminCtrl.updateVendor
                .replace('{userId}', this.session.getUserId())
                .replace('{vendorId}', this.vendorResponse.vendor.vendorId)
                .replace('{serviceId}', serviceId)
            , this.vendorResponse.vendor, null)
            .subscribe(
                res => {
                    // this.request = res;
                    // console.info('response', this.request);
                    this.http.successToast(null, '<b>' + this.vendorResponse.vendor.companyName + '</b>' + ' Company details successfully updated.');
                    // this.http.refresh();
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    assignPlan() {
        this.http.post(this.url.urls.adminCtrl.assignPlan
                .replace('{userId}', this.session.getUserId())
                .replace('{pricingTierToken}', this.pricingTierToken)
                .replace('{vendorId}', this.vendorResponse.vendor.vendorId)
                .replace('{purchased}', false),
            this.planSetting.assign, null)
            .subscribe(
                res => {
                    // this.request = res;
                    // console.info('response', this.request);
                    this.http.successToast(null, 'Plan has been successfully assigned.');
                    this.http.refresh();
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    newAssignPlan() {
        this.http.post(this.url.urls.adminCtrl.newAssignPlan
                .replace('{userId}', this.session.getUserId())
                .replace('{pricingTierToken}', this.pricingTierToken)
                .replace('{vendorId}', this.vendorResponse.vendor.vendorId)
                .replace('{purchased}', this.planSetting.isPurchased)
                .replace('{totalMonth}', this.planSetting.totalMonth)
                .replace('{autoExtendable}', this.planSetting.isAutoExtend),
            this.planSetting.assign, null)
            .subscribe(
                res => {
                    // this.request = res;
                    // console.info('response', this.request);
                    this.http.successToast(null, 'Plan has been successfully assigned.');
                    this.http.refresh();
                },
                err => {
                    console.info('Error occurred ', err);
                },
            );
    }

    updateUserEmail() {
        this.http.put(this.url.urls.adminCtrl.updateEmail
                .replace('{userId}', this.session.getUserId())
                .replace('{targetedUserId}', this.particularUserResponse.userAccountId)
                .replace('{emailAddress}', this.vendorResponse.vendor.emailAddress),
            null, null)
            .subscribe(
                res => {
                    this.http.successToast(null, 'Email Address successfully updated.');
                },
                err => {
                    console.info('Error occurred ', err);
                    this.http.errorToast(err);
                },
            );
    }

    viewUser(idx) {
        this.particularUserResponse = this.vendorResponse.userAccount[idx];
        // console.info('this.particularUserResponse: ', this.particularUserResponse);
    }

    updateUser(serviceId) {
        this.http.put(this.url.urls.adminCtrl.updateUser
                .replace('{userId}', this.session.getUserId())
                .replace('{serviceId}', serviceId),
            null, null)
            .subscribe(
                res => {
                    // console.info('Successfully Done! ', res);
                    this.http.successToast(null, '<b>' + this.particularUserResponse.firstName + ' ' + this.particularUserResponse.lastName + '</b>' + 'User has been successfully updated!');
                    this.particularUserResponse = res;
                },
                err => {
                    console.info('Error occurred ', err);
                    this.http.errorToast(err);
                },
            );
    }

    enabledDisabledUser(data) {
        this.http.get(this.url.urls.adminCtrl.enableDisabledUser
                .replace('{userId}', this.session.getUserId())
                .replace('{vendorId}', this.vendorResponse.vendor.vendorId)
                .replace('{vendorUserId}', data.userAccountId)
                .replace('{enableAndDisableStatus}', data.userEnabled),
            null)
            .subscribe(
                res => {
                    if (status) {
                        this.http.successToast(null, '' + data.firstName + ' ' + data.lastName + ' is successfully activated!');
                        // this.fetchUserByRole();
                    } else {
                        this.http.successToast(null, '' + data.firstName + ' ' + data.lastName + ' is successfully deactivated!');
                        // this.fetchUserByRole();
                    }

                },
                err => {
                    this.http.errorToast(err);
                },
            );
    }
}