import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {AppTranslationModule} from '../../app.translation.module';
import {NgaModule} from '../../theme/nga.module';

import {DashboardComponent} from './dashboard.component';
import {routing} from './dashboard.routing';

import {TooltipModule} from 'ng2-tooltip';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2PaginationModule} from 'ng2-pagination';
import {Ng2OrderModule} from 'ng2-order-pipe';
import {DirectiveModule} from '../../@core/directives/directive.module';
import {ServiceModule} from '../../@core/service/service.module';
import {ChartsModule} from 'ng2-charts';
import {NgbTooltipModule} from '@ng-bootstrap/ng-bootstrap';
import {Ng4GeoautocompleteModule} from 'ng4-geoautocomplete';
// import {UrlService} from '../../@core/service/url.service';
// import {HttpService} from '../../@core/service/http.service';
// import {SessionService} from '../../@core/service/session.service';
// import {PathService} from '../../@core/service/path.service';


/*import { PopularApp } from './popularApp';
import { PieChart } from './pieChart';
import { TrafficChart } from './trafficChart';
import { UsersMap } from './usersMap';
import { LineChart } from './lineChart';
import { Feed } from './feed';
import { Todo } from './todo';
import { Calendar } from './calendar';
import { CalendarService } from './calendar/calendar.service';
import { FeedService } from './feed/feed.service';
import { LineChartService } from './lineChart/lineChart.service';
import { PieChartService } from './pieChart/pieChart.service';
import { TodoService } from './todo/todo.service';
import { TrafficChartService } from './trafficChart/trafficChart.service';
import { UsersMapService } from './usersMap/usersMap.service';*/

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        AppTranslationModule,
        NgaModule,
        routing,

        TooltipModule,
        Ng2PaginationModule,
        Ng2SearchPipeModule,
        Ng2OrderModule,
        DirectiveModule,
        ServiceModule,
        ChartsModule,
        NgbTooltipModule,
        Ng4GeoautocompleteModule.forRoot(),
    ],
    declarations: [
        // PopularApp,
        // PieChart,
        // TrafficChart,
        // UsersMap,
        // LineChart,
        // Feed,
        // Todo,
        // Calendar,
        DashboardComponent,

    ],
    providers: [
        // CalendarService,
        // FeedService,
        // LineChartService,
        // PieChartService,
        // TodoService,
        // TrafficChartService,
        // UsersMapService,
        // HttpService,
        // UrlService,
        // SessionService,
        // PathService,
    ]
})
export class DashboardModule {
}
