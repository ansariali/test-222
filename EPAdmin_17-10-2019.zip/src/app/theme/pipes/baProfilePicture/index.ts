export * from './baProfilePicture.pipe';
