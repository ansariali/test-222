import {Component} from '@angular/core';

import {GlobalState} from '../../../global.state';
import {PathService} from '../../../@core/service/path.service';
import {HttpService} from '../../../@core/service/http.service';

@Component({
    selector: 'ba-content-top',
    styleUrls: ['./baContentTop.scss'],
    templateUrl: './baContentTop.html',
})
// tslint:disable
export class BaContentTop {
    public config: any = {
        pageUrl: null,
    };

    public activePageTitle: string = '';

    constructor(private _state: GlobalState, private path: PathService, public http: HttpService,) {
        // console.info('_state: ', _state);
        this._state.subscribe('menu.activeLink', (activeLink) => {
            if (activeLink) {
                this.activePageTitle = activeLink.title;
            }
        });
        this.config.pageUrl = this.path.pageUrl;
    }
}
