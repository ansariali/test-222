import {Component} from '@angular/core';

import {GlobalState} from '../../../global.state';
import {Router} from '@angular/router';
import {HttpService} from 'app/@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {SessionService} from 'app/@core/service/session.service';
import {PathService} from '../../../@core/service/path.service';

@Component({
    selector: 'ba-page-top',
    templateUrl: './baPageTop.html',
    styleUrls: ['./baPageTop.scss']
})
//tslint:disable
export class BaPageTop {
    public isScrolled: boolean = false;
    public isMenuCollapsed: boolean = false;
    private response: any;
    private test: any;

    public config: any = {
        pageUrl: null,
    };

    constructor(private _state: GlobalState,
                private router: Router,
                private http: HttpService,
                private url: UrlService,
                private session: SessionService,
                private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
        this.test = this.sLoaderSwitch();
        this._state.subscribe('menu.isCollapsed', (isCollapsed) => {
            this.isMenuCollapsed = isCollapsed;
        });
    }

    public toggleMenu() {
        this.isMenuCollapsed = !this.isMenuCollapsed;
        this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);
        return false;
    }

    public scrolledChanged(isScrolled) {
        // this.isScrolled = isScrolled;
    }

    sLoaderSwitch() {

        // console.info('1.1: ', this.http.config.smallLoader);
        return this.http.config.smallLoader;

        // return this.session.getCustomSession('sLoaderSwitch');
    }

    logout() {
        this.http.get(this.url.urls.epCtrl.signOut,
            {
                'ACCESS-TOKEN': this.session.getAccessId(),
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.response = res;
                    console.info('Successfully Done! ', this.response);

                    if (this.response.status) {
                        this.session.clearSession();
                        this.router.navigateByUrl('auth/login');
                    } else {
                        // console.info('signOut else me gaya');
                    }
                },
                err => {
                    // console.info('signOut else me gaya', err);
                    this.http.sLoaderSwitch(false);
                    this.http.errorToast(err);
                },
            );
    }
}
