import {Component} from '@angular/core';

import {BaMsgCenterService} from './baMsgCenter.service';
import {SessionService} from '../../../@core/service/session.service';
import {HttpService} from '../../../@core/service/http.service';
import {UrlService} from '../../../@core/service/url.service';
import {PathService} from '../../../@core/service/path.service';
import {Router} from '@angular/router';

@Component({
    selector: 'ba-msg-center',
    providers: [BaMsgCenterService],
    styleUrls: ['./baMsgCenter.scss'],
    templateUrl: './baMsgCenter.html'
})
// tslint:disable
export class BaMsgCenter {
    public config: any = {
        pageUrl: null,
    };

    public notifications: Array<Object>;
    public messages: Array<Object>;

    public firstName: string;
    public lastName: string;

    private response: any;
    private notificationCount: any = 0;
    public allNotification: any = {
        notifications: [],
    };

    constructor(private _baMsgCenterService: BaMsgCenterService, private router: Router,
                private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;
        this.notifications = this._baMsgCenterService.getNotifications();
        this.messages = this._baMsgCenterService.getMessages();

        this.firstName = this.session.getFirstName();
        this.lastName = this.session.getLastName();

        this.fetchNotification();
    }

    getFirstName() {
        return this.session.getFirstName();
    }

    getLastName() {
        return this.session.getLastName();
    }

    fetchNotification() {
        this.http.get(this.url.urls.adminCtrl.fetchNotification.
        replace('{userId}', this.session.getUserId()),
            null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.allNotification = res;

                    this.allNotification.notifications.forEach(value => {
                        if (value.seen === false) {
                            this.notificationCount = this.notificationCount + 1;
                        }
                    });
                    if (this.allNotification.notifications == null) {
                        this.allNotification.notifications = [];
                    }
                    // console.info('allNotification! ', this.allNotification);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // console.info('Error occurred ', err);
                },
            );
    }

    removeNotification(notificationId, index) {
        this.http.delete(this.url.urls.vendorNotificationCtrl.delete.replace('{userId}', this.session.getUserId())
            .replace('{notificationId}', notificationId), null)
            .subscribe(
                res => {
                    this.http.sLoaderSwitch(false);
                    this.allNotification.notifications.splice(index, 1);
                },
                err => {
                    this.http.sLoaderSwitch(false);
                    // // console.info('Error occurred ', err);
                },
            );
    }

    redirectPage() {
        this.router.navigateByUrl('/notification');
        this.seenNotification();

      /*  if (agentSite == true) {
            this.router.navigateByUrl(this.config.pageUrl.slashUrl.bid.select);

            this.http.get(this.url.urls.vendorNotificationCtrl.seen.replace('{vendorId}', this.session.getVendorId())
                    .replace('{userId}', this.session.getUserId())
                    .replace('{notificationId}', notificationId),
                null)
                .subscribe(
                    res => {
                        this.http.sLoaderSwitch(false);
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                    },
                );
        }

        if (agentSite == false) {
            this.router.navigateByUrl(this.config.pageUrl.slashUrl.bid.view);

            this.http.get(this.url.urls.vendorNotificationCtrl.seen.replace('{vendorId}', this.session.getVendorId())
                    .replace('{userId}', this.session.getUserId())
                    .replace('{notificationId}', notificationId),
                null)
                .subscribe(
                    res => {
                        this.http.sLoaderSwitch(false);
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                    },
                );
        }*/
    }
    seenNotification() {
        this.http.put(this.url.urls.adminCtrl.seenNotification
            .replace('{userId}', this.session.getUserId()), null, null)
            .subscribe(
                res => {
                    this.response = res;
                    console.info('notificaiton: ', this.response);
                    this.notificationCount = 0;
                    this.router.navigateByUrl('/notification');

                },
                err => {
                    // console.info('Error occurred ', err);
                },
            );
    }

}
