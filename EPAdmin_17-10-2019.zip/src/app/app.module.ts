import {NgModule, ApplicationRef} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {HttpClientModule} from '@angular/common/http';
import {NavigationEnd, NavigationStart, Router, RouterModule} from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import 'rxjs/add/operator/delay';
import {Event as NavigationEvent} from '@angular/router';

/*
 * Platform and Environment providers/directives/pipes
 */
import {routing} from './app.routing';

// App is our top level component
import {AppComponent} from './app.component';
import {AppState, InternalStateType} from './app.service';
import {GlobalState} from './global.state';
import {NgaModule} from './theme/nga.module';
import {PagesModule} from './pages/pages.module';
import {ServiceModule} from './@core/service/service.module';
import {HttpService} from './@core/service/http.service';
import {UrlService} from './@core/service/url.service';
import {SessionService} from './@core/service/session.service';
import {PathService} from './@core/service/path.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {defaultThrottleConfig} from 'rxjs/operator/throttle';


// Application wide providers
const APP_PROVIDERS = [
    AppState,
    GlobalState,
];

/*export type StoreType = {
  state: InternalStateType,
  restoreInputValues: () => void,
  disposeOldHosts: () => void,
};*/

/**
 * `AppModule` is the main entry point into Angular2's bootstraping process
 */
@NgModule({
    bootstrap: [AppComponent],
    declarations: [
        AppComponent,
    ],
    imports: [ // import Angular's modules
        BrowserModule,
        BrowserAnimationsModule,
        HttpModule,
        HttpClientModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        NgaModule.forRoot(),
        NgbModule.forRoot(),
        PagesModule,
        routing,
        ServiceModule,
    ],
    providers: [ // expose our Services and Providers into Angular's dependency injection
        APP_PROVIDERS
    ],
})

export class AppModule {
    // constructor(public appState: AppState) {}
    // tslint:disable

    protected config: any = {
        pageUrl: null
    };
    protected response: any;

    constructor(public appState: AppState, private router: Router, private http: HttpService, private url: UrlService,
                private session: SessionService, private path: PathService) {
        this.config.pageUrl = this.path.pageUrl;

        /* router.events.forEach((event) => {
             // if (!( event instanceof NavigationStart )) {
             //     return;
             // }
             // console.info('this.session.isSignIn(): ', this.session.isSignIn());
             if (event instanceof NavigationEnd) {
                 // if (location.hash.split('/')[1] != this.config.pageUrl.guest.splitOne) {
                 // if (!this.session.isSignIn()) {
                 if (this.session.getAccessId() != null) {
                     /!** Cross-verify HERE [ T&C ] *!/
                     this.http.get(this.url.urls.epCtrl.crossAuthentication, {
                         'ACCESS-TOKEN': this.session.getAccessId(),
                         'Accept': 'application/json'
                     }).subscribe(
                         res => {
                             this.http.sLoaderSwitch(false);
                             // console.info('Successfully Authentication Done! ', res);
                             // console.info('Successfully Authentication Done! ');
                             this.response = res;
                             if (res.sessionStatus) {
                                 // Todo: required data here
                                 // this.session.createSession(true, res);
                             } else {
                                 this.session.clearSession();
                             }
                             // this.session.createSession(true, res);
                         },
                         err => {
                             this.http.sLoaderSwitch(false);
                             if (err.status != 0) {
                                 this.session.clearSession();
                             }
                             // this.router.navigateByUrl(this.config.pageUrl.login.default);
                         },
                     );
                 }
                 else {
                     localStorage.clear();
                 }
                 // }
                 // }

                 if (this.session.isSignIn()) {
                     if (location.hash == this.config.pageUrl.hashSlash
                         || location.hash == this.config.pageUrl.login.hashUrl
                         // || location.hash == this.config.pageUrl.register.hashUrl
                         || location.hash == this.config.pageUrl.forgotPassword.hashUrl
                         || location.hash.split('/')[1] == this.config.pageUrl.guest.splitOne
                     ) {
                         console.info('Session Available');
                         router.navigateByUrl(this.config.pageUrl.dashboard.default);
                     }
                 }

                 if (!this.session.isSignIn()) {
                     if (location.hash != this.config.pageUrl.hashSlash
                         && location.hash != this.config.pageUrl.login.hashUrl
                         // && location.hash != this.config.pageUrl.register.hashUrl
                         && location.hash != this.config.pageUrl.forgotPassword.hashUrl
                         && location.hash.split('/')[1] != this.config.pageUrl.guest.splitOne
                     ) {
                         console.info('No Session');
                         location.replace(this.config.pageUrl.login.hashUrl);
                     }
                 }


             }

         });*/

        router.events.delay(0).subscribe((event: NavigationEvent) => {

            if (!(event instanceof NavigationStart)) {
                return;
            }

            if (this.session.getAccessId() != null) {
                /** Cross-verify HERE [ T&C ] */
                this.http.get(this.url.urls.epCtrl.crossAuthentication, {
                    'ACCESS-TOKEN': this.session.getAccessId(),
                    'Accept': 'application/json'
                }).subscribe(
                    res => {
                        this.http.sLoaderSwitch(false);
                        this.response = res;
                        if (res.sessionStatus) {
                            // Todo: required data here
                            // this.session.createSession(true, res);
                        } else {
                            this.session.clearSession();
                        }
                        // this.session.createSession(true, res);
                    },
                    err => {
                        this.http.sLoaderSwitch(false);
                        if (err.status != 0) {
                            this.session.clearSession();
                        }
                        // this.router.navigateByUrl(this.config.pageUrl.login.default);
                    },
                );
            }
            else {
                localStorage.clear();
            }

            if (this.session.isSignIn()) {
                if (location.hash == this.config.pageUrl.hashSlash
                    || location.hash == this.config.pageUrl.login.hashUrl
                    // || location.hash == this.config.pageUrl.register.hashUrl
                    || location.hash == this.config.pageUrl.forgotPassword.hashUrl
                    || location.hash.split('/')[1] == this.config.pageUrl.guest.splitOne
                ) {
                    // console.info('Session Available');
                    router.navigateByUrl('dashboard');
                }
            }

            if (!this.session.isSignIn()) {
                if (location.hash != this.config.pageUrl.hashSlash
                    && location.hash != this.config.pageUrl.login.hashUrl
                    // && location.hash != this.config.pageUrl.register.hashUrl
                    && location.hash != this.config.pageUrl.forgotPassword.hashUrl
                    && location.hash.split('/')[1] != this.config.pageUrl.guest.splitOne
                ) {
                    // console.info('No Session');
                    location.replace(this.config.pageUrl.login.hashUrl);
                }
            }
        });

    }
}
